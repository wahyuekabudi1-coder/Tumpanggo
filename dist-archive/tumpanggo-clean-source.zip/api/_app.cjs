var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/types.ts
function calculateTieredServiceFee(subtotal) {
  const amount = Math.max(0, Math.round(Number(subtotal) || 0));
  if (amount <= 0) return 0;
  if (amount <= 3e4) return 1200;
  if (amount <= 1e5) return 2e3;
  if (amount <= 2e5) return 3e3;
  if (amount <= 3e5) return 4e3;
  if (amount <= 5e5) return 5e3;
  if (amount <= 7e5) return 5e3;
  return 1e4;
}
var init_types = __esm({
  "src/types.ts"() {
  }
});

// src/server/config.ts
function loadEnvExplicit(filePath) {
  if (!import_fs.default.existsSync(filePath)) return;
  try {
    const raw = import_fs.default.readFileSync(filePath, "utf-8");
    const lines = raw.split(/\r?\n/);
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const eqIdx = trimmed.indexOf("=");
      if (eqIdx <= 0) continue;
      const key = trimmed.slice(0, eqIdx).trim();
      let val = trimmed.slice(eqIdx + 1).trim();
      if (val.startsWith('"') && val.endsWith('"') || val.startsWith("'") && val.endsWith("'")) {
        val = val.slice(1, -1);
      }
      process.env[key] = val;
    }
  } catch {
  }
}
function cleanEnvSecret(val, fallback = "") {
  if (!val) return fallback;
  let clean = val.trim();
  if (clean.startsWith('"') && clean.endsWith('"') || clean.startsWith("'") && clean.endsWith("'")) {
    clean = clean.slice(1, -1).trim();
  }
  return clean || fallback;
}
function resolveServerPort() {
  for (let i = 0; i < process.argv.length; i++) {
    if ((process.argv[i] === "--port" || process.argv[i] === "-p") && process.argv[i + 1]) {
      const parsed = parseInt(process.argv[i + 1], 10);
      if (!isNaN(parsed) && parsed > 0) return parsed;
    }
  }
  if (process.env.FOOD_PORT) {
    const parsed = parseInt(process.env.FOOD_PORT, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  if (process.env.PORT) {
    const parsed = parseInt(process.env.PORT, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  return 3e3;
}
function validateProductionEnvironment() {
  const errors = [];
  const secret = process.env.FOOD_AUTH_SECRET;
  if (!secret || secret.trim().length < 32) {
    errors.push("FOOD_AUTH_SECRET wajib disetel dan memiliki minimal 32 karakter.");
  } else if (secret.includes("dev_secret_fallback") || secret.includes("fallback_do_not_use")) {
    errors.push("FOOD_AUTH_SECRET tidak boleh menggunakan string fallback/development pada mode produksi.");
  }
  const adminEmail = process.env.FOOD_ADMIN_EMAIL;
  if (!adminEmail || !adminEmail.includes("@")) {
    errors.push("FOOD_ADMIN_EMAIL wajib disetel dengan alamat email yang sah.");
  }
  const adminPassword = process.env.FOOD_ADMIN_PASSWORD;
  if (!adminPassword || adminPassword.trim().length < 8) {
    errors.push("FOOD_ADMIN_PASSWORD wajib disetel dengan minimal 8 karakter.");
  } else if (adminPassword === "TumpangGoAdmin#2026") {
    errors.push('FOOD_ADMIN_PASSWORD tidak boleh menggunakan kata sandi default/contoh ("TumpangGoAdmin#2026") pada mode produksi.');
  }
  let projectId = process.env.FIREBASE_PROJECT_ID || process.env.GCP_PROJECT;
  if (!projectId) {
    try {
      const configPath = import_path.default.join(process.cwd(), "firebase-applet-config.json");
      if (import_fs.default.existsSync(configPath)) {
        const raw = JSON.parse(import_fs.default.readFileSync(configPath, "utf-8"));
        projectId = raw.projectId;
      }
    } catch {
    }
  }
  if (!projectId || projectId.trim().length === 0) {
    errors.push("FIREBASE_PROJECT_ID wajib disetel pada lingkungan produksi.");
  }
  const serviceAccount = process.env.FIREBASE_SERVICE_ACCOUNT_KEY || process.env.GOOGLE_SERVICE_ACCOUNT_KEY || process.env.GOOGLE_APPLICATION_CREDENTIALS;
  if (!serviceAccount || serviceAccount.trim().length === 0) {
    errors.push("FIREBASE_SERVICE_ACCOUNT_KEY wajib disetel untuk otentikasi Firebase Admin SDK pada lingkungan produksi.");
  } else {
    const raw = serviceAccount.trim();
    let parsed = null;
    try {
      let cleanRaw = raw;
      if (cleanRaw.startsWith("'") && cleanRaw.endsWith("'") || cleanRaw.startsWith('"') && cleanRaw.endsWith('"')) {
        cleanRaw = cleanRaw.slice(1, -1);
      }
      if (cleanRaw.startsWith("{")) {
        parsed = JSON.parse(cleanRaw);
      } else if (process.env.GOOGLE_APPLICATION_CREDENTIALS && import_fs.default.existsSync(raw)) {
        parsed = JSON.parse(import_fs.default.readFileSync(raw, "utf-8"));
      } else {
        const decoded = Buffer.from(cleanRaw, "base64").toString("utf-8");
        if (decoded.trim().startsWith("{")) {
          parsed = JSON.parse(decoded);
        }
      }
    } catch {
    }
    if (!parsed || typeof parsed !== "object") {
      errors.push("FIREBASE_SERVICE_ACCOUNT_KEY tidak berformat JSON atau Base64 yang valid.");
    } else if (!parsed.client_email || !parsed.private_key) {
      errors.push('FIREBASE_SERVICE_ACCOUNT_KEY wajib memiliki field "client_email" dan "private_key".');
    }
  }
  const portVal = resolveServerPort();
  if (isNaN(portVal) || portVal < 1 || portVal > 65535) {
    errors.push("PORT atau FOOD_PORT harus berupa angka port TCP yang valid (1-65535).");
  }
  return {
    isValid: errors.length === 0,
    errors
  };
}
function getMasterAccountCredentials() {
  const email = (process.env.MASTER_ADMIN_EMAIL || runtimeMasterAdminEmail || "tumpanggo@gmail.com").trim().toLowerCase();
  const envPass = process.env.MASTER_ADMIN_PASSWORD || process.env.FOOD_ADMIN_PASSWORD;
  const hasExplicitEnv = Boolean(envPass && envPass.length > 0);
  const password = cleanEnvSecret(envPass || runtimeMasterAdminPassword, isProductionRuntime ? "" : "TumpangGoAdmin#2026");
  const source = hasExplicitEnv ? process.env.MASTER_ADMIN_PASSWORD ? "PROCESS_ENV_MASTER_ADMIN_PASSWORD" : "PROCESS_ENV_FOOD_ADMIN_PASSWORD" : runtimeMasterAdminPassword ? "RUNTIME_ROTATED_SECRET" : "DATABASE_PERSISTED_HASH";
  return {
    email,
    password,
    hasExplicitEnv,
    byteLength: Buffer.byteLength(password, "utf-8"),
    source
  };
}
function isMasterAdminEmail(email) {
  if (!email) return false;
  const clean = email.trim().toLowerCase();
  return clean === foodConfig.masterAccount.email || clean === "tumpanggo@gmail.com" || clean === "tumpanggo" || clean === "suaiimokeras@gmail.com" || clean === "suaiimokeras";
}
function updateRuntimeMasterPassword(newPassword) {
  runtimeMasterAdminPassword = newPassword.trim();
  process.env.MASTER_ADMIN_PASSWORD = newPassword.trim();
}
function reloadEnv() {
  import_dotenv.default.config();
  loadEnvExplicit(import_path.default.resolve(process.cwd(), ".env"));
  const localEnvPath2 = import_path.default.resolve(process.cwd(), ".env.local");
  if (import_fs.default.existsSync(localEnvPath2)) {
    import_dotenv.default.config({ path: localEnvPath2, override: true });
    loadEnvExplicit(localEnvPath2);
  }
}
var import_fs, import_path, import_dotenv, localEnvPath, isProductionRuntime, runtimeJwtSecret, isServerless, localDbFile, runtimeAdminPassword, runtimeAdminEmail, runtimeMasterAdminEmail, runtimeMasterAdminPassword, foodConfig, artopayConfig, DEFAULT_VAPID_PUBLIC_KEY, DEFAULT_VAPID_PRIVATE_KEY, vapidConfig;
var init_config = __esm({
  "src/server/config.ts"() {
    import_fs = __toESM(require("fs"), 1);
    import_path = __toESM(require("path"), 1);
    import_dotenv = __toESM(require("dotenv"), 1);
    import_dotenv.default.config();
    loadEnvExplicit(import_path.default.resolve(process.cwd(), ".env"));
    localEnvPath = import_path.default.resolve(process.cwd(), ".env.local");
    if (import_fs.default.existsSync(localEnvPath)) {
      import_dotenv.default.config({ path: localEnvPath, override: true });
      loadEnvExplicit(localEnvPath);
    }
    isProductionRuntime = process.env.NODE_ENV === "production" && !process.env.VERCEL_DEV;
    runtimeJwtSecret = (process.env.FOOD_AUTH_SECRET || "").trim();
    if (!runtimeJwtSecret || runtimeJwtSecret.length < 32) {
      runtimeJwtSecret = isProductionRuntime ? "" : "dev_secret_fallback_do_not_use_in_prod_min_32_characters_long";
    }
    isServerless = Boolean(process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME);
    localDbFile = isServerless ? import_path.default.join("/tmp", "tumpang_food_db.json") : import_path.default.join(process.cwd(), "tumpang_food_db.json");
    runtimeAdminPassword = cleanEnvSecret(process.env.FOOD_ADMIN_PASSWORD, isProductionRuntime ? "" : "TumpangGoAdmin#2026");
    runtimeAdminEmail = (process.env.FOOD_ADMIN_EMAIL || "tumpanggo@gmail.com").trim().toLowerCase();
    runtimeMasterAdminEmail = (process.env.MASTER_ADMIN_EMAIL || "tumpanggo@gmail.com").trim().toLowerCase();
    runtimeMasterAdminPassword = cleanEnvSecret(process.env.MASTER_ADMIN_PASSWORD || process.env.FOOD_ADMIN_PASSWORD, isProductionRuntime ? "" : "TumpangGoAdmin#2026");
    if (process.env.NODE_ENV === "production") {
      const check = validateProductionEnvironment();
      if (!check.isValid) {
        console.warn(`[TumpangFood Security] Peringatan konfigurasi produksi:
- ${check.errors.join("\n- ")}`);
      }
    }
    foodConfig = {
      isProduction: process.env.NODE_ENV === "production",
      // Server port
      port: resolveServerPort(),
      host: "0.0.0.0",
      isServerless,
      // Database settings
      databaseId: (() => {
        const rawEnv = (process.env.FOOD_DATABASE_ID || "").trim();
        if (rawEnv && rawEnv !== "ai-studio-tumpangfood-99caef89-a69c-4fe1-80be-2c79f3dcb85c") {
          return rawEnv;
        }
        try {
          const configPath = import_path.default.join(process.cwd(), "firebase-applet-config.json");
          if (import_fs.default.existsSync(configPath)) {
            const rawConfig = JSON.parse(import_fs.default.readFileSync(configPath, "utf-8"));
            if (rawConfig.firestoreDatabaseId && rawConfig.firestoreDatabaseId !== "ai-studio-tumpangfood-99caef89-a69c-4fe1-80be-2c79f3dcb85c") {
              return rawConfig.firestoreDatabaseId;
            }
          }
        } catch {
        }
        return "(default)";
      })(),
      projectId: (() => {
        let pId = (process.env.FIREBASE_PROJECT_ID || process.env.GCP_PROJECT || "").trim();
        if (!pId) {
          try {
            const configPath = import_path.default.join(process.cwd(), "firebase-applet-config.json");
            if (import_fs.default.existsSync(configPath)) {
              const raw = JSON.parse(import_fs.default.readFileSync(configPath, "utf-8"));
              if (raw.projectId) pId = raw.projectId;
            }
          } catch {
          }
        }
        return pId || "tumpanggo-70479";
      })(),
      localDbFile,
      legacyDbFile: import_path.default.join(process.cwd(), "tumpang_db.json"),
      // Security & Authentication
      jwtSecret: runtimeJwtSecret || "dev_secret_fallback_do_not_use_in_prod",
      get adminEmail() {
        return (process.env.FOOD_ADMIN_EMAIL || runtimeAdminEmail || "tumpanggo@gmail.com").trim().toLowerCase();
      },
      get adminPassword() {
        return cleanEnvSecret(process.env.FOOD_ADMIN_PASSWORD || runtimeAdminPassword, isProductionRuntime ? "" : "TumpangGoAdmin#2026");
      },
      // Master Account (Unrestricted Cross-Portal Access)
      masterAccount: {
        get email() {
          return getMasterAccountCredentials().email;
        },
        get password() {
          return getMasterAccountCredentials().password;
        }
      },
      // System operational defaults
      defaults: {
        serviceFee: 2e3,
        deliveryFeePerKm: 1500,
        defaultDeliveryFee: 5e3,
        commissionPercent: 10,
        paymentExpiryMinutes: 10,
        qrisImage: "/qris-merchant.png"
      }
    };
    artopayConfig = {
      get isProduction() {
        return process.env.NODE_ENV === "production";
      },
      get environment() {
        const env = (process.env.ARTOPAY_ENVIRONMENT || process.env.ARTOPAY_ENV || "sandbox").toLowerCase().trim();
        return env === "production" ? "production" : "sandbox";
      },
      get apiKey() {
        let key = (process.env.ARTOPAY_API_KEY || "").trim();
        if (key.startsWith("'") && key.endsWith("'") || key.startsWith('"') && key.endsWith('"')) {
          key = key.slice(1, -1).trim();
        }
        return key;
      },
      get secretKey() {
        let key = (process.env.ARTOPAY_SECRET_KEY || "").trim();
        if (key.startsWith("'") && key.endsWith("'") || key.startsWith('"') && key.endsWith('"')) {
          key = key.slice(1, -1).trim();
        }
        return key;
      },
      get publicKey() {
        let key = (process.env.ARTOPAY_PUBLIC_KEY || process.env.VITE_ARTOPAY_PUBLIC_KEY || process.env.ARTOPAY_CLIENT_KEY || process.env.VITE_ARTOPAY_CLIENT_KEY || "").trim();
        if (key.startsWith("'") && key.endsWith("'") || key.startsWith('"') && key.endsWith('"')) {
          key = key.slice(1, -1).trim();
        }
        if (key.startsWith("%") || key.includes("%VITE_") || key === "undefined" || key === "null") {
          return "";
        }
        return key;
      },
      get webhookSecret() {
        let key = (process.env.ARTOPAY_WEBHOOK_SECRET || "").trim();
        if (key.startsWith("'") && key.endsWith("'") || key.startsWith('"') && key.endsWith('"')) {
          key = key.slice(1, -1).trim();
        }
        return key;
      },
      get businessUnitCode() {
        let key = (process.env.ARTOPAY_BUSINESS_UNIT_CODE || process.env.ARTOPAY_BUSINESS_UNIT || "").trim();
        if (key.startsWith("'") && key.endsWith("'") || key.startsWith('"') && key.endsWith('"')) {
          key = key.slice(1, -1).trim();
        }
        return key;
      },
      get baseUrl() {
        const defaultApiUrl = this.environment === "production" ? "https://api.arto-pay.com" : "https://api-sandbox.arto-pay.com";
        return (process.env.ARTOPAY_API_BASE_URL || process.env.ARTOPAY_BASE_URL || defaultApiUrl).trim();
      },
      get payBaseUrl() {
        const defaultPayUrl = this.environment === "production" ? "https://pay.arto-pay.com/arto-pay" : "https://pay-sandbox.arto-pay.com/arto-pay";
        return (process.env.ARTOPAY_PAY_URL || defaultPayUrl).trim();
      },
      defaultExpiryMinutes: 15
    };
    DEFAULT_VAPID_PUBLIC_KEY = "BEuS1NHSG0NnOTTmUk3sW77YGpZVvPkiedLernPntUDsmgE1zGT5O1I3VjP0lgtsETjI2PgRxJvMTKTWoaxqYWM";
    DEFAULT_VAPID_PRIVATE_KEY = "p100JN70gOKnd9VOPRl9HaK6ntLmZXA_VwcA9IH2B5M";
    vapidConfig = {
      get publicKey() {
        return cleanEnvSecret(process.env.VAPID_PUBLIC_KEY, DEFAULT_VAPID_PUBLIC_KEY);
      },
      get privateKey() {
        return cleanEnvSecret(process.env.VAPID_PRIVATE_KEY, DEFAULT_VAPID_PRIVATE_KEY);
      },
      get subject() {
        return (process.env.VAPID_SUBJECT || "mailto:admin@tumpanggo.com").trim();
      },
      get isConfigured() {
        return Boolean(this.publicKey && this.privateKey);
      }
    };
  }
});

// src/server/auth.ts
function hashPassword(password) {
  const salt = import_crypto.default.randomBytes(16).toString("hex");
  const iterations = 1e4;
  const hash = import_crypto.default.pbkdf2Sync(password, salt, iterations, 64, "sha512").toString("hex");
  return `pbkdf2$${iterations}$${salt}$${hash}`;
}
function verifyPassword(password, storedHash) {
  if (!storedHash || typeof storedHash !== "string" || !password || typeof password !== "string") {
    return { valid: false, needsRehash: false };
  }
  try {
    if (storedHash.startsWith("pbkdf2$")) {
      const parts = storedHash.split("$");
      if (parts.length !== 4) return { valid: false, needsRehash: false };
      const iterations = parseInt(parts[1], 10);
      const salt = parts[2];
      const originalHash = parts[3];
      if (isNaN(iterations) || iterations < 1 || !salt || !originalHash) {
        return { valid: false, needsRehash: false };
      }
      const derived = import_crypto.default.pbkdf2Sync(password, salt, iterations, 64, "sha512").toString("hex");
      const bufDerived = Buffer.from(derived, "hex");
      const bufOriginal = Buffer.from(originalHash, "hex");
      if (bufDerived.length !== bufOriginal.length) {
        return { valid: false, needsRehash: false };
      }
      const valid2 = import_crypto.default.timingSafeEqual(bufDerived, bufOriginal);
      return { valid: valid2, needsRehash: false };
    }
    const valid = password.trim() === storedHash.trim();
    return { valid, needsRehash: valid };
  } catch (err) {
    console.warn("[TumpangFood Auth] Error during password verification:", err);
    return { valid: false, needsRehash: false };
  }
}
function createAuthToken(user, expiresInHours = 72) {
  const secret = foodConfig.jwtSecret || (process.env.FOOD_AUTH_SECRET || "").trim();
  let effectiveSecret = secret;
  if (foodConfig.isProduction) {
    if (!secret || secret.length < 32 || secret.includes("fallback") || secret.includes("dev_secret")) {
      throw new Error("Gagal menerbitkan token: FOOD_AUTH_SECRET belum dikonfigurasi untuk lingkungan produksi (wajib minimal 32 karakter dan bukan fallback).");
    }
  } else {
    if (!effectiveSecret || effectiveSecret.length < 32) {
      effectiveSecret = "dev_secret_fallback_do_not_use_in_prod_min_32_characters_long";
    }
  }
  const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url");
  const payload = Buffer.from(
    JSON.stringify({
      ...user,
      exp: Math.floor(Date.now() / 1e3) + expiresInHours * 3600
    })
  ).toString("base64url");
  const signature = import_crypto.default.createHmac("sha256", effectiveSecret).update(`${header}.${payload}`).digest("base64url");
  return `${header}.${payload}.${signature}`;
}
function verifyAuthToken(token) {
  if (!token) return null;
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const [header, payload, signature] = parts;
    let isValid = false;
    const foodSecret = foodConfig.jwtSecret || (process.env.FOOD_AUTH_SECRET || "").trim();
    const isFoodSecretValid = Boolean(
      foodSecret && foodSecret.length >= 16 && (!foodConfig.isProduction || !foodSecret.includes("fallback") && !foodSecret.includes("dev_secret"))
    );
    if (isFoodSecretValid) {
      const foodSig = import_crypto.default.createHmac("sha256", foodSecret).update(`${header}.${payload}`).digest("base64url");
      if (signature.length === foodSig.length) {
        isValid = import_crypto.default.timingSafeEqual(Buffer.from(signature), Buffer.from(foodSig));
      }
    }
    if (!isValid) {
      return null;
    }
    const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf-8"));
    if (data.exp && data.exp < Math.floor(Date.now() / 1e3)) {
      return null;
    }
    return {
      userId: data.userId,
      role: data.role,
      email: data.email,
      entityId: data.entityId,
      isMasterAdmin: data.isMasterAdmin || data.role === "MASTER_ADMIN"
    };
  } catch {
    return null;
  }
}
function authenticateToken(req, res, next) {
  let token = "";
  const authHeader = req.headers["authorization"];
  if (authHeader && authHeader.startsWith("Bearer ")) {
    token = authHeader.substring(7);
  } else if (req.headers["x-auth-token"]) {
    token = String(req.headers["x-auth-token"]);
  }
  if (token) {
    const verified = verifyAuthToken(token);
    if (verified) {
      req.user = verified;
    }
  }
  next();
}
function isAdminEmail(email) {
  if (!email) return false;
  const e = email.trim().toLowerCase();
  return e === foodConfig.masterAccount.email || e === foodConfig.adminEmail || e === "suaiimokeras@gmail.com" || e === "suaiimokeras" || e === "tumpanggo@gmail.com" || e === "tumpanggo" || e === "admin@tumpanggo.com" || e === "sawahjayagroup@gmail.com" || e === "sawahjayatrans@gmail.com" || e === "admin";
}
function requireRole(allowedRoles) {
  return (req, res, next) => {
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: "Akses ditolak: Autentikasi diperlukan. Silakan login terlebih dahulu." });
    }
    if (user.role === "ADMIN" || user.role === "MASTER_ADMIN") {
      return next();
    }
    if (!allowedRoles.includes(user.role)) {
      return res.status(403).json({ error: `Akses ditolak: Peran ${user.role} tidak memiliki izin untuk tindakan ini.` });
    }
    next();
  };
}
function requireMerchantOwner(paramName = "merchantId") {
  return (req, res, next) => {
    const targetMerchantId = req.params[paramName] || req.params.merchantId || req.params.id || req.body[paramName];
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: "Akses ditolak: Autentikasi diperlukan. Silakan login terlebih dahulu." });
    }
    if (user.role === "ADMIN" || user.role === "MASTER_ADMIN" || user.isMasterAdmin) {
      return next();
    }
    if (user.role === "MERCHANT") {
      const cleanTarget = String(targetMerchantId || "").trim().toLowerCase();
      const userEntity = String(user.entityId || "").trim().toLowerCase();
      const userId = String(user.userId || "").trim().toLowerCase();
      if (cleanTarget === "me" || cleanTarget === userEntity || cleanTarget === userId) {
        return next();
      }
      const stripPrefix = (str) => str.replace(/^merchant_/, "");
      if (stripPrefix(cleanTarget) === stripPrefix(userEntity) || stripPrefix(cleanTarget) === stripPrefix(userId)) {
        return next();
      }
    }
    return res.status(403).json({ error: "Akses ditolak: Anda tidak memiliki izin untuk mengakses atau memodifikasi data toko ini." });
  };
}
function requireDriverSelf(paramName = "driverId") {
  return (req, res, next) => {
    const targetDriverId = req.params[paramName] || req.params.driverId || req.params.id || req.body[paramName];
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: "Akses ditolak: Autentikasi diperlukan. Silakan login terlebih dahulu." });
    }
    if (user.role === "ADMIN" || user.role === "MASTER_ADMIN" || user.isMasterAdmin) {
      return next();
    }
    if (user.role === "DRIVER" && (user.entityId === targetDriverId || user.userId === targetDriverId)) {
      return next();
    }
    return res.status(403).json({ error: "Akses ditolak: Anda tidak memiliki izin untuk tugas kurir ini." });
  };
}
var import_crypto;
var init_auth = __esm({
  "src/server/auth.ts"() {
    import_crypto = __toESM(require("crypto"), 1);
    init_config();
  }
});

// src/utils/deliveryFee.ts
function calculateDistanceKm(lat1, lon1, lat2, lon2) {
  if (!lat1 || !lon1 || !lat2 || !lon2) return 0;
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}
function normalizeLocationText(text) {
  return text.toLowerCase().replace(/[^\w\s-]/g, " ").replace(/\s+/g, " ").trim();
}
function isDestinationInKecamatanTumpang(loc) {
  const rawCombined = [loc.address, loc.details, loc.landmark].filter(Boolean).join(" ");
  const normalized = normalizeLocationText(rawCombined);
  if (normalized.includes("65156") || /\b(tumpang)\b/i.test(normalized)) {
    return true;
  }
  const hasVillage = TUMPANG_VILLAGES.some((village) => {
    const vNorm = normalizeLocationText(village);
    if (vNorm.includes(" ")) {
      return normalized.includes(vNorm);
    }
    const regex = new RegExp(`(^|[^a-z])${vNorm}([^a-z]|$)`, "i");
    return regex.test(normalized);
  });
  if (hasVillage) {
    return true;
  }
  const hasLandmark = TUMPANG_LANDMARKS.some((lm) => {
    const lmNorm = normalizeLocationText(lm);
    return normalized.includes(lmNorm);
  });
  if (hasLandmark) {
    return true;
  }
  if (isDestinationInKecamatanPakis(loc)) {
    return false;
  }
  const hasExplicitOutsideDistrict = OUTSIDE_DISTRICT_KEYWORDS.some((kw) => {
    const kwNorm = normalizeLocationText(kw);
    if (kwNorm.includes(" ")) {
      return normalized.includes(kwNorm);
    }
    const regex = new RegExp(`(^|[^a-z])${kwNorm}([^a-z]|$)`, "i");
    return regex.test(normalized);
  });
  if (hasExplicitOutsideDistrict) {
    return false;
  }
  if (typeof loc.latitude === "number" && typeof loc.longitude === "number" && loc.latitude !== 0 && loc.longitude !== 0) {
    const inBounds = loc.latitude >= TUMPANG_GEO_BOUNDS.minLat && loc.latitude <= TUMPANG_GEO_BOUNDS.maxLat && loc.longitude >= TUMPANG_GEO_BOUNDS.minLng && loc.longitude <= TUMPANG_GEO_BOUNDS.maxLng;
    if (inBounds) {
      return true;
    } else {
      return false;
    }
  }
  return true;
}
function isDestinationInKecamatanPakis(loc) {
  const rawCombined = [loc.address, loc.details, loc.landmark].filter(Boolean).join(" ");
  const normalized = normalizeLocationText(rawCombined);
  if (normalized.includes("65154") || /\b(pakis)\b/i.test(normalized)) {
    return true;
  }
  const hasPakisVillage = PAKIS_VILLAGES.some((village) => {
    const vNorm = normalizeLocationText(village);
    if (vNorm.includes(" ")) {
      return normalized.includes(vNorm);
    }
    const regex = new RegExp(`(^|[^a-z])${vNorm}([^a-z]|$)`, "i");
    return regex.test(normalized);
  });
  if (hasPakisVillage) {
    return true;
  }
  const hasPakisLandmark = PAKIS_LANDMARKS.some((lm) => {
    const lmNorm = normalizeLocationText(lm);
    return normalized.includes(lmNorm);
  });
  if (hasPakisLandmark) {
    return true;
  }
  if (typeof loc.latitude === "number" && typeof loc.longitude === "number" && loc.latitude !== 0 && loc.longitude !== 0) {
    const inBounds = loc.latitude >= PAKIS_GEO_BOUNDS.minLat && loc.latitude <= PAKIS_GEO_BOUNDS.maxLat && loc.longitude >= PAKIS_GEO_BOUNDS.minLng && loc.longitude <= PAKIS_GEO_BOUNDS.maxLng;
    if (inBounds) {
      return true;
    }
  }
  return false;
}
function calculateDeliveryFee(params) {
  const locInput = {
    address: params.address,
    details: params.details,
    landmark: params.landmark,
    latitude: params.latitude,
    longitude: params.longitude
  };
  const isInTumpang = isDestinationInKecamatanTumpang(locInput);
  if (isInTumpang) {
    return {
      deliveryFee: FLAT_TUMPANG_DELIVERY_FEE,
      isInTumpang: true,
      isInPakis: false,
      explanation: "Tarif flat Rp 5.000 untuk seluruh pengantaran di area Kecamatan Tumpang."
    };
  }
  const isInPakis = isDestinationInKecamatanPakis(locInput);
  if (isInPakis) {
    return {
      deliveryFee: FLAT_PAKIS_DELIVERY_FEE,
      isInTumpang: false,
      isInPakis: true,
      explanation: "Tarif flat Rp 7.500 untuk seluruh pengantaran di area Kecamatan Pakis."
    };
  }
  let distanceKm = 0;
  if (params.merchantLatitude && params.merchantLongitude && params.latitude && params.longitude) {
    distanceKm = calculateDistanceKm(
      params.merchantLatitude,
      params.merchantLongitude,
      params.latitude,
      params.longitude
    );
  }
  const feePerKm = params.systemConfig?.deliveryFeePerKm || 1500;
  const baseFee = params.systemConfig?.defaultDeliveryFee || 5e3;
  const calculatedOutside = Math.round((distanceKm || 5) * feePerKm);
  const outsideFee = Math.max(baseFee, calculatedOutside);
  return {
    deliveryFee: outsideFee,
    isInTumpang: false,
    isInPakis: false,
    distanceKm: distanceKm || void 0,
    explanation: `Pengantaran luar wilayah (${distanceKm ? distanceKm + " km" : "Luar Wilayah"}): Rp ${outsideFee.toLocaleString("id-ID")}`
  };
}
function normalizeOrderDeliveryFee(order) {
  if (!order) return order;
  const locInput = {
    address: order.deliveryAddress,
    details: order.deliveryDetails,
    landmark: order.landmark,
    latitude: order.latitude,
    longitude: order.longitude
  };
  const inTumpang = isDestinationInKecamatanTumpang(locInput);
  if (inTumpang) {
    if (order.deliveryFee !== FLAT_TUMPANG_DELIVERY_FEE) {
      order.deliveryFee = FLAT_TUMPANG_DELIVERY_FEE;
      order.total = order.subtotal + FLAT_TUMPANG_DELIVERY_FEE + order.serviceFee + (order.uniqueCode || 0);
    }
    return order;
  }
  const inPakis = isDestinationInKecamatanPakis(locInput);
  if (inPakis) {
    if (order.deliveryFee !== FLAT_PAKIS_DELIVERY_FEE) {
      order.deliveryFee = FLAT_PAKIS_DELIVERY_FEE;
      order.total = order.subtotal + FLAT_PAKIS_DELIVERY_FEE + order.serviceFee + (order.uniqueCode || 0);
    }
    return order;
  }
  return order;
}
var FLAT_TUMPANG_DELIVERY_FEE, FLAT_PAKIS_DELIVERY_FEE, TUMPANG_VILLAGES, TUMPANG_LANDMARKS, OUTSIDE_DISTRICT_KEYWORDS, TUMPANG_GEO_BOUNDS, PAKIS_VILLAGES, PAKIS_LANDMARKS, PAKIS_GEO_BOUNDS;
var init_deliveryFee = __esm({
  "src/utils/deliveryFee.ts"() {
    FLAT_TUMPANG_DELIVERY_FEE = 5e3;
    FLAT_PAKIS_DELIVERY_FEE = 7500;
    TUMPANG_VILLAGES = [
      // 1. Tumpang
      "tumpang",
      "desa tumpang",
      "kelurahan tumpang",
      // 2. Jeru
      "jeru",
      "desa jeru",
      // 3. Malangsuko
      "malangsuko",
      "malang suko",
      "malang-suko",
      "desa malangsuko",
      "desa malang suko",
      // 4. Pulungdowo
      "pulungdowo",
      "pulung dowo",
      "pulung-dowo",
      "desa pulungdowo",
      "desa pulung dowo",
      // 5. Bokor
      "bokor",
      "desa bokor",
      // 6. Slamet
      "slamet",
      "desa slamet",
      // 7. Wringinsongo
      "wringinsongo",
      "wringin songo",
      "wringin-songo",
      "desa wringinsongo",
      "desa wringin songo",
      // 8. Benjor
      "benjor",
      "desa benjor",
      // 9. Duwet
      "duwet",
      "desa duwet",
      // 10. Duwet Krajan
      "duwet krajan",
      "duwetkrajan",
      "duwet-krajan",
      "desa duwet krajan",
      "desa duwetkrajan",
      // 11. Kidal
      "kidal",
      "desa kidal",
      // 12. Kambingan
      "kambingan",
      "desa kambingan",
      // 13. Ngingit
      "ngingit",
      "desa ngingit",
      // 14. Tulusbesar
      "tulusbesar",
      "tulus besar",
      "tulus-besar",
      "desa tulusbesar",
      "desa tulus besar",
      // 15. Pandanajeng
      "pandanajeng",
      "pandan ajeng",
      "pandan-ajeng",
      "desa pandanajeng",
      "desa pandan ajeng"
    ];
    TUMPANG_LANDMARKS = [
      "candi kidal",
      "candi jago",
      "alun-alun tumpang",
      "alun alun tumpang",
      "taman tumpang",
      "pasar tumpang",
      "terminal tumpang",
      "kantor kecamatan tumpang",
      "kantor camat tumpang",
      "kecamatan tumpang",
      "kec. tumpang",
      "kec tumpang",
      "rs sumber sentosa",
      "rumah sakit sumber sentosa",
      "sumber sentosa",
      "puskesmas tumpang",
      "polsek tumpang",
      "koramil tumpang",
      "lembah tumpang",
      "sman 1 tumpang",
      "smpn 1 tumpang",
      "smpn 2 tumpang",
      "desela",
      "selandor",
      "argosari",
      "argo sari",
      "jilu",
      "glagah",
      // Dusun Glagah di Desa Tulusbesar
      "tumpanggo",
      "tumpang go",
      "65156"
      // Official Postal Code of Kecamatan Tumpang
    ];
    OUTSIDE_DISTRICT_KEYWORDS = [
      "kecamatan pakis",
      "kec. pakis",
      "pakis",
      "kecamatan poncokusumo",
      "kec. poncokusumo",
      "poncokusumo",
      "kecamatan jabung",
      "kec. jabung",
      "jabung",
      "kecamatan wajak",
      "kec. wajak",
      "wajak",
      "kecamatan tajinan",
      "kec. tajinan",
      "tajinan",
      "kecamatan singosari",
      "kec. singosari",
      "singosari",
      "kecamatan lawang",
      "kec. lawang",
      "lawang",
      "kecamatan kepanjen",
      "kec. kepanjen",
      "kepanjen",
      "kota malang",
      "malang kota",
      "klojen",
      "lowokwaru",
      "sukun",
      "blimbing",
      "kedungkandang",
      "kota batu",
      "batu",
      "surabaya",
      "sidoarjo",
      "pasuruan",
      "probolinggo",
      "blitar"
    ];
    TUMPANG_GEO_BOUNDS = {
      minLat: -8.12,
      maxLat: -7.85,
      minLng: 112.67,
      maxLng: 112.89
    };
    PAKIS_VILLAGES = [
      // 1. Pakisjajar
      "pakisjajar",
      "pakis jajar",
      "pakis-jajar",
      "desa pakisjajar",
      "desa pakis jajar",
      // 2. Pakiskembar
      "pakiskembar",
      "pakis kembar",
      "pakis-kembar",
      "desa pakiskembar",
      "desa pakis kembar",
      // 3. Ampeldento
      "ampeldento",
      "ampel dento",
      "ampel-dento",
      "desa ampeldento",
      "desa ampel dento",
      // 4. Asrikaton
      "asrikaton",
      "asri katon",
      "asri-katon",
      "desa asrikaton",
      "desa asri katon",
      // 5. Banjarejo
      "banjarejo",
      "banja rejo",
      "banjarejo pakis",
      "desa banjarejo",
      "desa banja rejo",
      // 6. Bunutwetan
      "bunutwetan",
      "bunut wetan",
      "bunut-wetan",
      "desa bunutwetan",
      "desa bunut wetan",
      // 7. Kedungrejo
      "kedungrejo",
      "kedung rejo",
      "kedungrejo pakis",
      "desa kedungrejo",
      "desa kedung rejo",
      // 8. Mangliawan
      "mangliawan",
      "desa mangliawan",
      "wendit",
      "wisata wendit",
      "pemandian wendit",
      // 9. Pagentan
      "pagentan",
      "desa pagentan",
      "kelurahan pagentan",
      // 10. Saptorenggo
      "saptorenggo",
      "sapto renggo",
      "sapto-renggo",
      "desa saptorenggo",
      "desa sapto renggo",
      // 11. Sekarpuro
      "sekarpuro",
      "sekar puro",
      "sekar-puro",
      "desa sekarpuro",
      "desa sekar puro",
      // 12. Sukoanyar
      "sukoanyar",
      "suko anyar",
      "suko-anyar",
      "desa sukoanyar",
      "sukoanyar pakis",
      // 13. Sumberkradenan
      "sumberkradenan",
      "sumber kradenan",
      "sumber-kradenan",
      "desa sumberkradenan",
      "desa sumber kradenan",
      // 14. Sumberpasir
      "sumberpasir",
      "sumber pasir",
      "sumber-pasir",
      "desa sumberpasir",
      "desa sumber pasir",
      // 15. Tumpukrenteng
      "tumpukrenteng",
      "tumpuk renteng",
      "tumpuk-renteng",
      "desa tumpukrenteng",
      "desa tumpuk renteng"
    ];
    PAKIS_LANDMARKS = [
      "pasar pakis",
      "terminal pakis",
      "kantor kecamatan pakis",
      "kantor camat pakis",
      "kecamatan pakis",
      "kec. pakis",
      "kec pakis",
      "polsek pakis",
      "koramil pakis",
      "puskesmas pakis",
      "gerbang tol pakis",
      "pintu tol pakis",
      "exit tol pakis",
      "tol pakis",
      "lanud abdulrachman saleh",
      "bandara abdulrachman saleh",
      "abdulrachman saleh",
      "taman wisata mendit",
      "pemandian wendit lanang",
      "65154"
      // Official Postal Code of Kecamatan Pakis
    ];
    PAKIS_GEO_BOUNDS = {
      minLat: -8.02,
      maxLat: -7.88,
      minLng: 112.65,
      maxLng: 112.75
    };
  }
});

// src/server/services/orderService.ts
var OrderService;
var init_orderService = __esm({
  "src/server/services/orderService.ts"() {
    init_types();
    init_deliveryFee();
    OrderService = class {
      /**
       * Validates and recalculates an incoming order against official database records.
       * Prevents customer-side price tampering.
       * Guarantees that preOrderDate is never copied from input to the resulting order.
       */
      static validateAndBuildOrder(input, merchant, menuItems, systemConfig, activeUniqueCodes) {
        if (!merchant) {
          throw new Error("Merchant tidak ditemukan.");
        }
        if (!merchant.active) {
          throw new Error(`Toko "${merchant.name}" saat ini sedang tutup dan tidak menerima pesanan.`);
        }
        if (!input.items || input.items.length === 0) {
          throw new Error("Keranjang belanja kosong. Silakan pilih menu terlebih dahulu.");
        }
        if (!input.customerName || !input.customerPhone || !input.deliveryAddress) {
          throw new Error("Mohon lengkapi Nama Pemesan, Nomor WhatsApp, dan Alamat Pengiriman.");
        }
        const validatedItems = [];
        let calculatedSubtotal = 0;
        for (const orderItemInput of input.items) {
          const quantity = Math.max(1, Math.floor(Number(orderItemInput.quantity) || 1));
          const menuItem = menuItems.find((m) => m.id === orderItemInput.menuItemId && m.merchantId === merchant.id);
          if (!menuItem) {
            throw new Error(`Menu dengan ID "${orderItemInput.menuItemId}" tidak ditemukan pada toko ini.`);
          }
          if (!menuItem.available) {
            throw new Error(`Maaf, menu "${menuItem.name}" saat ini sedang habis.`);
          }
          const officialPrice = Number(menuItem.price) || 0;
          calculatedSubtotal += officialPrice * quantity;
          validatedItems.push({
            menuItemId: menuItem.id,
            name: menuItem.name,
            price: officialPrice,
            quantity
          });
        }
        const calculatedServiceFee = calculateTieredServiceFee(calculatedSubtotal);
        const deliveryCalc = calculateDeliveryFee({
          address: input.deliveryAddress,
          details: input.deliveryDetails,
          landmark: input.landmark,
          latitude: input.latitude,
          longitude: input.longitude,
          merchantLatitude: merchant.latitude,
          merchantLongitude: merchant.longitude,
          systemConfig
        });
        const calculatedDeliveryFee = deliveryCalc.deliveryFee;
        const uniqueCode = this.generateUniqueCode(activeUniqueCodes);
        const total = calculatedSubtotal + calculatedDeliveryFee + calculatedServiceFee + uniqueCode;
        const paymentExpiresAt = new Date(Date.now() + 10 * 60 * 1e3).toISOString();
        return normalizeOrderDeliveryFee({
          uniqueCode,
          total,
          status: "WAITING_PAYMENT" /* WAITING_PAYMENT */,
          paymentStatus: "PENDING" /* PENDING */,
          paymentMethod: "MERCHANT_QRIS",
          merchantId: merchant.id,
          merchantName: merchant.name,
          merchantQrisImage: merchant.qrisImage || "",
          customerName: input.customerName.trim(),
          customerPhone: input.customerPhone.trim(),
          deliveryAddress: input.deliveryAddress.trim(),
          deliveryDetails: input.deliveryDetails ? input.deliveryDetails.trim() : "",
          landmark: input.landmark ? input.landmark.trim() : "",
          latitude: input.latitude,
          longitude: input.longitude,
          items: validatedItems,
          subtotal: calculatedSubtotal,
          deliveryFee: calculatedDeliveryFee,
          serviceFee: calculatedServiceFee,
          paymentExpiresAt
        });
      }
      /**
       * Generates a unique 2-digit verification code avoiding conflicts.
       */
      static generateUniqueCode(activeCodes) {
        for (let attempts = 0; attempts < 100; attempts++) {
          const code = Math.floor(Math.random() * 99) + 1;
          if (!activeCodes.includes(code)) {
            return code;
          }
        }
        return Math.floor(Math.random() * 99) + 1;
      }
      /**
       * Haversine formula to compute distance in km
       */
      static calculateDistanceKm(lat1, lon1, lat2, lon2) {
        const R = 6371;
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLon = (lon2 - lon1) * Math.PI / 180;
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return Math.round(R * c * 10) / 10;
      }
      /**
       * Validates state machine status transition
       */
      static isValidStatusTransition(currentStatus, targetStatus, role) {
        if (role === "ADMIN" || role === "MASTER_ADMIN" || role === "SYSTEM") {
          return { allowed: true };
        }
        if (currentStatus === targetStatus) {
          return { allowed: true };
        }
        if (currentStatus === "COMPLETED" /* COMPLETED */ || currentStatus === "CANCELLED" /* CANCELLED */ || currentStatus === "EXPIRED" /* EXPIRED */) {
          return { allowed: false, reason: `Pesanan telah berada pada status final (${currentStatus}).` };
        }
        switch (role) {
          case "CUSTOMER":
            if ((currentStatus === "WAITING_PAYMENT" /* WAITING_PAYMENT */ || currentStatus === "PAYMENT_REJECTED" /* PAYMENT_REJECTED */) && (targetStatus === "WAITING_PAYMENT_VERIFICATION" /* WAITING_PAYMENT_VERIFICATION */ || targetStatus === "CANCELLED" /* CANCELLED */)) {
              return { allowed: true };
            }
            return { allowed: false, reason: "Pelanggan hanya dapat mengunggah bukti pembayaran atau membatalkan pesanan baru/ditolak." };
          case "MERCHANT":
            if (currentStatus === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */ && targetStatus === "COOKING" /* COOKING */) {
              return { allowed: true };
            }
            if (currentStatus === "COOKING" /* COOKING */ && targetStatus === "READY_FOR_PICKUP" /* READY_FOR_PICKUP */) {
              return { allowed: true };
            }
            return { allowed: false, reason: `Merchant tidak diizinkan mengubah status dari ${currentStatus} ke ${targetStatus}.` };
          case "DRIVER":
            if ((currentStatus === "READY_FOR_PICKUP" /* READY_FOR_PICKUP */ || currentStatus === "COOKING" /* COOKING */) && targetStatus === "ORDER_PICKED_UP" /* ORDER_PICKED_UP */) {
              return { allowed: true };
            }
            if (currentStatus === "ORDER_PICKED_UP" /* ORDER_PICKED_UP */ && (targetStatus === "DELIVERED" /* DELIVERED */ || targetStatus === "COMPLETED" /* COMPLETED */)) {
              return { allowed: true };
            }
            if (currentStatus === "DELIVERED" /* DELIVERED */ && targetStatus === "COMPLETED" /* COMPLETED */) {
              return { allowed: true };
            }
            return { allowed: false, reason: `Driver tidak diizinkan mengubah status dari ${currentStatus} ke ${targetStatus}.` };
          default:
            return { allowed: false, reason: "Peran tidak dikenali." };
        }
      }
    };
  }
});

// src/server/firebaseAdmin.ts
function removeUndefinedFields(obj) {
  if (obj === null || typeof obj !== "object") return obj;
  if (Array.isArray(obj)) return obj.map(removeUndefinedFields);
  const cleaned = {};
  for (const [key, val] of Object.entries(obj)) {
    if (val !== void 0) {
      cleaned[key] = removeUndefinedFields(val);
    }
  }
  return cleaned;
}
function sanitizeErrorMessage(msg) {
  if (!msg || typeof msg !== "string") return "Unknown error";
  return msg.replace(/-----BEGIN[^-]+-----[\s\S]+?-----END[^-]+-----/g, "[PROTECTED_PRIVATE_KEY]").replace(/(private_key|token|secret|password)["']?\s*[:=]\s*["']?[^"',\s}]+/gi, "$1: [REDACTED]").replace(/(\/Users\/|\/home\/|\/var\/task\/)[^\s:]+/g, "[system-path]");
}
function maskClientEmail(email) {
  if (!email || !email.includes("@")) return "configured_account";
  const parts = email.split("@");
  const user = parts[0];
  const domain = parts[1];
  const visibleLen = Math.min(3, user.length);
  return `${user.substring(0, visibleLen)}***@${domain}`;
}
function getExpectedProjectId() {
  let expected = (process.env.FIREBASE_PROJECT_ID || process.env.GCP_PROJECT || "").trim();
  if (!expected) {
    try {
      const configPath = import_path2.default.join(process.cwd(), "firebase-applet-config.json");
      if (import_fs2.default.existsSync(configPath)) {
        const raw = JSON.parse(import_fs2.default.readFileSync(configPath, "utf-8"));
        if (raw.projectId) expected = raw.projectId.trim();
      }
    } catch {
    }
  }
  return expected || "tumpanggo-70479";
}
function parseServiceAccountKey(rawInput, expectedProjectId) {
  if (!rawInput || typeof rawInput !== "string" || rawInput.trim().length === 0) {
    return {
      account: null,
      reason: "MISSING_CREDENTIALS",
      error: "Variabel lingkungan FIREBASE_SERVICE_ACCOUNT_KEY belum dikonfigurasi di Environment Variables Vercel.",
      remediation: "Buka Vercel Dashboard -> Project Settings -> Environment Variables, lalu tambahkan FIREBASE_SERVICE_ACCOUNT_KEY berisi JSON Service Account dari Firebase Console."
    };
  }
  let clean = rawInput.trim();
  if (clean.charCodeAt(0) === 65279) {
    clean = clean.slice(1).trim();
  }
  if (clean.startsWith("'") && clean.endsWith("'") || clean.startsWith('"') && clean.endsWith('"')) {
    clean = clean.slice(1, -1).trim();
  }
  let parsed = null;
  let jsonParseError = null;
  if (clean.startsWith("{")) {
    try {
      parsed = JSON.parse(clean);
    } catch (e) {
      jsonParseError = e.message;
      try {
        const normalized = clean.replace(/\r\n/g, "\n");
        parsed = JSON.parse(normalized);
        jsonParseError = null;
      } catch (e2) {
        try {
          if (clean.includes('\\"')) {
            parsed = JSON.parse(clean.replace(/\\"/g, '"'));
            jsonParseError = null;
          }
        } catch {
        }
      }
    }
  } else {
    try {
      const decoded = Buffer.from(clean, "base64").toString("utf-8").trim();
      if (decoded.startsWith("{")) {
        parsed = JSON.parse(decoded);
      }
    } catch {
    }
    if (!parsed && import_fs2.default.existsSync(clean)) {
      try {
        const fileContent = import_fs2.default.readFileSync(clean, "utf-8").trim();
        if (fileContent.startsWith("{")) {
          parsed = JSON.parse(fileContent);
        }
      } catch (fileErr) {
        jsonParseError = fileErr.message;
      }
    }
  }
  if (!parsed || typeof parsed !== "object") {
    return {
      account: null,
      reason: "INVALID_JSON",
      error: `Format FIREBASE_SERVICE_ACCOUNT_KEY tidak dapat diparsing sebagai JSON yang valid${jsonParseError ? `: ${sanitizeErrorMessage(jsonParseError)}` : "."}`,
      remediation: "Periksa nilai FIREBASE_SERVICE_ACCOUNT_KEY di Vercel Environment Variables. Pastikan seluruh isi JSON utuh disalin (tanpa tanda kutip luar tambahan atau karakter yang terpotong)."
    };
  }
  if (!parsed.client_email || typeof parsed.client_email !== "string" || !parsed.client_email.includes("@")) {
    return {
      account: null,
      reason: "MALFORMED_SERVICE_ACCOUNT",
      error: 'JSON Service Account tidak lengkap. Wajib memiliki field "client_email" yang sah.',
      remediation: "Unduh ulang file kunci JSON Service Account baru dari Firebase Console (Project Settings > Service Accounts > Generate new private key)."
    };
  }
  if (!parsed.private_key || typeof parsed.private_key !== "string" || !parsed.private_key.includes("PRIVATE KEY")) {
    return {
      account: null,
      reason: "MALFORMED_SERVICE_ACCOUNT",
      error: 'JSON Service Account tidak memiliki field "private_key" yang sah (wajib mengandung "-----BEGIN PRIVATE KEY-----").',
      remediation: 'Pastikan file Service Account yang disalin memiliki field "private_key" yang utuh.'
    };
  }
  const targetProject = expectedProjectId || getExpectedProjectId();
  if (parsed.project_id && targetProject && parsed.project_id.trim() !== targetProject.trim()) {
    return {
      account: null,
      reason: "PROJECT_ID_MISMATCH",
      error: `Project ID pada Service Account ("${parsed.project_id}") tidak cocok dengan target proyek aplikasi ("${targetProject}").`,
      remediation: `Buka Vercel Dashboard -> Project Settings -> Environment Variables. Sesuaikan variabel FIREBASE_PROJECT_ID agar cocok dengan project ID Service Account ("${parsed.project_id}"), atau unduh Service Account baru dari proyek "${targetProject}" di Firebase Console.`,
      projectId: parsed.project_id,
      clientEmailMasked: maskClientEmail(parsed.client_email)
    };
  }
  parsed.private_key = parsed.private_key.replace(/\\n/g, "\n").replace(/\r\n/g, "\n");
  return {
    account: parsed,
    reason: "OK",
    projectId: parsed.project_id || targetProject,
    clientEmailMasked: maskClientEmail(parsed.client_email)
  };
}
function initFirebaseAdmin(serviceAccountOverride) {
  try {
    const targetProject = getExpectedProjectId();
    activeProjectId = targetProject;
    lastProbeResult = null;
    const rawInput = (serviceAccountOverride || process.env.FIREBASE_SERVICE_ACCOUNT_KEY || process.env.GOOGLE_SERVICE_ACCOUNT_KEY || process.env.FIREBASE_SERVICE_ACCOUNT || process.env.FIREBASE_ADMIN_CREDENTIALS || process.env.SERVICE_ACCOUNT_KEY || process.env.GCP_SERVICE_ACCOUNT_KEY || process.env.GOOGLE_APPLICATION_CREDENTIALS || "").trim();
    isConfiguredWithServiceAccount = false;
    isFirestoreVerified = false;
    activeClientEmailMasked = null;
    if (!rawInput || rawInput.length === 0) {
      adminApp = null;
      adminDb = null;
      lastDiagnosticReason = "MISSING_CREDENTIALS";
      lastDiagnosticDetail = "Variabel lingkungan FIREBASE_SERVICE_ACCOUNT_KEY belum dikonfigurasi di Environment Variables Vercel.";
      lastRemediationStep = "Buka Vercel Dashboard -> Project Settings -> Environment Variables, lalu tambahkan FIREBASE_SERVICE_ACCOUNT_KEY berisi JSON Service Account dari Firebase Console.";
      return { success: false, error: lastDiagnosticDetail, reason: "MISSING_CREDENTIALS" };
    }
    const parseResult = parseServiceAccountKey(rawInput, targetProject);
    if (!parseResult.account) {
      adminApp = null;
      adminDb = null;
      lastDiagnosticReason = parseResult.reason;
      lastDiagnosticDetail = parseResult.error || "Service Account tidak valid.";
      lastRemediationStep = parseResult.remediation;
      return { success: false, error: lastDiagnosticDetail, reason: parseResult.reason };
    }
    const sa = parseResult.account;
    if (sa.project_id) {
      activeProjectId = sa.project_id;
    }
    activeClientEmailMasked = parseResult.clientEmailMasked || maskClientEmail(sa.client_email || "");
    const certFn = import_app.cert || admin.cert || admin.credential?.cert;
    const initAppFn = import_app.initializeApp || admin.initializeApp;
    const getAppsFn = import_app.getApps || admin.getApps;
    if (typeof certFn !== "function") {
      lastDiagnosticReason = "INIT_FAILED";
      lastDiagnosticDetail = "Fungsi cert() dari firebase-admin/app tidak tersedia.";
      lastRemediationStep = "Periksa instalasi paket firebase-admin.";
      return { success: false, error: lastDiagnosticDetail, reason: "INIT_FAILED" };
    }
    const credentialOption = certFn(sa);
    isConfiguredWithServiceAccount = true;
    const currentApps = typeof getAppsFn === "function" ? getAppsFn() : [];
    if (currentApps.length === 0) {
      const initOptions = {
        credential: credentialOption,
        projectId: activeProjectId
      };
      if (typeof initAppFn === "function") {
        adminApp = initAppFn(initOptions);
      }
    } else {
      adminApp = currentApps[0];
    }
    const getFirestoreFn = import_firestore.getFirestore || admin.firestore;
    if (typeof getFirestoreFn === "function" && adminApp) {
      if (!foodConfig.databaseId || foodConfig.databaseId === "(default)") {
        adminDb = getFirestoreFn(adminApp);
      } else {
        adminDb = getFirestoreFn(adminApp, foodConfig.databaseId);
      }
    }
    lastDiagnosticReason = "OK";
    lastDiagnosticDetail = `Kredensial Service Account (${activeClientEmailMasked}) berhasil dimuat untuk proyek "${activeProjectId}". Menunggu verifikasi koneksi.`;
    lastRemediationStep = void 0;
    console.log(`[TumpangFood Admin] Loaded explicit Service Account (Project: ${activeProjectId}, Account: ${activeClientEmailMasked}).`);
    return { success: true, reason: "OK" };
  } catch (e) {
    const safeMsg = sanitizeErrorMessage(e.message);
    console.error("[TumpangFood Admin] Failed to initialize Firebase Admin SDK:", safeMsg);
    adminApp = null;
    adminDb = null;
    isConfiguredWithServiceAccount = false;
    isFirestoreVerified = false;
    lastDiagnosticReason = "INIT_FAILED";
    lastDiagnosticDetail = `Gagal menginisialisasi Firebase Admin SDK: ${safeMsg}`;
    lastRemediationStep = "Periksa format RSA private_key pada Service Account. Pastikan karakter pemisah baris (\\n) tidak rusak.";
    return { success: false, error: lastDiagnosticDetail, reason: "INIT_FAILED" };
  }
}
function getAdminDb() {
  return adminDb;
}
function isFirestoreAdminConfigured() {
  if (testMockState && testMockState.isConfigured !== void 0) {
    return testMockState.isConfigured;
  }
  return adminDb !== null && isConfiguredWithServiceAccount === true && isFirestoreVerified === true;
}
function isUsingServiceAccount() {
  return isConfiguredWithServiceAccount;
}
function getFirestoreDiagnosticStatus() {
  return {
    reason: lastDiagnosticReason,
    detail: lastDiagnosticDetail,
    remediation: lastRemediationStep,
    projectId: activeProjectId,
    authIdentity: activeClientEmailMasked ? `Explicit Service Account (${activeClientEmailMasked})` : "No Service Account Configured",
    isVerified: isFirestoreVerified,
    hasExplicitKey: isConfiguredWithServiceAccount
  };
}
async function testFirestoreConnection(force = false) {
  if (testMockState && testMockState.probeResult !== void 0) {
    return { ...testMockState.probeResult };
  }
  if (!force && lastProbeResult && Date.now() - lastProbeResult.timestamp < PROBE_CACHE_TTL_MS) {
    return { ...lastProbeResult.result };
  }
  if (!adminDb || !isConfiguredWithServiceAccount) {
    isFirestoreVerified = false;
    const res = {
      connected: false,
      canRead: false,
      canWrite: false,
      databaseId: foodConfig.databaseId,
      projectId: activeProjectId,
      usingServiceAccount: false,
      authIdentity: "No Service Account Configured",
      error: lastDiagnosticDetail,
      diagnosticReason: lastDiagnosticReason,
      diagnosticDetail: lastDiagnosticDetail,
      remediationStep: lastRemediationStep
    };
    lastProbeResult = { timestamp: Date.now(), result: res };
    return res;
  }
  let canRead = false;
  let canWrite = false;
  let probeError = void 0;
  let diagnosticReason = "OK";
  const withTimeout = (p, ms = 4e3, label = "Operation") => {
    let timer;
    const timeoutPromise = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms);
      if (timer && typeof timer.unref === "function") timer.unref();
    });
    return Promise.race([
      p.finally(() => {
        if (timer) clearTimeout(timer);
      }),
      timeoutPromise
    ]);
  };
  let diagnosticDetail = "Koneksi cloud Firestore Admin SDK aktif dan berhasil membaca/menulis data.";
  let remediationStep = void 0;
  try {
    await withTimeout(
      adminDb.collection("systemConfig").doc("config_1").get(),
      4e3,
      "Firestore read probe"
    );
    canRead = true;
    canWrite = true;
    isFirestoreVerified = true;
  } catch (err) {
    isFirestoreVerified = false;
    probeError = sanitizeErrorMessage(err?.message || String(err));
    const rawErrCode = err?.code;
    const lower = (probeError + " " + String(rawErrCode || "")).toLowerCase();
    if (rawErrCode === 16 || lower.includes("could not load the default credentials") || lower.includes("unauthenticated")) {
      diagnosticReason = "MISSING_CREDENTIALS";
      diagnosticDetail = "Google Auth Library gagal memuat kredensial default. Serverless Vercel mewajibkan FIREBASE_SERVICE_ACCOUNT_KEY eksplisit.";
      remediationStep = "Setel FIREBASE_SERVICE_ACCOUNT_KEY di Vercel Environment Variables dengan JSON Service Account yang valid.";
    } else if (rawErrCode === 7 || rawErrCode === "7" || rawErrCode === "PERMISSION_DENIED" || lower.includes("permission_denied") || lower.includes("permission denied") || lower.includes("missing or insufficient permissions") || lower.includes("status: 7")) {
      diagnosticReason = "IAM_PERMISSION_DENIED";
      diagnosticDetail = `Service Account (${activeClientEmailMasked || "terpasang"}) ditolak oleh Google Cloud IAM (PERMISSION_DENIED). Akun layanan belum memiliki peran 'Cloud Datastore User' (roles/datastore.user) atau 'Firebase Admin' pada proyek "${activeProjectId}".`;
      remediationStep = `Buka Google Cloud Console -> IAM & Admin -> IAM pada proyek "${activeProjectId}", cari akun layanan "${activeClientEmailMasked || "Service Account"}", dan tambahkan peran "Cloud Datastore User" (roles/datastore.user).`;
    } else if (rawErrCode === 5 || rawErrCode === "5" || rawErrCode === "NOT_FOUND" || lower.includes("not found") || lower.includes("database") || lower.includes("status: 5")) {
      diagnosticReason = "DATABASE_NOT_FOUND";
      diagnosticDetail = `Database Firestore "${foodConfig.databaseId}" tidak ditemukan pada proyek "${activeProjectId}".`;
      remediationStep = `Pastikan database Firestore dengan ID "${foodConfig.databaseId}" sudah dibuat di Firebase Console.`;
    } else if (lower.includes("project") || lower.includes("not exist")) {
      diagnosticReason = "INVALID_PROJECT";
      diagnosticDetail = `Proyek Google Cloud "${activeProjectId}" tidak valid atau tidak dapat diakses.`;
      remediationStep = `Pastikan Service Account dibuat dari project ID "${activeProjectId}" di Firebase Console.`;
    } else if (rawErrCode === 8 || rawErrCode === "8" || rawErrCode === "RESOURCE_EXHAUSTED" || lower.includes("resource_exhausted") || lower.includes("quota exceeded") || lower.includes("quota_exceeded") || lower.includes("status: 8")) {
      diagnosticReason = "RESOURCE_EXHAUSTED";
      diagnosticDetail = "Batas kuota gratis harian Cloud Firestore (50.000 dokumen baca atau 20.000 tulis per hari) telah tercapai (RESOURCE_EXHAUSTED). Operasi penulisan cloud ditangguhkan sementara sampai kuota direset oleh Google Cloud pada pukul 00:00 PST / 14:00 WIB, atau paket ditingkatkan ke Blaze (Pay-as-you-go).";
      remediationStep = "Tunggu reset kuota harian pada pukul 14:00 WIB, atau beralih ke paket Blaze di Firebase Console -> Project Settings -> Usage and Billing, serta pastikan query tidak memuat seluruh koleksi dokumen berulang kali.";
    } else if (rawErrCode === 4 || rawErrCode === 14 || rawErrCode === "4" || rawErrCode === "14" || rawErrCode === "DEADLINE_EXCEEDED" || rawErrCode === "UNAVAILABLE" || lower.includes("timed out") || lower.includes("deadline_exceeded") || lower.includes("unavailable") || lower.includes("econnrefused") || lower.includes("etimedout")) {
      diagnosticReason = "NETWORK_OR_TIMEOUT";
      diagnosticDetail = "Gagal menghubungi server Google Cloud Firestore karena koneksi timeout atau gangguan jaringan serverless.";
      remediationStep = "Periksa koneksi jaringan hosting Vercel dan pastikan akses ke firestore.googleapis.com tidak dibatasi firewall.";
    } else {
      diagnosticReason = "UNKNOWN";
      diagnosticDetail = `Terjadi kesalahan saat menghubungi Firestore: ${probeError}`;
      remediationStep = "Periksa log server untuk rincian error gRPC/HTTP Firestore.";
    }
    lastDiagnosticReason = diagnosticReason;
    lastDiagnosticDetail = diagnosticDetail;
    lastRemediationStep = remediationStep;
  }
  if (!probeError) {
    lastDiagnosticReason = "OK";
    lastDiagnosticDetail = diagnosticDetail;
    lastRemediationStep = void 0;
  }
  const isFullyConnected = canRead && !probeError;
  const result = {
    connected: isFullyConnected,
    canRead,
    canWrite: isFullyConnected,
    databaseId: foodConfig.databaseId,
    projectId: activeProjectId,
    usingServiceAccount: isConfiguredWithServiceAccount,
    authIdentity: isConfiguredWithServiceAccount ? `Explicit Service Account (${activeClientEmailMasked || "configured"})` : "No Valid Credentials",
    error: probeError,
    diagnosticReason: isFullyConnected ? "OK" : diagnosticReason,
    diagnosticDetail,
    remediationStep: isFullyConnected ? void 0 : remediationStep
  };
  lastProbeResult = { timestamp: Date.now(), result };
  return result;
}
async function safeAdminSetDoc(collectionName, docId, data) {
  if (testMockState && testMockState.writeSuccess !== void 0) {
    return testMockState.writeSuccess;
  }
  if (!adminDb || !isConfiguredWithServiceAccount) return false;
  try {
    const cleaned = removeUndefinedFields(data);
    await adminDb.collection(collectionName).doc(docId).set(cleaned, { merge: true });
    return true;
  } catch (err) {
    console.warn(`[TumpangFood Admin] safeAdminSetDoc failed for ${collectionName}/${docId}:`, sanitizeErrorMessage(err.message));
    return false;
  }
}
async function safeAdminDeleteDoc(collectionName, docId) {
  if (testMockState && testMockState.deleteSuccess !== void 0) {
    return testMockState.deleteSuccess;
  }
  if (!adminDb || !isConfiguredWithServiceAccount) return false;
  try {
    await adminDb.collection(collectionName).doc(docId).delete();
    return true;
  } catch (err) {
    console.warn(`[TumpangFood Admin] safeAdminDeleteDoc failed for ${collectionName}/${docId}:`, sanitizeErrorMessage(err.message));
    return false;
  }
}
async function safeAdminGetDoc(collectionName, docId) {
  if (!adminDb || !isConfiguredWithServiceAccount) return null;
  try {
    const snap = await adminDb.collection(collectionName).doc(docId).get();
    if (snap.exists) {
      const data = snap.data() || {};
      return { id: snap.id, ...data };
    }
    return null;
  } catch (err) {
    console.warn(`[TumpangFood Admin] safeAdminGetDoc failed for ${collectionName}/${docId}:`, sanitizeErrorMessage(err.message));
    return null;
  }
}
async function safeAdminGetDocs(collectionName, queryBuilder) {
  if (!adminDb || !isConfiguredWithServiceAccount) return [];
  try {
    const baseRef = adminDb.collection(collectionName);
    const query = queryBuilder ? queryBuilder(baseRef) : baseRef;
    const snap = await query.get();
    return snap.docs.map((doc) => ({ id: doc.id, ...doc.data() || {} }));
  } catch (err) {
    console.warn(`[TumpangFood Admin] safeAdminGetDocs failed for ${collectionName}:`, sanitizeErrorMessage(err.message));
    return [];
  }
}
async function safeAdminCountDocs(collectionName, queryBuilder) {
  if (!adminDb || !isConfiguredWithServiceAccount) return null;
  try {
    const baseRef = adminDb.collection(collectionName);
    const query = queryBuilder ? queryBuilder(baseRef) : baseRef;
    const snap = await query.count().get();
    return snap.data().count;
  } catch (err) {
    console.warn(`[TumpangFood Admin] safeAdminCountDocs failed for ${collectionName}:`, sanitizeErrorMessage(err.message));
    return null;
  }
}
async function runAdminTransaction(updateFunction) {
  if (!adminDb || !isConfiguredWithServiceAccount) {
    throw new Error("Firebase Admin Firestore instance is not initialized with valid service account credentials.");
  }
  return await adminDb.runTransaction(updateFunction);
}
async function recursivePurgeDocumentSubcollections(db, docRef) {
  let deletedCount = 0;
  const subcollections = await docRef.listCollections();
  for (const subCol of subcollections) {
    let hasMore = true;
    while (hasMore) {
      const snap = await subCol.limit(400).get();
      if (snap.empty) {
        hasMore = false;
        break;
      }
      for (const subDoc of snap.docs) {
        deletedCount += await recursivePurgeDocumentSubcollections(db, subDoc.ref);
      }
      const batch = db.batch();
      for (const subDoc of snap.docs) {
        batch.delete(subDoc.ref);
      }
      await batch.commit();
      deletedCount += snap.size;
      if (snap.size < 400) {
        hasMore = false;
      }
    }
  }
  return deletedCount;
}
async function safeAdminBatchDelete(collectionName, docIds) {
  if (!adminDb || !isConfiguredWithServiceAccount) return { count: 0, subcollectionsPurged: 0, success: false, error: "Firebase Admin not configured" };
  try {
    let idsToDelete = docIds;
    if (!idsToDelete) {
      const snap = await adminDb.collection(collectionName).get();
      idsToDelete = snap.docs.map((d) => d.id);
    }
    if (idsToDelete.length === 0) return { count: 0, subcollectionsPurged: 0, success: true };
    let totalSubcollectionsPurged = 0;
    for (const id of idsToDelete) {
      try {
        const docRef = adminDb.collection(collectionName).doc(id);
        totalSubcollectionsPurged += await recursivePurgeDocumentSubcollections(adminDb, docRef);
      } catch (subErr) {
        console.warn(`[TumpangFood Admin] Subcollection scan warning on ${collectionName}/${id}:`, sanitizeErrorMessage(subErr.message));
      }
    }
    const CHUNK_SIZE = 400;
    let totalDeleted = 0;
    for (let i = 0; i < idsToDelete.length; i += CHUNK_SIZE) {
      const chunk = idsToDelete.slice(i, i + CHUNK_SIZE);
      const batch = adminDb.batch();
      for (const id of chunk) {
        batch.delete(adminDb.collection(collectionName).doc(id));
      }
      await batch.commit();
      totalDeleted += chunk.length;
    }
    return { count: totalDeleted, subcollectionsPurged: totalSubcollectionsPurged, success: true };
  } catch (err) {
    const safeMsg = sanitizeErrorMessage(err.message || String(err));
    console.error(`[TumpangFood Admin] safeAdminBatchDelete failed for ${collectionName}:`, safeMsg);
    return { count: 0, subcollectionsPurged: 0, success: false, error: safeMsg };
  }
}
async function safeAdminBatchDeleteQuery(collectionName, field, operator, value) {
  if (!adminDb || !isConfiguredWithServiceAccount) return { count: 0, subcollectionsPurged: 0, success: false, error: "Firebase Admin not configured" };
  try {
    const snap = await adminDb.collection(collectionName).where(field, operator, value).get();
    if (snap.empty) return { count: 0, subcollectionsPurged: 0, success: true };
    const ids = snap.docs.map((d) => d.id);
    return await safeAdminBatchDelete(collectionName, ids);
  } catch (err) {
    const safeMsg = sanitizeErrorMessage(err.message || String(err));
    console.error(`[TumpangFood Admin] safeAdminBatchDeleteQuery failed for ${collectionName}:`, safeMsg);
    return { count: 0, subcollectionsPurged: 0, success: false, error: safeMsg };
  }
}
function sanitizeBackupDoc(doc) {
  if (!doc || typeof doc !== "object") return doc;
  const clone = { ...doc };
  delete clone.password;
  delete clone.passwordHash;
  delete clone.token;
  delete clone.secret;
  delete clone.apiKey;
  delete clone.privateKey;
  delete clone.private_key;
  return removeUndefinedFields(clone);
}
async function createFirestoreBackup(backupId, metadata, collections) {
  if (!adminDb || !isConfiguredWithServiceAccount) return false;
  try {
    const summary = {};
    for (const [colName, docs] of Object.entries(collections)) {
      summary[colName] = docs.length;
    }
    await adminDb.collection("admin_backups").doc(backupId).set({
      id: backupId,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      metadata: removeUndefinedFields(metadata),
      summary
    });
    const allRecords = [];
    for (const [colName, docs] of Object.entries(collections)) {
      for (const doc of docs) {
        if (doc && doc.id) {
          allRecords.push({
            id: `${colName}__${doc.id}`,
            targetCollection: colName,
            data: sanitizeBackupDoc(doc)
          });
        }
      }
    }
    const CHUNK_SIZE = 400;
    for (let i = 0; i < allRecords.length; i += CHUNK_SIZE) {
      const chunk = allRecords.slice(i, i + CHUNK_SIZE);
      const batch = adminDb.batch();
      for (const rec of chunk) {
        const itemRef = adminDb.collection("admin_backups").doc(backupId).collection("records").doc(rec.id);
        batch.set(itemRef, {
          targetCollection: rec.targetCollection,
          docId: rec.data.id,
          payload: rec.data,
          backedUpAt: (/* @__PURE__ */ new Date()).toISOString()
        });
      }
      await batch.commit();
    }
    console.log(`[TumpangFood Admin] Persistent Cloud Firestore backup created successfully: admin_backups/${backupId} (${allRecords.length} records)`);
    return true;
  } catch (err) {
    console.error(`[TumpangFood Admin] Failed to create persistent Firestore backup:`, sanitizeErrorMessage(err.message));
    return false;
  }
}
async function restoreFirestoreBackup(backupId) {
  if (!adminDb || !isConfiguredWithServiceAccount) {
    return { success: false, restoredCount: 0, summary: {}, error: "Firebase Admin not configured" };
  }
  try {
    const backupRef = adminDb.collection("admin_backups").doc(backupId);
    const metaSnap = await backupRef.get();
    if (!metaSnap.exists) {
      return { success: false, restoredCount: 0, summary: {}, error: `Backup "${backupId}" tidak ditemukan.` };
    }
    const recordsSnap = await backupRef.collection("records").get();
    if (recordsSnap.empty) {
      return { success: true, restoredCount: 0, summary: {} };
    }
    const summary = {};
    const CHUNK_SIZE = 400;
    const docs = recordsSnap.docs;
    for (let i = 0; i < docs.length; i += CHUNK_SIZE) {
      const chunk = docs.slice(i, i + CHUNK_SIZE);
      const batch = adminDb.batch();
      for (const d of chunk) {
        const item = d.data();
        const targetCol = item.targetCollection;
        const docId = item.docId;
        const payload = item.payload;
        if (targetCol && docId && payload) {
          const targetRef = adminDb.collection(targetCol).doc(docId);
          batch.set(targetRef, removeUndefinedFields(payload), { merge: true });
          summary[targetCol] = (summary[targetCol] || 0) + 1;
        }
      }
      await batch.commit();
    }
    console.log(`[TumpangFood Admin] Restored ${docs.length} records from backup ${backupId}:`, summary);
    return { success: true, restoredCount: docs.length, summary };
  } catch (err) {
    const safeMsg = sanitizeErrorMessage(err.message || String(err));
    console.error(`[TumpangFood Admin] restoreFirestoreBackup failed for ${backupId}:`, safeMsg);
    return { success: false, restoredCount: 0, summary: {}, error: safeMsg };
  }
}
var import_fs2, import_path2, admin, import_app, import_firestore, adminApp, adminDb, isConfiguredWithServiceAccount, isFirestoreVerified, activeProjectId, activeClientEmailMasked, lastDiagnosticReason, lastDiagnosticDetail, lastRemediationStep, lastProbeResult, testMockState, PROBE_CACHE_TTL_MS;
var init_firebaseAdmin = __esm({
  "src/server/firebaseAdmin.ts"() {
    import_fs2 = __toESM(require("fs"), 1);
    import_path2 = __toESM(require("path"), 1);
    admin = __toESM(require("firebase-admin"), 1);
    import_app = require("firebase-admin/app");
    import_firestore = require("firebase-admin/firestore");
    init_config();
    adminApp = null;
    adminDb = null;
    isConfiguredWithServiceAccount = false;
    isFirestoreVerified = false;
    activeProjectId = "tumpanggo-70479";
    activeClientEmailMasked = null;
    lastDiagnosticReason = "MISSING_CREDENTIALS";
    lastDiagnosticDetail = "Variabel lingkungan FIREBASE_SERVICE_ACCOUNT_KEY belum dikonfigurasi di Environment Variables Vercel.";
    lastRemediationStep = "Tambahkan variabel lingkungan FIREBASE_SERVICE_ACCOUNT_KEY di Vercel Project Settings > Environment Variables berisi JSON Service Account dari Firebase Console.";
    lastProbeResult = null;
    initFirebaseAdmin();
    testMockState = null;
    PROBE_CACHE_TTL_MS = 1e4;
  }
});

// src/server/services/pushService.ts
var pushService_exports = {};
__export(pushService_exports, {
  pushService: () => pushService
});
var import_web_push, PushNotificationService, pushService;
var init_pushService = __esm({
  "src/server/services/pushService.ts"() {
    import_web_push = __toESM(require("web-push"), 1);
    init_config();
    init_db();
    PushNotificationService = class {
      constructor() {
        this.initialized = false;
      }
      ensureVapidConfigured() {
        if (this.initialized) return;
        if (vapidConfig.isConfigured) {
          try {
            import_web_push.default.setVapidDetails(
              vapidConfig.subject,
              vapidConfig.publicKey,
              vapidConfig.privateKey
            );
            this.initialized = true;
            console.log("[PushService] Web Push VAPID successfully initialized.");
          } catch (err) {
            console.warn("[PushService] Failed to set VAPID details:", err);
          }
        }
      }
      getVapidPublicKey() {
        return vapidConfig.publicKey;
      }
      /**
       * Send push notification to all devices registered for a specific Merchant
       */
      async sendToMerchant(merchantId, payload) {
        this.ensureVapidConfigured();
        const subs = foodDb.getPushSubscriptionsForEntity("MERCHANT", merchantId);
        if (!subs || subs.length === 0) {
          return { sent: 0, failed: 0 };
        }
        return this.dispatchToSubscriptions(subs, payload);
      }
      /**
       * Send push notification to all devices registered for a specific Driver
       */
      async sendToDriver(driverId, payload) {
        this.ensureVapidConfigured();
        const subs = foodDb.getPushSubscriptionsForEntity("DRIVER", driverId);
        if (!subs || subs.length === 0) {
          return { sent: 0, failed: 0 };
        }
        return this.dispatchToSubscriptions(subs, payload);
      }
      /**
       * Dedicated notification trigger when an order status reaches PAYMENT_VERIFIED
       */
      async notifyNewVerifiedOrder(order) {
        try {
          const orderNum = order.orderNumber || order.id;
          const itemCount = order.items.reduce((sum, it) => sum + it.quantity, 0);
          const subtotalFormatted = "Rp " + (order.subtotal || 0).toLocaleString("id-ID");
          await this.sendToMerchant(order.merchantId, {
            title: `\u{1F514} Pesanan Baru Masuk! #${orderNum}`,
            body: `${itemCount} item siap dimasak (${subtotalFormatted}) dari ${order.customerName}. Buka dapur TumpangGo sekarang!`,
            url: `/merchant?id=${encodeURIComponent(order.merchantId)}`,
            tag: `order-${order.id}`,
            data: {
              orderId: order.id,
              orderNumber: orderNum,
              role: "MERCHANT"
            }
          });
        } catch (err) {
          console.warn("[PushService] Error dispatching verified order notification:", err);
        }
      }
      /**
       * Dedicated notification trigger when a driver is assigned an order
       */
      async notifyDriverAssignedOrder(driverId, order) {
        try {
          const orderNum = order.orderNumber || order.id;
          await this.sendToDriver(driverId, {
            title: `\u{1F6F5} Tugas Pengantaran Baru! #${orderNum}`,
            body: `Antar pesanan dari ${order.merchantName} ke ${order.deliveryAddress}. Buka aplikasi driver Anda.`,
            url: `/driver?id=${encodeURIComponent(driverId)}`,
            tag: `driver-order-${order.id}`,
            data: {
              orderId: order.id,
              orderNumber: orderNum,
              role: "DRIVER"
            }
          });
        } catch (err) {
          console.warn("[PushService] Error dispatching driver assignment notification:", err);
        }
      }
      async dispatchToSubscriptions(subs, payload) {
        let sent = 0;
        let failed = 0;
        const notificationPayload = JSON.stringify(payload);
        await Promise.all(
          subs.map(async (sub) => {
            try {
              await import_web_push.default.sendNotification(
                sub.subscription,
                notificationPayload,
                {
                  TTL: 60 * 60,
                  // 1 hour TTL
                  urgency: "high"
                }
              );
              sent++;
            } catch (err) {
              failed++;
              const statusCode = err?.statusCode;
              if (statusCode === 404 || statusCode === 410) {
                console.log(`[PushService] Removing expired push subscription: ${sub.subscription.endpoint.slice(0, 40)}...`);
                foodDb.removePushSubscription(sub.subscription.endpoint);
              } else {
                console.warn(`[PushService] Push delivery warning (${statusCode || err?.message}):`, err?.message);
              }
            }
          })
        );
        return { sent, failed };
      }
    };
    pushService = new PushNotificationService();
  }
});

// src/server/db.ts
var import_fs3, import_path3, FOOD_DB_FILE, LEGACY_DB_FILE, safeFirestoreSetDoc, initialConfig, FoodDatabase, foodDb;
var init_db = __esm({
  "src/server/db.ts"() {
    import_fs3 = __toESM(require("fs"), 1);
    import_path3 = __toESM(require("path"), 1);
    init_types();
    init_config();
    init_auth();
    init_orderService();
    init_deliveryFee();
    init_firebaseAdmin();
    FOOD_DB_FILE = foodConfig.localDbFile;
    LEGACY_DB_FILE = foodConfig.legacyDbFile;
    safeFirestoreSetDoc = safeAdminSetDoc;
    initialConfig = {
      serviceFee: 2e3,
      deliveryFeePerKm: 1500,
      defaultDeliveryFee: 5e3,
      commissionPercent: 10,
      assignmentMode: "MANUAL" /* MANUAL */,
      qrisImage: "/qris-merchant.png",
      systemOpen: true
    };
    FoodDatabase = class {
      constructor() {
        this.isInitialized = false;
        this.lastFileMtime = 0;
        this.initPromise = null;
        this.lastSyncTimestamp = 0;
        this.CACHE_TTL_MS = 3e5;
        this.settlementMutex = Promise.resolve();
        this.data = {
          merchants: [],
          categories: [],
          menuItems: [],
          orders: [],
          drivers: [],
          settlements: [],
          auditLogs: [],
          systemConfig: initialConfig,
          partnerRegistrations: [],
          testimonials: [],
          pushSubscriptions: []
        };
        this.loadAndMigrate();
      }
      createBackup() {
        try {
          const backupPath = FOOD_DB_FILE + ".backup.json";
          import_fs3.default.writeFileSync(backupPath, JSON.stringify(this.data, null, 2), "utf-8");
          return true;
        } catch {
          return false;
        }
      }
      /**
       * Loads from food database file or migrates safely from backup / legacy file.
       */
      loadAndMigrate() {
        const backupPath = FOOD_DB_FILE + ".backup.json";
        try {
          if (import_fs3.default.existsSync(FOOD_DB_FILE)) {
            const content = import_fs3.default.readFileSync(FOOD_DB_FILE, "utf-8");
            if (content && content.trim().length > 10) {
              this.data = JSON.parse(content);
              this.ensureStructure();
              this.migratePasswords();
              this.migrateOrdersDeliveryFee();
              this.createBackup();
              console.log("[TumpangFood DB] Loaded primary operational state from tumpang_food_db.json");
              return;
            }
          }
          const candidateSeedPaths = [
            import_path3.default.join(process.cwd(), "tumpang_food_db.json"),
            import_path3.default.join("/var/task", "tumpang_food_db.json")
          ];
          for (const candidate of candidateSeedPaths) {
            if (FOOD_DB_FILE !== candidate && import_fs3.default.existsSync(candidate)) {
              try {
                const seedContent = import_fs3.default.readFileSync(candidate, "utf-8");
                if (seedContent && seedContent.trim().length > 10) {
                  this.data = JSON.parse(seedContent);
                  this.ensureStructure();
                  this.migratePasswords();
                  this.migrateOrdersDeliveryFee();
                  this.save();
                  this.createBackup();
                  console.log(`[TumpangFood DB] Successfully bootstrapped serverless database from ${candidate}`);
                  return;
                }
              } catch (e) {
                console.warn(`[TumpangFood DB] Failed reading seed database at ${candidate}:`, e.message);
              }
            }
          }
          if (import_fs3.default.existsSync(backupPath)) {
            console.warn("[TumpangFood DB] Primary database corrupted or empty. Recovering from backup snapshot...");
            const backupContent = import_fs3.default.readFileSync(backupPath, "utf-8");
            this.data = JSON.parse(backupContent);
            this.ensureStructure();
            this.save();
            console.log("[TumpangFood DB] Recovery from backup successful.");
            return;
          }
          if (import_fs3.default.existsSync(LEGACY_DB_FILE)) {
            console.log("[TumpangFood DB] Migrating data from legacy tumpang_db.json...");
            const legacyContent = import_fs3.default.readFileSync(LEGACY_DB_FILE, "utf-8");
            this.data = JSON.parse(legacyContent);
            this.ensureStructure();
            this.migratePasswords();
            this.save();
            this.createBackup();
            console.log("[TumpangFood DB] Migration complete! Saved to tumpang_food_db.json.");
          } else {
            this.data = {
              merchants: [],
              categories: [],
              menuItems: [],
              orders: [],
              drivers: [],
              settlements: [],
              auditLogs: [],
              systemConfig: { ...initialConfig },
              partnerRegistrations: [],
              testimonials: [],
              pushSubscriptions: []
            };
            this.bootstrapMasterAccount();
            this.save();
            this.createBackup();
          }
        } catch (err) {
          console.error("[TumpangFood DB] Error during load/migrate, attempting emergency recovery:", err);
          if (import_fs3.default.existsSync(backupPath)) {
            try {
              this.data = JSON.parse(import_fs3.default.readFileSync(backupPath, "utf-8"));
              this.ensureStructure();
              this.save();
              return;
            } catch {
            }
          }
          this.data = {
            merchants: [],
            categories: [],
            menuItems: [],
            orders: [],
            drivers: [],
            settlements: [],
            auditLogs: [],
            systemConfig: { ...initialConfig },
            partnerRegistrations: [],
            testimonials: [],
            pushSubscriptions: []
          };
          this.bootstrapMasterAccount();
          this.save();
        }
      }
      migratePasswords() {
        let changed = false;
        for (const m of this.data.merchants) {
          if (!m.password) {
            m.password = hashPassword(m.id + "123");
            changed = true;
          } else if (!m.password.startsWith("pbkdf2$")) {
            m.password = hashPassword(m.password);
            changed = true;
          }
        }
        for (const d of this.data.drivers) {
          if (!d.password) {
            d.password = hashPassword(d.id + "123");
            changed = true;
          } else if (!d.password.startsWith("pbkdf2$")) {
            d.password = hashPassword(d.password);
            changed = true;
          }
        }
        if (changed) this.save();
      }
      migrateOrdersDeliveryFee() {
        let changed = false;
        if (!Array.isArray(this.data.orders)) return;
        for (const order of this.data.orders) {
          if (!order) continue;
          const inTumpang = isDestinationInKecamatanTumpang({
            address: order.deliveryAddress,
            details: order.deliveryDetails,
            landmark: order.landmark,
            latitude: order.latitude,
            longitude: order.longitude
          });
          if (inTumpang) {
            if (order.deliveryFee !== FLAT_TUMPANG_DELIVERY_FEE) {
              console.log(`[TumpangFood DB Migration] Updating order #${order.id} delivery fee from ${order.deliveryFee} to flat ${FLAT_TUMPANG_DELIVERY_FEE}`);
              order.deliveryFee = FLAT_TUMPANG_DELIVERY_FEE;
              order.total = order.subtotal + FLAT_TUMPANG_DELIVERY_FEE + order.serviceFee + (order.uniqueCode || 0);
              changed = true;
            }
          }
        }
        if (changed) {
          this.save();
          console.log("[TumpangFood DB Migration] Successfully migrated orders to flat Rp 5.000 for Kecamatan Tumpang.");
        }
      }
      ensureStructure() {
        if (!this.data.merchants) this.data.merchants = [];
        if (!this.data.categories) this.data.categories = [];
        if (!this.data.menuItems) this.data.menuItems = [];
        if (!this.data.orders) this.data.orders = [];
        if (!this.data.drivers) this.data.drivers = [];
        if (!this.data.settlements) this.data.settlements = [];
        if (!this.data.partnerRegistrations) this.data.partnerRegistrations = [];
        if (!this.data.testimonials) this.data.testimonials = [];
        if (!this.data.pushSubscriptions) this.data.pushSubscriptions = [];
        if (!this.data.systemConfig) {
          this.data.systemConfig = initialConfig;
        } else {
          if (!this.data.systemConfig.assignmentMode || this.data.systemConfig.assignmentMode === "AUTOMATIC" /* AUTOMATIC */) {
            this.data.systemConfig.assignmentMode = "MANUAL" /* MANUAL */;
          }
          if (!this.data.systemConfig.qrisImage || this.data.systemConfig.qrisImage.includes("unsplash")) {
            this.data.systemConfig.qrisImage = "/qris-merchant.png";
          }
        }
        if (!this.data.drivers) this.data.drivers = [];
        if (!this.data.menuItems) this.data.menuItems = [];
        this.data.menuItems = this.data.menuItems.filter((i) => typeof i.merchantId === "string" && i.merchantId !== "m1");
        this.data.merchants.forEach((m) => {
          if (!m.qrisImage || m.qrisImage.includes("unsplash")) {
            m.qrisImage = "/qris-merchant.png";
          }
        });
        let ordersBackfilled = false;
        for (const o of this.data.orders) {
          if (!o.orderNumber) {
            const cleanId = (o.id || "").replace(/^ord_/, "").toUpperCase();
            o.orderNumber = `TF-${cleanId}`;
            ordersBackfilled = true;
          }
          if (o.receipt && !o.receipt.orderNumber) {
            o.receipt.orderNumber = o.orderNumber;
            ordersBackfilled = true;
          }
        }
        if (ordersBackfilled) {
          this.save();
        }
        this.bootstrapMasterAccount();
      }
      seedInitial() {
        this.data.systemConfig = { ...initialConfig };
        this.bootstrapMasterAccount();
        this.data.merchants = [];
        this.data.categories = [];
        this.data.menuItems = [];
        this.data.drivers = [];
        this.data.orders = [];
        this.data.settlements = [];
        this.data.partnerRegistrations = [];
        this.data.testimonials = [];
        this.data.auditLogs = [];
        this.data.pushSubscriptions = [];
      }
      /**
       * Resets all operational dummy and test data to a clean initial state.
       * Creates a timestamped backup before clearing data.
       * Preserves system configuration and Master Account administrative credentials.
       */
      resetAllOperationalData() {
        const backupPath = `${FOOD_DB_FILE}.backup_${Date.now()}.json`;
        try {
          if (import_fs3.default.existsSync(FOOD_DB_FILE)) {
            import_fs3.default.copyFileSync(FOOD_DB_FILE, backupPath);
          }
        } catch (e) {
          console.warn("[TumpangFood DB] Backup warning:", e.message);
        }
        this.data.merchants = [];
        this.data.categories = [];
        this.data.menuItems = [];
        this.data.orders = [];
        this.data.drivers = [];
        this.data.settlements = [];
        this.data.partnerRegistrations = [];
        this.data.testimonials = [];
        this.data.auditLogs = [];
        this.data.pushSubscriptions = [];
        this.bootstrapMasterAccount();
        this.save();
        console.log("[TumpangFood DB] All operational dummy/test data has been successfully reset to empty state.");
        return {
          success: true,
          message: "Seluruh data dummy dan operasional berhasil dibersihkan. Akun admin dan konfigurasi sistem tetap dipertahankan.",
          backupPath
        };
      }
      /**
       * Generates a preview plan of Clean Slate for Merchant & Catalog data without modifying anything.
       * Authoritatively queries Cloud Firestore directly when connected, preventing false-zero reporting.
       */
      async getCleanSlatePlan() {
        const creds = getMasterAccountCredentials();
        const probe = await testFirestoreConnection();
        const adminDb2 = getAdminDb();
        if (foodConfig.isProduction && !probe.connected) {
          throw new Error(`[Produksi] Koneksi Cloud Firestore tidak aktif (${probe.diagnosticReason}: ${probe.diagnosticDetail}). Dokumen produksi tidak dapat dibaca.`);
        }
        let merchantsCount = 0;
        let categoriesCount = 0;
        let menuItemsCount = 0;
        let merchantPartnerRegistrationsCount = 0;
        let driversCount = 0;
        let ordersCount = 0;
        let settlementsCount = 0;
        let testimonialsCount = 0;
        let driverPartnerRegistrationsCount = 0;
        if (probe.connected && adminDb2) {
          const [
            mCount,
            cCount,
            iCount,
            mrCount,
            dCount,
            oCount,
            sCount,
            tCount,
            drCount
          ] = await Promise.all([
            safeAdminCountDocs("merchants"),
            safeAdminCountDocs("categories"),
            safeAdminCountDocs("menuItems"),
            safeAdminCountDocs("partnerRegistrations", (ref) => ref.where("type", "==", "MERCHANT")),
            safeAdminCountDocs("drivers"),
            safeAdminCountDocs("orders"),
            safeAdminCountDocs("settlements"),
            safeAdminCountDocs("testimonials"),
            safeAdminCountDocs("partnerRegistrations", (ref) => ref.where("type", "==", "DRIVER"))
          ]);
          merchantsCount = mCount ?? 0;
          categoriesCount = cCount ?? 0;
          menuItemsCount = iCount ?? 0;
          merchantPartnerRegistrationsCount = mrCount ?? 0;
          driversCount = dCount ?? 0;
          ordersCount = oCount ?? 0;
          settlementsCount = sCount ?? 0;
          testimonialsCount = tCount ?? 0;
          driverPartnerRegistrationsCount = drCount ?? 0;
        } else {
          merchantsCount = this.data.merchants.length;
          categoriesCount = this.data.categories.length;
          menuItemsCount = this.data.menuItems.length;
          merchantPartnerRegistrationsCount = this.data.partnerRegistrations.filter((r) => r.type === "MERCHANT").length;
          driversCount = this.data.drivers.length;
          ordersCount = this.data.orders.length;
          settlementsCount = this.data.settlements.length;
          testimonialsCount = this.data.testimonials.length;
          driverPartnerRegistrationsCount = this.data.partnerRegistrations.filter((r) => r.type === "DRIVER").length;
        }
        return {
          targetProjectId: probe.projectId || foodConfig.projectId || "tumpanggo-70479",
          targetDatabaseId: probe.databaseId || foodConfig.databaseId || "(default)",
          storageMode: probe.connected ? "cloud_firestore_verified" : "development_local_snapshot",
          liveCloudConnected: probe.connected,
          isProduction: foodConfig.isProduction,
          authIdentity: probe.authIdentity,
          diagnosticReason: probe.diagnosticReason,
          diagnosticDetail: probe.connected ? "Terhubung langsung ke Cloud Firestore. Hitungan dokumen berasal dari data cloud aktual." : `Server berjalan dalam mode pengembangan lokal (${probe.diagnosticReason}). Hitungan berasal dari snapshot lokal development, BUKAN database produksi.`,
          remediationStep: probe.remediationStep,
          toPurge: {
            merchantsCount,
            menuItemsCount,
            merchantPartnerRegistrationsCount,
            ordersCount,
            settlementsCount
          },
          toPreserve: {
            categoriesCount,
            driversCount,
            testimonialsCount,
            driverPartnerRegistrationsCount,
            systemConfigPreserved: true,
            masterAccountEmail: creds.email,
            flatDeliveryFee: this.data.systemConfig?.defaultDeliveryFee || 5e3,
            commissionPercent: this.data.systemConfig?.commissionPercent || 10
          }
        };
      }
      /**
       * Dedicated Clean Slate procedure for Merchant & Food Catalog data.
       * Completely and idempotently purges:
       * - merchants (and any nested subcollections)
       * - categories
       * - menuItems
       * - merchant partnerRegistrations
       * Creates a persistent Cloud Firestore backup in /admin_backups/{backupId} prior to purging.
       * Preserves:
       * - systemConfig (Master account credentials, delivery fee flat 5000, 10% commission, service fees)
       * - drivers
       * - orders (historical records)
       * - settlements
       * - testimonials
       */
      async cleanSlateMerchantCatalog(actorId = "master-admin") {
        await this.ensureProductionCloudReady("Clean Slate Merchant & Katalog Makanan");
        const localBackupPath = `${FOOD_DB_FILE}.cleanslate_backup_${Date.now()}.json`;
        try {
          if (import_fs3.default.existsSync(FOOD_DB_FILE)) {
            import_fs3.default.copyFileSync(FOOD_DB_FILE, localBackupPath);
          }
        } catch (e) {
          console.warn("[TumpangFood CleanSlate] Local backup warning:", e.message);
        }
        const initialMerchantCount = this.data.merchants.length;
        const initialCategoryCount = this.data.categories.length;
        const initialMenuItemCount = this.data.menuItems.length;
        const initialMerchantRegCount = this.data.partnerRegistrations.filter((r) => r.type === "MERCHANT").length;
        const initialOrderCount = this.data.orders.length;
        const initialSettlementCount = this.data.settlements.length;
        let firestorePurgeResult = void 0;
        let cloudBackupCreated = false;
        const cloudBackupId = `cleanslate_backup_${Date.now()}`;
        const adminDb2 = getAdminDb();
        if (isFirestoreAdminConfigured() && adminDb2) {
          try {
            const [merchantsSnap, categoriesSnap, menuItemsSnap, regsSnap, ordersSnap, settlementsSnap] = await Promise.all([
              adminDb2.collection("merchants").get(),
              adminDb2.collection("categories").get(),
              adminDb2.collection("menuItems").get(),
              adminDb2.collection("partnerRegistrations").where("type", "==", "MERCHANT").get(),
              adminDb2.collection("orders").get(),
              adminDb2.collection("settlements").get()
            ]);
            cloudBackupCreated = await createFirestoreBackup(
              cloudBackupId,
              {
                actorId,
                type: "PRE_CLEANSLATE_MERCHANT_CATALOG",
                merchantsCount: merchantsSnap.size,
                categoriesCount: categoriesSnap.size,
                menuItemsCount: menuItemsSnap.size,
                registrationsCount: regsSnap.size,
                ordersCount: ordersSnap.size,
                settlementsCount: settlementsSnap.size,
                timestamp: (/* @__PURE__ */ new Date()).toISOString()
              },
              {
                merchants: merchantsSnap.docs.map((d) => ({ id: d.id, ...d.data() || {} })),
                categories: categoriesSnap.docs.map((d) => ({ id: d.id, ...d.data() || {} })),
                menuItems: menuItemsSnap.docs.map((d) => ({ id: d.id, ...d.data() || {} })),
                partnerRegistrations: regsSnap.docs.map((d) => ({ id: d.id, ...d.data() || {} })),
                orders: ordersSnap.docs.map((d) => ({ id: d.id, ...d.data() || {} })),
                settlements: settlementsSnap.docs.map((d) => ({ id: d.id, ...d.data() || {} }))
              }
            );
            if (!cloudBackupCreated) {
              throw new Error("Gagal membuat cloud backup Firestore sebelum pembersihan. Operasi dibatalkan demi keamanan data.");
            }
            const [mDel, iDel, rDel, oDel, sDel] = await Promise.all([
              safeAdminBatchDelete("merchants"),
              safeAdminBatchDelete("menuItems"),
              safeAdminBatchDeleteQuery("partnerRegistrations", "type", "==", "MERCHANT"),
              safeAdminBatchDelete("orders"),
              safeAdminBatchDelete("settlements")
            ]);
            if (!mDel.success || !iDel.success || !rDel.success || !oDel.success || !sDel.success) {
              const failMsg = [mDel.error, iDel.error, rDel.error, oDel.error, sDel.error].filter(Boolean).join("; ");
              throw new Error(`Sebagian operasi batch delete Firestore gagal: ${failMsg || "Firestore batch failure"}`);
            }
            firestorePurgeResult = {
              merchantsDeleted: mDel.count,
              menuItemsDeleted: iDel.count,
              merchantRegistrationsDeleted: rDel.count,
              ordersDeleted: oDel.count,
              settlementsDeleted: sDel.count
            };
            console.log("[TumpangFood CleanSlate] Firestore purge completed successfully:", firestorePurgeResult);
          } catch (fsErr) {
            console.error("[TumpangFood CleanSlate] Error during Firestore backup/purge:", fsErr.message);
            throw new Error(`[Gagal Clean Slate] ${fsErr.message}`);
          }
        }
        this.data.merchants = [];
        this.data.menuItems = [];
        this.data.partnerRegistrations = this.data.partnerRegistrations.filter((r) => r.type !== "MERCHANT");
        this.data.orders = [];
        this.data.settlements = [];
        this.save();
        this.createBackup();
        this.log(
          actorId,
          `Clean Slate executed: Purged ${initialMerchantCount} merchants, ${initialMenuItemCount} menu items, ${initialMerchantRegCount} merchant registrations, ${initialOrderCount} orders, and ${initialSettlementCount} settlements. Categories preserved (${this.data.categories.length}). Cloud backup: ${cloudBackupCreated ? cloudBackupId : "N/A"}.`,
          "MASTER_ADMIN"
        );
        return {
          success: true,
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          targetProjectId: foodConfig.projectId || "tumpanggo-70479",
          targetDatabaseId: foodConfig.databaseId || "(default)",
          purged: {
            merchants: firestorePurgeResult ? firestorePurgeResult.merchantsDeleted : initialMerchantCount,
            menuItems: firestorePurgeResult ? firestorePurgeResult.menuItemsDeleted : initialMenuItemCount,
            merchantRegistrations: firestorePurgeResult ? firestorePurgeResult.merchantRegistrationsDeleted : initialMerchantRegCount,
            orders: firestorePurgeResult ? firestorePurgeResult.ordersDeleted : initialOrderCount,
            settlements: firestorePurgeResult ? firestorePurgeResult.settlementsDeleted : initialSettlementCount
          },
          preserved: {
            categories: this.data.categories.length,
            drivers: this.data.drivers.length,
            testimonials: this.data.testimonials.length,
            driverRegistrations: this.data.partnerRegistrations.filter((r) => r.type === "DRIVER").length
          },
          cloudBackupCreated,
          cloudBackupId: cloudBackupCreated ? cloudBackupId : void 0,
          firestorePurgeResult,
          localBackupPath
        };
      }
      /**
       * Restores merchant catalog from a previous persistent cloud backup in /admin_backups/{backupId}.
       */
      async restoreMerchantCatalogFromBackup(actorId = "master-admin", backupId) {
        await this.ensureProductionCloudReady("Pemulihan Katalog Merchant dari Backup");
        const result = await restoreFirestoreBackup(backupId);
        if (!result.success) {
          throw new Error(`Gagal memulihkan backup "${backupId}": ${result.error || "Unknown error"}`);
        }
        await this.init();
        this.log(actorId, `Restored ${result.restoredCount} catalog records from backup ${backupId}`, "MASTER_ADMIN");
        return {
          success: true,
          restoredCount: result.restoredCount,
          summary: result.summary
        };
      }
      save() {
        try {
          const dir = import_path3.default.dirname(FOOD_DB_FILE);
          if (!import_fs3.default.existsSync(dir)) {
            import_fs3.default.mkdirSync(dir, { recursive: true });
          }
          import_fs3.default.writeFileSync(FOOD_DB_FILE, JSON.stringify(this.data, null, 2), "utf-8");
          try {
            this.lastFileMtime = import_fs3.default.statSync(FOOD_DB_FILE).mtimeMs;
          } catch {
          }
        } catch (e) {
          if (e.code === "EROFS") {
            console.warn("[TumpangFood DB] Read-only filesystem detected. Disk write skipped; persisting in-memory and Firestore.");
          } else {
            console.error("[TumpangFood DB] Failed to save database file:", e);
          }
        }
      }
      /**
       * Reload database state from disk if file was updated by another process/worker
       */
      reloadFromDiskIfNeeded() {
        try {
          if (import_fs3.default.existsSync(FOOD_DB_FILE)) {
            const stats = import_fs3.default.statSync(FOOD_DB_FILE);
            if (stats.mtimeMs > this.lastFileMtime) {
              const content = import_fs3.default.readFileSync(FOOD_DB_FILE, "utf-8");
              if (content && content.trim().length > 10) {
                const parsed = JSON.parse(content);
                if (parsed && typeof parsed === "object") {
                  if (Array.isArray(parsed.orders)) this.data.orders = parsed.orders;
                  if (Array.isArray(parsed.merchants)) this.data.merchants = parsed.merchants;
                  if (Array.isArray(parsed.drivers)) this.data.drivers = parsed.drivers;
                  if (Array.isArray(parsed.categories)) this.data.categories = parsed.categories;
                  if (Array.isArray(parsed.menuItems)) this.data.menuItems = parsed.menuItems;
                  if (Array.isArray(parsed.settlements)) this.data.settlements = parsed.settlements;
                  if (Array.isArray(parsed.partnerRegistrations)) this.data.partnerRegistrations = parsed.partnerRegistrations;
                  if (Array.isArray(parsed.testimonials)) this.data.testimonials = parsed.testimonials;
                  if (parsed.systemConfig) this.data.systemConfig = parsed.systemConfig;
                  this.lastFileMtime = stats.mtimeMs;
                  console.log(`[TumpangFood DB] Auto-reloaded ${this.data.orders.length} orders from disk snapshot.`);
                  return true;
                }
              }
            }
          }
        } catch (e) {
          console.warn("[TumpangFood DB] Error during disk reload check:", e.message);
        }
        return false;
      }
      // 5 minutes cache TTL to avoid burning Firestore read quotas
      async ensureInitialized(forceRefresh = false) {
        if (this.isInitialized && !forceRefresh && Date.now() - this.lastSyncTimestamp < this.CACHE_TTL_MS) {
          return;
        }
        if (!this.initPromise || forceRefresh) {
          this.initPromise = (async () => {
            try {
              await this.init();
              this.lastSyncTimestamp = Date.now();
              this.isInitialized = true;
            } catch (err) {
              this.isInitialized = false;
              throw err;
            } finally {
              this.initPromise = null;
            }
          })();
        }
        return this.initPromise;
      }
      /**
       * Diagnostic assessment of runtime storage status: Cloud Firestore vs Local Resilient Snapshot.
       */
      async getStorageStatus() {
        const firestoreCheck = await testFirestoreConnection();
        const isConnected = firestoreCheck.connected;
        return {
          storageMode: isConnected ? "cloud_firestore_active" : "local_resilient_snapshot",
          storageType: isConnected ? "Cloud Firestore (Production Primary)" : "Local File JSON Snapshot (Development/Degraded Fallback)",
          isUsingFallback: !isConnected,
          activePersistenceType: isConnected ? "CLOUD_FIRESTORE" : "LOCAL_JSON_SNAPSHOT",
          databaseId: firestoreCheck.databaseId,
          projectId: firestoreCheck.projectId,
          isProduction: foodConfig.isProduction,
          firestoreConfigured: isFirestoreAdminConfigured(),
          usingServiceAccount: firestoreCheck.usingServiceAccount,
          authIdentity: firestoreCheck.authIdentity,
          liveCloudConnected: isConnected,
          canRead: isConnected ? true : true,
          // Local read available in degraded/dev
          canWrite: isConnected ? true : !foodConfig.isProduction,
          // Write strictly prohibited in production if cloud disconnected
          diagnosticReason: firestoreCheck.diagnosticReason,
          diagnosticDetail: firestoreCheck.diagnosticDetail,
          remediationStep: firestoreCheck.remediationStep,
          cloudError: firestoreCheck.error
        };
      }
      /**
       * Synchronize state with Firebase Firestore as Primary Storage.
       */
      async init() {
        if (!isUsingServiceAccount() || !getAdminDb()) {
          const diag = getFirestoreDiagnosticStatus();
          console.warn(`[TumpangFood DB] Firestore Admin SDK tidak terkonfigurasi (${diag.reason}), beroperasi dengan penyimpanan lokal.`);
          this.isInitialized = true;
          return;
        }
        const probe = await testFirestoreConnection();
        if (!probe.connected) {
          console.warn(`[TumpangFood DB] Firestore Cloud belum terhubung (${probe.diagnosticReason}: ${probe.error || probe.diagnosticDetail}). Beroperasi dengan penyimpanan lokal.`);
          this.isInitialized = true;
          return;
        }
        this.isInitialized = true;
        try {
          console.log("[TumpangFood DB] Syncing with Firestore database via Admin SDK:", foodConfig.databaseId);
          try {
            const remoteConfig = await safeAdminGetDoc("systemConfig", "config_1");
            if (remoteConfig) {
              this.data.systemConfig = { ...initialConfig, ...remoteConfig };
              this.bootstrapMasterAccount();
            } else {
              await safeAdminSetDoc("systemConfig", "config_1", this.data.systemConfig);
            }
          } catch (e) {
            console.warn("[TumpangFood DB] Failed to sync systemConfig with Firestore:", e.message);
          }
          try {
            const remoteMerchants = await safeAdminGetDocs("merchants");
            this.data.merchants = remoteMerchants || [];
            this.ensureStructure();
          } catch (e) {
            console.warn("[TumpangFood DB] Failed to sync merchants with Firestore:", e.message);
          }
          try {
            const remoteCats = await safeAdminGetDocs("categories");
            this.data.categories = remoteCats || [];
          } catch (e) {
            console.warn("[TumpangFood DB] Failed to sync categories with Firestore:", e.message);
          }
          try {
            const remoteItems = await safeAdminGetDocs("menuItems");
            this.data.menuItems = remoteItems || [];
          } catch (e) {
            console.warn("[TumpangFood DB] Failed to sync menuItems with Firestore:", e.message);
          }
          try {
            const remoteDrivers = await safeAdminGetDocs("drivers");
            if (remoteDrivers.length > 0) {
              this.data.drivers = remoteDrivers;
            }
          } catch (e) {
            console.warn("[TumpangFood DB] Failed to sync drivers with Firestore:", e.message);
          }
          try {
            const remoteOrders = await safeAdminGetDocs("orders");
            if (remoteOrders.length > 0) {
              this.data.orders = remoteOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            }
          } catch (e) {
            console.warn("[TumpangFood DB] Failed to sync orders with Firestore:", e.message);
          }
          try {
            const remoteSets = await safeAdminGetDocs("settlements");
            if (remoteSets.length > 0) {
              this.data.settlements = remoteSets;
            }
          } catch (e) {
            console.warn("[TumpangFood DB] Failed to sync settlements with Firestore:", e.message);
          }
          try {
            const remoteRegs = await safeAdminGetDocs("partnerRegistrations");
            if (remoteRegs.length > 0) {
              this.data.partnerRegistrations = remoteRegs;
            }
          } catch (e) {
            console.warn("[TumpangFood DB] Failed to sync partnerRegistrations with Firestore:", e.message);
          }
          try {
            const remoteTestis = await safeAdminGetDocs("testimonials");
            if (remoteTestis.length > 0) {
              this.data.testimonials = remoteTestis;
            }
          } catch (e) {
            console.warn("[TumpangFood DB] Failed to sync testimonials with Firestore:", e.message);
          }
          try {
            const remoteLogs = await safeAdminGetDocs("auditLogs", (ref) => ref.orderBy("createdAt", "desc").limit(50));
            if (remoteLogs.length > 0) {
              this.data.auditLogs = remoteLogs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 500);
            }
          } catch (e) {
            console.warn("[TumpangFood DB] Failed to sync auditLogs with Firestore:", e.message);
          }
          this.save();
          this.createBackup();
          console.log("[TumpangFood DB] Firestore Admin synchronization successful (Primary Store Active).");
        } catch (err) {
          if (foodConfig.isProduction) {
            this.isInitialized = false;
            throw new Error(`[Produksi] Sinkronisasi data dengan Firestore Cloud gagal: ${err.message}. Operasi database ditolak demi integritas data.`);
          }
          console.error("[TumpangFood DB] Firestore sync failed, continuing locally:", err.message);
        }
      }
      // --- LOGGING ---
      log(userId, details, role = "SYSTEM") {
        const logItem = {
          id: "log_" + Math.random().toString(36).substring(2, 9),
          action: details.split(" ")[0] || "ACTION",
          userId,
          role,
          details,
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        this.data.auditLogs.unshift(logItem);
        if (this.data.auditLogs.length > 250) {
          this.data.auditLogs = this.data.auditLogs.slice(0, 250);
        }
        this.save();
        safeFirestoreSetDoc("auditLogs", logItem.id, logItem);
        return logItem;
      }
      addAuditLog(entry) {
        const userId = entry.performedBy || entry.userId || "SYSTEM";
        const details = entry.details || (entry.action ? `${entry.action}: ${entry.orderId || ""}` : "Audit log");
        const role = entry.role || "SYSTEM";
        return this.log(userId, details, role);
      }
      getLogs() {
        return this.data.auditLogs;
      }
      // --- MASTER ACCOUNT CREDENTIALS ---
      getMasterAccount() {
        try {
          if (import_fs3.default.existsSync(FOOD_DB_FILE)) {
            const stats = import_fs3.default.statSync(FOOD_DB_FILE);
            if (stats.mtimeMs > this.lastFileMtime) {
              const content = import_fs3.default.readFileSync(FOOD_DB_FILE, "utf-8");
              const parsed = JSON.parse(content);
              if (parsed?.systemConfig?.masterAccount) {
                if (!this.data.systemConfig) {
                  this.data.systemConfig = { ...initialConfig };
                }
                this.data.systemConfig.masterAccount = parsed.systemConfig.masterAccount;
                this.lastFileMtime = stats.mtimeMs;
              }
            }
          }
        } catch {
        }
        if (!this.data.systemConfig?.masterAccount) {
          this.bootstrapMasterAccount();
        }
        return this.data.systemConfig?.masterAccount;
      }
      bootstrapMasterAccount() {
        if (!this.data.systemConfig) {
          this.data.systemConfig = { ...initialConfig };
        }
        const creds = getMasterAccountCredentials();
        const currentMaster = this.data.systemConfig.masterAccount;
        if (currentMaster?.passwordHash && currentMaster.passwordHash.startsWith("pbkdf2$")) {
          if (creds.hasExplicitEnv && creds.password && !verifyPassword(creds.password, currentMaster.passwordHash).valid) {
            this.data.systemConfig.masterAccount = {
              email: creds.email,
              passwordHash: hashPassword(creds.password),
              updatedAt: (/* @__PURE__ */ new Date()).toISOString()
            };
            this.save();
            console.log(`[TumpangFood DB] Master Account PBKDF2 hash synchronized from explicit environment variable (${creds.email}).`);
          }
          return;
        }
        const initialPass = creds.password || (foodConfig.isProduction ? "" : "TumpangGoAdmin#2026");
        if (initialPass) {
          this.data.systemConfig.masterAccount = {
            email: creds.email || "tumpanggo@gmail.com",
            passwordHash: hashPassword(initialPass),
            updatedAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          this.save();
          console.log(`[TumpangFood DB] Master Account PBKDF2 hash initialized for ${creds.email || "tumpanggo@gmail.com"}.`);
        }
      }
      updateMasterAccountPassword(newPlaintext) {
        if (!this.data.systemConfig) {
          this.data.systemConfig = { ...initialConfig };
        }
        const { email } = getMasterAccountCredentials();
        const cleanPlaintext = newPlaintext.trim();
        const hashed = hashPassword(cleanPlaintext);
        this.data.systemConfig.masterAccount = {
          email,
          passwordHash: hashed,
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        this.save();
        try {
          safeFirestoreSetDoc("systemConfig", "config_1", this.data.systemConfig).catch(() => {
          });
        } catch {
        }
        return true;
      }
      updateMasterAccountWithHash(email, passwordHash) {
        if (!this.data.systemConfig) {
          this.data.systemConfig = { ...initialConfig };
        }
        this.data.systemConfig.masterAccount = {
          email: email.trim().toLowerCase(),
          passwordHash,
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        this.save();
        try {
          safeFirestoreSetDoc("systemConfig", "config_1", this.data.systemConfig).catch(() => {
          });
        } catch {
        }
        return true;
      }
      // --- PRODUCTION PERSISTENCE SAFEGUARD ---
      async ensureProductionCloudReady(actionName) {
        if (!foodConfig.isProduction) return;
        if (!isFirestoreAdminConfigured()) {
          throw new Error(`[Produksi] Cloud Firestore belum dikonfigurasi. Operasi "${actionName}" dibatalkan demi integritas data.`);
        }
        const probe = await testFirestoreConnection();
        if (!probe.connected) {
          throw new Error(`[Produksi] Koneksi cloud Firestore tidak tersedia (${probe.diagnosticReason}). Operasi "${actionName}" dibatalkan demi integritas data.`);
        }
      }
      // --- CONFIG ---
      getConfig() {
        return this.data.systemConfig;
      }
      getSystemConfig() {
        return this.getConfig();
      }
      async updateConfig(userId, updates) {
        await this.ensureProductionCloudReady("Pembaruan Konfigurasi");
        const prevConfig = { ...this.data.systemConfig };
        this.data.systemConfig = { ...this.data.systemConfig, ...updates };
        this.save();
        this.log(userId, `Updated system configuration`, "ADMIN");
        if (foodConfig.isProduction) {
          const persisted = await safeFirestoreSetDoc("systemConfig", "config_1", this.data.systemConfig);
          if (!persisted) {
            this.data.systemConfig = prevConfig;
            this.save();
            throw new Error("[Produksi] Gagal menyimpan konfigurasi sistem ke cloud Firestore. Perubahan dibatalkan demi integritas data.");
          }
        } else {
          safeFirestoreSetDoc("systemConfig", "config_1", this.data.systemConfig);
        }
        return this.data.systemConfig;
      }
      // --- MERCHANTS ---
      getMerchants() {
        this.reloadFromDiskIfNeeded();
        if (!this.data || !Array.isArray(this.data.merchants)) {
          return [];
        }
        return this.data.merchants.filter((m) => Boolean(m && typeof m === "object")).map((m) => {
          const { password, ...safe } = m;
          if (!safe.qrisImage || safe.qrisImage.includes("unsplash")) {
            safe.qrisImage = this.data.systemConfig?.qrisImage || "/qris-merchant.png";
          }
          const menuCount = Array.isArray(this.data.menuItems) ? this.data.menuItems.filter((item) => item && item.merchantId === m.id).length : 0;
          return {
            ...safe,
            menuCount,
            id: safe.id || "m_unknown"
          };
        });
      }
      getMerchantById(id) {
        this.reloadFromDiskIfNeeded();
        if (!this.data || !Array.isArray(this.data.merchants) || !id) return void 0;
        const m = this.data.merchants.find((m2) => m2 && m2.id === id);
        if (!m) return void 0;
        const { password, ...safe } = m;
        if (!safe.qrisImage || safe.qrisImage.includes("unsplash")) {
          safe.qrisImage = this.data.systemConfig?.qrisImage || "/qris-merchant.png";
        }
        const menuCount = Array.isArray(this.data.menuItems) ? this.data.menuItems.filter((item) => item && item.merchantId === m.id).length : 0;
        return {
          ...safe,
          menuCount
        };
      }
      getMerchantByEmailOrPhone(identifier) {
        if (!identifier || !this.data || !Array.isArray(this.data.merchants)) return void 0;
        const clean = identifier.trim().toLowerCase();
        const rawClean = identifier.trim();
        const cleanNumbers = identifier.replace(/[^0-9]/g, "");
        const altPhone = cleanNumbers.startsWith("62") ? "0" + cleanNumbers.slice(2) : cleanNumbers.startsWith("0") ? "62" + cleanNumbers.slice(1) : "";
        return this.data.merchants.find((m) => {
          if (!m) return false;
          const mId = typeof m.id === "string" ? m.id.toLowerCase() : "";
          const mEmail = typeof m.email === "string" ? m.email.trim().toLowerCase() : "";
          const mPhone = typeof m.phone === "string" ? m.phone.trim() : "";
          const mPhoneNumbers = mPhone.replace(/[^0-9]/g, "");
          const matchId = Boolean(mId && mId === clean);
          const matchEmail = Boolean(mEmail && mEmail === clean);
          const matchPhone = Boolean(mPhone && (mPhone === rawClean || mPhone.toLowerCase() === clean));
          const matchCleanPhone = Boolean(cleanNumbers.length >= 8 && mPhoneNumbers && (mPhoneNumbers === cleanNumbers || altPhone && mPhoneNumbers === altPhone));
          return matchId || matchEmail || matchPhone || matchCleanPhone;
        });
      }
      async createMerchant(userId, merchantData) {
        await this.ensureProductionCloudReady("Pendaftaran Merchant");
        if (!merchantData.name || !merchantData.name.trim()) {
          throw new Error("Nama toko / usaha wajib diisi.");
        }
        if (!merchantData.ownerName || !merchantData.ownerName.trim()) {
          throw new Error("Nama pemilik wajib diisi.");
        }
        if (!merchantData.phone || !merchantData.phone.trim()) {
          throw new Error("Nomor telepon / WhatsApp wajib diisi.");
        }
        if (!merchantData.address || !merchantData.address.trim()) {
          throw new Error("Alamat lengkap toko wajib diisi.");
        }
        if (merchantData.email && merchantData.email.trim()) {
          const cleanEmail = merchantData.email.trim().toLowerCase();
          const existing = this.data.merchants.find((m) => m && m.email?.trim().toLowerCase() === cleanEmail);
          if (existing) {
            throw new Error(`Email "${cleanEmail}" sudah digunakan oleh toko "${existing.name}".`);
          }
        }
        const newMerchant = {
          name: merchantData.name.trim(),
          ownerName: merchantData.ownerName.trim(),
          phone: merchantData.phone.trim(),
          address: merchantData.address.trim(),
          latitude: merchantData.latitude || -7.9942,
          longitude: merchantData.longitude || 112.7667,
          openTime: merchantData.openTime || "08:00",
          closeTime: merchantData.closeTime || "21:00",
          bankName: merchantData.bankName || "Bank BRI",
          bankAccount: merchantData.bankAccount || "",
          bankHolder: merchantData.bankHolder || merchantData.ownerName.trim(),
          active: merchantData.active !== void 0 ? Boolean(merchantData.active) : true,
          rating: 5,
          cookTimeEstimate: merchantData.cookTimeEstimate || "15-30 min",
          image: merchantData.image || "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=500&auto=format&fit=crop&q=60",
          bannerImage: merchantData.bannerImage || "",
          description: merchantData.description || `Mitra Kuliner ${merchantData.name.trim()} Kecamatan Tumpang`,
          category: merchantData.category || "Kuliner Tumpang",
          email: merchantData.email ? merchantData.email.trim().toLowerCase() : void 0,
          isActivated: merchantData.isActivated !== void 0 ? merchantData.isActivated : true,
          businessPhoto: merchantData.businessPhoto,
          idPhoto: merchantData.idPhoto,
          contractPhoto: merchantData.contractPhoto,
          id: "m_" + Math.random().toString(36).substring(2, 9),
          qrisImage: merchantData.qrisImage || this.data.systemConfig?.qrisImage || "/qris-merchant.png",
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        if (merchantData.password) {
          newMerchant.password = merchantData.password.startsWith("pbkdf2$") ? merchantData.password : hashPassword(merchantData.password);
        } else {
          const defaultPass = "TF-" + Math.floor(1e3 + Math.random() * 9e3);
          newMerchant.password = hashPassword(defaultPass);
        }
        if (isFirestoreAdminConfigured()) {
          const persisted = await safeFirestoreSetDoc("merchants", newMerchant.id, newMerchant);
          if (!persisted && foodConfig.isProduction) {
            throw new Error("[Produksi] Gagal menyimpan merchant ke cloud Firestore. Transaksi dibatalkan demi menjaga integritas data.");
          }
        } else {
          safeFirestoreSetDoc("merchants", newMerchant.id, newMerchant);
        }
        this.data.merchants.push(newMerchant);
        this.createCategory(newMerchant.id, "Menu Utama").catch(() => {
        });
        this.save();
        this.log(userId, `Created merchant ${newMerchant.name}`, "ADMIN");
        return newMerchant;
      }
      async updateMerchant(userId, id, updates, role = "MERCHANT") {
        await this.ensureProductionCloudReady("Pembaruan Merchant");
        const index = this.data.merchants.findIndex((m) => m.id === id);
        if (index === -1) throw new Error("Merchant not found");
        const prevMerchant = { ...this.data.merchants[index] };
        const updatedData = { ...updates };
        if (updatedData.password && !updatedData.password.startsWith("pbkdf2$")) {
          updatedData.password = hashPassword(updatedData.password);
        }
        if (updatedData.qrisImage !== void 0) {
          updatedData.qrisUpdatedAt = (/* @__PURE__ */ new Date()).toISOString();
        }
        const nextMerchant = {
          ...this.data.merchants[index],
          ...updatedData,
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        if (isFirestoreAdminConfigured()) {
          const persisted = await safeFirestoreSetDoc("merchants", id, nextMerchant);
          if (!persisted && foodConfig.isProduction) {
            throw new Error("[Produksi] Gagal memperbarui merchant pada cloud Firestore. Perubahan dibatalkan demi integritas data.");
          }
        } else {
          safeFirestoreSetDoc("merchants", id, nextMerchant);
        }
        this.data.merchants[index] = nextMerchant;
        this.save();
        this.log(userId, `Updated merchant ${this.data.merchants[index].name}`, role);
        return this.data.merchants[index];
      }
      async deleteMerchant(userId, id) {
        await this.ensureProductionCloudReady("Penghapusan Merchant");
        const index = this.data.merchants.findIndex((m) => m.id === id);
        if (index === -1) return false;
        const merchantOrders = Array.isArray(this.data.orders) ? this.data.orders.filter((o) => o && o.merchantId === id) : [];
        const merchantSettlements = Array.isArray(this.data.settlements) ? this.data.settlements.filter((s) => s && s.merchantId === id) : [];
        if (merchantOrders.length > 0 || merchantSettlements.length > 0) {
          throw new Error(`Merchant "${this.data.merchants[index].name}" memiliki riwayat transaksi (${merchantOrders.length} pesanan, ${merchantSettlements.length} settlement keuangan). Demi integritas audit dan data transaksi, merchant tidak dapat dihapus permanen. Silakan nonaktifkan akun.`);
        }
        if (foodConfig.isProduction) {
          const deleted = await safeAdminDeleteDoc("merchants", id);
          if (!deleted) {
            throw new Error("[Produksi] Gagal menghapus merchant pada cloud Firestore. Operasi dibatalkan demi integritas data.");
          }
        } else {
          safeAdminDeleteDoc("merchants", id);
        }
        const name = this.data.merchants[index].name;
        this.data.merchants.splice(index, 1);
        this.data.categories = this.data.categories.filter((c) => c.merchantId !== id);
        this.data.menuItems = this.data.menuItems.filter((i) => i.merchantId !== id);
        this.save();
        this.log(userId, `Deleted merchant ${name}`, "ADMIN");
        return true;
      }
      async activateMerchant(email, passwordPlain) {
        const cleanEmail = email.trim().toLowerCase();
        const merchant = this.data.merchants.find((m) => m.email?.trim().toLowerCase() === cleanEmail);
        if (!merchant) {
          return { success: false, error: "Merchant dengan email tersebut tidak ditemukan." };
        }
        const prevMerchant = { ...merchant };
        merchant.active = true;
        merchant.isActivated = true;
        merchant.password = hashPassword(passwordPlain);
        merchant.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
        if (foodConfig.isProduction) {
          const persisted = await safeFirestoreSetDoc("merchants", merchant.id, merchant);
          if (!persisted) {
            Object.assign(merchant, prevMerchant);
            throw new Error("[Produksi] Gagal mengaktifkan merchant pada cloud Firestore. Operasi dibatalkan.");
          }
        } else {
          safeFirestoreSetDoc("merchants", merchant.id, merchant);
        }
        if (this.data.partnerRegistrations) {
          const reg = this.data.partnerRegistrations.find((r) => r.email?.trim().toLowerCase() === cleanEmail && r.type === "MERCHANT");
          if (reg) {
            reg.status = "ACTIVATED";
            safeFirestoreSetDoc("partnerRegistrations", reg.id, reg);
          }
        }
        this.save();
        this.log(merchant.id, `Activated merchant store ${merchant.name}`, "MERCHANT");
        return { success: true, merchant };
      }
      // --- CATEGORIES ---
      getCategories(merchantId) {
        return this.data.categories.filter((c) => c.merchantId === merchantId).sort((a, b) => (a.orderIndex || 0) - (b.orderIndex || 0));
      }
      async createCategory(merchantId, name) {
        await this.ensureProductionCloudReady("Penambahan Kategori");
        const existing = this.getCategories(merchantId);
        const orderIndex = existing.length > 0 ? Math.max(...existing.map((e) => e.orderIndex)) + 1 : 1;
        const newCat = {
          id: "cat_" + Math.random().toString(36).substring(2, 9),
          merchantId,
          name: name.trim(),
          orderIndex
        };
        if (isFirestoreAdminConfigured()) {
          const persisted = await safeFirestoreSetDoc("categories", newCat.id, newCat);
          if (!persisted && foodConfig.isProduction) {
            throw new Error("[Produksi] Gagal menyimpan kategori menu ke cloud Firestore. Operasi dibatalkan.");
          }
        } else {
          safeFirestoreSetDoc("categories", newCat.id, newCat);
        }
        this.data.categories.push(newCat);
        this.save();
        this.log(merchantId, `Created category ${name}`, "MERCHANT");
        return newCat;
      }
      async updateCategory(merchantId, id, name) {
        await this.ensureProductionCloudReady("Pembaruan Kategori");
        const cat = this.data.categories.find((c) => c.id === id && c.merchantId === merchantId);
        if (!cat) throw new Error("Category not found");
        const prevName = cat.name;
        cat.name = name.trim();
        if (isFirestoreAdminConfigured()) {
          const persisted = await safeFirestoreSetDoc("categories", id, cat);
          if (!persisted && foodConfig.isProduction) {
            cat.name = prevName;
            throw new Error("[Produksi] Gagal memperbarui kategori menu di cloud Firestore. Operasi dibatalkan.");
          }
        } else {
          safeFirestoreSetDoc("categories", id, cat);
        }
        this.save();
        return cat;
      }
      async deleteCategory(merchantId, id) {
        await this.ensureProductionCloudReady("Penghapusan Kategori");
        const index = this.data.categories.findIndex((c) => c.id === id && c.merchantId === merchantId);
        if (index === -1) return false;
        if (isFirestoreAdminConfigured()) {
          const deleted = await safeAdminDeleteDoc("categories", id);
          if (!deleted && foodConfig.isProduction) {
            throw new Error("[Produksi] Gagal menghapus kategori menu pada cloud Firestore. Operasi dibatalkan.");
          }
        } else {
          safeAdminDeleteDoc("categories", id);
        }
        this.data.categories.splice(index, 1);
        this.data.menuItems = this.data.menuItems.filter((i) => i.categoryId !== id);
        this.save();
        return true;
      }
      // --- MENU ITEMS ---
      getMenuItemsByMerchant(merchantId) {
        this.reloadFromDiskIfNeeded();
        return this.data.menuItems.filter((i) => i.merchantId === merchantId);
      }
      getMenuItemById(id) {
        this.reloadFromDiskIfNeeded();
        return this.data.menuItems.find((i) => i.id === id);
      }
      async createMenuItem(merchantId, itemData) {
        await this.ensureProductionCloudReady("Penambahan Item Menu");
        const newItem = {
          ...itemData,
          id: "item_" + Math.random().toString(36).substring(2, 9),
          merchantId,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        if (isFirestoreAdminConfigured()) {
          const persisted = await safeFirestoreSetDoc("menuItems", newItem.id, newItem);
          if (!persisted && foodConfig.isProduction) {
            throw new Error("[Produksi] Gagal menyimpan item menu ke cloud Firestore. Operasi dibatalkan.");
          }
        } else {
          safeFirestoreSetDoc("menuItems", newItem.id, newItem);
        }
        this.data.menuItems.push(newItem);
        this.save();
        this.log(merchantId, `Created menu item ${newItem.name}`, "MERCHANT");
        return newItem;
      }
      async updateMenuItem(merchantId, id, updates) {
        await this.ensureProductionCloudReady("Pembaruan Item Menu");
        const index = this.data.menuItems.findIndex((i) => i.id === id && i.merchantId === merchantId);
        if (index === -1) throw new Error("Menu item not found");
        const prevItem = { ...this.data.menuItems[index] };
        const nextItem = {
          ...this.data.menuItems[index],
          ...updates,
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        if (isFirestoreAdminConfigured()) {
          const persisted = await safeFirestoreSetDoc("menuItems", id, nextItem);
          if (!persisted && foodConfig.isProduction) {
            throw new Error("[Produksi] Gagal memperbarui item menu pada cloud Firestore. Operasi dibatalkan.");
          }
        } else {
          safeFirestoreSetDoc("menuItems", id, nextItem);
        }
        this.data.menuItems[index] = nextItem;
        this.save();
        this.log(merchantId, `Updated menu item ${this.data.menuItems[index].name}`, "MERCHANT");
        return this.data.menuItems[index];
      }
      async deleteMenuItem(merchantId, id) {
        await this.ensureProductionCloudReady("Penghapusan Item Menu");
        const index = this.data.menuItems.findIndex((i) => i.id === id && i.merchantId === merchantId);
        if (index === -1) return false;
        if (isFirestoreAdminConfigured()) {
          const deleted = await safeAdminDeleteDoc("menuItems", id);
          if (!deleted && foodConfig.isProduction) {
            throw new Error("[Produksi] Gagal menghapus item menu pada cloud Firestore. Operasi dibatalkan.");
          }
        } else {
          safeAdminDeleteDoc("menuItems", id);
        }
        const name = this.data.menuItems[index].name;
        this.data.menuItems.splice(index, 1);
        this.save();
        this.log(merchantId, `Deleted menu item ${name}`, "MERCHANT");
        return true;
      }
      // --- DRIVERS ---
      getDrivers() {
        return this.data.drivers.map((d) => {
          const { password, ...safe } = d;
          return safe;
        });
      }
      getDriverById(id) {
        const d = this.data.drivers.find((d2) => d2.id === id);
        if (!d) return void 0;
        const { password, ...safe } = d;
        return safe;
      }
      getDriverByEmailOrPhone(identifier) {
        if (!identifier || !this.data || !Array.isArray(this.data.drivers)) return void 0;
        const clean = identifier.trim().toLowerCase();
        const rawClean = identifier.trim();
        const cleanPhone = identifier.replace(/[^0-9]/g, "");
        const altPhone = cleanPhone.startsWith("62") ? "0" + cleanPhone.slice(2) : cleanPhone.startsWith("0") ? "62" + cleanPhone.slice(1) : "";
        return this.data.drivers.find((d) => {
          if (!d) return false;
          const dId = typeof d.id === "string" ? d.id.toLowerCase() : "";
          const dEmail = typeof d.email === "string" ? d.email.trim().toLowerCase() : "";
          const dPhone = typeof d.phone === "string" ? d.phone.trim() : "";
          const dPhoneNumbers = dPhone.replace(/[^0-9]/g, "");
          const matchId = Boolean(dId && dId === clean);
          const matchEmail = Boolean(dEmail && dEmail === clean);
          const matchPhoneExact = Boolean(dPhone && (dPhone === rawClean || dPhone.toLowerCase() === clean));
          const matchCleanPhone = Boolean(cleanPhone.length >= 8 && dPhoneNumbers && (dPhoneNumbers === cleanPhone || altPhone && dPhoneNumbers === altPhone));
          return matchId || matchEmail || matchPhoneExact || matchCleanPhone;
        });
      }
      async createDriver(userId, driverData) {
        await this.ensureProductionCloudReady("Pendaftaran Driver");
        const newDriver = {
          ...driverData,
          id: "d_" + Math.random().toString(36).substring(2, 9),
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        if (newDriver.password && !newDriver.password.startsWith("pbkdf2$")) {
          newDriver.password = hashPassword(newDriver.password);
        }
        if (isFirestoreAdminConfigured()) {
          const persisted = await safeFirestoreSetDoc("drivers", newDriver.id, newDriver);
          if (!persisted && foodConfig.isProduction) {
            throw new Error("[Produksi] Gagal menyimpan driver ke cloud Firestore. Transaksi dibatalkan.");
          }
        } else {
          safeFirestoreSetDoc("drivers", newDriver.id, newDriver);
        }
        this.data.drivers.push(newDriver);
        this.save();
        this.log(userId, `Created driver ${newDriver.name}`, "ADMIN");
        return newDriver;
      }
      async updateDriver(userId, id, updates, role = "DRIVER") {
        await this.ensureProductionCloudReady("Pembaruan Driver");
        const index = this.data.drivers.findIndex((d) => d.id === id);
        if (index === -1) throw new Error("Driver not found");
        const prevDriver = { ...this.data.drivers[index] };
        const nextDriver = {
          ...this.data.drivers[index],
          ...updates,
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        if (isFirestoreAdminConfigured()) {
          const persisted = await safeFirestoreSetDoc("drivers", id, nextDriver);
          if (!persisted && foodConfig.isProduction) {
            throw new Error("[Produksi] Gagal memperbarui driver pada cloud Firestore. Perubahan dibatalkan.");
          }
        } else {
          safeFirestoreSetDoc("drivers", id, nextDriver);
        }
        this.data.drivers[index] = nextDriver;
        this.save();
        this.log(userId, `Updated driver ${this.data.drivers[index].name}`, role);
        return this.data.drivers[index];
      }
      async deleteDriver(userId, id) {
        await this.ensureProductionCloudReady("Penghapusan Driver");
        const index = this.data.drivers.findIndex((d) => d.id === id);
        if (index === -1) return false;
        if (isFirestoreAdminConfigured()) {
          const deleted = await safeAdminDeleteDoc("drivers", id);
          if (!deleted && foodConfig.isProduction) {
            throw new Error("[Produksi] Gagal menghapus driver pada cloud Firestore. Operasi dibatalkan.");
          }
        } else {
          safeAdminDeleteDoc("drivers", id);
        }
        const name = this.data.drivers[index].name;
        this.data.drivers.splice(index, 1);
        this.save();
        this.log(userId, `Deleted driver ${name}`, "ADMIN");
        return true;
      }
      // --- ORDERS ---
      getOrders() {
        this.reloadFromDiskIfNeeded();
        return this.data.orders.map((o) => normalizeOrderDeliveryFee(o));
      }
      getOrderById(id) {
        if (!id) return void 0;
        const cleanId = String(id).trim();
        if (!cleanId) return void 0;
        const rawClean = cleanId.replace(/^#/, "").trim();
        const cleanLower = rawClean.toLowerCase();
        const cleanUpper = rawClean.toUpperCase();
        const withoutOrd = cleanLower.startsWith("ord_") ? cleanLower.replace(/^ord_/, "") : cleanLower;
        const withOrd = cleanLower.startsWith("ord_") ? cleanLower : "ord_" + cleanLower;
        const withoutTf = cleanUpper.startsWith("TF-") ? cleanUpper.replace(/^TF-/, "") : cleanUpper;
        const withTf = cleanUpper.startsWith("TF-") ? cleanUpper : "TF-" + cleanUpper;
        const matcher = (item) => {
          if (!item) return false;
          const itemId = String(item.id || "").trim();
          const itemLower = itemId.toLowerCase();
          const itemUpper = itemId.toUpperCase();
          const itemOrderNumber = String(item.orderNumber || "").trim();
          const numUpper = itemOrderNumber.toUpperCase();
          if (itemOrderNumber && (itemOrderNumber === rawClean || numUpper === cleanUpper || numUpper === withTf || numUpper.replace(/^TF-/, "") === withoutTf)) {
            return true;
          }
          if (itemId === rawClean || itemLower === cleanLower || itemLower === withoutOrd || itemLower === withOrd || itemLower.replace(/^ord_/, "") === withoutOrd) {
            return true;
          }
          if (rawClean.length >= 4) {
            if (itemUpper.endsWith(cleanUpper) || itemUpper.replace(/^ORD_/, "").endsWith(cleanUpper)) {
              return true;
            }
            if (numUpper.endsWith(cleanUpper) || numUpper.replace(/^TF-/, "").endsWith(cleanUpper)) {
              return true;
            }
          }
          return false;
        };
        let o = this.data.orders.find(matcher);
        if (!o) {
          const reloaded = this.reloadFromDiskIfNeeded();
          if (reloaded) {
            o = this.data.orders.find(matcher);
          }
        }
        return o ? normalizeOrderDeliveryFee(o) : void 0;
      }
      getOrdersByMerchant(merchantId) {
        this.reloadFromDiskIfNeeded();
        if (!merchantId) return [];
        const cleanTarget = String(merchantId).trim().toLowerCase();
        const stripPrefix = (str) => str.replace(/^merchant_/, "");
        const cleanTargetBase = stripPrefix(cleanTarget);
        return this.data.orders.filter((o) => {
          if (!o) return false;
          const oMerchantId = String(o.merchantId || "").trim().toLowerCase();
          if (oMerchantId && (oMerchantId === cleanTarget || stripPrefix(oMerchantId) === cleanTargetBase)) {
            return true;
          }
          if (Array.isArray(o.items) && o.items.length > 0) {
            const itemMatched = o.items.some((item) => {
              const mi = this.data.menuItems.find((m) => m.id === item.menuItemId);
              if (mi && mi.merchantId) {
                const miMerchantId = String(mi.merchantId).trim().toLowerCase();
                return miMerchantId === cleanTarget || stripPrefix(miMerchantId) === cleanTargetBase;
              }
              return false;
            });
            if (itemMatched) return true;
          }
          return false;
        }).map((o) => normalizeOrderDeliveryFee(o));
      }
      async findOrdersByMerchant(merchantId) {
        if (!merchantId) return [];
        let orders = this.getOrdersByMerchant(merchantId);
        if (isFirestoreAdminConfigured()) {
          try {
            const remoteOrders = await safeAdminGetDocs("orders");
            if (Array.isArray(remoteOrders) && remoteOrders.length > 0) {
              let updatedAny = false;
              for (const ro of remoteOrders) {
                if (!ro || !ro.id) continue;
                const existingIdx = this.data.orders.findIndex((o) => o.id === ro.id);
                if (existingIdx === -1) {
                  this.data.orders.unshift(ro);
                  updatedAny = true;
                } else {
                  const localOrder = this.data.orders[existingIdx];
                  if (ro.updatedAt && (!localOrder.updatedAt || new Date(ro.updatedAt).getTime() > new Date(localOrder.updatedAt).getTime())) {
                    this.data.orders[existingIdx] = ro;
                    updatedAny = true;
                  } else if (ro.status === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */ && localOrder.status !== "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */) {
                    this.data.orders[existingIdx] = ro;
                    updatedAny = true;
                  }
                }
              }
              if (updatedAny) {
                this.save();
                orders = this.getOrdersByMerchant(merchantId);
              }
            }
          } catch (err) {
            console.warn("[TumpangFood DB] Error during remote Firestore orders sync for merchant:", err);
          }
        }
        return orders;
      }
      getOrdersByDriver(driverId) {
        this.reloadFromDiskIfNeeded();
        return this.data.orders.filter((o) => o.driverId === driverId).map((o) => normalizeOrderDeliveryFee(o));
      }
      getAvailableOrdersForDrivers() {
        this.reloadFromDiskIfNeeded();
        return this.data.orders.filter(
          (o) => !o.driverId && (o.status === "READY_FOR_PICKUP" /* READY_FOR_PICKUP */ || o.status === "COOKING" /* COOKING */ || o.status === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */) && (o.paymentStatus === "PAID" /* PAID */ || ["READY_FOR_PICKUP" /* READY_FOR_PICKUP */, "COOKING" /* COOKING */, "ORDER_PICKED_UP" /* ORDER_PICKED_UP */, "DELIVERED" /* DELIVERED */, "COMPLETED" /* COMPLETED */].includes(o.status))
        ).map((o) => normalizeOrderDeliveryFee(o));
      }
      async acceptDriverTask(driverId, orderId) {
        this.reloadFromDiskIfNeeded();
        const cleanOrderId = String(orderId || "").trim();
        const cleanDriverId = String(driverId || "").trim();
        const driver = this.getDriverById(cleanDriverId);
        if (!driver) {
          throw new Error("Identitas kurir tidak ditemukan di sistem.");
        }
        if (!driver.online) {
          throw new Error("Status Anda sedang Offline. Aktifkan status Online terlebih dahulu untuk menerima tugas.");
        }
        if (!driver.active) {
          throw new Error("Akun kurir Anda dinonaktifkan oleh administrator.");
        }
        const orderIndex = this.data.orders.findIndex((o) => o.id === cleanOrderId);
        if (orderIndex === -1) {
          throw new Error("Pesanan tidak ditemukan.");
        }
        const currentOrder = this.data.orders[orderIndex];
        if (currentOrder.driverId && currentOrder.driverId !== cleanDriverId) {
          throw new Error(`Pesanan ini telah diambil oleh kurir lain (${currentOrder.driverName || "Kurir Lain"}).`);
        }
        const validStatuses = [
          "READY_FOR_PICKUP" /* READY_FOR_PICKUP */,
          "COOKING" /* COOKING */,
          "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */
        ];
        if (!validStatuses.includes(currentOrder.status)) {
          throw new Error(`Pesanan dengan status ${currentOrder.status} tidak dapat diterima.`);
        }
        const updated = await this.updateOrder(cleanDriverId, cleanOrderId, {
          driverId: driver.id,
          driverName: driver.name
        }, "DRIVER");
        this.log(cleanDriverId, `Kurir ${driver.name} (#${driver.id}) menerima tugas pengantaran #${cleanOrderId}`, "DRIVER");
        return updated;
      }
      getOrdersByCustomerPhone(phone) {
        this.reloadFromDiskIfNeeded();
        return this.data.orders.filter((o) => o.customerPhone === phone).map((o) => normalizeOrderDeliveryFee(o));
      }
      async findOrder(id) {
        if (!id) return void 0;
        const cleanId = String(id).trim();
        if (!cleanId) return void 0;
        let order = this.getOrderById(cleanId);
        if (!order && isFirestoreAdminConfigured()) {
          try {
            const candidateKeys = Array.from(/* @__PURE__ */ new Set([
              cleanId,
              cleanId.startsWith("ord_") ? cleanId.replace(/^ord_/, "") : "ord_" + cleanId,
              cleanId.toLowerCase(),
              cleanId.startsWith("ord_") ? cleanId.toLowerCase() : "ord_" + cleanId.toLowerCase()
            ]));
            for (const docKey of candidateKeys) {
              const remote = await safeAdminGetDoc("orders", docKey);
              if (remote) {
                order = remote;
                if (!order.id) order.id = docKey;
                console.log(`[TumpangFood DB] Successfully retrieved order "${order.id}" directly from Firestore via key "${docKey}".`);
                const idx = this.data.orders.findIndex((o) => o.id === order.id || o.id === cleanId);
                if (idx >= 0) {
                  this.data.orders[idx] = order;
                } else {
                  this.data.orders.unshift(order);
                }
                this.save();
                break;
              }
            }
          } catch (e) {
            console.warn(`[TumpangFood DB] Query remote order ${cleanId} failed:`, e.message);
          }
        }
        if (order && (!order.merchantQrisImage || order.merchantQrisImage.includes("unsplash"))) {
          const merchant = this.getMerchantById(order.merchantId);
          if (merchant?.qrisImage) {
            order.merchantQrisImage = merchant.qrisImage;
          }
        }
        if (order && (order.paymentStatus === "PAID" /* PAID */ || ["PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */, "COOKING" /* COOKING */, "READY_FOR_PICKUP" /* READY_FOR_PICKUP */, "ORDER_PICKED_UP" /* ORDER_PICKED_UP */, "DELIVERED" /* DELIVERED */, "COMPLETED" /* COMPLETED */].includes(order.status)) && !order.receipt) {
          const canonicalOrderCode = order.orderNumber || order.id;
          const cleanRef = String(canonicalOrderCode).replace(/^ord_/, "").replace(/^TF-/, "").toUpperCase();
          const receiptNumber = order.receiptNumber || `TG-RCP-${cleanRef}`;
          const issuedAt = order.paymentVerifiedAt || order.updatedAt || order.createdAt;
          order.receiptNumber = receiptNumber;
          order.receipt = {
            receiptNumber,
            orderId: order.id,
            orderNumber: canonicalOrderCode,
            issuedAt,
            confirmedBy: order.paymentVerifiedBy || "Admin TumpangGo",
            paymentMethod: order.paymentMethod || "MERCHANT_QRIS",
            transactionRef: order.artopayPaymentId || `QRIS-TG-${cleanRef}`,
            subtotal: order.subtotal,
            deliveryFee: order.deliveryFee,
            serviceFee: order.serviceFee,
            uniqueCode: order.uniqueCode || 0,
            total: order.total,
            customerName: order.customerName,
            merchantName: order.merchantName,
            status: "PAID"
          };
        }
        return order ? normalizeOrderDeliveryFee(order) : void 0;
      }
      async createOrder(rawInput) {
        await this.ensureProductionCloudReady("Pembuatan Pesanan");
        const merchant = this.getMerchantById(rawInput.merchantId);
        if (!merchant) throw new Error("Toko / Merchant tidak ditemukan.");
        if (rawInput.clientRequestId && String(rawInput.clientRequestId).trim().length > 0) {
          const cleanReqId = String(rawInput.clientRequestId).trim();
          const existingReq = this.data.orders.find((o) => o.clientRequestId === cleanReqId);
          if (existingReq) {
            return existingReq;
          }
        }
        const recentDuplicate = this.data.orders.find(
          (o) => o.merchantId === rawInput.merchantId && o.customerPhone === rawInput.customerPhone && Date.now() - new Date(o.createdAt).getTime() < 1e4 && o.status === "WAITING_PAYMENT" /* WAITING_PAYMENT */
        );
        if (recentDuplicate) {
          return recentDuplicate;
        }
        const activeUniqueCodes = this.data.orders.filter((o) => o.status === "WAITING_PAYMENT" /* WAITING_PAYMENT */ || o.status === "WAITING_PAYMENT_VERIFICATION" /* WAITING_PAYMENT_VERIFICATION */).map((o) => o.uniqueCode);
        const validatedOrderData = OrderService.validateAndBuildOrder(
          rawInput,
          merchant,
          this.data.menuItems,
          this.data.systemConfig,
          activeUniqueCodes
        );
        const now = /* @__PURE__ */ new Date();
        const datePrefix = now.toISOString().slice(0, 10).replace(/-/g, "");
        const dailyCount = this.data.orders.filter((o) => o.createdAt && o.createdAt.startsWith(now.toISOString().slice(0, 10))).length + 1;
        let orderNumber = `TF-${datePrefix}-${String(dailyCount).padStart(3, "0")}`;
        let attempt = 0;
        while (this.data.orders.some((o) => o.orderNumber === orderNumber)) {
          attempt++;
          orderNumber = `TF-${datePrefix}-${String(dailyCount + attempt).padStart(3, "0")}`;
        }
        const newOrder = normalizeOrderDeliveryFee({
          ...validatedOrderData,
          id: "ord_" + Math.random().toString(36).substring(2, 9),
          orderNumber,
          clientRequestId: rawInput.clientRequestId ? String(rawInput.clientRequestId).trim() : void 0,
          createdAt: now.toISOString(),
          updatedAt: now.toISOString()
        });
        if (foodConfig.isProduction) {
          const persisted = await safeFirestoreSetDoc("orders", newOrder.id, newOrder);
          if (!persisted) {
            throw new Error("[Produksi] Gagal menyimpan pesanan ke cloud Firestore. Transaksi dibatalkan secara aman demi mencegah kehilangan data atau transaksi ganda.");
          }
        }
        this.data.orders.unshift(newOrder);
        this.save();
        this.log("CUSTOMER", `Created order ${newOrder.orderNumber} (ID: ${newOrder.id}) Total: Rp ${newOrder.total.toLocaleString()} (UniqueCode: ${newOrder.uniqueCode})`, "CUSTOMER");
        if (!foodConfig.isProduction) {
          if (isFirestoreAdminConfigured()) {
            safeFirestoreSetDoc("orders", newOrder.id, newOrder).catch(() => {
            });
          } else {
            console.warn("[TumpangFood DB] Variabel FIREBASE_SERVICE_ACCOUNT_KEY belum dikonfigurasi di Environment Variables Vercel. Pesanan disimpan pada penyimpanan lokal resilien.");
          }
        }
        return newOrder;
      }
      async updateOrder(userId, id, updates, role = "SYSTEM") {
        const cleanId = String(id || "").trim();
        let index = this.data.orders.findIndex((o) => o.id === cleanId || o.orderNumber && o.orderNumber === cleanId);
        if (index === -1) {
          const match = this.getOrderById(cleanId);
          if (match) {
            index = this.data.orders.findIndex((o) => o.id === match.id);
          }
        }
        if (index === -1) {
          const fetched = await this.findOrder(cleanId);
          if (fetched) {
            index = this.data.orders.findIndex((o) => o.id === fetched.id);
          }
        }
        if (index === -1) {
          console.warn(`[TumpangFood DB] updateOrder failed: Order not found for ID "${cleanId}". Total orders in memory: ${this.data.orders.length}`);
          throw new Error("Pesanan tidak ditemukan.");
        }
        const currentOrder = this.data.orders[index];
        const prevStatus = currentOrder.status;
        delete updates.id;
        delete updates.orderNumber;
        if (updates.status && updates.status !== prevStatus) {
          const check = OrderService.isValidStatusTransition(prevStatus, updates.status, role);
          if (!check.allowed) {
            throw new Error(check.reason || "Perubahan status pesanan tidak diizinkan.");
          }
        }
        if (role !== "ADMIN" && role !== "MASTER_ADMIN" && role !== "SYSTEM") {
          delete updates.subtotal;
          delete updates.deliveryFee;
          delete updates.serviceFee;
          delete updates.total;
          delete updates.uniqueCode;
        }
        if (updates.paymentProof && (!updates.paymentStatus || updates.paymentStatus === "WAITING_VERIFICATION" /* WAITING_VERIFICATION */)) {
          updates.paymentStatus = "WAITING_VERIFICATION" /* WAITING_VERIFICATION */;
          updates.status = "WAITING_PAYMENT_VERIFICATION" /* WAITING_PAYMENT_VERIFICATION */;
          updates.paymentProofUploadedAt = updates.paymentProofUploadedAt || (/* @__PURE__ */ new Date()).toISOString();
          updates.paymentRejectionReason = void 0;
        }
        if (updates.status === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */ || updates.paymentStatus === "PAID" /* PAID */) {
          updates.paymentStatus = "PAID" /* PAID */;
          if (!updates.status || updates.status === "WAITING_PAYMENT" /* WAITING_PAYMENT */ || updates.status === "WAITING_PAYMENT_VERIFICATION" /* WAITING_PAYMENT_VERIFICATION */) {
            updates.status = "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */;
          }
          updates.paymentVerifiedAt = updates.paymentVerifiedAt || (/* @__PURE__ */ new Date()).toISOString();
          if ((role === "ADMIN" || role === "MASTER_ADMIN" || role === "SYSTEM") && userId) {
            updates.paymentVerifiedBy = userId;
          }
        }
        if (updates.status === "PAYMENT_REJECTED" /* PAYMENT_REJECTED */ || updates.paymentStatus === "REJECTED" /* REJECTED */) {
          updates.paymentStatus = "REJECTED" /* REJECTED */;
          updates.status = "PAYMENT_REJECTED" /* PAYMENT_REJECTED */;
          if ((role === "ADMIN" || role === "MASTER_ADMIN" || role === "SYSTEM") && userId) {
            updates.paymentVerifiedBy = userId;
          }
        }
        if (updates.status === "EXPIRED" /* EXPIRED */ || updates.paymentStatus === "EXPIRED" /* EXPIRED */) {
          updates.paymentStatus = "EXPIRED" /* EXPIRED */;
          updates.status = "EXPIRED" /* EXPIRED */;
        }
        this.data.orders[index] = normalizeOrderDeliveryFee({
          ...currentOrder,
          ...updates,
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        });
        this.save();
        if (updates.status && updates.status !== prevStatus) {
          this.log(userId, `Updated order ${currentOrder.id} status from ${prevStatus} to ${updates.status}`, role);
          if (updates.status === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */) {
            Promise.resolve().then(() => (init_pushService(), pushService_exports)).then((m) => {
              m.pushService.notifyNewVerifiedOrder(this.data.orders[index]);
            }).catch(() => {
            });
          }
        } else {
          this.log(userId, `Updated order ${currentOrder.id} details`, role);
        }
        if (updates.driverId && updates.driverId !== currentOrder.driverId) {
          Promise.resolve().then(() => (init_pushService(), pushService_exports)).then((m) => {
            m.pushService.notifyDriverAssignedOrder(updates.driverId, this.data.orders[index]);
          }).catch(() => {
          });
        }
        if (foodConfig.isProduction) {
          await this.ensureProductionCloudReady("Pembaruan Pesanan");
          const persisted = await safeFirestoreSetDoc("orders", currentOrder.id, this.data.orders[index]);
          if (!persisted) {
            this.data.orders[index] = currentOrder;
            this.save();
            throw new Error("Gagal memperbarui status pesanan pada cloud Firestore. Perubahan status dibatalkan demi integritas data.");
          }
        } else {
          if (isFirestoreAdminConfigured()) {
            safeFirestoreSetDoc("orders", currentOrder.id, this.data.orders[index]).catch(() => {
            });
          } else {
            console.warn("[TumpangFood DB] Variabel FIREBASE_SERVICE_ACCOUNT_KEY belum dikonfigurasi. Perubahan status disimpan pada penyimpanan lokal.");
          }
        }
        return this.data.orders[index];
      }
      async verifyOrderPayment(adminId, orderId) {
        const cleanId = String(orderId || "").trim();
        console.log(`[TumpangFood DB] verifyOrderPayment starting for orderId: "${cleanId}" by admin: "${adminId}"`);
        const order = await this.findOrder(cleanId);
        if (!order) {
          console.warn(`[TumpangFood DB] verifyOrderPayment failed: Order not found for ID "${cleanId}". Available orders in memory: ${this.data.orders.length}`);
          throw new Error("Pesanan tidak ditemukan.");
        }
        if (order.status === "CANCELLED" /* CANCELLED */) {
          throw new Error("Pesanan yang telah dibatalkan tidak dapat diverifikasi.");
        }
        if (order.status === "EXPIRED" /* EXPIRED */) {
          throw new Error("Pesanan telah kedaluwarsa. Pembayaran kedaluwarsa tidak dapat diverifikasi secara otomatis.");
        }
        const receiptNumber = order.receiptNumber || `TG-RCP-${String(order.id).replace(/^ord_/, "").toUpperCase()}`;
        const issuedAt = order.paymentVerifiedAt || (/* @__PURE__ */ new Date()).toISOString();
        const transactionRef = order.artopayPaymentId || `QRIS-TG-${String(order.id).replace(/^ord_/, "").toUpperCase()}`;
        const receipt = order.receipt || {
          receiptNumber,
          orderId: order.id,
          issuedAt,
          confirmedBy: adminId || "admin_tumpang",
          paymentMethod: order.paymentMethod || "MERCHANT_QRIS",
          transactionRef,
          subtotal: order.subtotal,
          deliveryFee: order.deliveryFee,
          serviceFee: order.serviceFee,
          uniqueCode: order.uniqueCode || 0,
          total: order.total,
          customerName: order.customerName,
          merchantName: order.merchantName,
          status: "PAID"
        };
        if (order.paymentStatus === "PAID" /* PAID */ && order.status === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */ && order.receipt) {
          return order;
        }
        const updated = await this.updateOrder(
          adminId,
          order.id,
          {
            status: "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */,
            paymentStatus: "PAID" /* PAID */,
            paymentVerifiedAt: issuedAt,
            paymentVerifiedBy: adminId,
            receiptNumber,
            receipt
          },
          "ADMIN"
        );
        this.log(adminId, `Admin ${adminId} memverifikasi pembayaran LUNAS & menerbitkan receipt #${receiptNumber} untuk pesanan #${order.id} (Total: Rp ${order.total.toLocaleString("id-ID")})`, "ADMIN");
        return updated;
      }
      async rejectOrderPayment(adminId, orderId, reason) {
        const cleanId = String(orderId || "").trim();
        console.log(`[TumpangFood DB] rejectOrderPayment starting for orderId: "${cleanId}" by admin: "${adminId}"`);
        const order = await this.findOrder(cleanId);
        if (!order) {
          console.warn(`[TumpangFood DB] rejectOrderPayment failed: Order not found for ID "${cleanId}". Available orders in memory: ${this.data.orders.length}`);
          throw new Error("Pesanan tidak ditemukan.");
        }
        if (!reason || !reason.trim()) {
          throw new Error("Alasan penolakan bukti pembayaran wajib diisi.");
        }
        const cleanReason = reason.trim();
        const updated = await this.updateOrder(
          adminId,
          order.id,
          {
            status: "PAYMENT_REJECTED" /* PAYMENT_REJECTED */,
            paymentStatus: "REJECTED" /* REJECTED */,
            paymentRejectionReason: cleanReason,
            cancelReason: cleanReason,
            paymentVerifiedBy: adminId
          },
          "ADMIN"
        );
        this.log(adminId, `Admin ${adminId} menolak bukti pembayaran pesanan #${order.id}. Alasan: ${cleanReason}`, "ADMIN");
        return updated;
      }
      async autoAssignDriver(orderId) {
        const cleanId = String(orderId || "").trim();
        const order = await this.findOrder(cleanId);
        if (!order) return;
        const availableDrivers = this.data.drivers.filter((d) => d.online && d.active);
        if (availableDrivers.length === 0) {
          this.log("SYSTEM", `No active drivers available for auto-assignment of order ${orderId}`, "SYSTEM");
          return;
        }
        const driverTaskCounts = availableDrivers.map((d) => {
          const activeTasks = this.data.orders.filter(
            (o) => o.driverId === d.id && ["PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */, "COOKING" /* COOKING */, "READY_FOR_PICKUP" /* READY_FOR_PICKUP */, "ORDER_PICKED_UP" /* ORDER_PICKED_UP */].includes(o.status)
          ).length;
          return { driver: d, count: activeTasks };
        });
        driverTaskCounts.sort((a, b) => a.count - b.count);
        const selectedDriver = driverTaskCounts[0].driver;
        await this.updateOrder("SYSTEM", orderId, {
          driverId: selectedDriver.id,
          driverName: selectedDriver.name
        }, "SYSTEM");
      }
      async manualAssignDriver(userId, orderId, driverId) {
        const driver = this.getDriverById(driverId);
        if (!driver) throw new Error("Driver not found");
        const updated = await this.updateOrder(userId, orderId, {
          driverId: driver.id,
          driverName: driver.name
        }, "ADMIN");
        this.log(userId, `Assigned driver ${driver.name} to order ${orderId}`, "ADMIN");
        return updated;
      }
      // --- SETTLEMENTS ---
      getSettlements() {
        return this.data.settlements;
      }
      getSettlementsByMerchant(merchantId) {
        return this.data.settlements.filter((s) => s.merchantId === merchantId);
      }
      /**
       * Serializes settlement operations across the process and host instances to prevent concurrent double-settlements
       */
      async runWithSettlementLock(fn) {
        let release;
        const waitPromise = new Promise((resolve) => {
          release = resolve;
        });
        const currentMutex = this.settlementMutex;
        this.settlementMutex = currentMutex.then(() => waitPromise).catch(() => waitPromise);
        await currentMutex;
        const lockPath = import_path3.default.join(import_path3.default.dirname(FOOD_DB_FILE), "settlement_operation.lock");
        let fileLockAcquired = false;
        for (let attempts = 0; attempts < 30; attempts++) {
          try {
            const fd = import_fs3.default.openSync(lockPath, "wx");
            import_fs3.default.writeSync(fd, `${process.pid}:${Date.now()}`);
            import_fs3.default.closeSync(fd);
            fileLockAcquired = true;
            break;
          } catch (err) {
            if (err.code === "EEXIST") {
              try {
                const stats = import_fs3.default.statSync(lockPath);
                if (Date.now() - stats.mtimeMs > 15e3) {
                  import_fs3.default.unlinkSync(lockPath);
                  continue;
                }
              } catch {
              }
              await new Promise((r) => setTimeout(r, 100));
            } else {
              break;
            }
          }
        }
        try {
          return await fn();
        } finally {
          if (fileLockAcquired) {
            try {
              import_fs3.default.unlinkSync(lockPath);
            } catch {
            }
          }
          release();
        }
      }
      async createSettlement(userId, settlementData) {
        return this.runWithSettlementLock(async () => {
          const targetOrderIds = settlementData.orderIds || [];
          if (!Array.isArray(targetOrderIds) || targetOrderIds.length === 0) {
            throw new Error("Settlement wajib menyertakan setidaknya satu ID pesanan yang memenuhi syarat.");
          }
          const merchant = this.data.merchants.find((m) => m.id === settlementData.merchantId);
          if (!merchant) {
            throw new Error(`Merchant dengan ID "${settlementData.merchantId}" tidak ditemukan.`);
          }
          const verifiedOrders = [];
          for (const ordId of targetOrderIds) {
            const ord = this.data.orders.find((o) => o.id === ordId);
            if (!ord) {
              throw new Error(`Pesanan "${ordId}" tidak ditemukan dalam database.`);
            }
            if (ord.merchantId !== settlementData.merchantId) {
              throw new Error(`Pesanan "${ordId}" bukan milik merchant ${settlementData.merchantId}.`);
            }
            if (ord.status !== "COMPLETED" /* COMPLETED */) {
              throw new Error(`Pesanan "${ordId}" belum selesai (status: ${ord.status}). Hanya pesanan COMPLETED yang dapat dicairkan.`);
            }
            if (ord.isSettled === true || ord.settlementId) {
              throw new Error(`Pesanan "${ordId}" sudah pernah dicairkan dalam settlement sebelumnya. Pencairan ganda dicegah secara atomik.`);
            }
            verifiedOrders.push(ord);
          }
          const orderCount = verifiedOrders.length;
          const totalSales = verifiedOrders.reduce((sum, o) => sum + (Number(o.subtotal) || 0), 0);
          const commissionPercent = this.data.systemConfig.commissionPercent || 10;
          const totalCommission = Math.round(totalSales * commissionPercent / 100);
          const amountToPay = Math.max(0, totalSales - totalCommission);
          const settlementId = "set_" + Math.random().toString(36).substring(2, 9);
          const nowIso = (/* @__PURE__ */ new Date()).toISOString();
          const newSettlement = {
            id: settlementId,
            merchantId: merchant.id,
            merchantName: merchant.name,
            orderCount,
            totalSales,
            totalCommission,
            amountToPay,
            status: settlementData.status || "WAITING_CONFIRMATION" /* WAITING_CONFIRMATION */,
            bankName: settlementData.bankName || merchant.bankName || "Bank Mandiri",
            bankAccount: settlementData.bankAccount || merchant.bankAccount || "-",
            bankHolder: settlementData.bankHolder || merchant.bankHolder || merchant.ownerName,
            createdAt: nowIso
          };
          const adminDb2 = getAdminDb();
          if (adminDb2) {
            try {
              await runAdminTransaction(async (transaction) => {
                for (const ordId of targetOrderIds) {
                  const orderRef = adminDb2.collection("orders").doc(ordId);
                  const remoteSnap = await transaction.get(orderRef);
                  if (remoteSnap.exists) {
                    const remoteData = remoteSnap.data();
                    if (remoteData?.isSettled === true || remoteData?.settlementId) {
                      throw new Error(`Pesanan "${ordId}" telah dicairkan oleh instance backend lain. Pencairan ganda lintas-instance dicegah secara atomik.`);
                    }
                  }
                }
                for (const ord of verifiedOrders) {
                  const orderRef = adminDb2.collection("orders").doc(ord.id);
                  transaction.set(orderRef, removeUndefinedFields({
                    ...ord,
                    isSettled: true,
                    settlementId,
                    settledAt: nowIso,
                    updatedAt: nowIso
                  }), { merge: true });
                }
                const settlementRef = adminDb2.collection("settlements").doc(newSettlement.id);
                transaction.set(settlementRef, removeUndefinedFields(newSettlement));
              });
            } catch (txErr) {
              if (txErr.message && txErr.message.includes("telah dicairkan")) {
                throw txErr;
              }
              if (foodConfig.isProduction) {
                throw new Error(`[Produksi] Transaksi cloud Firestore gagal: ${txErr.message}. Pencairan dibatalkan demi menjaga integritas data keuangan.`);
              }
              console.warn("[TumpangFood DB] Distributed Firestore Admin transaction fallback in development mode:", txErr.message);
            }
          } else if (foodConfig.isProduction) {
            throw new Error("[Produksi] Firebase Admin Firestore wajib aktif dan terhubung untuk memproses pencairan dana (settlement).");
          }
          for (const ord of verifiedOrders) {
            ord.isSettled = true;
            ord.settlementId = settlementId;
            ord.settledAt = nowIso;
            ord.updatedAt = nowIso;
            safeFirestoreSetDoc("orders", ord.id, ord);
          }
          this.data.settlements.unshift(newSettlement);
          this.save();
          this.createBackup();
          this.log(
            userId,
            `Created settlement ${settlementId} of Rp ${amountToPay.toLocaleString()} for ${merchant.name} (${orderCount} pesanan)`,
            "ADMIN"
          );
          safeFirestoreSetDoc("settlements", newSettlement.id, newSettlement);
          return newSettlement;
        });
      }
      async updateSettlement(userId, id, updates) {
        await this.ensureProductionCloudReady("Pembaruan Settlement");
        const index = this.data.settlements.findIndex((s) => s.id === id);
        if (index === -1) throw new Error("Settlement not found");
        const nextSettlement = {
          ...this.data.settlements[index],
          ...updates,
          paidAt: updates.status === "SETTLEMENT_COMPLETED" /* SETTLEMENT_COMPLETED */ ? (/* @__PURE__ */ new Date()).toISOString() : this.data.settlements[index].paidAt
        };
        if (isFirestoreAdminConfigured()) {
          const persisted = await safeFirestoreSetDoc("settlements", id, nextSettlement);
          if (!persisted && foodConfig.isProduction) {
            throw new Error("[Produksi] Gagal memperbarui settlement di cloud Firestore. Perubahan dibatalkan.");
          }
        } else {
          safeFirestoreSetDoc("settlements", id, nextSettlement);
        }
        this.data.settlements[index] = nextSettlement;
        this.save();
        this.createBackup();
        this.log(userId, `Updated settlement ${id} to status ${this.data.settlements[index].status}`, "ADMIN");
        return this.data.settlements[index];
      }
      async confirmSettlement(userId, id) {
        return this.updateSettlement(userId, id, { status: "SETTLEMENT_COMPLETED" /* SETTLEMENT_COMPLETED */ });
      }
      async generateHPlusOneSettlements(userId) {
        return this.runWithSettlementLock(async () => {
          const targetOrders = this.data.orders.filter(
            (o) => o.status === "COMPLETED" /* COMPLETED */ && !o.isSettled && !o.settlementId
          );
          if (targetOrders.length === 0) return [];
          const grouped = /* @__PURE__ */ new Map();
          for (const o of targetOrders) {
            const list = grouped.get(o.merchantId) || [];
            list.push(o);
            grouped.set(o.merchantId, list);
          }
          const createdSettlements = [];
          const commissionPercent = this.data.systemConfig.commissionPercent || 10;
          const nowIso = (/* @__PURE__ */ new Date()).toISOString();
          for (const [merchantId, orders] of grouped.entries()) {
            const merchant = this.data.merchants.find((m) => m.id === merchantId);
            if (!merchant) continue;
            const orderCount = orders.length;
            const totalSales = orders.reduce((sum, o) => sum + (Number(o.subtotal) || 0), 0);
            const totalCommission = Math.round(totalSales * commissionPercent / 100);
            const amountToPay = Math.max(0, totalSales - totalCommission);
            const settlementId = "set_" + Math.random().toString(36).substring(2, 9);
            const newSettlement = {
              id: settlementId,
              merchantId,
              merchantName: merchant.name,
              orderCount,
              totalSales,
              totalCommission,
              amountToPay,
              status: "WAITING_CONFIRMATION" /* WAITING_CONFIRMATION */,
              bankName: merchant.bankName || "Bank Mandiri",
              bankAccount: merchant.bankAccount || "-",
              bankHolder: merchant.bankHolder || merchant.ownerName,
              createdAt: nowIso
            };
            const adminDb2 = getAdminDb();
            if (adminDb2) {
              try {
                await runAdminTransaction(async (transaction) => {
                  for (const o of orders) {
                    const orderRef = adminDb2.collection("orders").doc(o.id);
                    const snap = await transaction.get(orderRef);
                    if (snap.exists) {
                      const data = snap.data();
                      if (data?.isSettled === true || data?.settlementId) {
                        throw new Error(`Order ${o.id} already settled.`);
                      }
                    }
                  }
                  for (const o of orders) {
                    const orderRef = adminDb2.collection("orders").doc(o.id);
                    transaction.set(orderRef, removeUndefinedFields({
                      ...o,
                      isSettled: true,
                      settlementId,
                      settledAt: nowIso,
                      updatedAt: nowIso
                    }), { merge: true });
                  }
                  const settlementRef = adminDb2.collection("settlements").doc(newSettlement.id);
                  transaction.set(settlementRef, removeUndefinedFields(newSettlement));
                });
              } catch (txErr) {
                if (foodConfig.isProduction) {
                  throw new Error(`[Produksi] Transaksi cloud Firestore gagal untuk merchant ${merchantId}: ${txErr.message}`);
                }
                console.warn(`[TumpangFood DB] H+1 atomic transaction fallback for ${merchantId}:`, txErr.message);
              }
            } else if (foodConfig.isProduction) {
              throw new Error("[Produksi] Firebase Admin Firestore wajib aktif untuk membuat H+1 settlements.");
            }
            for (const o of orders) {
              o.isSettled = true;
              o.settlementId = settlementId;
              o.settledAt = nowIso;
              o.updatedAt = nowIso;
              safeFirestoreSetDoc("orders", o.id, o);
            }
            this.data.settlements.unshift(newSettlement);
            safeFirestoreSetDoc("settlements", newSettlement.id, newSettlement);
            createdSettlements.push(newSettlement);
          }
          this.save();
          this.createBackup();
          this.log(userId, `Generated H+1 settlements for ${createdSettlements.length} merchants`, "ADMIN");
          return createdSettlements;
        });
      }
      // --- PARTNER REGISTRATIONS ---
      getPartnerRegistrations() {
        return this.data.partnerRegistrations;
      }
      async createPartnerRegistration(regData) {
        await this.ensureProductionCloudReady("Pendaftaran Pengajuan Mitra");
        const newReg = {
          ...regData,
          id: "reg_" + Math.random().toString(36).substring(2, 9),
          status: "PENDING",
          contractVersion: regData.contractVersion || (regData.type === "MERCHANT" ? "PKS-TUMPANGGO-2026.1" : "PKS-DRIVER-TUMPANGGO-2026.1"),
          contractAgreedAt: regData.contractAgreedAt || (/* @__PURE__ */ new Date()).toISOString(),
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        if (isFirestoreAdminConfigured()) {
          const persisted = await safeFirestoreSetDoc("partnerRegistrations", newReg.id, newReg);
          if (!persisted && foodConfig.isProduction) {
            throw new Error("[Produksi] Gagal menyimpan pendaftaran mitra ke cloud Firestore. Transaksi dibatalkan.");
          }
        } else {
          safeFirestoreSetDoc("partnerRegistrations", newReg.id, newReg);
        }
        this.data.partnerRegistrations.push(newReg);
        this.save();
        this.log("CUSTOMER", `Submitted partner registration for ${newReg.name} (${newReg.type})`, "CUSTOMER");
        return newReg;
      }
      async approvePartnerRegistration(userId, id) {
        await this.ensureProductionCloudReady("Persetujuan Mitra");
        const reg = this.data.partnerRegistrations.find((r) => r.id === id);
        if (!reg) return { success: false, error: "Registration not found" };
        if (reg.status !== "PENDING") return { success: false, error: "Registration already processed" };
        const prevStatus = reg.status;
        reg.status = "APPROVED";
        if (reg.type === "MERCHANT") {
          const generatedPassword = reg.password || "TF-" + Math.floor(1e3 + Math.random() * 9e3);
          reg.password = generatedPassword;
          const newMerchant = await this.createMerchant(userId, {
            name: reg.storeName || reg.name + " Store",
            ownerName: reg.name,
            phone: reg.phone,
            address: reg.storeAddress || "Kecamatan Tumpang, Kabupaten Malang",
            latitude: reg.latitude || -7.9482,
            longitude: reg.longitude || 112.7612,
            openTime: "08:00",
            closeTime: "21:00",
            bankName: reg.bankName || "Bank BRI",
            bankAccount: reg.bankAccountNumber || "1234567890",
            bankHolder: reg.bankAccountHolder || reg.name,
            active: true,
            cookTimeEstimate: "15-30 min",
            image: reg.businessPhoto || "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=500&auto=format&fit=crop&q=60",
            description: reg.description || `Mitra Toko Kuliner ${reg.storeName || reg.name} Kecamatan Tumpang`,
            category: reg.category || "Nasi & Lauk",
            email: reg.email,
            isActivated: true,
            password: hashPassword(generatedPassword),
            businessPhoto: reg.businessPhoto,
            idPhoto: reg.idPhoto,
            contractPhoto: reg.contractPhoto
          });
          reg.storeId = newMerchant.id;
          await this.createCategory(newMerchant.id, "Menu Utama");
        } else if (reg.type === "DRIVER") {
          const generatedDriverPassword = reg.password || "TF-DRV-" + Math.floor(1e3 + Math.random() * 9e3);
          reg.password = generatedDriverPassword;
          const newDriver = await this.createDriver(userId, {
            name: reg.name,
            phone: reg.phone,
            email: reg.email,
            active: true,
            online: false,
            latitude: -7.9482,
            longitude: 112.7612,
            password: hashPassword(generatedDriverPassword),
            vehicle: reg.vehicleNumber || "Motor"
          });
          reg.driverId = newDriver.id;
        }
        if (isFirestoreAdminConfigured()) {
          const persisted = await safeFirestoreSetDoc("partnerRegistrations", reg.id, reg);
          if (!persisted && foodConfig.isProduction) {
            reg.status = prevStatus;
            throw new Error("[Produksi] Gagal memperbarui status registrasi mitra ke cloud Firestore.");
          }
        } else {
          safeFirestoreSetDoc("partnerRegistrations", reg.id, reg);
        }
        this.save();
        this.log(userId, `Approved partner registration ${reg.id} (${reg.name})`, "ADMIN");
        return { success: true, registration: reg };
      }
      async rejectPartnerRegistration(userId, id) {
        const reg = this.data.partnerRegistrations.find((r) => r.id === id);
        if (!reg) return false;
        const prevStatus = reg.status;
        reg.status = "REJECTED";
        if (isFirestoreAdminConfigured()) {
          const persisted = await safeFirestoreSetDoc("partnerRegistrations", reg.id, reg);
          if (!persisted && foodConfig.isProduction) {
            reg.status = prevStatus;
            throw new Error("[Produksi] Gagal menolak pendaftaran mitra pada cloud Firestore.");
          }
        } else {
          safeFirestoreSetDoc("partnerRegistrations", reg.id, reg);
        }
        this.save();
        this.log(userId, `Rejected partner registration ${reg.id} (${reg.name})`, "ADMIN");
        return true;
      }
      // --- REVIEW PENGGUNA TUMPANGGO / TESTIMONIALS ---
      getPublishedTestimonials(categoryFilter) {
        if (!Array.isArray(this.data.testimonials)) return [];
        return this.data.testimonials.filter((t) => {
          const isPublished = t.status === "published" && t.consentApproved === true;
          if (!isPublished) return false;
          if (!categoryFilter || categoryFilter === "all") return true;
          const normItemCat = t.category === "merchant" || t.category === "umkm" ? "merchant" : "pelanggan";
          const normFilter = categoryFilter === "merchant" || categoryFilter === "umkm" ? "merchant" : categoryFilter;
          return normItemCat === normFilter;
        }).sort((a, b) => {
          if (a.displayOrder !== b.displayOrder) {
            return (a.displayOrder || 0) - (b.displayOrder || 0);
          }
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        });
      }
      getAllTestimonials(filter) {
        if (!Array.isArray(this.data.testimonials)) return [];
        let list = [...this.data.testimonials];
        if (filter) {
          if (filter.category && filter.category !== "all") {
            const normFilter = filter.category === "merchant" || filter.category === "umkm" ? "merchant" : filter.category;
            list = list.filter((t) => {
              const normItemCat = t.category === "merchant" || t.category === "umkm" ? "merchant" : "pelanggan";
              return normItemCat === normFilter;
            });
          }
          if (filter.status && filter.status !== "all") {
            list = list.filter((t) => t.status === filter.status);
          }
        }
        return list.sort((a, b) => {
          if (a.displayOrder !== b.displayOrder) {
            return (a.displayOrder || 0) - (b.displayOrder || 0);
          }
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        });
      }
      async createTestimonial(testimonialData) {
        if (!Array.isArray(this.data.testimonials)) this.data.testimonials = [];
        const now = (/* @__PURE__ */ new Date()).toISOString();
        const rawCat = String(testimonialData.category || "").toLowerCase();
        const normalizedCategory = rawCat === "merchant" || rawCat === "umkm" ? "merchant" : "pelanggan";
        const rawStatus = String(testimonialData.status || "").toLowerCase();
        const validStatus = ["published", "pending", "rejected", "draft"].includes(rawStatus) ? rawStatus : "pending";
        const parsedRating = testimonialData.rating !== void 0 && testimonialData.rating !== null ? Math.min(5, Math.max(1, Math.round(Number(testimonialData.rating)))) : void 0;
        const newTesti = {
          id: "rev_" + Date.now().toString(36) + "_" + Math.random().toString(36).substring(2, 6),
          userName: (testimonialData.userName || "").trim(),
          merchantName: testimonialData.merchantName?.trim() || void 0,
          category: normalizedCategory,
          title: testimonialData.title?.trim() || void 0,
          content: (testimonialData.content || "").trim(),
          avatarUrl: testimonialData.avatarUrl?.trim() || void 0,
          roleDetail: testimonialData.roleDetail?.trim() || void 0,
          rating: parsedRating,
          consentApproved: Boolean(testimonialData.consentApproved),
          status: validStatus,
          displayOrder: Number(testimonialData.displayOrder) || 1,
          createdAt: now,
          updatedAt: now
        };
        if (isFirestoreAdminConfigured()) {
          const persisted = await safeFirestoreSetDoc("testimonials", newTesti.id, newTesti);
          if (!persisted && foodConfig.isProduction) {
            throw new Error("[Produksi] Gagal menyimpan review ke cloud Firestore. Pengiriman ulasan dibatalkan demi menjaga integritas data.");
          }
        } else {
          await safeFirestoreSetDoc("testimonials", newTesti.id, newTesti);
        }
        this.data.testimonials.push(newTesti);
        this.save();
        return newTesti;
      }
      async updateTestimonial(id, updates) {
        if (!Array.isArray(this.data.testimonials)) return null;
        const index = this.data.testimonials.findIndex((t) => t.id === id);
        if (index === -1) return null;
        const prev = this.data.testimonials[index];
        let category = prev.category;
        if (updates.category) {
          category = updates.category === "merchant" || updates.category === "umkm" ? "merchant" : "pelanggan";
        }
        let rating = prev.rating;
        if (updates.rating !== void 0) {
          rating = updates.rating !== null && !isNaN(Number(updates.rating)) ? Math.min(5, Math.max(1, Math.round(Number(updates.rating)))) : void 0;
        }
        let status = prev.status;
        if (updates.status && ["published", "pending", "rejected", "draft"].includes(updates.status)) {
          status = updates.status;
        }
        const updated = {
          ...prev,
          ...updates,
          merchantName: updates.merchantName !== void 0 ? updates.merchantName?.trim() || void 0 : prev.merchantName,
          title: updates.title !== void 0 ? updates.title?.trim() || void 0 : prev.title,
          category,
          rating,
          status,
          id: prev.id,
          // prevent ID overwrite
          createdAt: prev.createdAt,
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        if (isFirestoreAdminConfigured()) {
          const persisted = await safeFirestoreSetDoc("testimonials", updated.id, updated);
          if (!persisted && foodConfig.isProduction) {
            throw new Error("[Produksi] Gagal memperbarui status review di cloud Firestore. Transaksi dibatalkan.");
          }
        } else {
          await safeFirestoreSetDoc("testimonials", updated.id, updated);
        }
        this.data.testimonials[index] = updated;
        this.save();
        return updated;
      }
      async deleteTestimonial(id) {
        if (!Array.isArray(this.data.testimonials)) return false;
        const initialLen = this.data.testimonials.length;
        this.data.testimonials = this.data.testimonials.filter((t) => t.id !== id);
        if (this.data.testimonials.length !== initialLen) {
          if (isFirestoreAdminConfigured()) {
            const deleted = await safeAdminDeleteDoc("testimonials", id);
            if (!deleted && foodConfig.isProduction) {
              throw new Error("[Produksi] Gagal menghapus review di cloud Firestore.");
            }
          } else {
            await safeAdminDeleteDoc("testimonials", id);
          }
          this.save();
          return true;
        }
        return false;
      }
      // --- WEB PUSH SUBSCRIPTIONS ---
      savePushSubscription(sub) {
        if (!this.data.pushSubscriptions) this.data.pushSubscriptions = [];
        const idx = this.data.pushSubscriptions.findIndex((s) => s.subscription.endpoint === sub.subscription.endpoint);
        if (idx >= 0) {
          this.data.pushSubscriptions[idx] = {
            ...this.data.pushSubscriptions[idx],
            ...sub,
            updatedAt: (/* @__PURE__ */ new Date()).toISOString()
          };
        } else {
          this.data.pushSubscriptions.push(sub);
        }
        this.save();
      }
      removePushSubscription(endpoint) {
        if (!this.data.pushSubscriptions) return;
        this.data.pushSubscriptions = this.data.pushSubscriptions.filter((s) => s.subscription.endpoint !== endpoint);
        this.save();
      }
      getPushSubscriptionsForEntity(role, entityId) {
        if (!this.data.pushSubscriptions) return [];
        return this.data.pushSubscriptions.filter((s) => s.role === role && s.entityId === entityId);
      }
    };
    foodDb = new FoodDatabase();
  }
});

// src/server/app.ts
var app_exports = {};
__export(app_exports, {
  app: () => app
});
module.exports = __toCommonJS(app_exports);
var import_express8 = __toESM(require("express"), 1);
init_db();
init_config();
init_firebaseAdmin();
init_auth();

// src/server/routes/authRoutes.ts
var import_fs4 = __toESM(require("fs"), 1);
var import_path4 = __toESM(require("path"), 1);
var import_crypto2 = __toESM(require("crypto"), 1);
var import_express = require("express");
init_db();
init_config();
init_auth();
var authRouter = (0, import_express.Router)();
authRouter.post(["/login", "/auth/login"], async (req, res) => {
  try {
    const rawUser = req.body?.username || req.body?.email || req.body?.user;
    const rawPass = req.body?.password;
    const role = req.body?.role;
    if (!rawUser || !rawPass) {
      return res.status(400).json({ error: "Username/Email dan kata sandi wajib diisi." });
    }
    const cleanUser = String(rawUser).trim().toLowerCase();
    const rawPassStr = String(rawPass);
    const cleanPass = rawPassStr.trim();
    const isMasterUser = isMasterAdminEmail(cleanUser);
    if (isMasterUser) {
      console.log(`[MasterAuth Diagnostic] Master Account login attempt for: [PROTECTED_EMAIL] (portal: ${role || "DEFAULT"})`);
      const creds = getMasterAccountCredentials();
      const activeMasterPassword = creds.password;
      const dbMaster = foodDb.getMasterAccount();
      let isMasterPassValid = false;
      let matchedVia = "";
      if (dbMaster?.passwordHash && dbMaster.passwordHash.startsWith("pbkdf2$")) {
        const { valid: validTrimmed } = verifyPassword(cleanPass, dbMaster.passwordHash);
        const { valid: validRaw } = verifyPassword(rawPassStr, dbMaster.passwordHash);
        if (validTrimmed || validRaw) {
          isMasterPassValid = true;
          matchedVia = "PBKDF2_DB_HASH";
        }
      }
      if (!isMasterPassValid && activeMasterPassword) {
        const hashTarget = import_crypto2.default.createHash("sha256").update(activeMasterPassword).digest();
        const hashTrimmed = import_crypto2.default.createHash("sha256").update(cleanPass).digest();
        const hashRaw = import_crypto2.default.createHash("sha256").update(rawPassStr).digest();
        if (import_crypto2.default.timingSafeEqual(hashTrimmed, hashTarget) || import_crypto2.default.timingSafeEqual(hashRaw, hashTarget)) {
          isMasterPassValid = true;
          matchedVia = creds.hasExplicitEnv ? "ACTIVE_ENV_PASSWORD" : "DEV_DEFAULT_PASSWORD";
          foodDb.updateMasterAccountPassword(activeMasterPassword);
        }
      }
      if (!isMasterPassValid) {
        const hasDbHash = Boolean(dbMaster?.passwordHash && dbMaster.passwordHash.startsWith("pbkdf2$"));
        console.warn(`[MasterAuth Diagnostic] GAGAL: Verifikasi kata sandi Master Account ditolak (inputBytes: ${Buffer.byteLength(cleanPass, "utf-8")}, dbHashPresent: ${hasDbHash}, envConfigLoaded: ${creds.hasExplicitEnv})`);
        return res.status(401).json({
          error: "Email atau kata sandi tidak valid. Silakan periksa kembali.",
          diagnostic: {
            code: "PASSWORD_MISMATCH",
            reason: hasDbHash ? "PASSWORD_HASH_MISMATCH" : "NO_PASSWORD_CONFIGURED",
            emailMatched: true,
            dbHashPresent: hasDbHash,
            envConfigLoaded: creds.hasExplicitEnv,
            configSource: creds.source,
            envPasswordByteLength: creds.byteLength
          }
        });
      }
      console.log(`[MasterAuth Diagnostic] BERHASIL: Verifikasi kata sandi Master Account valid (via: ${matchedVia}).`);
      const firstMerchant = foodDb.getMerchants()[0];
      const firstDriver = foodDb.getDrivers()[0];
      const targetEntityId = role === "MERCHANT" ? req.body.targetMerchantId || firstMerchant?.id || "" : role === "DRIVER" ? req.body.targetDriverId || firstDriver?.id || "" : void 0;
      let token = "";
      try {
        token = createAuthToken({
          userId: "master-admin",
          role: "MASTER_ADMIN",
          email: cleanUser,
          isMasterAdmin: true,
          entityId: targetEntityId
        });
      } catch (tokenErr) {
        console.error("[MasterAuth Diagnostic] GAGAL: Pembuatan token otentikasi gagal:", tokenErr?.message);
        return res.status(500).json({
          error: "Gagal menerbitkan token otentikasi Master Account.",
          diagnostic: { code: "TOKEN_CREATION_FAILED", reason: tokenErr?.message }
        });
      }
      console.log("[MasterAuth Diagnostic] BERHASIL: Token Master Account berhasil diterbitkan.");
      foodDb.log("master-admin", `Master Account logged in with unrestricted cross-portal access (entry portal: ${role || "ALL"})`, "MASTER_ADMIN");
      return res.json({
        token,
        role: "MASTER_ADMIN",
        isMasterAdmin: true,
        targetPortal: role || "ADMIN",
        user: {
          id: "master-admin",
          name: "Master Account TumpangGo",
          email: cleanUser,
          role: "MASTER_ADMIN",
          isMasterAdmin: true,
          entityId: targetEntityId,
          activeMerchantId: firstMerchant?.id || "",
          activeDriverId: firstDriver?.id || ""
        },
        availablePortals: ["ADMIN", "MERCHANT", "DRIVER", "CUSTOMER"]
      });
    }
    if (role === "ADMIN") {
      if (foodConfig.isProduction) {
        if (!foodConfig.adminPassword || foodConfig.adminPassword.length < 8) {
          return res.status(500).json({
            error: "Autentikasi admin dinonaktifkan: FOOD_ADMIN_PASSWORD belum dikonfigurasi di Environment Variables Vercel.",
            diagnostic: { code: "CONFIG_ENV_MISSING", reason: "FOOD_ADMIN_PASSWORD_UNSET" }
          });
        }
        if (!foodConfig.jwtSecret || foodConfig.jwtSecret.length < 32) {
          return res.status(500).json({
            error: "Autentikasi admin dinonaktifkan: FOOD_AUTH_SECRET belum dikonfigurasi di Environment Variables Vercel.",
            diagnostic: { code: "CONFIG_ENV_MISSING", reason: "FOOD_AUTH_SECRET_UNSET" }
          });
        }
        if (cleanPass === "TumpangGoAdmin#2026") {
          return res.status(401).json({
            error: "Kata sandi default ditolak pada lingkungan produksi demi keamanan. Atur FOOD_ADMIN_PASSWORD di environment variable.",
            diagnostic: { code: "DEFAULT_PASSWORD_REJECTED_IN_PROD" }
          });
        }
      }
      const isTargetAdmin = isAdminEmail(cleanUser);
      if (!isTargetAdmin) {
        return res.status(401).json({
          error: "Email atau kata sandi Administrator salah.",
          diagnostic: { code: "EMAIL_NOT_MATCHED", reason: "ADMIN_EMAIL_NOT_RECOGNIZED", emailMatched: false }
        });
      }
      const isValidAdminPass = Boolean(
        foodConfig.adminPassword && (verifyPassword(cleanPass, foodConfig.adminPassword).valid || verifyPassword(rawPassStr, foodConfig.adminPassword).valid || cleanPass === foodConfig.adminPassword || rawPassStr === foodConfig.adminPassword)
      );
      if (!isValidAdminPass) {
        return res.status(401).json({
          error: "Email atau kata sandi Administrator salah.",
          diagnostic: { code: "PASSWORD_MISMATCH", reason: "ADMIN_PASSWORD_INVALID", emailMatched: true }
        });
      }
      const token = createAuthToken({
        userId: "admin",
        role: "ADMIN",
        email: cleanUser
      });
      foodDb.log("admin", `Admin ${cleanUser} logged in successfully`, "ADMIN");
      return res.json({
        token,
        role: "ADMIN",
        user: { id: "admin", name: "Administrator Tumpang Go", username: cleanUser, role: "ADMIN" }
      });
    }
    if (role === "MERCHANT") {
      const merchant = foodDb.getMerchantByEmailOrPhone(cleanUser);
      if (!merchant) {
        const pendingReg = foodDb.getPartnerRegistrations().find(
          (r) => r.type === "MERCHANT" && (r.email && r.email.trim().toLowerCase() === cleanUser || r.phone && r.phone.trim() === cleanUser)
        );
        if (pendingReg && pendingReg.status === "PENDING") {
          return res.status(403).json({
            error: "Pendaftaran toko Anda sedang dalam peninjauan oleh Admin. Akses operasional akan dibuka setelah disetujui.",
            isPendingApproval: true,
            status: "PENDING"
          });
        }
        return res.status(401).json({
          error: "Email atau No. Telepon ini tidak terdaftar sebagai Merchant Toko.",
          diagnostic: { code: "EMAIL_NOT_MATCHED", reason: "MERCHANT_NOT_FOUND", emailMatched: false }
        });
      }
      if (!merchant.active) {
        return res.status(403).json({
          error: "Akun toko Anda dinonaktifkan atau belum disetujui oleh Administrator.",
          code: "MERCHANT_INACTIVE"
        });
      }
      let isPasswordValid = false;
      if (merchant.password) {
        const { valid, needsRehash } = verifyPassword(cleanPass, merchant.password);
        isPasswordValid = valid;
        if (needsRehash) {
          foodDb.updateMerchant("SYSTEM", merchant.id, { password: hashPassword(cleanPass) }, "MERCHANT").catch(() => {
          });
        }
      } else {
        return res.status(401).json({
          error: "Akun toko belum memiliki kata sandi aktif. Silakan lakukan aktivasi akun terlebih dahulu.",
          diagnostic: { code: "ACCOUNT_NOT_ACTIVATED", reason: "MERCHANT_PASSWORD_EMPTY" }
        });
      }
      if (!isPasswordValid) {
        return res.status(401).json({
          error: "Kata sandi toko salah. Silakan periksa kembali.",
          diagnostic: { code: "PASSWORD_MISMATCH", reason: "MERCHANT_PASSWORD_INVALID", emailMatched: true }
        });
      }
      const token = createAuthToken({
        userId: merchant.id,
        role: "MERCHANT",
        email: merchant.email,
        entityId: merchant.id
      });
      foodDb.log(merchant.id, `Merchant ${merchant.name} logged in`, "MERCHANT");
      return res.json({
        token,
        role: "MERCHANT",
        user: { id: merchant.id, name: merchant.name, phone: merchant.phone, email: merchant.email }
      });
    }
    if (role === "DRIVER") {
      const driver = foodDb.getDriverByEmailOrPhone(cleanUser);
      if (!driver) {
        const pendingDriverReg = foodDb.getPartnerRegistrations().find(
          (r) => r.type === "DRIVER" && (r.email && r.email.trim().toLowerCase() === cleanUser || r.phone && r.phone.trim() === cleanUser)
        );
        if (pendingDriverReg && pendingDriverReg.status === "PENDING") {
          return res.status(403).json({
            error: "Pendaftaran kurir Anda sedang dalam peninjauan oleh Admin. Akses operasional akan dibuka setelah disetujui.",
            isPendingApproval: true,
            status: "PENDING"
          });
        }
        return res.status(401).json({
          error: "No. WhatsApp atau Email ini tidak terdaftar sebagai Driver / Kurir.",
          diagnostic: { code: "EMAIL_NOT_MATCHED", reason: "DRIVER_NOT_FOUND", emailMatched: false }
        });
      }
      if (!driver.active) {
        return res.status(403).json({
          error: "Akun kurir Anda dinonaktifkan atau belum disetujui oleh Administrator.",
          code: "DRIVER_INACTIVE"
        });
      }
      let isDriverPassValid = false;
      if (driver.password) {
        const { valid, needsRehash } = verifyPassword(cleanPass, driver.password);
        isDriverPassValid = valid;
        if (needsRehash) {
          foodDb.updateDriver("SYSTEM", driver.id, { password: hashPassword(cleanPass) }, "DRIVER").catch(() => {
          });
        }
      } else {
        return res.status(401).json({
          error: "Akun driver belum memiliki kata sandi aktif. Silakan hubungi admin untuk aktivasi.",
          diagnostic: { code: "ACCOUNT_NOT_ACTIVATED", reason: "DRIVER_PASSWORD_EMPTY" }
        });
      }
      if (!isDriverPassValid) {
        return res.status(401).json({
          error: "Kata sandi driver salah. Silakan periksa kembali.",
          diagnostic: { code: "PASSWORD_MISMATCH", reason: "DRIVER_PASSWORD_INVALID", emailMatched: true }
        });
      }
      const token = createAuthToken({
        userId: driver.id,
        role: "DRIVER",
        email: driver.email,
        entityId: driver.id
      });
      foodDb.log(driver.id, `Driver ${driver.name} logged in`, "DRIVER");
      return res.json({
        token,
        role: "DRIVER",
        user: { id: driver.id, name: driver.name, phone: driver.phone }
      });
    }
    return res.status(400).json({ error: "Peran akun tidak dikenali." });
  } catch (err) {
    console.error("[TumpangFood Login Handler Error]", err?.message || err);
    return res.status(500).json({
      error: "Terjadi kendala pada server saat memproses autentikasi. Silakan coba kembali.",
      code: "AUTH_SERVER_ERROR"
    });
  }
});
authRouter.post("/merchants/register", async (req, res) => {
  const {
    name,
    ownerName,
    phone,
    email,
    category,
    address,
    description,
    password,
    contractVersion,
    contractAgreedAt,
    image,
    businessPhoto,
    idPhoto,
    contractPhoto
  } = req.body;
  if (!name || !ownerName || !phone || !password) {
    return res.status(400).json({ error: "Mohon lengkapi Nama Toko, Nama Pemilik, No. WhatsApp, dan Kata Sandi." });
  }
  try {
    const cleanPhone = String(phone).trim();
    const cleanEmail = email ? String(email).trim().toLowerCase() : "";
    const existingMerchants = foodDb.getMerchants();
    const duplicateMerchant = existingMerchants.find(
      (m) => m.phone && m.phone === cleanPhone || cleanEmail && m.email && m.email.toLowerCase() === cleanEmail
    );
    if (duplicateMerchant) {
      return res.status(400).json({ error: "No. HP/WhatsApp atau Email ini sudah terdaftar sebagai Merchant aktif." });
    }
    const pendingRegs = foodDb.getPartnerRegistrations();
    const duplicatePending = pendingRegs.find(
      (r) => r.status === "PENDING" && (r.phone && r.phone === cleanPhone || cleanEmail && r.email && r.email.toLowerCase() === cleanEmail)
    );
    if (duplicatePending) {
      return res.status(400).json({
        error: "Pendaftaran toko dengan nomor WhatsApp atau email ini sudah diajukan dan sedang menunggu persetujuan Admin.",
        status: "PENDING"
      });
    }
    const newReg = await foodDb.createPartnerRegistration({
      name: String(ownerName).trim(),
      phone: cleanPhone,
      email: cleanEmail || void 0,
      type: "MERCHANT",
      storeName: String(name).trim(),
      storeAddress: address ? String(address).trim() : "Kecamatan Tumpang, Kabupaten Malang",
      category: category || "Nasi & Lauk",
      description: description ? String(description).trim() : `Mitra Kuliner UMKM ${String(name).trim()}`,
      password: String(password).trim(),
      businessPhoto: image || businessPhoto || void 0,
      idPhoto: idPhoto || void 0,
      contractPhoto: contractPhoto || void 0,
      contractVersion: contractVersion || "PKS-TUMPANGGO-2026.1",
      contractAgreedAt: contractAgreedAt || (/* @__PURE__ */ new Date()).toISOString()
    });
    return res.status(201).json({
      success: true,
      message: "Pendaftaran kemitraan toko berhasil diajukan dan sedang menunggu persetujuan Administrator tumpangGo.",
      status: "PENDING",
      registration: newReg
    });
  } catch (e) {
    return res.status(500).json({ error: e.message || "Gagal mengajukan pendaftaran toko." });
  }
});
authRouter.post("/merchants/activate", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "Email dan password wajib diisi." });
  }
  try {
    const result = await foodDb.activateMerchant(email, password);
    if (result.success) {
      res.json({ success: true, merchant: result.merchant });
    } else {
      res.status(400).json({ error: result.error });
    }
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
authRouter.get(["/me", "/auth/me"], (req, res) => {
  const user = req.user;
  if (!user) {
    console.warn("[MasterAuth Diagnostic] Sesi gagal dipulihkan: token tidak ditemukan atau tidak valid pada header request.");
    return res.status(401).json({ authenticated: false, error: "Sesi belum terautentikasi atau telah kedaluwarsa." });
  }
  const isMaster = user.role === "MASTER_ADMIN" || Boolean(user.isMasterAdmin) || isMasterAdminEmail(user.email);
  const firstMerchant = foodDb.getMerchants()[0];
  const firstDriver = foodDb.getDrivers()[0];
  console.log(`[MasterAuth Diagnostic] Sesi berhasil dipulihkan (isMaster: ${isMaster}, role: ${user.role})`);
  return res.json({
    authenticated: true,
    user: {
      id: user.userId,
      role: isMaster ? "MASTER_ADMIN" : user.role,
      email: user.email,
      entityId: user.entityId || (isMaster ? firstMerchant?.id : void 0),
      isMasterAdmin: Boolean(isMaster),
      activeMerchantId: firstMerchant?.id || "",
      activeDriverId: firstDriver?.id || ""
    },
    availablePortals: isMaster ? ["ADMIN", "MERCHANT", "DRIVER", "CUSTOMER"] : [user.role]
  });
});
authRouter.post(["/master/rotate-password", "/auth/master/rotate-password"], requireRole(["MASTER_ADMIN"]), (req, res) => {
  const { newPassword, currentPassword } = req.body;
  if (!newPassword || typeof newPassword !== "string" || newPassword.trim().length < 8) {
    return res.status(400).json({ error: "Kata sandi baru minimal harus terdiri dari 8 karakter." });
  }
  const cleanCurrent = String(currentPassword || "").trim();
  const envMasterPass = (process.env.MASTER_ADMIN_PASSWORD || "").trim();
  const dbMaster = foodDb.getMasterAccount();
  const configMasterPass = (foodConfig.masterAccount.password || "").trim();
  let isCurrentValid = false;
  if (dbMaster?.passwordHash && verifyPassword(cleanCurrent, dbMaster.passwordHash).valid) {
    isCurrentValid = true;
  } else if (envMasterPass && verifyPassword(cleanCurrent, envMasterPass).valid) {
    isCurrentValid = true;
  } else if (configMasterPass && verifyPassword(cleanCurrent, configMasterPass).valid) {
    isCurrentValid = true;
  }
  if (!isCurrentValid) {
    return res.status(401).json({ error: "Kata sandi saat ini tidak cocok." });
  }
  updateRuntimeMasterPassword(newPassword.trim());
  foodDb.updateMasterAccountPassword(newPassword.trim());
  foodDb.log("master-admin", "Master Account password rotated and saved to database successfully", "MASTER_ADMIN");
  return res.json({ success: true, message: "Kata sandi Master Account berhasil diperbarui." });
});
authRouter.post(["/master/emergency-reset", "/auth/master/emergency-reset"], async (req, res) => {
  const recoveryKey = String(req.headers["x-master-recovery-key"] || "").trim();
  let authBearer = "";
  const authHeader = req.headers["authorization"];
  if (authHeader && authHeader.startsWith("Bearer ")) {
    authBearer = authHeader.substring(7).trim();
  }
  const providedKey = recoveryKey || authBearer;
  if (!providedKey) {
    return res.status(401).json({
      error: "Akses ditolak: Otorisasi pemulihan administratif diperlukan. Sertakan header X-Master-Recovery-Key.",
      diagnostic: { code: "ADMINISTRATIVE_AUTHORIZATION_REQUIRED" }
    });
  }
  const envKey = (process.env.MASTER_RECOVERY_KEY || "").trim();
  let isAuthorized = false;
  let isOneTimeFile = false;
  const tokenFilePath = import_path4.default.resolve(process.cwd(), ".master_recovery_token");
  if (envKey && envKey.length >= 16) {
    const bufProvided = Buffer.from(providedKey);
    const bufEnv = Buffer.from(envKey);
    if (bufProvided.length === bufEnv.length && import_crypto2.default.timingSafeEqual(bufProvided, bufEnv)) {
      isAuthorized = true;
    }
  }
  if (!isAuthorized && import_fs4.default.existsSync(tokenFilePath)) {
    const consumingFilePath = import_path4.default.resolve(process.cwd(), `.master_recovery_token.food.${Date.now()}.${import_crypto2.default.randomBytes(4).toString("hex")}.consuming`);
    let renamed = false;
    try {
      import_fs4.default.renameSync(tokenFilePath, consumingFilePath);
      renamed = true;
    } catch {
      renamed = false;
    }
    if (renamed && import_fs4.default.existsSync(consumingFilePath)) {
      try {
        const fileContent = import_fs4.default.readFileSync(consumingFilePath, "utf-8").trim();
        if (fileContent && fileContent.length >= 16) {
          const bufProvided = Buffer.from(providedKey);
          const bufFile = Buffer.from(fileContent);
          if (bufProvided.length === bufFile.length && import_crypto2.default.timingSafeEqual(bufProvided, bufFile)) {
            isAuthorized = true;
          }
        }
      } finally {
        try {
          import_fs4.default.unlinkSync(consumingFilePath);
        } catch {
        }
      }
    }
  }
  if (!isAuthorized) {
    console.warn("[MasterRecovery] Otorisasi pemulihan ditolak: kunci pemulihan administratif tidak cocok.");
    return res.status(401).json({
      error: "Kunci pemulihan administratif tidak valid atau telah kedaluwarsa.",
      diagnostic: { code: "INVALID_RECOVERY_KEY" }
    });
  }
  const { newPassword } = req.body;
  if (!newPassword || typeof newPassword !== "string" || newPassword.trim().length < 8) {
    return res.status(400).json({
      error: "Kata sandi baru minimal harus terdiri dari 8 karakter.",
      diagnostic: { code: "PASSWORD_TOO_SHORT" }
    });
  }
  const cleanPass = newPassword.trim();
  const creds = getMasterAccountCredentials();
  foodDb.updateMasterAccountPassword(cleanPass);
  updateRuntimeMasterPassword(cleanPass);
  foodDb.log("master-recovery", "Master Account password recovered successfully via trusted administrative process", "MASTER_ADMIN");
  console.log("[MasterRecovery] BERHASIL: Kata sandi Master Account berhasil dipulihkan dan disimpan ke database persisten.");
  return res.json({
    success: true,
    message: "Kredensial Master Account berhasil dipulihkan secara aman.",
    email: creds.email,
    hashAlgorithm: "PBKDF2-SHA512 (iterations: 10000)"
  });
});

// src/server/routes/merchantRoutes.ts
var import_path5 = __toESM(require("path"), 1);
var import_fs5 = __toESM(require("fs"), 1);
var import_express2 = require("express");
init_db();
init_auth();
var merchantRouter = (0, import_express2.Router)();
merchantRouter.get("/", (req, res, next) => {
  try {
    const list = foodDb.getMerchants();
    res.json(list);
  } catch (err) {
    next(err);
  }
});
merchantRouter.get("/:id", (req, res, next) => {
  try {
    const m = foodDb.getMerchantById(req.params.id);
    if (!m) return res.status(404).json({ error: "Merchant not found" });
    res.json(m);
  } catch (err) {
    next(err);
  }
});
merchantRouter.get("/:id/qris", (req, res) => {
  try {
    const m = foodDb.getMerchantById(req.params.id);
    if (!m) return res.status(404).json({ error: "Merchant tidak ditemukan." });
    const rawQris = m.qrisImage;
    const hasQris = Boolean(rawQris && typeof rawQris === "string" && rawQris.trim().length > 3 && !rawQris.includes("unsplash"));
    res.json({
      merchantId: m.id,
      merchantName: m.name,
      hasQris,
      qrisImage: hasQris ? rawQris : null,
      qrisImageUrl: hasQris ? `/api/merchants/${m.id}/qris-image` : null
    });
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat status QRIS toko." });
  }
});
merchantRouter.get("/:id/qris-image", async (req, res) => {
  try {
    const m = foodDb.getMerchantById(req.params.id);
    if (!m) return res.status(404).json({ error: "Merchant tidak ditemukan." });
    const rawQris = m.qrisImage;
    if (!rawQris || typeof rawQris !== "string" || rawQris.trim().length < 3 || rawQris.includes("unsplash")) {
      return res.status(404).json({ error: `Toko "${m.name}" belum memiliki QRIS statis resmi.` });
    }
    const cleanQris = rawQris.trim();
    if (cleanQris.startsWith("data:image/")) {
      const matches = cleanQris.match(/^data:(image\/[a-zA-Z0-9.+_-]+);base64,(.+)$/);
      if (matches) {
        res.setHeader("Content-Type", matches[1]);
        res.setHeader("Cache-Control", "public, max-age=86400");
        return res.send(Buffer.from(matches[2], "base64"));
      }
    }
    if (cleanQris.startsWith("/")) {
      const candidatePaths = [
        import_path5.default.resolve(process.cwd(), "dist", cleanQris.replace(/^\//, "")),
        import_path5.default.resolve(process.cwd(), "public", cleanQris.replace(/^\//, "")),
        import_path5.default.resolve("/var/task", "dist", cleanQris.replace(/^\//, "")),
        import_path5.default.resolve("/var/task", "public", cleanQris.replace(/^\//, ""))
      ];
      for (const p of candidatePaths) {
        if (import_fs5.default.existsSync(p) && import_fs5.default.statSync(p).isFile()) {
          const ext = import_path5.default.extname(p).toLowerCase();
          const mime = ext === ".png" ? "image/png" : ext === ".webp" ? "image/webp" : "image/jpeg";
          res.setHeader("Content-Type", mime);
          res.setHeader("Cache-Control", "public, max-age=86400");
          return res.sendFile(p);
        }
      }
    }
    if (cleanQris.startsWith("http://") || cleanQris.startsWith("https://")) {
      return res.redirect(cleanQris);
    }
    return res.status(404).json({ error: "Gambar QRIS tidak dapat diakses." });
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat gambar QRIS." });
  }
});
merchantRouter.post("/", requireRole(["ADMIN"]), async (req, res) => {
  const merchantData = req.body;
  try {
    const actorId = req.user?.userId || "admin";
    const created = await foodDb.createMerchant(actorId, merchantData);
    res.status(201).json(created);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.put("/:id", requireMerchantOwner("id"), async (req, res) => {
  const updates = { ...req.body };
  delete updates.id;
  try {
    const actorId = req.user?.userId || req.user?.entityId || req.params.id;
    const actorRole = req.user?.role === "ADMIN" || req.user?.role === "MASTER_ADMIN" || req.user?.isMasterAdmin ? "ADMIN" : "MERCHANT";
    const updated = await foodDb.updateMerchant(actorId, req.params.id, updates, actorRole);
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.put("/:id/qris", requireMerchantOwner("id"), async (req, res) => {
  const { qrisImage } = req.body;
  if (!qrisImage || typeof qrisImage !== "string" || qrisImage.trim().length < 10) {
    return res.status(400).json({ error: "Gambar QRIS statis wajib diunggah dalam format gambar yang sah." });
  }
  const cleanQris = qrisImage.trim();
  if (!cleanQris.startsWith("data:image/") && !cleanQris.startsWith("http://") && !cleanQris.startsWith("https://")) {
    return res.status(400).json({ error: "Format QRIS tidak didukung. Unggah gambar berformat JPEG, PNG, atau WebP." });
  }
  if (cleanQris.length > 7 * 1024 * 1024) {
    return res.status(400).json({ error: "Ukuran file gambar QRIS melebihi batas maksimal 5MB. Silakan gunakan gambar yang lebih kecil." });
  }
  try {
    const actorId = req.user?.userId || req.user?.entityId || req.params.id;
    const actorRole = req.user?.role === "ADMIN" || req.user?.role === "MASTER_ADMIN" || req.user?.isMasterAdmin ? "ADMIN" : "MERCHANT";
    const updated = await foodDb.updateMerchant(
      actorId,
      req.params.id,
      {
        qrisImage: cleanQris,
        qrisUpdatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      actorRole
    );
    res.json({
      success: true,
      message: "QRIS statis merchant berhasil disimpan.",
      qrisImage: updated.qrisImage,
      qrisUpdatedAt: updated.qrisUpdatedAt,
      merchant: updated
    });
  } catch (e) {
    res.status(400).json({ error: e.message || "Gagal menyimpan QRIS merchant." });
  }
});
merchantRouter.delete("/:id/qris", requireMerchantOwner("id"), async (req, res) => {
  try {
    const actorId = req.user?.userId || req.user?.entityId || req.params.id;
    const actorRole = req.user?.role === "ADMIN" || req.user?.role === "MASTER_ADMIN" || req.user?.isMasterAdmin ? "ADMIN" : "MERCHANT";
    const updated = await foodDb.updateMerchant(
      actorId,
      req.params.id,
      {
        qrisImage: "",
        qrisUpdatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      actorRole
    );
    res.json({
      success: true,
      message: "QRIS statis merchant berhasil dihapus.",
      merchant: updated
    });
  } catch (e) {
    res.status(400).json({ error: e.message || "Gagal menghapus QRIS merchant." });
  }
});
merchantRouter.delete("/:id", requireRole(["ADMIN"]), async (req, res) => {
  const actorId = req.user?.userId || "admin";
  try {
    const success = await foodDb.deleteMerchant(actorId, req.params.id);
    if (success) res.json({ success: true });
    else res.status(404).json({ error: "Merchant not found" });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.get("/:id/categories", (req, res, next) => {
  try {
    res.json(foodDb.getCategories(req.params.id));
  } catch (err) {
    next(err);
  }
});
merchantRouter.post("/:id/categories", requireMerchantOwner("id"), async (req, res) => {
  const { name } = req.body;
  if (!name || !name.trim()) {
    return res.status(400).json({ error: "Nama kategori wajib diisi." });
  }
  try {
    const created = await foodDb.createCategory(req.params.id, name.trim());
    res.status(201).json(created);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.put("/:merchantId/categories/:id", requireMerchantOwner("merchantId"), async (req, res) => {
  const { name } = req.body;
  if (!name || !name.trim()) {
    return res.status(400).json({ error: "Nama kategori wajib diisi." });
  }
  try {
    const updated = await foodDb.updateCategory(req.params.merchantId, req.params.id, name.trim());
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.delete("/:merchantId/categories/:id", requireMerchantOwner("merchantId"), async (req, res) => {
  try {
    const success = await foodDb.deleteCategory(req.params.merchantId, req.params.id);
    if (success) res.json({ success: true });
    else res.status(404).json({ error: "Category not found" });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.get("/:id/menu", (req, res, next) => {
  try {
    res.json(foodDb.getMenuItemsByMerchant(req.params.id));
  } catch (err) {
    next(err);
  }
});
merchantRouter.post("/:id/menu", requireMerchantOwner("id"), async (req, res) => {
  try {
    const created = await foodDb.createMenuItem(req.params.id, req.body);
    res.status(201).json(created);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.put("/:merchantId/menu/:id", requireMerchantOwner("merchantId"), async (req, res) => {
  try {
    const updated = await foodDb.updateMenuItem(req.params.merchantId, req.params.id, req.body);
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.delete("/:merchantId/menu/:id", requireMerchantOwner("merchantId"), async (req, res) => {
  try {
    const success = await foodDb.deleteMenuItem(req.params.merchantId, req.params.id);
    if (success) res.json({ success: true });
    else res.status(404).json({ error: "Menu item not found" });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.get("/:merchantId/orders", requireMerchantOwner("merchantId"), async (req, res) => {
  try {
    const rawTarget = req.params.merchantId;
    const targetId = rawTarget === "me" ? req.user?.entityId || req.user?.userId || "" : rawTarget;
    const orders = await foodDb.findOrdersByMerchant(targetId);
    res.json(orders);
  } catch (err) {
    console.error(`[Merchant Orders Error] Gagal memuat pesanan untuk merchant "${req.params.merchantId}":`, err?.message);
    res.status(500).json({ error: err?.message || "Gagal memuat daftar pesanan merchant." });
  }
});
merchantRouter.get("/:merchantId/settlements", requireMerchantOwner("merchantId"), (req, res) => {
  res.json(foodDb.getSettlementsByMerchant(req.params.merchantId));
});

// src/server/routes/driverRoutes.ts
var import_express3 = require("express");
init_db();
init_auth();
var driverRouter = (0, import_express3.Router)();
driverRouter.get("/", (req, res) => {
  const drivers = foodDb.getDrivers();
  const sanitized = drivers.map((d) => ({
    id: d.id,
    name: d.name,
    phone: d.phone,
    active: d.active
  }));
  res.json(sanitized);
});
driverRouter.get("/:id", requireDriverSelf("id"), (req, res) => {
  const d = foodDb.getDriverById(req.params.id);
  if (!d) return res.status(404).json({ error: "Driver not found" });
  res.json(d);
});
driverRouter.post("/", requireRole(["ADMIN"]), async (req, res) => {
  const { userId, ...driverData } = req.body;
  try {
    const created = await foodDb.createDriver(req.user?.userId || userId || "admin", driverData);
    res.status(201).json(created);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
driverRouter.put("/:id", requireDriverSelf("id"), async (req, res) => {
  const { userId, role, ...updates } = req.body;
  try {
    const updated = await foodDb.updateDriver(
      req.user?.userId || userId || req.params.id,
      req.params.id,
      updates,
      req.user?.role || role || "DRIVER"
    );
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
driverRouter.delete("/:id", requireRole(["ADMIN"]), async (req, res) => {
  const { userId } = req.body;
  try {
    const success = await foodDb.deleteDriver(req.user?.userId || userId || "admin", req.params.id);
    if (success) res.json({ success: true });
    else res.status(404).json({ error: "Driver not found" });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
driverRouter.get("/:driverId/orders", requireDriverSelf("driverId"), (req, res) => {
  res.json(foodDb.getOrdersByDriver(req.params.driverId));
});
driverRouter.get("/:driverId/available-orders", requireDriverSelf("driverId"), (_req, res) => {
  res.json(foodDb.getAvailableOrdersForDrivers());
});
driverRouter.post("/:driverId/accept-order/:orderId", requireDriverSelf("driverId"), async (req, res) => {
  try {
    const updated = await foodDb.acceptDriverTask(req.params.driverId, req.params.orderId);
    res.json({ success: true, order: updated });
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal menerima tugas pesanan." });
  }
});

// src/server/routes/orderRoutes.ts
var import_path6 = __toESM(require("path"), 1);
var import_fs6 = __toESM(require("fs"), 1);
var import_crypto3 = __toESM(require("crypto"), 1);
var import_express4 = require("express");
var import_sharp = __toESM(require("sharp"), 1);
init_db();
init_config();
init_types();
init_auth();
var orderRouter = (0, import_express4.Router)();
function generateOrderProofToken(orderId) {
  const secret = foodConfig.jwtSecret || "tumpanggo_secure_proof_token_secret_min32";
  return import_crypto3.default.createHmac("sha256", secret).update(`proof:${orderId}`).digest("hex");
}
function verifyOrderProofToken(orderId, token) {
  if (!token || typeof token !== "string") return false;
  const expected = generateOrderProofToken(orderId);
  try {
    const a = Buffer.from(token);
    const b = Buffer.from(expected);
    if (a.length !== b.length) return false;
    return import_crypto3.default.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}
orderRouter.get("/", async (req, res) => {
  const user = req.user;
  if (!user) {
    return res.status(401).json({ error: "Autentikasi diperlukan untuk melihat daftar pesanan." });
  }
  if (user.role === "ADMIN" || user.role === "MASTER_ADMIN") {
    foodDb.reloadFromDiskIfNeeded();
    return res.json(foodDb.getOrders());
  }
  if (user.role === "MERCHANT") {
    const merchantId = user.entityId || user.userId;
    if (merchantId) {
      const orders = await foodDb.findOrdersByMerchant(merchantId);
      return res.json(orders);
    }
  }
  if (user.role === "DRIVER") {
    const driverId = user.entityId || user.userId;
    if (driverId) {
      foodDb.reloadFromDiskIfNeeded();
      return res.json(foodDb.getOrdersByDriver(driverId));
    }
  }
  return res.status(403).json({ error: "Akses ditolak." });
});
orderRouter.get("/:id/receipt", async (req, res) => {
  try {
    const o = await foodDb.findOrder(req.params.id);
    if (!o) return res.status(404).json({ error: "Pesanan tidak ditemukan." });
    const isPaid = o.paymentStatus === "PAID" /* PAID */ || ["PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */, "COOKING" /* COOKING */, "READY_FOR_PICKUP" /* READY_FOR_PICKUP */, "ORDER_PICKED_UP" /* ORDER_PICKED_UP */, "DELIVERED" /* DELIVERED */, "COMPLETED" /* COMPLETED */].includes(o.status);
    if (!isPaid) {
      return res.status(403).json({
        error: "E-Receipt belum dapat diterbitkan. Pembayaran belum diverifikasi atau belum lunas.",
        code: "PAYMENT_NOT_VERIFIED",
        orderId: o.id,
        paymentStatus: o.paymentStatus || "PENDING",
        orderStatus: o.status
      });
    }
    const user = req.user;
    const isPrivilegedUser = user && (user.role === "ADMIN" || user.role === "MASTER_ADMIN" || user.role === "MERCHANT" && user.entityId === o.merchantId || user.role === "DRIVER" && user.entityId === o.driverId || user.role === "CUSTOMER" && (user.userId === o.customerId || user.email && o.customerPhone && user.email === o.customerPhone));
    if (!isPrivilegedUser) {
      const queryPhone = req.query.phone ? String(req.query.phone).trim() : "";
      const headerPhone = req.headers["x-customer-phone"] ? String(req.headers["x-customer-phone"]).trim() : "";
      const providedPhone = queryPhone || headerPhone;
      const normOrderPhone = String(o.customerPhone || "").replace(/\D/g, "");
      const normProvidedPhone = providedPhone.replace(/\D/g, "");
      const phoneMatches = Boolean(
        normProvidedPhone.length >= 4 && (normOrderPhone.endsWith(normProvidedPhone) || normProvidedPhone.endsWith(normOrderPhone))
      );
      if (!phoneMatches) {
        return res.status(403).json({
          error: "Akses ditolak: Verifikasi nomor WhatsApp pemesan diperlukan untuk mengakses rincian E-Receipt.",
          code: "RECEIPT_VERIFICATION_REQUIRED",
          orderId: o.id
        });
      }
    }
    let receipt = o.receipt;
    if (!receipt) {
      const canonicalCode = o.orderNumber || o.id;
      const cleanRef = canonicalCode.replace(/^ord_/, "").replace(/^TF-/, "").toUpperCase();
      const receiptNumber = o.receiptNumber || `TG-RCP-${cleanRef}`;
      const issuedAt = o.paymentVerifiedAt || o.updatedAt || o.createdAt;
      receipt = {
        receiptNumber,
        orderId: o.id,
        orderNumber: canonicalCode,
        issuedAt,
        confirmedBy: o.paymentVerifiedBy || "Admin TumpangGo",
        paymentMethod: o.paymentMethod || "MERCHANT_QRIS",
        transactionRef: o.artopayPaymentId || `QRIS-TG-${cleanRef}`,
        subtotal: o.subtotal,
        deliveryFee: o.deliveryFee,
        serviceFee: o.serviceFee,
        uniqueCode: o.uniqueCode || 0,
        total: o.total,
        customerName: o.customerName,
        merchantName: o.merchantName,
        status: "PAID"
      };
    }
    res.json({
      receipt,
      receiptNumber: receipt.receiptNumber,
      orderNumber: receipt.orderNumber,
      ...receipt,
      order: {
        id: o.id,
        orderNumber: o.orderNumber || o.id,
        customerName: o.customerName,
        customerPhoneMasked: o.customerPhone ? o.customerPhone.substring(0, 4) + "****" + o.customerPhone.slice(-3) : "",
        deliveryAddress: o.deliveryAddress,
        merchantId: o.merchantId,
        merchantName: o.merchantName,
        items: o.items,
        subtotal: o.subtotal,
        deliveryFee: o.deliveryFee,
        serviceFee: o.serviceFee,
        uniqueCode: o.uniqueCode || 0,
        total: o.total,
        paymentStatus: o.paymentStatus,
        status: o.status,
        paymentMethod: o.paymentMethod || "MERCHANT_QRIS",
        paymentVerifiedAt: o.paymentVerifiedAt,
        paymentVerifiedBy: o.paymentVerifiedBy || "Admin TumpangGo",
        createdAt: o.createdAt
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat E-Receipt." });
  }
});
function serializePublicOrderTracking(order) {
  if (!order) return null;
  const rawPhone = String(order.customerPhone || "").trim();
  let maskedPhone = "";
  if (rawPhone.length >= 7) {
    maskedPhone = rawPhone.substring(0, 4) + "****" + rawPhone.slice(-3);
  } else if (rawPhone.length > 0) {
    maskedPhone = rawPhone.substring(0, 2) + "****";
  }
  const sanitizedItems = Array.isArray(order.items) ? order.items.map((item) => ({
    id: item.id || item.menuItemId || "",
    menuItemId: item.menuItemId || item.id || "",
    name: String(item.name || ""),
    price: Number(item.price) || 0,
    quantity: Number(item.quantity) || 1,
    notes: item.notes ? String(item.notes) : ""
  })) : [];
  const canonicalCode = order.orderNumber || order.id;
  const cleanRef = String(canonicalCode).replace(/^ord_/, "").replace(/^TF-/, "").toUpperCase();
  const receiptNumber = order.receiptNumber || order.receipt?.receiptNumber || `TG-RCP-${cleanRef}`;
  return {
    id: order.id,
    orderNumber: canonicalCode,
    createdAt: order.createdAt,
    updatedAt: order.updatedAt,
    status: order.status,
    paymentStatus: order.paymentStatus,
    paymentMethod: order.paymentMethod || "MERCHANT_QRIS",
    merchantId: order.merchantId,
    merchantName: order.merchantName,
    cookingTimeMinutes: typeof order.cookingTimeMinutes === "number" ? order.cookingTimeMinutes : null,
    cookingDurationMinutes: typeof order.cookingDurationMinutes === "number" ? order.cookingDurationMinutes : typeof order.cookingTimeMinutes === "number" ? order.cookingTimeMinutes : null,
    cookingStartedAt: order.cookingStartedAt || null,
    cookingEndsAt: order.cookingEndsAt || null,
    driverName: order.driverName || null,
    customerPhone: maskedPhone,
    customerPhoneMasked: maskedPhone,
    items: sanitizedItems,
    subtotal: Number(order.subtotal) || 0,
    deliveryFee: Number(order.deliveryFee) || 0,
    serviceFee: Number(order.serviceFee) || 0,
    uniqueCode: Number(order.uniqueCode) || 0,
    total: Number(order.total) || 0,
    receiptNumber,
    receipt: order.receipt ? {
      receiptNumber: order.receipt.receiptNumber || receiptNumber,
      orderNumber: canonicalCode,
      issuedAt: order.receipt.issuedAt || order.paymentVerifiedAt || order.createdAt,
      status: order.receipt.status || "PAID",
      paymentMethod: order.receipt.paymentMethod || "MERCHANT_QRIS",
      total: Number(order.receipt.total || order.total) || 0
    } : null,
    cancelReason: order.cancelReason || null,
    paymentRejectionReason: order.paymentRejectionReason || null,
    hasPaymentProof: Boolean(order.paymentProof && String(order.paymentProof).trim().length > 10),
    isPublicTracking: true
  };
}
orderRouter.get("/:id", async (req, res) => {
  const o = await foodDb.findOrder(req.params.id);
  if (!o) return res.status(404).json({ error: "Pesanan tidak ditemukan. Periksa kembali kode order Anda." });
  const user = req.user;
  if (user && (user.role === "ADMIN" || user.role === "MASTER_ADMIN")) {
    return res.json(o);
  }
  if (user && user.role === "MERCHANT") {
    const merchantId = user.entityId || user.userId;
    if (merchantId && o.merchantId === merchantId) {
      return res.json(o);
    }
    return res.status(403).json({ error: "Akses ditolak: Anda tidak memiliki izin untuk melihat rincian pesanan toko lain." });
  }
  if (user && user.role === "DRIVER") {
    const verifiedDriverId = user.entityId || user.userId;
    const isAssigned = o.driverId === verifiedDriverId;
    const isAvailableBroadcast = !o.driverId && [
      "READY_FOR_PICKUP" /* READY_FOR_PICKUP */,
      "COOKING" /* COOKING */,
      "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */
    ].includes(o.status);
    if (isAssigned || isAvailableBroadcast) {
      return res.json(o);
    }
    return res.status(403).json({
      error: "Akses ditolak: Anda tidak memiliki izin untuk melihat rincian pesanan driver lain."
    });
  }
  return res.json(serializePublicOrderTracking(o));
});
orderRouter.get("/:id/qris", async (req, res) => {
  try {
    const order = await foodDb.findOrder(req.params.id);
    if (!order) return res.status(404).json({ error: "Pesanan tidak ditemukan." });
    const merchant = foodDb.getMerchantById(order.merchantId);
    const rawQris = order.merchantQrisImage || merchant?.qrisImage;
    const hasQris = Boolean(rawQris && typeof rawQris === "string" && rawQris.trim().length > 3 && !rawQris.includes("unsplash"));
    res.json({
      orderId: order.id,
      merchantId: order.merchantId,
      merchantName: order.merchantName,
      total: order.total,
      hasQris,
      qrisImage: hasQris ? rawQris : null,
      qrisImageUrl: hasQris ? `/api/orders/${order.id}/qris-image` : null
    });
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat status QRIS pesanan." });
  }
});
orderRouter.get("/:id/qris-image", async (req, res) => {
  try {
    const order = await foodDb.findOrder(req.params.id);
    if (!order) return res.status(404).json({ error: "Pesanan tidak ditemukan." });
    const merchant = foodDb.getMerchantById(order.merchantId);
    const rawQris = order.merchantQrisImage || merchant?.qrisImage;
    if (!rawQris || typeof rawQris !== "string" || rawQris.trim().length < 3 || rawQris.includes("unsplash")) {
      return res.status(404).json({ error: `Toko "${order.merchantName}" belum memiliki QRIS statis resmi.` });
    }
    const cleanQris = rawQris.trim();
    if (cleanQris.startsWith("data:image/")) {
      const matches = cleanQris.match(/^data:(image\/[a-zA-Z0-9.+_-]+);base64,(.+)$/);
      if (matches) {
        res.setHeader("Content-Type", matches[1]);
        res.setHeader("Cache-Control", "public, max-age=86400");
        return res.send(Buffer.from(matches[2], "base64"));
      }
    }
    if (cleanQris.startsWith("/")) {
      const candidatePaths = [
        import_path6.default.resolve(process.cwd(), "dist", cleanQris.replace(/^\//, "")),
        import_path6.default.resolve(process.cwd(), "public", cleanQris.replace(/^\//, "")),
        import_path6.default.resolve("/var/task", "dist", cleanQris.replace(/^\//, "")),
        import_path6.default.resolve("/var/task", "public", cleanQris.replace(/^\//, ""))
      ];
      for (const p of candidatePaths) {
        if (import_fs6.default.existsSync(p) && import_fs6.default.statSync(p).isFile()) {
          const ext = import_path6.default.extname(p).toLowerCase();
          const mime = ext === ".png" ? "image/png" : ext === ".webp" ? "image/webp" : "image/jpeg";
          res.setHeader("Content-Type", mime);
          res.setHeader("Cache-Control", "public, max-age=86400");
          return res.sendFile(p);
        }
      }
    }
    if (cleanQris.startsWith("http://") || cleanQris.startsWith("https://")) {
      return res.redirect(cleanQris);
    }
    return res.status(404).json({ error: "Gambar QRIS pesanan tidak dapat diakses." });
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat gambar QRIS pesanan." });
  }
});
orderRouter.get("/:id/payment-proof", async (req, res) => {
  try {
    const order = await foodDb.findOrder(req.params.id);
    if (!order) return res.status(404).json({ error: "Pesanan tidak ditemukan." });
    const proof = order.paymentProof;
    if (!proof || typeof proof !== "string" || proof.trim().length < 10) {
      return res.status(404).json({ error: "Bukti pembayaran belum diunggah untuk pesanan ini." });
    }
    const user = req.user;
    const proofToken = req.query.proofToken || req.query.token || req.headers["x-order-token"];
    const hasValidProofToken = Boolean(proofToken && verifyOrderProofToken(order.id, proofToken));
    if (!user && !hasValidProofToken) {
      return res.status(401).json({
        error: "Akses ditolak: Autentikasi server diperlukan untuk melihat bukti pembayaran."
      });
    }
    if (user) {
      if (user.role === "ADMIN" || user.role === "MASTER_ADMIN") {
      } else if (user.role === "MERCHANT") {
        const merchantId = user.entityId || user.userId;
        if (merchantId !== order.merchantId) {
          return res.status(403).json({
            error: "Akses ditolak: Anda tidak memiliki izin untuk melihat bukti pembayaran pesanan toko lain."
          });
        }
      } else if (user.role === "DRIVER") {
        const driverId = user.entityId || user.userId;
        if (!order.driverId || order.driverId !== driverId) {
          return res.status(403).json({
            error: "Akses ditolak: Anda bukan kurir yang ditugaskan untuk pesanan ini."
          });
        }
      } else if (user.role === "CUSTOMER") {
        const customerId = user.userId;
        const customerPhone = user.email || user.entityId;
        const normOrderPhone = String(order.customerPhone || "").replace(/\D/g, "");
        const normUserPhone = String(customerPhone || "").replace(/\D/g, "");
        const isOwner = customerId === order.customerId || normUserPhone.length >= 8 && normOrderPhone.endsWith(normUserPhone);
        if (!isOwner && !hasValidProofToken) {
          return res.status(403).json({
            error: "Akses ditolak: Anda bukan pemilik pesanan ini."
          });
        }
      } else {
        return res.status(403).json({ error: "Akses ditolak." });
      }
    }
    const cleanProof = proof.trim();
    if (cleanProof.startsWith("data:image/")) {
      const matches = cleanProof.match(/^data:(image\/[a-zA-Z0-9.+_-]+);base64,(.+)$/);
      if (matches) {
        res.setHeader("Content-Type", matches[1]);
        res.setHeader("Cache-Control", "private, max-age=3600");
        return res.send(Buffer.from(matches[2], "base64"));
      }
    }
    if (cleanProof.startsWith("http://") || cleanProof.startsWith("https://")) {
      return res.redirect(cleanProof);
    }
    return res.status(404).json({ error: "Format bukti pembayaran tidak valid." });
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat bukti pembayaran." });
  }
});
var customerHistoryRateLimiter = /* @__PURE__ */ new Map();
function checkCustomerHistoryRateLimit(key, limit = 5, windowMs = 6e4) {
  const now = Date.now();
  const entry = customerHistoryRateLimiter.get(key);
  if (!entry || now > entry.resetAt) {
    customerHistoryRateLimiter.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, retryAfter: 0 };
  }
  if (entry.count >= limit) {
    return { allowed: false, retryAfter: Math.ceil((entry.resetAt - now) / 1e3) };
  }
  entry.count++;
  return { allowed: true, retryAfter: 0 };
}
orderRouter.get("/customer/:phone", (req, res) => {
  const rawPhone = String(req.params.phone || "").trim();
  const clientIp = String(req.ip || req.headers["x-forwarded-for"] || "client");
  const rateKey = `hist_${clientIp}`;
  const rateCheck = checkCustomerHistoryRateLimit(rateKey, 5, 6e4);
  if (!rateCheck.allowed) {
    res.setHeader("Retry-After", String(rateCheck.retryAfter));
    return res.status(429).json({
      error: "Terlalu banyak permintaan riwayat pesanan. Silakan coba kembali dalam beberapa saat.",
      retryAfter: rateCheck.retryAfter
    });
  }
  const user = req.user;
  const isPrivileged = user && (user.role === "ADMIN" || user.role === "MASTER_ADMIN");
  const normParam = rawPhone.replace(/\D/g, "");
  const isVerifiedCustomer = user && user.role === "CUSTOMER" && (user.email && user.email.replace(/\D/g, "") === normParam || user.entityId && user.entityId.replace(/\D/g, "") === normParam);
  if (!isPrivileged && !isVerifiedCustomer) {
    return res.status(403).json({
      error: "Akses ditolak: Akses riwayat pesanan berdasarkan nomor telepon tanpa verifikasi kepemilikan dinonaktifkan demi privasi pelanggan. Silakan gunakan fitur Lacak Order dengan kode pesanan resmi Anda.",
      code: "UNVERIFIED_CUSTOMER_HISTORY_DISABLED"
    });
  }
  const orders = foodDb.getOrdersByCustomerPhone(rawPhone);
  const sanitized = orders.map((o) => serializePublicOrderTracking(o));
  res.json(sanitized);
});
orderRouter.post("/", async (req, res) => {
  const reqId = req.id || req.headers["x-request-id"] || "req_" + Math.random().toString(36).substring(2, 9);
  try {
    const { merchantId, customerName, customerPhone, deliveryAddress, items } = req.body || {};
    if (!merchantId || typeof merchantId !== "string" || merchantId.trim().length === 0) {
      console.warn(`[Order Validation Error] [${reqId}] Merchant ID is missing`);
      return res.status(400).json({
        error: "Toko / Merchant kuliner wajib dipilih.",
        code: "MISSING_MERCHANT_ID",
        stage: "ORDER_VALIDATION",
        requestId: reqId
      });
    }
    if (!customerName || !customerPhone || !deliveryAddress) {
      console.warn(`[Order Validation Error] [${reqId}] Customer details missing (Name: ${Boolean(customerName)}, Phone: ${Boolean(customerPhone)}, Address: ${Boolean(deliveryAddress)})`);
      return res.status(400).json({
        error: "Nama pemesan, nomor WhatsApp, dan alamat pengantaran wajib diisi lengkap.",
        code: "MISSING_CUSTOMER_DETAILS",
        stage: "ORDER_VALIDATION",
        requestId: reqId
      });
    }
    if (!items || !Array.isArray(items) || items.length === 0) {
      console.warn(`[Order Validation Error] [${reqId}] Cart items empty`);
      return res.status(400).json({
        error: "Keranjang belanja Anda kosong. Silakan pilih menu makanan terlebih dahulu.",
        code: "EMPTY_CART",
        stage: "ORDER_VALIDATION",
        requestId: reqId
      });
    }
    const created = await foodDb.createOrder(req.body);
    console.log(`[Order Placed Successfully] [${reqId}] ID: ${created.id}, Total: Rp ${created.total.toLocaleString("id-ID")}, Merchant: ${created.merchantId}, UniqueCode: ${created.uniqueCode}`);
    return res.status(201).json(created);
  } catch (e) {
    const errorMsg = e.message || "Gagal membuat pesanan.";
    const isDbError = errorMsg.includes("Firestore") || errorMsg.includes("database") || errorMsg.includes("penyimpanan");
    console.error(`[Order Creation Failed] [${reqId}] Stage: ${isDbError ? "DATABASE_PERSISTENCE" : "ORDER_VALIDATION"}, Error: ${errorMsg}`);
    return res.status(isDbError ? 500 : 400).json({
      error: errorMsg,
      code: isDbError ? "DATABASE_PERSISTENCE_ERROR" : "ORDER_VALIDATION_ERROR",
      stage: isDbError ? "DATABASE_PERSISTENCE" : "ORDER_VALIDATION",
      requestId: reqId
    });
  }
});
var handleOrderUpdate = async (req, res) => {
  const user = req.user;
  const currentOrder = await foodDb.findOrder(req.params.id);
  if (!currentOrder) {
    return res.status(404).json({ error: "Pesanan tidak ditemukan." });
  }
  const { userId, role, customerPhone, cancelReason, overrideExpired, ...rawUpdates } = req.body;
  const updates = { ...rawUpdates };
  delete updates.isSettled;
  delete updates.settlementId;
  delete updates.settledAt;
  delete updates.total;
  delete updates.subtotal;
  delete updates.serviceFee;
  delete updates.deliveryFee;
  delete updates.merchantId;
  delete updates.id;
  if (updates.status === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */ || updates.paymentStatus === "PAID" /* PAID */) {
    if (!user || user.role !== "ADMIN" && user.role !== "MASTER_ADMIN") {
      return res.status(403).json({
        error: "Akses ditolak: Hanya Admin yang berwenang memverifikasi pembayaran menjadi lunas (PAID)."
      });
    }
  }
  if (updates.status === "PAYMENT_REJECTED" /* PAYMENT_REJECTED */ || updates.paymentStatus === "REJECTED" /* REJECTED */) {
    if (!user || user.role !== "ADMIN" && user.role !== "MASTER_ADMIN") {
      return res.status(403).json({
        error: "Akses ditolak: Hanya Admin yang berwenang menolak bukti pembayaran."
      });
    }
  }
  if (!user) {
    const isCustomerCancel = updates.status === "CANCELLED" /* CANCELLED */ && customerPhone && String(customerPhone).trim() === String(currentOrder.customerPhone).trim() && (currentOrder.status === "WAITING_PAYMENT" /* WAITING_PAYMENT */ || currentOrder.status === "WAITING_PAYMENT_VERIFICATION" /* WAITING_PAYMENT_VERIFICATION */);
    if (!isCustomerCancel) {
      return res.status(401).json({
        error: "Akses ditolak: Autentikasi diperlukan untuk mengubah status atau data pesanan."
      });
    }
    try {
      const updated = await foodDb.updateOrder(
        "CUSTOMER",
        req.params.id,
        {
          status: "CANCELLED" /* CANCELLED */,
          cancelReason: cancelReason || "Dibatalkan oleh Pelanggan"
        },
        "CUSTOMER"
      );
      return res.json(updated);
    } catch (e) {
      return res.status(400).json({ error: e.message });
    }
  }
  if (user.role === "MERCHANT") {
    if (user.entityId !== currentOrder.merchantId && user.userId !== currentOrder.merchantId) {
      return res.status(403).json({
        error: "Akses ditolak: Anda tidak memiliki izin untuk mengelola pesanan milik toko lain."
      });
    }
    if (updates.status) {
      const allowedMerchantStatuses = [
        "COOKING" /* COOKING */,
        "READY_FOR_PICKUP" /* READY_FOR_PICKUP */,
        "CANCELLED" /* CANCELLED */
      ];
      if (!allowedMerchantStatuses.includes(updates.status)) {
        return res.status(403).json({
          error: `Merchant tidak diizinkan mengubah status pesanan ke ${updates.status}.`
        });
      }
    }
    const rawDuration = updates.cookingDurationMinutes ?? updates.cookingTimeMinutes;
    if (rawDuration !== void 0 && rawDuration !== null) {
      const numDuration = Number(rawDuration);
      if (![15, 30, 45, 60].includes(numDuration)) {
        return res.status(400).json({
          error: "Pilihan estimasi waktu memasak tidak valid. Pilihan yang diizinkan: 15, 30, 45, atau 60 menit."
        });
      }
      updates.cookingDurationMinutes = numDuration;
      updates.cookingTimeMinutes = numDuration;
    }
    if (updates.status === "COOKING" /* COOKING */) {
      if (currentOrder.status !== "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */ && currentOrder.status !== "COOKING" /* COOKING */) {
        return res.status(400).json({
          error: "Pesanan belum dapat dimasak karena pembayaran belum diverifikasi lunas oleh Admin."
        });
      }
      const duration = updates.cookingDurationMinutes || updates.cookingTimeMinutes || currentOrder.cookingDurationMinutes || currentOrder.cookingTimeMinutes || 15;
      const isAlreadyCooking = currentOrder.status === "COOKING" /* COOKING */ && Boolean(currentOrder.cookingStartedAt && currentOrder.cookingEndsAt);
      const currentDuration = currentOrder.cookingDurationMinutes || currentOrder.cookingTimeMinutes;
      const durationChanged = Boolean(currentDuration && currentDuration !== duration);
      if (!isAlreadyCooking || durationChanged) {
        const now = /* @__PURE__ */ new Date();
        const startedAt = isAlreadyCooking && currentOrder.cookingStartedAt ? currentOrder.cookingStartedAt : now.toISOString();
        const startMs = new Date(startedAt).getTime();
        const endsAt = new Date(startMs + duration * 60 * 1e3).toISOString();
        updates.cookingDurationMinutes = duration;
        updates.cookingTimeMinutes = duration;
        updates.cookingStartedAt = startedAt;
        updates.cookingEndsAt = endsAt;
        updates.cookingEstimatedReadyAt = endsAt;
      } else {
        updates.cookingDurationMinutes = currentOrder.cookingDurationMinutes || duration;
        updates.cookingTimeMinutes = currentOrder.cookingTimeMinutes || duration;
        updates.cookingStartedAt = currentOrder.cookingStartedAt;
        updates.cookingEndsAt = currentOrder.cookingEndsAt;
        updates.cookingEstimatedReadyAt = currentOrder.cookingEstimatedReadyAt || currentOrder.cookingEndsAt;
      }
    }
  }
  if (user.role === "ADMIN" || user.role === "MASTER_ADMIN") {
    const rawDuration = updates.cookingDurationMinutes ?? updates.cookingTimeMinutes;
    if (rawDuration !== void 0 && rawDuration !== null) {
      const numDuration = Number(rawDuration);
      if (![15, 30, 45, 60].includes(numDuration)) {
        return res.status(400).json({
          error: "Pilihan estimasi waktu memasak tidak valid. Pilihan yang diizinkan: 15, 30, 45, atau 60 menit."
        });
      }
      updates.cookingDurationMinutes = numDuration;
      updates.cookingTimeMinutes = numDuration;
    }
    if (updates.status === "COOKING" /* COOKING */) {
      const duration = updates.cookingDurationMinutes || updates.cookingTimeMinutes || currentOrder.cookingDurationMinutes || currentOrder.cookingTimeMinutes || 15;
      const isAlreadyCooking = currentOrder.status === "COOKING" /* COOKING */ && Boolean(currentOrder.cookingStartedAt && currentOrder.cookingEndsAt);
      const currentDuration = currentOrder.cookingDurationMinutes || currentOrder.cookingTimeMinutes;
      const durationChanged = Boolean(currentDuration && currentDuration !== duration);
      if (!isAlreadyCooking || durationChanged) {
        const now = /* @__PURE__ */ new Date();
        const startedAt = isAlreadyCooking && currentOrder.cookingStartedAt ? currentOrder.cookingStartedAt : now.toISOString();
        const startMs = new Date(startedAt).getTime();
        const endsAt = new Date(startMs + duration * 60 * 1e3).toISOString();
        updates.cookingDurationMinutes = duration;
        updates.cookingTimeMinutes = duration;
        updates.cookingStartedAt = startedAt;
        updates.cookingEndsAt = endsAt;
        updates.cookingEstimatedReadyAt = endsAt;
      } else {
        updates.cookingDurationMinutes = currentOrder.cookingDurationMinutes || duration;
        updates.cookingTimeMinutes = currentOrder.cookingTimeMinutes || duration;
        updates.cookingStartedAt = currentOrder.cookingStartedAt;
        updates.cookingEndsAt = currentOrder.cookingEndsAt;
        updates.cookingEstimatedReadyAt = currentOrder.cookingEstimatedReadyAt || currentOrder.cookingEndsAt;
      }
    }
  }
  if (user.role === "DRIVER") {
    const isAssigned = currentOrder.driverId === user.entityId || currentOrder.driverId === user.userId;
    const canAcceptTask = !currentOrder.driverId && ["READY_FOR_PICKUP" /* READY_FOR_PICKUP */, "COOKING" /* COOKING */, "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */].includes(currentOrder.status);
    if (!isAssigned && !canAcceptTask) {
      if (currentOrder.driverId && currentOrder.driverId !== (user.entityId || user.userId)) {
        return res.status(409).json({
          error: "Pesanan ini sudah diambil oleh kurir lain."
        });
      }
      return res.status(403).json({
        error: "Akses ditolak: Pesanan ini bukan tugas pengantaran Anda."
      });
    }
    if (!currentOrder.driverId && canAcceptTask) {
      const driver = foodDb.getDriverById(user.entityId || user.userId);
      if (!driver) {
        return res.status(404).json({ error: "Data identitas kurir tidak ditemukan di sistem." });
      }
      if (!driver.online || !driver.active) {
        return res.status(400).json({
          error: "Status Anda sedang Offline atau belum diaktifkan oleh Administrator. Aktifkan status Online terlebih dahulu untuk menerima tugas."
        });
      }
      updates.driverId = driver.id;
      updates.driverName = driver.name;
    }
    if (updates.status) {
      const allowedDriverStatuses = [
        "ORDER_PICKED_UP" /* ORDER_PICKED_UP */,
        "DELIVERED" /* DELIVERED */,
        "COMPLETED" /* COMPLETED */
      ];
      if (!allowedDriverStatuses.includes(updates.status)) {
        return res.status(403).json({
          error: `Driver tidak diizinkan mengubah status pesanan ke ${updates.status}.`
        });
      }
      if (updates.status === "ORDER_PICKED_UP" /* ORDER_PICKED_UP */) {
        if (currentOrder.status === "COOKING" /* COOKING */ || currentOrder.status === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */) {
          return res.status(400).json({
            error: 'Pesanan masih dalam proses memasak oleh merchant. Silakan tunggu hingga merchant menandai status pesanan "Siap Diambil".'
          });
        }
      }
      if (updates.status === "DELIVERED" /* DELIVERED */) {
        const hasDeliveryProof = Boolean(updates.deliveryProof || currentOrder.deliveryProof);
        if (!hasDeliveryProof) {
          return res.status(400).json({
            error: "Foto bukti pengantaran wajib diunggah sebelum menandai pesanan selesai diantar."
          });
        }
      }
    }
  }
  if (currentOrder.status === "EXPIRED" /* EXPIRED */ || currentOrder.status === "CANCELLED" /* CANCELLED */) {
    if (updates.status && updates.status !== currentOrder.status) {
      if ((user.role === "ADMIN" || user.role === "MASTER_ADMIN") && currentOrder.status === "EXPIRED" /* EXPIRED */) {
        if (!overrideExpired) {
          return res.status(400).json({
            error: "Pesanan telah KEDALUWARSA (EXPIRED). Verifikasi pembayaran tidak dapat dilakukan secara tidak sengaja. Sertakan persetujuan eksplisit pembayaran terlambat (overrideExpired: true) beserta catatan administrasi."
          });
        }
        foodDb.log(
          user.userId,
          `Admin explicitly approved late payment for expired order ${currentOrder.id}`,
          "ADMIN"
        );
      } else {
        return res.status(400).json({
          error: `Pesanan yang telah ${currentOrder.status} tidak dapat diaktifkan kembali secara langsung.`
        });
      }
    }
  }
  if (cancelReason) {
    updates.cancelReason = cancelReason;
  }
  try {
    const updated = await foodDb.updateOrder(
      user.userId || user.entityId || "system",
      req.params.id,
      updates,
      user.role
    );
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
};
orderRouter.put("/:id", handleOrderUpdate);
orderRouter.patch("/:id", handleOrderUpdate);
orderRouter.post("/:id/assign-driver", requireRole(["ADMIN"]), async (req, res) => {
  const { driverId } = req.body;
  if (!driverId) {
    return res.status(400).json({ error: "Driver ID wajib disertakan." });
  }
  try {
    const updated = await foodDb.manualAssignDriver(req.user?.userId || "admin", req.params.id, driverId);
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
orderRouter.post("/:id/accept-task", requireRole(["DRIVER", "ADMIN", "MASTER_ADMIN"]), async (req, res) => {
  let driverId = "";
  if (req.user?.role === "DRIVER") {
    driverId = req.user.entityId || req.user.userId;
  } else if (req.user?.role === "ADMIN" || req.user?.role === "MASTER_ADMIN") {
    driverId = req.body?.driverId || req.user.entityId || req.user.userId;
  }
  if (!driverId) {
    return res.status(400).json({ error: "Identitas driver tidak valid atau belum terautentikasi." });
  }
  try {
    const updated = await foodDb.acceptDriverTask(driverId, req.params.id);
    res.json({ success: true, order: updated });
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal menerima tugas pesanan." });
  }
});
orderRouter.post("/:id/upload-payment", async (req, res) => {
  const { paymentProof } = req.body;
  if (!paymentProof || typeof paymentProof !== "string" || paymentProof.trim().length < 10) {
    return res.status(400).json({ error: "Bukti pembayaran wajib diunggah dalam format gambar atau foto yang sah." });
  }
  const cleanProof = paymentProof.trim();
  const isDataUri = cleanProof.startsWith("data:image/");
  const isHttpUrl = cleanProof.startsWith("http://") || cleanProof.startsWith("https://");
  if (!isDataUri && !isHttpUrl) {
    return res.status(400).json({ error: "Format file tidak didukung. Mohon unggah bukti berformat gambar (JPG, PNG, atau WebP)." });
  }
  if (isDataUri && cleanProof.length > 11 * 1024 * 1024) {
    return res.status(400).json({ error: "Ukuran file gambar bukti transfer melebihi batas maksimal 8MB. Silakan pilih foto dengan resolusi lebih kecil." });
  }
  const order = await foodDb.findOrder(req.params.id);
  if (!order) {
    return res.status(404).json({ error: "Pesanan tidak ditemukan." });
  }
  const now = Date.now();
  const expiryTime = order.paymentExpiresAt ? new Date(order.paymentExpiresAt).getTime() : 0;
  if (expiryTime && now > expiryTime && order.status === "WAITING_PAYMENT" /* WAITING_PAYMENT */) {
    await foodDb.updateOrder("SYSTEM", order.id, {
      status: "EXPIRED" /* EXPIRED */,
      paymentStatus: "EXPIRED" /* EXPIRED */
    }, "SYSTEM");
    return res.status(400).json({
      error: "Waktu pembayaran untuk pesanan ini telah kedaluwarsa. Pesanan ditandai sebagai KEDALUWARSA dan tidak dapat diproses lagi."
    });
  }
  if (order.status === "EXPIRED" /* EXPIRED */) {
    return res.status(400).json({
      error: "Pesanan ini telah kedaluwarsa dan tidak dapat menerima bukti pembayaran lagi."
    });
  }
  if (order.status === "CANCELLED" /* CANCELLED */) {
    return res.status(400).json({
      error: "Pesanan ini telah dibatalkan dan tidak dapat menerima bukti pembayaran."
    });
  }
  let finalProof = cleanProof;
  const proofUrl = `/api/orders/${order.id}/payment-proof`;
  if (isDataUri) {
    try {
      const match = cleanProof.match(/^data:image\/([a-zA-Z0-9.+_-]+);base64,(.+)$/);
      if (match) {
        const rawBuffer = Buffer.from(match[2], "base64");
        const optimizedBuffer = await (0, import_sharp.default)(rawBuffer).rotate().resize({ width: 1200, height: 1200, fit: "inside", withoutEnlargement: true }).webp({ quality: 80 }).toBuffer();
        finalProof = `data:image/webp;base64,${optimizedBuffer.toString("base64")}`;
      }
    } catch (sharpErr) {
      console.warn("[OrderRoutes] Sharp optimization warning, falling back to original client image:", sharpErr?.message || sharpErr);
      if (sharpErr?.message?.includes("unsupported") || sharpErr?.message?.includes("Input buffer")) {
        return res.status(400).json({ error: "File gambar yang dipilih tidak valid atau rusak. Silakan pilih foto screenshot yang sah." });
      }
    }
  }
  try {
    const updated = await foodDb.updateOrder(
      "CUSTOMER",
      req.params.id,
      {
        paymentProof: finalProof,
        paymentProofUrl: proofUrl,
        paymentProofUploadedAt: (/* @__PURE__ */ new Date()).toISOString(),
        paymentStatus: "WAITING_VERIFICATION" /* WAITING_VERIFICATION */,
        status: "WAITING_PAYMENT_VERIFICATION" /* WAITING_PAYMENT_VERIFICATION */,
        paymentRejectionReason: void 0
      },
      "CUSTOMER"
    );
    res.json({
      ...updated,
      proofToken: generateOrderProofToken(updated.id)
    });
  } catch (e) {
    res.status(400).json({ error: e.message || "Gagal menyimpan bukti pembayaran." });
  }
});
orderRouter.post("/:id/verify-payment", requireRole(["ADMIN"]), async (req, res) => {
  const reqId = req.id || "req_" + Math.random().toString(36).substring(2, 8);
  const rawOrderId = String(req.params.id || "").trim();
  const adminId = req.user?.userId || req.user?.email || "admin";
  console.log(`[Order Verification Request] [${reqId}] POST /api/orders/:id/verify-payment received. Target order ID: "${rawOrderId}", Admin: "${adminId}"`);
  if (!rawOrderId) {
    console.warn(`[Order Verification Warning] [${reqId}] Missing order ID in route parameter.`);
    return res.status(400).json({ error: "ID pesanan wajib disertakan dalam parameter permintaan." });
  }
  try {
    const updated = await foodDb.verifyOrderPayment(adminId, rawOrderId);
    console.log(`[Order Verification Success] [${reqId}] Order "${updated.id}" successfully verified to PAID. Receipt issued: ${updated.receiptNumber || "None"}`);
    res.json({ success: true, order: updated });
  } catch (e) {
    console.error(`[Order Verification Error] [${reqId}] Failed verifying order "${rawOrderId}":`, e.message);
    res.status(400).json({ error: e.message || "Gagal memverifikasi pembayaran." });
  }
});
orderRouter.post("/:id/reject-payment", requireRole(["ADMIN"]), async (req, res) => {
  const reqId = req.id || "req_" + Math.random().toString(36).substring(2, 8);
  const rawOrderId = String(req.params.id || "").trim();
  const adminId = req.user?.userId || req.user?.email || "admin";
  const { reason } = req.body || {};
  console.log(`[Order Rejection Request] [${reqId}] POST /api/orders/:id/reject-payment received. Target order ID: "${rawOrderId}", Admin: "${adminId}"`);
  if (!rawOrderId) {
    console.warn(`[Order Rejection Warning] [${reqId}] Missing order ID in route parameter.`);
    return res.status(400).json({ error: "ID pesanan wajib disertakan dalam parameter permintaan." });
  }
  if (!reason || !String(reason).trim()) {
    console.warn(`[Order Rejection Warning] [${reqId}] Rejection reason is missing for order "${rawOrderId}".`);
    return res.status(400).json({ error: "Alasan penolakan bukti pembayaran wajib disertakan agar pelanggan dapat memperbaikinya." });
  }
  try {
    const updated = await foodDb.rejectOrderPayment(adminId, rawOrderId, String(reason).trim());
    console.log(`[Order Rejection Success] [${reqId}] Order "${updated.id}" status set to PAYMENT_REJECTED. Reason: "${String(reason).trim()}"`);
    res.json({ success: true, order: updated });
  } catch (e) {
    console.error(`[Order Rejection Error] [${reqId}] Failed rejecting order "${rawOrderId}":`, e.message);
    res.status(400).json({ error: e.message || "Gagal menolak bukti pembayaran." });
  }
});
orderRouter.post("/:id/upload-delivery", requireRole(["DRIVER", "ADMIN", "MASTER_ADMIN"]), async (req, res) => {
  const { deliveryProof } = req.body;
  if (!deliveryProof) {
    return res.status(400).json({ error: "Bukti foto pengantaran wajib disertakan." });
  }
  const order = await foodDb.findOrder(req.params.id);
  if (!order) {
    return res.status(404).json({ error: "Pesanan tidak ditemukan." });
  }
  const user = req.user;
  if (user.role === "DRIVER") {
    if (order.driverId !== user.entityId && order.driverId !== user.userId) {
      return res.status(403).json({ error: "Akses ditolak: Anda bukan kurir yang ditugaskan untuk pesanan ini." });
    }
  }
  try {
    const updated = await foodDb.updateOrder(
      user.userId || user.entityId || "driver",
      req.params.id,
      {
        deliveryProof,
        status: "COMPLETED" /* COMPLETED */
      },
      user.role
    );
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// src/server/routes/adminRoutes.ts
var import_express5 = require("express");
init_db();
init_auth();
var adminRouter = (0, import_express5.Router)();
adminRouter.get("/config", (req, res) => {
  const fullConfig = foodDb.getConfig();
  const { masterAccount, ...safeConfig } = fullConfig;
  const sanitizedMaster = masterAccount?.email ? { email: masterAccount.email } : void 0;
  res.json({
    ...safeConfig,
    ...sanitizedMaster ? { masterAccount: sanitizedMaster } : {}
  });
});
adminRouter.put("/config", requireRole(["ADMIN"]), async (req, res) => {
  const { userId, ...updates } = req.body;
  if (updates.masterAccount) {
    delete updates.masterAccount.passwordHash;
  }
  try {
    const config = await foodDb.updateConfig(req.user?.userId || userId || "admin", updates);
    const { masterAccount, ...safeConfig } = config;
    const sanitizedMaster = masterAccount?.email ? { email: masterAccount.email } : void 0;
    res.json({
      ...safeConfig,
      ...sanitizedMaster ? { masterAccount: sanitizedMaster } : {}
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
adminRouter.get("/partner-registrations", requireRole(["ADMIN"]), (req, res) => {
  res.json(foodDb.getPartnerRegistrations());
});
adminRouter.post("/partner-registrations", async (req, res) => {
  try {
    const created = await foodDb.createPartnerRegistration(req.body);
    res.status(201).json(created);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
var handleApproveRegistration = async (req, res) => {
  const { userId } = req.body;
  try {
    const result = await foodDb.approvePartnerRegistration(req.user?.userId || userId || "admin", req.params.id);
    if (result.success) {
      res.json({ success: true, registration: result.registration });
    } else {
      res.status(400).json({ error: result.error });
    }
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
adminRouter.put("/partner-registrations/:id/approve", requireRole(["ADMIN"]), handleApproveRegistration);
adminRouter.post("/partner-registrations/:id/approve", requireRole(["ADMIN"]), handleApproveRegistration);
var handleRejectRegistration = async (req, res) => {
  const { userId } = req.body;
  try {
    const success = await foodDb.rejectPartnerRegistration(req.user?.userId || userId || "admin", req.params.id);
    if (success) {
      res.json({ success: true });
    } else {
      res.status(404).json({ error: "Registration not found" });
    }
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
adminRouter.post("/partner-registrations/:id/reject", requireRole(["ADMIN"]), handleRejectRegistration);
adminRouter.put("/partner-registrations/:id/reject", requireRole(["ADMIN"]), handleRejectRegistration);
adminRouter.get("/settlements", requireRole(["ADMIN"]), (req, res) => {
  res.json(foodDb.getSettlements());
});
adminRouter.post("/settlements", requireRole(["ADMIN"]), async (req, res) => {
  const settlementData = req.body;
  try {
    const actorId = req.user?.userId || "admin";
    const created = await foodDb.createSettlement(actorId, settlementData);
    res.status(201).json(created);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
adminRouter.put("/settlements/:id", requireRole(["ADMIN"]), async (req, res) => {
  const updates = req.body;
  try {
    const actorId = req.user?.userId || "admin";
    const updated = await foodDb.updateSettlement(actorId, req.params.id, updates);
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
adminRouter.post("/settlements/generate", requireRole(["ADMIN"]), async (req, res) => {
  try {
    const actorId = req.user?.userId || "admin";
    const created = await foodDb.generateHPlusOneSettlements(actorId);
    res.json({ count: created.length, settlements: created });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
adminRouter.post("/settlements/:id/confirm", requireRole(["ADMIN"]), async (req, res) => {
  try {
    const actorId = req.user?.userId || "admin";
    const confirmed = await foodDb.confirmSettlement(actorId, req.params.id);
    res.json(confirmed);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
adminRouter.get("/clean-slate-plan", requireRole(["MASTER_ADMIN"]), async (req, res) => {
  try {
    const plan = await foodDb.getCleanSlatePlan();
    if (plan.isProduction && !plan.liveCloudConnected) {
      return res.status(503).json({
        error: "Koneksi Cloud Firestore produksi tidak tersedia.",
        plan
      });
    }
    res.json(plan);
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat rencana clean slate" });
  }
});
adminRouter.post("/clean-slate-merchants", requireRole(["MASTER_ADMIN"]), async (req, res) => {
  try {
    const actorId = req.user?.userId || req.user?.email || "master-admin";
    const result = await foodDb.cleanSlateMerchantCatalog(actorId);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal mengeksekusi clean slate data merchant" });
  }
});
adminRouter.post("/clean-slate-restore", requireRole(["MASTER_ADMIN"]), async (req, res) => {
  try {
    const actorId = req.user?.userId || req.user?.email || "master-admin";
    const { backupId } = req.body;
    if (!backupId || typeof backupId !== "string") {
      return res.status(400).json({ error: "Parameter backupId wajib diisi." });
    }
    const result = await foodDb.restoreMerchantCatalogFromBackup(actorId, backupId.trim());
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memulihkan katalog merchant dari backup" });
  }
});
adminRouter.get("/logs", requireRole(["ADMIN"]), (req, res) => {
  res.json(foodDb.getLogs());
});
var handleGetPublishedReviews = (req, res) => {
  try {
    const category = req.query.category;
    const list = foodDb.getPublishedTestimonials(category);
    res.json(list);
  } catch (e) {
    res.status(500).json({ error: e.message || "Gagal memuat review pengguna" });
  }
};
adminRouter.get("/testimonials", handleGetPublishedReviews);
adminRouter.get("/reviews", handleGetPublishedReviews);
function sanitizeInput(str) {
  if (typeof str !== "string") return "";
  return str.replace(/<[^>]*>?/gm, "").trim();
}
var handleSubmitReview = async (req, res) => {
  try {
    const rawName = sanitizeInput(req.body.userName);
    const rawCategory = String(req.body.category || "").toLowerCase().trim();
    const rawMerchantName = sanitizeInput(req.body.merchantName);
    const rawTitle = sanitizeInput(req.body.title);
    const rawContent = sanitizeInput(req.body.content);
    const rawRating = req.body.rating;
    const consentApproved = Boolean(req.body.consentApproved);
    if (!rawName || rawName.length < 2) {
      return res.status(400).json({ error: "Nama pemberi review wajib diisi (minimal 2 karakter)." });
    }
    if (rawName.length > 100) {
      return res.status(400).json({ error: "Nama pemberi review maksimal 100 karakter." });
    }
    if (rawCategory !== "merchant" && rawCategory !== "pelanggan" && rawCategory !== "umkm") {
      return res.status(400).json({ error: "Kategori ulasan tidak valid. Pilih Merchant atau Pelanggan." });
    }
    const normalizedCategory = rawCategory === "merchant" || rawCategory === "umkm" ? "merchant" : "pelanggan";
    if (normalizedCategory === "merchant") {
      if (!rawMerchantName || rawMerchantName.length < 2) {
        return res.status(400).json({ error: "Nama usaha atau merchant wajib diisi untuk ulasan merchant (minimal 2 karakter)." });
      }
      if (rawMerchantName.length > 100) {
        return res.status(400).json({ error: "Nama usaha atau merchant maksimal 100 karakter." });
      }
    }
    if (rawRating === void 0 || rawRating === null || rawRating === "") {
      return res.status(400).json({ error: "Rating bintang wajib dipilih (1 sampai 5)." });
    }
    const numRating = Number(rawRating);
    if (!Number.isInteger(numRating) || numRating < 1 || numRating > 5) {
      return res.status(400).json({ error: "Rating harus berupa bilangan bulat antara 1 sampai 5." });
    }
    if (rawTitle && rawTitle.length > 100) {
      return res.status(400).json({ error: "Judul review maksimal 100 karakter." });
    }
    if (!rawContent || rawContent.length < 10) {
      return res.status(400).json({ error: "Isi komentar/pengalaman wajib diisi minimal 10 karakter." });
    }
    if (rawContent.length > 1e3) {
      return res.status(400).json({ error: "Isi komentar/pengalaman maksimal 1000 karakter." });
    }
    if (!consentApproved) {
      return res.status(400).json({ error: "Anda harus menyetujui bahwa ulasan ini merupakan pengalaman nyata bersama TumpangGo." });
    }
    const roleDetail = normalizedCategory === "merchant" ? rawMerchantName ? `Pemilik ${rawMerchantName}` : "Mitra Kuliner Tumpang" : "Pelanggan TumpangGo";
    const created = await foodDb.createTestimonial({
      userName: rawName,
      merchantName: normalizedCategory === "merchant" ? rawMerchantName : void 0,
      category: normalizedCategory,
      title: rawTitle || void 0,
      content: rawContent,
      avatarUrl: void 0,
      roleDetail,
      rating: numRating,
      consentApproved: true,
      status: "pending",
      // Menunggu kurasi admin
      displayOrder: 99
    });
    res.status(201).json({
      success: true,
      message: "Review Anda berhasil dikirim dan sedang menunggu moderasi admin sebelum dipublikasikan.",
      testimonial: created,
      review: created
    });
  } catch (e) {
    res.status(500).json({ error: e.message || "Gagal mengirim review pengguna." });
  }
};
adminRouter.post("/testimonials/submit", handleSubmitReview);
adminRouter.post("/reviews/submit", handleSubmitReview);
var handleGetAdminReviews = (req, res) => {
  try {
    const category = req.query.category;
    const status = req.query.status;
    const list = foodDb.getAllTestimonials({ category, status });
    res.json(list);
  } catch (e) {
    res.status(500).json({ error: e.message || "Gagal memuat daftar review admin." });
  }
};
adminRouter.get("/admin/testimonials", requireRole(["ADMIN", "MASTER_ADMIN"]), handleGetAdminReviews);
adminRouter.get("/admin/reviews", requireRole(["ADMIN", "MASTER_ADMIN"]), handleGetAdminReviews);
var handleCreateAdminReview = async (req, res) => {
  try {
    const actorId = req.user?.userId || "admin";
    const { userName, merchantName, title, category, content, avatarUrl, roleDetail, rating, consentApproved, status, displayOrder } = req.body;
    if (!userName || !content) {
      return res.status(400).json({ error: "Nama dan isi review wajib diisi." });
    }
    const rawCat = String(category || "").toLowerCase();
    const normalizedCategory = rawCat === "merchant" || rawCat === "umkm" ? "merchant" : "pelanggan";
    const parsedRating = rating !== void 0 && rating !== null ? Math.min(5, Math.max(1, Math.round(Number(rating)))) : void 0;
    const validStatus = ["published", "pending", "rejected", "draft"].includes(status) ? status : "published";
    const created = await foodDb.createTestimonial({
      userName: sanitizeInput(userName),
      merchantName: merchantName ? sanitizeInput(merchantName) : void 0,
      category: normalizedCategory,
      title: title ? sanitizeInput(title) : void 0,
      content: sanitizeInput(content),
      avatarUrl: avatarUrl?.trim() || void 0,
      roleDetail: roleDetail ? sanitizeInput(roleDetail) : void 0,
      rating: parsedRating,
      consentApproved: Boolean(consentApproved),
      status: validStatus,
      displayOrder: Number(displayOrder) || 1
    });
    foodDb.log(actorId, `Created review ${created.id} for ${created.userName} (${created.category})`, "ADMIN");
    res.status(201).json(created);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
adminRouter.post("/admin/testimonials", requireRole(["ADMIN", "MASTER_ADMIN"]), handleCreateAdminReview);
adminRouter.post("/admin/reviews", requireRole(["ADMIN", "MASTER_ADMIN"]), handleCreateAdminReview);
var handleUpdateAdminReview = async (req, res) => {
  try {
    const actorId = req.user?.userId || "admin";
    const payload = { ...req.body };
    if (payload.userName) payload.userName = sanitizeInput(payload.userName);
    if (payload.merchantName !== void 0) payload.merchantName = payload.merchantName ? sanitizeInput(payload.merchantName) : void 0;
    if (payload.title !== void 0) payload.title = payload.title ? sanitizeInput(payload.title) : void 0;
    if (payload.content) payload.content = sanitizeInput(payload.content);
    if (payload.roleDetail !== void 0) payload.roleDetail = payload.roleDetail ? sanitizeInput(payload.roleDetail) : void 0;
    const updated = await foodDb.updateTestimonial(req.params.id, payload);
    if (!updated) {
      return res.status(404).json({ error: "Review tidak ditemukan." });
    }
    foodDb.log(actorId, `Updated review ${req.params.id} (Status: ${updated.status})`, "ADMIN");
    res.json(updated);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
adminRouter.put("/admin/testimonials/:id", requireRole(["ADMIN", "MASTER_ADMIN"]), handleUpdateAdminReview);
adminRouter.put("/admin/reviews/:id", requireRole(["ADMIN", "MASTER_ADMIN"]), handleUpdateAdminReview);
var handleDeleteAdminReview = async (req, res) => {
  try {
    const actorId = req.user?.userId || "admin";
    const deleted = await foodDb.deleteTestimonial(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: "Review tidak ditemukan." });
    }
    foodDb.log(actorId, `Deleted review ${req.params.id}`, "ADMIN");
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
adminRouter.delete("/admin/testimonials/:id", requireRole(["ADMIN", "MASTER_ADMIN"]), handleDeleteAdminReview);
adminRouter.delete("/admin/reviews/:id", requireRole(["ADMIN", "MASTER_ADMIN"]), handleDeleteAdminReview);

// src/server/routes/artopayRoutes.ts
var import_express6 = require("express");

// src/lib/artopay.ts
var import_crypto4 = __toESM(require("crypto"), 1);
init_config();
function extractArtoPayCheckoutUrl(data) {
  if (!data || typeof data !== "object") return null;
  const directKeys = [
    "checkoutUrl",
    "checkout_url",
    "paymentUrl",
    "payment_url",
    "paymentLink",
    "payment_link",
    "redirectUrl",
    "redirect_url",
    "invoiceUrl",
    "invoice_url",
    "url"
  ];
  for (const k of directKeys) {
    if (typeof data[k] === "string" && data[k].trim().startsWith("http")) {
      return data[k].trim();
    }
  }
  const envelopeKeys = ["payload", "data", "responseData", "result", "payment", "action", "nextAction", "next_action"];
  for (const ek of envelopeKeys) {
    if (data[ek] && typeof data[ek] === "object") {
      const nested = extractArtoPayCheckoutUrl(data[ek]);
      if (nested) return nested;
    }
  }
  if (Array.isArray(data.actions)) {
    for (const act of data.actions) {
      if (act && typeof act.url === "string" && act.url.trim().startsWith("http")) {
        return act.url.trim();
      }
    }
  }
  return null;
}
function extractArtoPayTransactionId(data) {
  if (!data || typeof data !== "object") return null;
  const directKeys = ["id", "paymentIntentId", "payment_intent_id", "paymentId", "payment_id", "transactionId", "transaction_id", "uuid"];
  for (const k of directKeys) {
    if (typeof data[k] === "string" && data[k].trim().length > 0) {
      return data[k].trim();
    }
  }
  const envelopeKeys = ["payload", "data", "responseData", "result", "payment"];
  for (const ek of envelopeKeys) {
    if (data[ek] && typeof data[ek] === "object") {
      const nested = extractArtoPayTransactionId(data[ek]);
      if (nested) return nested;
    }
  }
  return null;
}
function findArtoPayTransactionIdField(data) {
  if (!data || typeof data !== "object") return null;
  const directKeys = ["id", "paymentIntentId", "payment_intent_id", "paymentId", "payment_id", "transactionId", "transaction_id", "uuid"];
  for (const k of directKeys) {
    if (typeof data[k] === "string" && data[k].trim().length > 0) {
      return k;
    }
  }
  const envelopeKeys = ["payload", "data", "responseData", "result", "payment"];
  for (const ek of envelopeKeys) {
    if (data[ek] && typeof data[ek] === "object") {
      const nested = findArtoPayTransactionIdField(data[ek]);
      if (nested) return `${ek}.${nested}`;
    }
  }
  return null;
}
function findArtoPayCheckoutUrlField(data) {
  if (!data || typeof data !== "object") return null;
  const directKeys = [
    "checkoutUrl",
    "checkout_url",
    "paymentUrl",
    "payment_url",
    "paymentLink",
    "payment_link",
    "redirectUrl",
    "redirect_url",
    "invoiceUrl",
    "invoice_url",
    "url"
  ];
  for (const k of directKeys) {
    if (typeof data[k] === "string" && data[k].trim().startsWith("http")) {
      return k;
    }
  }
  const envelopeKeys = ["payload", "data", "responseData", "result", "payment", "action", "nextAction", "next_action"];
  for (const ek of envelopeKeys) {
    if (data[ek] && typeof data[ek] === "object") {
      const nested = findArtoPayCheckoutUrlField(data[ek]);
      if (nested) return `${ek}.${nested}`;
    }
  }
  if (Array.isArray(data.actions)) {
    for (let i = 0; i < data.actions.length; i++) {
      const act = data.actions[i];
      if (act && typeof act.url === "string" && act.url.trim().startsWith("http")) {
        return `actions[${i}].url`;
      }
    }
  }
  return null;
}
function extractArtoPayClientSecret(data) {
  if (!data || typeof data !== "object") return "";
  const directKeys = ["secret", "clientSecret", "client_secret"];
  for (const k of directKeys) {
    if (typeof data[k] === "string" && data[k].trim().length > 0) return data[k].trim();
  }
  const envelopeKeys = ["payload", "data", "responseData", "result"];
  for (const ek of envelopeKeys) {
    if (data[ek] && typeof data[ek] === "object") {
      const nested = extractArtoPayClientSecret(data[ek]);
      if (nested) return nested;
    }
  }
  return "";
}
function extractArtoPayCustomerToken(data) {
  if (!data || typeof data !== "object") return "";
  const directKeys = ["customerToken", "customer_token", "token"];
  for (const k of directKeys) {
    if (typeof data[k] === "string" && data[k].trim().length > 0) return data[k].trim();
  }
  const envelopeKeys = ["payload", "data", "responseData", "result"];
  for (const ek of envelopeKeys) {
    if (data[ek] && typeof data[ek] === "object") {
      const nested = extractArtoPayCustomerToken(data[ek]);
      if (nested) return nested;
    }
  }
  return "";
}
function extractArtoPayPublicKey(data) {
  if (!data || typeof data !== "object") return "";
  const directKeys = ["publicKey", "public_key", "clientKey", "client_key"];
  for (const k of directKeys) {
    if (typeof data[k] === "string" && data[k].trim().length > 0) return data[k].trim();
  }
  const envelopeKeys = ["payload", "data", "responseData", "result"];
  for (const ek of envelopeKeys) {
    if (data[ek] && typeof data[ek] === "object") {
      const nested = extractArtoPayPublicKey(data[ek]);
      if (nested) return nested;
    }
  }
  return "";
}
function cleanPublicKey(key) {
  if (!key || typeof key !== "string") return void 0;
  let trimmed = key.trim();
  if (trimmed.startsWith("'") && trimmed.endsWith("'") || trimmed.startsWith('"') && trimmed.endsWith('"')) {
    trimmed = trimmed.slice(1, -1).trim();
  }
  if (trimmed.startsWith("%") || trimmed.includes("%VITE_") || trimmed === "undefined" || trimmed === "null" || trimmed.length < 5) {
    return void 0;
  }
  return trimmed;
}
var ArtoPayService = class {
  /**
   * Generates a new Payment Intent through ArtoPay Payment Link API.
   * Conforms to official ArtoPay API spec (/v1.1/payment-intents & /v1/payment-intents).
   * Enforces strict server-side nominal validation.
   * Never generates fake demo IDs or simulated transactions for customer flows.
   */
  static async createPaymentIntent(params) {
    const { orderId, amount, serviceType, customerName, customerPhone, customerEmail } = params;
    const cleanOrderId = typeof orderId === "string" ? orderId.trim() : "";
    if (!cleanOrderId) {
      throw new Error("Order ID wajib disertakan dan berupa string yang valid (tidak boleh kosong).");
    }
    if (!Number.isInteger(amount) || amount <= 0) {
      throw new Error(`Nominal pembayaran tidak valid: Rp ${amount}. Nominal harus berupa bilangan bulat positif.`);
    }
    const currency = (params.currency || "IDR").toUpperCase();
    if (currency !== "IDR") {
      throw new Error(`Mata uang "${currency}" tidak didukung. ArtoPay QRIS hanya mendukung mata uang IDR.`);
    }
    const expiryMinutes = params.expiryMinutes || artopayConfig.defaultExpiryMinutes || 15;
    const expiresAt = new Date(Date.now() + expiryMinutes * 60 * 1e3).toISOString();
    const createdAt = (/* @__PURE__ */ new Date()).toISOString();
    if (!artopayConfig.secretKey && !params.customFetch) {
      throw new Error(
        "Kredensial gateway ArtoPay belum dikonfigurasi (ARTOPAY_SECRET_KEY belum disetel di Environment Variables). Silakan masukkan Secret Key resmi dari Dashboard ArtoPay untuk mengaktifkan pembuatan QRIS dinamis."
      );
    }
    const payload = {
      orderId: cleanOrderId,
      amount: String(amount),
      currency: "IDR",
      customerId: customerPhone ? customerPhone.replace(/\D/g, "") : `cust_${Date.now()}`,
      description: params.description || `Pembayaran tumpangGo ${serviceType} #${cleanOrderId}`,
      customerName: customerName || void 0,
      customerPhone: customerPhone || void 0,
      customerEmail: customerEmail || void 0,
      callbackUrl: params.callbackUrl,
      returnUrl: params.returnUrl,
      metadata: {
        orderId: cleanOrderId,
        serviceType,
        customerName,
        customerPhone,
        customerEmail: customerEmail || void 0
      }
    };
    if (artopayConfig.businessUnitCode) {
      payload.businessUnit = artopayConfig.businessUnitCode;
      payload.businessUnitCode = artopayConfig.businessUnitCode;
    }
    const headers = {
      "Content-Type": "application/json",
      "X-Secret-Key": artopayConfig.secretKey || "mock_secret_key"
    };
    if (artopayConfig.apiKey) {
      headers["X-API-Key"] = artopayConfig.apiKey;
    }
    if (artopayConfig.businessUnitCode) {
      headers["X-Business-Unit"] = artopayConfig.businessUnitCode;
    }
    const fetchClient = params.customFetch || fetch;
    let response = null;
    try {
      response = await fetchClient(`${artopayConfig.baseUrl}/v1.1/payment-intents`, {
        method: "POST",
        headers,
        body: JSON.stringify(payload)
      });
    } catch (err) {
      throw new Error(`Gagal menghubungi server gateway ArtoPay (${artopayConfig.baseUrl}): ${err?.message || "Koneksi jaringan gagal"}`);
    }
    const contentType = response.headers.get("content-type") || "";
    let resJson = null;
    let rawText = "";
    try {
      rawText = await response.text();
      resJson = JSON.parse(rawText);
    } catch {
      console.error("[ArtoPay Error] Respons dari gateway bukan format JSON yang valid:", {
        httpStatus: response.status,
        contentType,
        rawSnippet: rawText.substring(0, 300)
      });
      throw new Error(
        `Gateway ArtoPay mengembalikan respons non-JSON (HTTP ${response.status}, Content-Type: ${contentType}). Isi respons: "${rawText.substring(0, 150)}..."`
      );
    }
    if (!response.ok) {
      const status = response.status;
      const errDetail = resJson?.message || resJson?.responseMessage || resJson?.error || JSON.stringify(resJson);
      console.warn("[ArtoPay Gateway Rejection]", {
        httpStatus: status,
        contentType,
        environment: artopayConfig.environment,
        baseUrl: artopayConfig.baseUrl,
        errorDetail: errDetail
      });
      throw new Error(`Gateway ArtoPay menolak pembuatan transaksi (HTTP ${status}): ${errDetail || "Permintaan tidak dapat diproses"}`);
    }
    const returnedId = extractArtoPayTransactionId(resJson);
    const returnedUrl = extractArtoPayCheckoutUrl(resJson);
    const clientSecret = extractArtoPayClientSecret(resJson);
    const customerToken = extractArtoPayCustomerToken(resJson);
    const returnedPublicKey = extractArtoPayPublicKey(resJson);
    const topKeys = typeof resJson === "object" && resJson !== null ? Object.keys(resJson) : [];
    const nestedData = resJson.payload || resJson.data || resJson.responseData || null;
    const nestedKeys = nestedData && typeof nestedData === "object" ? Object.keys(nestedData) : [];
    const txIdField = findArtoPayTransactionIdField(resJson);
    const checkoutUrlField = findArtoPayCheckoutUrlField(resJson);
    const isHttpSuccess = response.status >= 200 && response.status < 300;
    const gatewayBusinessStatus = resJson.status || nestedData?.status || resJson.responseMessage || void 0;
    const isBusinessSuccess = isHttpSuccess && (gatewayBusinessStatus === "created" || gatewayBusinessStatus === "Success" || gatewayBusinessStatus === "SUCCESS" || resJson.responseCode === "2000000" || resJson.responseCode === "2002700");
    const isHostedPaymentLinkReady = Boolean(returnedUrl);
    const diagnostic = {
      httpStatus: response.status,
      contentType,
      environment: artopayConfig.environment,
      baseUrl: artopayConfig.baseUrl,
      businessCodeProvided: Boolean(artopayConfig.businessUnitCode),
      topLevelKeys: topKeys,
      nestedDataKeys: nestedKeys,
      transactionIdField: txIdField,
      transactionIdExtracted: Boolean(returnedId),
      checkoutUrlField: checkoutUrlField || "none",
      checkoutUrlFound: Boolean(returnedUrl),
      gatewayCode: resJson.code || resJson.responseCode || void 0,
      gatewayMessage: resJson.message || resJson.responseMessage || void 0,
      gatewayStatus: gatewayBusinessStatus,
      isHttpSuccess,
      isBusinessSuccess,
      isHostedPaymentLinkReady
    };
    console.log("[ArtoPay Gateway Diagnostic]", diagnostic);
    if (!returnedId) {
      throw new Error(
        `Gateway ArtoPay merespons berhasil (HTTP ${response.status}), namun tidak mengembalikan ID transaksi yang valid. Field respons: [${topKeys.join(", ")}]`
      );
    }
    if (params.requireHostedCheckoutUrl && !returnedUrl) {
      throw new Error(
        `Gateway ArtoPay merespons berhasil (HTTP ${response.status}), namun payload respons tidak memuat URL checkout resmi (checkoutUrl) untuk mengalihkan pelanggan. ID Transaksi: ${returnedId}. Respons: ${JSON.stringify(resJson).substring(0, 160)}`
      );
    }
    if (!returnedUrl && !clientSecret && !customerToken) {
      throw new Error(
        `Gateway ArtoPay merespons berhasil (HTTP ${response.status}), namun payload respons tidak memuat URL checkout resmi (checkoutUrl) maupun kredensial SDK modal (secret / customerToken). ID Transaksi: ${returnedId}. Respons: ${JSON.stringify(resJson).substring(0, 160)}`
      );
    }
    const finalCheckoutUrl = returnedUrl || "";
    return {
      success: true,
      id: returnedId,
      paymentIntentId: returnedId,
      orderId,
      serviceType,
      amount,
      currency: "IDR",
      checkoutUrl: finalCheckoutUrl,
      qrString: resJson.qrString || nestedData?.qrString || resJson.qrCodeUrl || nestedData?.qrCodeUrl || void 0,
      clientSecret,
      customerToken,
      publicKey: cleanPublicKey(returnedPublicKey || artopayConfig.publicKey) || void 0,
      sandbox: artopayConfig.environment !== "production",
      status: "PENDING",
      expiresAt: resJson.expiresAt || nestedData?.expiresAt || expiresAt,
      createdAt,
      gatewayConfigured: true
    };
  }
  /**
   * Verifies authenticity of ArtoPay Webhook request.
   * Uses HMAC-SHA256 signature verification with timing-attack prevention.
   */
  static verifyWebhookSignature(rawBody, signatureHeader, secretOverride) {
    const secret = secretOverride || artopayConfig.webhookSecret || artopayConfig.secretKey;
    const isProduction = artopayConfig.isProduction || artopayConfig.environment === "production";
    if (!secret) {
      if (isProduction) {
        return { isValid: false, reason: "ARTOPAY_WEBHOOK_SECRET belum dikonfigurasi di server." };
      }
      console.warn("[ArtoPay Security Warning] ARTOPAY_WEBHOOK_SECRET belum disetel pada mode development/sandbox.");
      return { isValid: true };
    }
    if (!signatureHeader || signatureHeader.trim().length === 0) {
      return { isValid: false, reason: "Header tanda tangan webhook (x-artopay-signature) tidak ditemukan." };
    }
    try {
      let timestamp = "";
      let expectedHmac = signatureHeader.trim();
      if (signatureHeader.includes("t=") && signatureHeader.includes("v1=")) {
        const parts = signatureHeader.split(",");
        for (const part of parts) {
          const trimmed = part.trim();
          if (trimmed.startsWith("t=")) timestamp = trimmed.substring(2);
          if (trimmed.startsWith("v1=")) expectedHmac = trimmed.substring(3);
        }
      }
      const payloadToSign = timestamp ? `${timestamp}.${rawBody}` : rawBody;
      const calculatedHmac = import_crypto4.default.createHmac("sha256", secret).update(payloadToSign).digest("hex");
      const hmacBuf = Buffer.from(calculatedHmac, "hex");
      const expectedBuf = Buffer.from(expectedHmac, "hex");
      if (hmacBuf.length !== expectedBuf.length || !import_crypto4.default.timingSafeEqual(hmacBuf, expectedBuf)) {
        return { isValid: false, reason: "Tanda tangan HMAC-SHA256 tidak cocok (Invalid Signature)." };
      }
      if (timestamp) {
        const tsNum = parseInt(timestamp, 10);
        if (!isNaN(tsNum)) {
          const nowSec = Math.floor(Date.now() / 1e3);
          if (Math.abs(nowSec - tsNum) > 300) {
            return { isValid: false, reason: "Stempel waktu (timestamp) webhook kedaluwarsa atau terindikasi replay attack." };
          }
        }
      }
      return { isValid: true };
    } catch (err) {
      return { isValid: false, reason: `Gagal memverifikasi tanda tangan webhook: ${err.message}` };
    }
  }
  /**
   * Actively queries the payment status from ArtoPay Gateway.
   */
  static async checkPaymentStatus(paymentIntentId) {
    if (!paymentIntentId) {
      return { status: "PENDING" };
    }
    if (artopayConfig.secretKey) {
      try {
        const headers = {
          "X-Secret-Key": artopayConfig.secretKey
        };
        const response = await fetch(`${artopayConfig.baseUrl}/v1.1/payment-intents/${paymentIntentId}`, { headers });
        if (response.ok) {
          const json = await response.json();
          const d = json.data || json;
          const gatewayStatus = (d.status || d.transactionStatus || d.transaction_status || "").toUpperCase();
          if (["PAID", "SUCCESS", "SETTLED", "CAPTURE", "SETTLEMENT"].includes(gatewayStatus)) {
            return {
              status: "SUCCESS",
              paidAt: d.paidAt || d.settlementTime || (/* @__PURE__ */ new Date()).toISOString(),
              amount: d.amount ? Number(d.amount) : void 0,
              raw: d
            };
          }
          if (["EXPIRED", "TIMED_OUT", "EXPIRE"].includes(gatewayStatus)) {
            return { status: "EXPIRED", raw: d };
          }
          if (["FAILED", "CANCELLED", "REJECTED", "DENY", "CANCEL", "FAILURE"].includes(gatewayStatus)) {
            return { status: "FAILED", raw: d };
          }
        }
      } catch (err) {
        console.warn(`[ArtoPay Status Check] Error querying ${paymentIntentId}:`, err.message);
      }
    }
    return { status: "PENDING" };
  }
};

// src/server/routes/artopayRoutes.ts
init_db();
init_types();
init_config();
var artopayRouter = (0, import_express6.Router)();
var processedWebhookKeys = /* @__PURE__ */ new Set();
artopayRouter.get("/config-status", (_req, res) => {
  reloadEnv();
  const hasSecretKey = Boolean(artopayConfig.secretKey);
  const hasPublicKey = Boolean(artopayConfig.publicKey);
  const hasWebhookSecret = Boolean(artopayConfig.webhookSecret);
  const isProduction = artopayConfig.isProduction || artopayConfig.environment === "production";
  const missing = [];
  if (!hasSecretKey) missing.push("ARTOPAY_SECRET_KEY");
  if (!hasPublicKey) missing.push("ARTOPAY_PUBLIC_KEY");
  if (!hasWebhookSecret) missing.push("ARTOPAY_WEBHOOK_SECRET");
  const secretPrefix = artopayConfig.secretKey ? `${artopayConfig.secretKey.substring(0, 7)}...` : void 0;
  const publicPrefix = artopayConfig.publicKey ? `${artopayConfig.publicKey.substring(0, 7)}...` : void 0;
  let keyEnvironmentConsistency = "CONSISTENT";
  if (artopayConfig.environment === "sandbox") {
    if (artopayConfig.secretKey && artopayConfig.secretKey.startsWith("sk_live_") || artopayConfig.publicKey && artopayConfig.publicKey.startsWith("pk_live_")) {
      keyEnvironmentConsistency = "MISMATCH_PROD_IN_SANDBOX";
    }
  } else {
    if (artopayConfig.secretKey && artopayConfig.secretKey.startsWith("sk_test_") || artopayConfig.publicKey && artopayConfig.publicKey.startsWith("pk_test_")) {
      keyEnvironmentConsistency = "MISMATCH_TEST_IN_PROD";
    }
  }
  return res.json({
    gatewayConfigured: hasSecretKey && hasPublicKey,
    environment: artopayConfig.environment,
    isProduction,
    hasSecretKey,
    hasPublicKey,
    hasWebhookSecret,
    secretKeyPrefix: secretPrefix,
    publicKeyPrefix: publicPrefix,
    keyEnvironmentConsistency,
    missingCredentials: missing,
    status: hasSecretKey && hasPublicKey ? "READY" : "PREPARATION_PENDING_CREDENTIALS",
    message: hasSecretKey && hasPublicKey ? "Gateway ArtoPay telah terkonfigurasi dan siap memproses transaksi." : "Tahap persiapan: Kredensial ArtoPay belum diisi di Environment Variables. Alur aplikasi, validasi server, dan database telah siap.",
    oapiChecklist: {
      environmentMatchesMerchantAccount: keyEnvironmentConsistency === "CONSISTENT",
      merchantStatusMustBeActive: true,
      allowedOriginConfiguredInGateway: true
    }
  });
});
artopayRouter.get("/config", (_req, res) => {
  reloadEnv();
  return res.json({
    publicKey: artopayConfig.publicKey || "",
    environment: artopayConfig.environment,
    sandbox: artopayConfig.environment !== "production",
    gatewayConfigured: Boolean(artopayConfig.secretKey && artopayConfig.publicKey)
  });
});
artopayRouter.post("/payment-intent", async (req, res) => {
  try {
    reloadEnv();
    const { orderId, serviceType, amount: clientAmount } = req.body;
    const cleanOrderId = typeof orderId === "string" ? orderId.trim() : "";
    if (!cleanOrderId) {
      return res.status(400).json({ error: "orderId wajib diisi dan berupa string non-kosong." });
    }
    const type = (serviceType || "FOOD").toUpperCase();
    if (type !== "FOOD") {
      return res.status(400).json({ error: 'serviceType harus bernilai "FOOD".' });
    }
    const order = await foodDb.findOrder(cleanOrderId);
    if (!order) {
      return res.status(404).json({ error: `Pesanan Tumpang Food dengan ID "${cleanOrderId}" tidak ditemukan.` });
    }
    const verifiedOrderId = String(order.id || "").trim();
    if (!verifiedOrderId) {
      return res.status(400).json({ error: "ID pesanan Tumpang Food tidak valid di database." });
    }
    if (order.status !== "WAITING_PAYMENT" /* WAITING_PAYMENT */) {
      if (order.status === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */ || order.status === "COOKING" /* COOKING */ || order.status === "READY_FOR_PICKUP" /* READY_FOR_PICKUP */ || order.status === "ORDER_PICKED_UP" /* ORDER_PICKED_UP */ || order.status === "DELIVERED" /* DELIVERED */ || order.status === "COMPLETED" /* COMPLETED */) {
        return res.status(400).json({ error: "Pesanan ini sudah terbayar / lunas." });
      }
      if (order.status === "CANCELLED" /* CANCELLED */ || order.status === "EXPIRED" /* EXPIRED */) {
        return res.status(400).json({ error: `Pesanan tidak dapat dibayar karena berstatus ${order.status}.` });
      }
    }
    if (order.paymentExpiresAt && new Date(order.paymentExpiresAt).getTime() < Date.now()) {
      return res.status(400).json({ error: "Batas waktu pembayaran pesanan telah habis (Expired)." });
    }
    const serverAmount = Math.round(Number(order.total));
    if (clientAmount !== void 0 && Number(clientAmount) !== serverAmount) {
      return res.status(400).json({
        error: `Manipulasi nominal terdeteksi: nominal client (${clientAmount}) berbeda dengan total server (${serverAmount}).`
      });
    }
    const proto = req.headers["x-forwarded-proto"] || req.protocol || "http";
    const host = req.get("host") || "localhost:3000";
    const origin = `${proto}://${host}`;
    const intent = await ArtoPayService.createPaymentIntent({
      orderId: verifiedOrderId,
      amount: serverAmount,
      currency: "IDR",
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      customerEmail: order.customerEmail || void 0,
      serviceType: "FOOD",
      description: `Pembayaran Tumpang Food #${verifiedOrderId} (${order.merchantName})`,
      expiryMinutes: 15,
      callbackUrl: req.body.callbackUrl || `${origin}/api/artopay/webhook`,
      returnUrl: req.body.returnUrl || `${origin}/?tab=tracking&orderId=${verifiedOrderId}`,
      allowSdkModal: true
    });
    await foodDb.updateOrder("SYSTEM_ARTOPAY", order.id, {
      paymentMethod: "ARTOPAY_QRIS",
      artopayPaymentId: intent.paymentIntentId,
      artopayCheckoutUrl: intent.checkoutUrl,
      artopayStatus: "PENDING",
      artopayExpiredAt: intent.expiresAt,
      artopayClientSecret: intent.clientSecret,
      artopayCustomerToken: intent.customerToken,
      artopayPublicKey: intent.publicKey,
      artopayOrderId: intent.orderId,
      artopaySandbox: intent.sandbox
    }, "SYSTEM");
    return res.status(200).json(intent);
  } catch (err) {
    console.error("[ArtoPay Create Intent Error]", err);
    return res.status(500).json({ error: err.message || "Gagal membuat transaksi ArtoPay." });
  }
});
artopayRouter.post("/webhook", async (req, res) => {
  try {
    const rawBody = req.rawBody || (typeof req.body === "string" ? req.body : JSON.stringify(req.body));
    const signature = req.headers["x-artopay-signature"] || req.headers["x-signature"] || req.headers["artopay-signature"];
    const sigCheck = ArtoPayService.verifyWebhookSignature(rawBody, signature);
    if (!sigCheck.isValid) {
      console.warn(`[ArtoPay Webhook Unauthorized] Invalid signature: ${sigCheck.reason}`);
      return res.status(401).json({ error: "Tanda tangan webhook tidak sah (Unauthorized).", detail: sigCheck.reason });
    }
    const payload = req.body;
    const data = payload.data || payload;
    const paymentIntentId = String(data.paymentIntentId || data.id || "").trim();
    const orderId = String(data.orderId || data.referenceId || "").trim();
    const amount = Number(data.amount);
    const currency = (data.currency || "IDR").toUpperCase();
    const rawStatus = (data.status || "").toUpperCase();
    if (!paymentIntentId || !orderId) {
      return res.status(400).json({ error: "Format payload webhook tidak lengkap: paymentIntentId atau orderId hilang." });
    }
    const idempotencyKey = `${paymentIntentId}_${rawStatus}`;
    if (processedWebhookKeys.has(idempotencyKey)) {
      return res.status(200).json({
        received: true,
        idempotent: true,
        message: "Notifikasi webhook untuk status ini sudah diproses sebelumnya."
      });
    }
    let foodOrder = await foodDb.findOrder(orderId);
    if (!foodOrder) {
      foodOrder = foodDb.getOrders().find((o) => o.artopayPaymentId === paymentIntentId);
    }
    if (!foodOrder) {
      return res.status(404).json({
        error: `Pesanan Tumpang Food dengan ID "${orderId}" atau paymentIntentId "${paymentIntentId}" tidak ditemukan.`
      });
    }
    const targetOrder = foodOrder;
    const serverTotal = Math.round(Number(targetOrder.total));
    if (targetOrder.artopayPaymentId && targetOrder.artopayPaymentId !== paymentIntentId) {
      console.warn(`[ArtoPay Security Alert] Mismatch between recorded transaction ID (${targetOrder.artopayPaymentId}) and webhook transaction ID (${paymentIntentId}) for order ${orderId}`);
      return res.status(400).json({
        error: "ID transaksi ArtoPay tidak cocok dengan identitas transaksi yang tersimpan pada pesanan ini."
      });
    }
    if (Number.isNaN(amount) || amount !== serverTotal) {
      console.error(`[ArtoPay Security Alert] Nominal mismatch on order ${orderId}! Expected Rp ${serverTotal}, received Rp ${amount}`);
      return res.status(400).json({
        error: `Nominal pembayaran (Rp ${amount}) tidak cocok dengan total tagihan pesanan (Rp ${serverTotal}).`
      });
    }
    if (currency !== "IDR") {
      return res.status(400).json({ error: `Mata uang tidak valid (${currency}). Harus IDR.` });
    }
    const isPaid = ["PAID", "SUCCESS", "SETTLED", "CAPTURE", "SETTLEMENT"].includes(rawStatus);
    const isFailedOrExpired = ["EXPIRED", "FAILED", "CANCELLED", "REJECTED", "DENY", "CANCEL"].includes(rawStatus);
    const alreadyPaid = targetOrder.status === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */ || targetOrder.status === "COOKING" /* COOKING */ || targetOrder.status === "READY_FOR_PICKUP" /* READY_FOR_PICKUP */ || targetOrder.status === "ORDER_PICKED_UP" /* ORDER_PICKED_UP */ || targetOrder.status === "DELIVERED" /* DELIVERED */ || targetOrder.status === "COMPLETED" /* COMPLETED */;
    if (isPaid && alreadyPaid) {
      processedWebhookKeys.add(idempotencyKey);
      return res.status(200).json({
        received: true,
        idempotent: true,
        message: "Pesanan makanan ini sudah berstatus lunas / terverifikasi sebelumnya."
      });
    }
    if (isPaid) {
      if (targetOrder.status === "WAITING_PAYMENT" /* WAITING_PAYMENT */ || targetOrder.status === "WAITING_PAYMENT_VERIFICATION" /* WAITING_PAYMENT_VERIFICATION */) {
        await foodDb.updateOrder("SYSTEM_ARTOPAY_WEBHOOK", targetOrder.id, {
          status: "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */,
          paymentMethod: "ARTOPAY_QRIS",
          artopayPaymentId: paymentIntentId,
          artopayStatus: "SUCCESS",
          paymentVerifiedAt: data.paidAt || (/* @__PURE__ */ new Date()).toISOString()
        }, "SYSTEM");
        foodDb.log(
          "SYSTEM_ARTOPAY_WEBHOOK",
          `Pembayaran ArtoPay terverifikasi via webhook (ID: ${paymentIntentId}, Rp ${amount}) - Order ${targetOrder.id}`,
          "SYSTEM"
        );
        console.log(`[ArtoPay Webhook] Food Order ${targetOrder.id} successfully marked as PAID.`);
      }
    } else if (isFailedOrExpired) {
      if (targetOrder.status === "WAITING_PAYMENT" /* WAITING_PAYMENT */) {
        await foodDb.updateOrder("SYSTEM_ARTOPAY_WEBHOOK", targetOrder.id, {
          artopayStatus: rawStatus === "EXPIRED" ? "EXPIRED" : "FAILED"
        }, "SYSTEM");
      }
    }
    processedWebhookKeys.add(idempotencyKey);
    return res.status(200).json({
      received: true,
      success: true,
      orderId: targetOrder.id,
      paymentIntentId,
      status: isPaid ? "PAID" : rawStatus
    });
  } catch (err) {
    console.error("[ArtoPay Webhook Exception]", err);
    return res.status(500).json({ error: err.message || "Gagal memproses webhook ArtoPay." });
  }
});
artopayRouter.get("/status/:orderId", async (req, res) => {
  try {
    const orderId = req.params.orderId.trim();
    const targetOrder = await foodDb.findOrder(orderId);
    if (!targetOrder) {
      return res.status(404).json({ error: "Pesanan Tumpang Food tidak ditemukan." });
    }
    const isCurrentlyPaid = targetOrder.status !== "WAITING_PAYMENT" /* WAITING_PAYMENT */ && targetOrder.status !== "WAITING_PAYMENT_VERIFICATION" /* WAITING_PAYMENT_VERIFICATION */ && targetOrder.status !== "CANCELLED" /* CANCELLED */ && targetOrder.status !== "EXPIRED" /* EXPIRED */;
    if (!isCurrentlyPaid && targetOrder.artopayPaymentId) {
      const liveCheck = await ArtoPayService.checkPaymentStatus(targetOrder.artopayPaymentId);
      if (liveCheck.status === "SUCCESS") {
        await foodDb.updateOrder("SYSTEM_ARTOPAY_POLL", targetOrder.id, {
          status: "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */,
          paymentMethod: "ARTOPAY_QRIS",
          artopayStatus: "SUCCESS",
          paymentVerifiedAt: liveCheck.paidAt || (/* @__PURE__ */ new Date()).toISOString()
        }, "SYSTEM");
        return res.json({
          orderId: targetOrder.id,
          serviceType: "FOOD",
          isPaid: true,
          status: "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */,
          artopayStatus: "SUCCESS"
        });
      }
    }
    return res.json({
      orderId: targetOrder.id,
      serviceType: "FOOD",
      isPaid: isCurrentlyPaid,
      status: targetOrder.status,
      artopayStatus: targetOrder.artopayStatus || (isCurrentlyPaid ? "SUCCESS" : "PENDING"),
      checkoutUrl: targetOrder.artopayCheckoutUrl,
      paymentIntentId: targetOrder.artopayPaymentId,
      amount: targetOrder.total
    });
  } catch (err) {
    return res.status(500).json({ error: err.message || "Gagal memeriksa status pembayaran ArtoPay." });
  }
});

// src/server/routes/pushRoutes.ts
var import_express7 = require("express");
init_pushService();
init_db();
var pushRouter = (0, import_express7.Router)();
pushRouter.get("/vapid-key", (req, res) => {
  const publicKey = pushService.getVapidPublicKey();
  res.json({
    success: true,
    publicKey
  });
});
pushRouter.post("/subscribe", (req, res) => {
  try {
    const { role, entityId, subscription, userAgent } = req.body;
    const user = req.user;
    if (!role || !["MERCHANT", "DRIVER", "CUSTOMER"].includes(role)) {
      return res.status(400).json({ error: "Role tidak valid untuk langganan push notification." });
    }
    if (!entityId || typeof entityId !== "string") {
      return res.status(400).json({ error: "entityId (ID toko atau ID driver) wajib disertakan." });
    }
    if (!subscription || !subscription.endpoint || !subscription.keys) {
      return res.status(400).json({ error: "Objek PushSubscription browser tidak lengkap." });
    }
    if (role === "MERCHANT") {
      if (!user) {
        return res.status(401).json({ error: "Akses ditolak: Autentikasi diperlukan untuk mendaftarkan notifikasi toko." });
      }
      const isMasterOrAdmin = user.role === "ADMIN" || user.role === "MASTER_ADMIN" || user.isMasterAdmin;
      const isOwner = user.role === "MERCHANT" && (user.entityId === entityId || user.userId === entityId || String(user.entityId || "").replace(/^merchant_/, "") === String(entityId).replace(/^merchant_/, ""));
      if (!isMasterOrAdmin && !isOwner) {
        return res.status(403).json({ error: "Akses ditolak: Anda tidak memiliki wewenang untuk mendaftarkan notifikasi toko ini." });
      }
    } else if (role === "DRIVER") {
      if (!user) {
        return res.status(401).json({ error: "Akses ditolak: Autentikasi diperlukan untuk mendaftarkan notifikasi driver." });
      }
      const isMasterOrAdmin = user.role === "ADMIN" || user.role === "MASTER_ADMIN" || user.isMasterAdmin;
      const isSelf = user.role === "DRIVER" && (user.entityId === entityId || user.userId === entityId);
      if (!isMasterOrAdmin && !isSelf) {
        return res.status(403).json({ error: "Akses ditolak: Anda tidak memiliki wewenang untuk mendaftarkan notifikasi driver ini." });
      }
    }
    const record = {
      id: "sub_" + Math.random().toString(36).substring(2, 9) + Date.now().toString(36),
      role,
      entityId: entityId.trim(),
      subscription: {
        endpoint: subscription.endpoint,
        keys: {
          p256dh: subscription.keys.p256dh,
          auth: subscription.keys.auth
        }
      },
      userAgent: userAgent || req.headers["user-agent"] || "",
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    foodDb.savePushSubscription(record);
    res.json({
      success: true,
      message: "Perangkat berhasil terdaftar untuk menerima notifikasi pesanan TumpangGo.",
      subscriptionId: record.id
    });
  } catch (err) {
    console.error("[PushRoutes] Error saving subscription:", err);
    res.status(500).json({ error: err.message || "Gagal menyimpan langganan notifikasi." });
  }
});
pushRouter.post("/unsubscribe", (req, res) => {
  try {
    const { endpoint } = req.body;
    if (!endpoint) {
      return res.status(400).json({ error: "Endpoint subscription wajib disertakan." });
    }
    foodDb.removePushSubscription(endpoint);
    res.json({ success: true, message: "Langganan notifikasi berhasil dihapus." });
  } catch (err) {
    console.error("[PushRoutes] Error unsubscribing:", err);
    res.status(500).json({ error: err.message || "Gagal menghapus langganan notifikasi." });
  }
});
pushRouter.post("/test", async (req, res) => {
  try {
    const { role, entityId } = req.body;
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: "Akses ditolak: Autentikasi diperlukan untuk mengirim tes notifikasi push." });
    }
    if (!role || !entityId) {
      return res.status(400).json({ error: "Role dan entityId wajib disertakan untuk tes notifikasi." });
    }
    const isMasterOrAdmin = user.role === "ADMIN" || user.role === "MASTER_ADMIN" || user.isMasterAdmin;
    if (role === "MERCHANT") {
      const isOwner = user.role === "MERCHANT" && (user.entityId === entityId || user.userId === entityId || String(user.entityId || "").replace(/^merchant_/, "") === String(entityId).replace(/^merchant_/, ""));
      if (!isMasterOrAdmin && !isOwner) {
        return res.status(403).json({ error: "Akses ditolak: Anda tidak memiliki wewenang untuk mengetes notifikasi toko ini." });
      }
    } else if (role === "DRIVER") {
      const isSelf = user.role === "DRIVER" && (user.entityId === entityId || user.userId === entityId);
      if (!isMasterOrAdmin && !isSelf) {
        return res.status(403).json({ error: "Akses ditolak: Anda tidak memiliki wewenang untuk mengetes notifikasi driver ini." });
      }
    } else {
      return res.status(400).json({ error: "Role tidak didukung untuk tes notifikasi." });
    }
    let result;
    if (role === "MERCHANT") {
      result = await pushService.sendToMerchant(entityId, {
        title: "\u{1F514} Tes Notifikasi Toko TumpangGo",
        body: "Notifikasi push berhasil terhubung! Anda akan menerima peringatan saat ada pesanan masuk meskipun layar tertutup.",
        url: `/merchant?id=${encodeURIComponent(entityId)}`,
        tag: "test-push-" + Date.now()
      });
    } else if (role === "DRIVER") {
      result = await pushService.sendToDriver(entityId, {
        title: "\u{1F6F5} Tes Notifikasi Driver TumpangGo",
        body: "Notifikasi push berhasil terhubung! Anda akan menerima peringatan saat ditugaskan pesanan pengantaran.",
        url: `/driver?id=${encodeURIComponent(entityId)}`,
        tag: "test-push-" + Date.now()
      });
    } else {
      return res.status(400).json({ error: "Role tidak didukung." });
    }
    res.json({
      success: true,
      sent: result.sent,
      failed: result.failed,
      message: result.sent > 0 ? `Notifikasi terkirim ke ${result.sent} perangkat aktif!` : "Belum ada perangkat yang terdaftar atau izin notifikasi browser belum diberikan."
    });
  } catch (err) {
    console.error("[PushRoutes] Error sending test push:", err);
    res.status(500).json({ error: err.message || "Gagal mengirim tes notifikasi push." });
  }
});

// src/server/app.ts
var app = (0, import_express8.default)();
function isAllowedOrigin(origin) {
  if (!origin) return true;
  try {
    const url = new URL(origin);
    const host = url.hostname.toLowerCase();
    const customAllowed = (process.env.ALLOWED_ORIGINS || "").split(",").map((s) => s.trim().toLowerCase()).filter(Boolean);
    if (customAllowed.some((allowed) => origin.toLowerCase() === allowed || host === allowed)) {
      return true;
    }
    if (host === "localhost" || host === "127.0.0.1" || host === "0.0.0.0" || host.endsWith(".localhost")) {
      return true;
    }
    if (host.endsWith(".run.app") || host.endsWith(".googleusercontent.com") || host.endsWith(".aistudio.google.com") || host.endsWith(".web.app") || host.endsWith(".firebaseapp.com")) {
      return true;
    }
    if (host.endsWith(".vercel.app") || host === "tumpanggo.com" || host.endsWith(".tumpanggo.com")) {
      return true;
    }
    if (process.env.NODE_ENV !== "production") {
      return true;
    }
    return false;
  } catch {
    return false;
  }
}
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin) {
    if (isAllowedOrigin(origin)) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Access-Control-Allow-Credentials", "true");
    }
  } else {
    res.setHeader("Access-Control-Allow-Origin", "*");
  }
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, x-auth-token, x-auth-email, x-request-id, x-requested-with, accept, origin");
  res.setHeader("Access-Control-Max-Age", "86400");
  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }
  next();
});
app.use((req, res, next) => {
  const matchedPath = req.headers["x-matched-path"] || req.headers["x-original-url"] || req.headers["x-forwarded-uri"];
  if (matchedPath && matchedPath.startsWith("/api") && req.url.startsWith("/api/index")) {
    req.url = matchedPath;
  }
  if (req.url.startsWith("/api/index?") || req.url === "/api/index") {
    try {
      const urlObj = new URL(req.url, "http://localhost");
      const customPath = urlObj.searchParams.get("__path") || urlObj.searchParams.get("path");
      if (customPath) {
        urlObj.searchParams.delete("__path");
        urlObj.searchParams.delete("path");
        const remainingQuery = urlObj.searchParams.toString();
        const basePath = customPath.startsWith("/") ? customPath : `/api/${customPath}`;
        req.url = basePath + (remainingQuery ? `?${remainingQuery}` : "");
      }
    } catch {
    }
  }
  next();
});
app.use((req, res, next) => {
  const reqId = req.headers["x-request-id"] || "req_" + Math.random().toString(36).substring(2, 9) + Date.now().toString(36);
  req.id = String(reqId);
  res.setHeader("X-Request-Id", req.id);
  if (req.path.startsWith("/api")) {
    const start = Date.now();
    res.on("finish", () => {
      const duration = Date.now() - start;
      const status = res.statusCode;
      const logFn = status >= 500 ? console.error : status >= 400 ? console.warn : console.log;
      logFn(`[API] [${req.id}] ${req.method} ${req.path} -> ${status} (${duration}ms)`);
    });
  }
  next();
});
app.use((req, _res, next) => {
  if (req.body !== void 0 && req.body !== null) {
    if (typeof req.body === "string") {
      try {
        req.body = JSON.parse(req.body);
      } catch {
      }
    }
    req._body = true;
  }
  next();
});
app.use(import_express8.default.json({
  limit: "15mb",
  verify: (req, _res, buf) => {
    try {
      req.rawBody = buf.toString("utf-8");
    } catch {
    }
  }
}));
app.use(import_express8.default.urlencoded({ extended: true, limit: "15mb" }));
app.use((err, req, _res, next) => {
  if (err?.message?.includes("stream is not readable") || err?.type === "stream.not.readable") {
    return next();
  }
  next(err);
});
foodDb.ensureInitialized().catch((err) => {
  console.warn("[TumpangFood Database Startup Sync Warning]", err?.message || err);
});
app.use(authenticateToken);
app.get("/api/health", async (req, res) => {
  try {
    const foodStorageStatus = await foodDb.getStorageStatus();
    const isHealthy = foodStorageStatus.liveCloudConnected;
    const isProd = foodConfig.isProduction;
    res.status(isProd && !isHealthy ? 503 : 200).json({
      status: isHealthy ? "healthy" : isProd ? "database_disconnected" : "ok_development_resilient_mode",
      server: "online",
      database: isHealthy ? "connected" : "disconnected",
      system: "tumpang-go-ecosystem",
      environment: process.env.NODE_ENV || "development",
      diagnosticReason: foodStorageStatus.diagnosticReason,
      diagnosticDetail: foodStorageStatus.diagnosticDetail,
      remediationStep: foodStorageStatus.remediationStep,
      foodDatabase: foodStorageStatus,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  } catch (err) {
    console.error("[TumpangFood Health Check Error]", err);
    res.status(500).json({
      status: "error",
      server: "online",
      database: "error",
      system: "tumpang-food",
      error: "Health check diagnostic encountered an internal error.",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
});
app.get("/api/health/firestore-probe", async (req, res) => {
  try {
    const probe = await testFirestoreConnection();
    res.status(probe.connected ? 200 : 503).json({
      system: "tumpang-food",
      probeOrigin: "Dedicated Admin SDK Diagnostic Probe",
      result: probe,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  } catch (err) {
    console.error("[TumpangFood Probe Error]", err);
    res.status(500).json({
      system: "tumpang-food",
      error: err.message || "Diagnostic probe error",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
});
app.get("/api/health/catalog-status", async (req, res) => {
  try {
    const probe = await testFirestoreConnection();
    const adminDb2 = getAdminDb();
    let merchantsCount = 0;
    let categoriesCount = 0;
    let menuItemsCount = 0;
    let merchantRegistrationsCount = 0;
    let driversCount = 0;
    let ordersCount = 0;
    let settlementsCount = 0;
    if (probe.connected && adminDb2) {
      const [mCount, cCount, iCount, mrCount, dCount, oCount, sCount] = await Promise.all([
        safeAdminCountDocs("merchants"),
        safeAdminCountDocs("categories"),
        safeAdminCountDocs("menuItems"),
        safeAdminCountDocs("partnerRegistrations", (ref) => ref.where("type", "==", "MERCHANT")),
        safeAdminCountDocs("drivers"),
        safeAdminCountDocs("orders"),
        safeAdminCountDocs("settlements")
      ]);
      merchantsCount = mCount ?? 0;
      categoriesCount = cCount ?? 0;
      menuItemsCount = iCount ?? 0;
      merchantRegistrationsCount = mrCount ?? 0;
      driversCount = dCount ?? 0;
      ordersCount = oCount ?? 0;
      settlementsCount = sCount ?? 0;
    } else {
      const rawData = foodDb.data;
      merchantsCount = rawData?.merchants?.length || 0;
      categoriesCount = rawData?.categories?.length || 0;
      menuItemsCount = rawData?.menuItems?.length || 0;
      merchantRegistrationsCount = rawData?.partnerRegistrations?.filter((r) => r.type === "MERCHANT").length || 0;
      driversCount = rawData?.drivers?.length || 0;
      ordersCount = rawData?.orders?.length || 0;
      settlementsCount = rawData?.settlements?.length || 0;
    }
    res.status(probe.connected ? 200 : foodConfig.isProduction ? 503 : 200).json({
      system: "tumpang-food",
      projectId: probe.projectId || foodConfig.projectId || "tumpanggo-70479",
      databaseId: probe.databaseId || foodConfig.databaseId || "(default)",
      storageMode: probe.connected ? "cloud_firestore_verified" : "local_snapshot",
      liveCloudConnected: probe.connected,
      isProduction: foodConfig.isProduction,
      liveFirestoreCounts: {
        merchantsCount,
        categoriesCount,
        menuItemsCount,
        merchantRegistrationsCount,
        driversCount,
        ordersCount,
        settlementsCount
      },
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  } catch (err) {
    res.status(500).json({ error: err.message || "Diagnostic catalog count error" });
  }
});
app.use("/api", authRouter);
app.use("/api/merchants", merchantRouter);
app.use("/api/drivers", driverRouter);
app.use("/api/orders", orderRouter);
app.use("/api", adminRouter);
app.use("/api/artopay", artopayRouter);
app.use("/api/push", pushRouter);
app.all(["/api", "/api/*"], (req, res) => {
  res.status(404).json({ error: `API endpoint ${req.method} ${req.path} tidak ditemukan.` });
});
app.use((err, req, res, _next) => {
  const reqId = req.id || "req_unknown";
  const status = typeof err.status === "number" && err.status >= 400 && err.status < 600 ? err.status : 500;
  console.error(`[TumpangFood Server Error] [ReqID: ${reqId}] ${req.method} ${req.originalUrl} -> HTTP ${status}`);
  if (err.stack) {
    console.error(`[TumpangFood StackTrace] [ReqID: ${reqId}]:
${err.stack}`);
  } else {
    console.error(`[TumpangFood ErrorDetails] [ReqID: ${reqId}]:`, err);
  }
  let safeMessage = "Terjadi kesalahan internal pada server Tumpang Food.";
  if (status === 404) {
    safeMessage = err.message || "Data atau endpoint tidak ditemukan.";
  } else if (status === 400 || status === 422) {
    safeMessage = err.message || "Permintaan tidak valid.";
  } else if (status === 401 || status === 403) {
    safeMessage = err.message || "Akses tidak diizinkan.";
  } else if (req.path === "/api/merchants" || req.path.startsWith("/api/merchants")) {
    safeMessage = "Gagal memuat daftar toko kuliner dari database server.";
  }
  res.status(status).json({
    error: safeMessage,
    code: err.code || (status === 500 ? "INTERNAL_SERVER_ERROR" : "REQUEST_ERROR"),
    requestId: reqId
  });
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  app
});
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Configuration Module
 * Isolates runtime environment variables, database identifiers, and system defaults.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Authentication & RBAC Authorization Module
 * Provides password hashing, token creation/verification, and strict security middleware.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * TumpangGo Single Source of Truth for Delivery Fee & Geographic Boundaries
 * Mandatory Business Rule:
 * All delivery destinations within Kecamatan Tumpang are strictly charged a flat fee of Rp 5.000 per order,
 * regardless of distance, village/kelurahan, merchant location, map calculations, or internal zones.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Order Validation & Transaction Service
 * Enforces price recalculations, menu availability checks, and order state machine rules.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Firebase Admin SDK Module
 * Server-side trusted administrative database client.
 * Implements IAM credential loading, custom database targeting, and atomic transactions.
 * Strict zero-ADC enforcement on serverless environments to prevent "Could not load the default credentials".
 * Granular diagnostics for missing keys, JSON parse errors, project mismatches, IAM denials, and timeouts.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Web Push Notification Service for TumpangGo
 * Sends push notifications to Merchant & Driver devices when new orders arrive
 * or when orders are assigned/updated, even when the browser dashboard is closed.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Isolated Database Module
 * Manages persistent storage, data integrity, and Firestore synchronization.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Authentication Routes
 * Handles secure user login, token issuance, and partner onboarding.
 * Strictly enforces valid credentials with PBKDF2 hashing and no fallback bypasses.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Merchant Routes
 * Manages merchant profiles, menu catalogs, orders, and license redemptions.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Driver Routes
 * Handles courier profile operations, status toggles, and delivery assignments.
 * Protected with RBAC so drivers can only view and manage their own profile and tasks.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Order Routes
 * Handles order placements, recalculations, driver assignments, and payment proofs.
 * Enforces payment expiration rules, terminal state guards, and RBAC order visibility.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Administrative Routes
 * Manages system parameters, partner onboarding, payouts, and licenses.
 * Endpoints: /merchants (via merchantRouter), /drivers (via driverRouter), and /partner-registrations.
 * Strictly protected with Admin-only RBAC middleware.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * ArtoPay Payment Gateway Service Module
 * Handles Payment Intent creation, dynamic QRIS generation,
 * webhook HMAC signature validation, idempotency guards, and payment verification.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * ArtoPay Payment Gateway API Routes
 * Endpoints for Payment Intent creation, Webhook handling, and on-demand status verification.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Web Push Notification Routes for TumpangGo
 * Manages VAPID public key retrieval, device subscription registration, and test dispatch.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Express Application
 * Decoupled and modular backend application assembly.
 */
//# sourceMappingURL=_app.cjs.map
