var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/server/app.ts
var app_exports = {};
__export(app_exports, {
  app: () => app
});
module.exports = __toCommonJS(app_exports);
var import_express8 = __toESM(require("express"), 1);

// src/server/db.ts
var import_fs4 = __toESM(require("fs"), 1);
var import_path4 = __toESM(require("path"), 1);

// src/types/shop.ts
var ShopShipmentStatus = /* @__PURE__ */ ((ShopShipmentStatus3) => {
  ShopShipmentStatus3["WAITING_DISPATCH"] = "WAITING_DISPATCH";
  ShopShipmentStatus3["PROCESSING"] = "PROCESSING";
  ShopShipmentStatus3["DISPATCHED"] = "DISPATCHED";
  ShopShipmentStatus3["IN_TRANSIT"] = "IN_TRANSIT";
  ShopShipmentStatus3["ARRIVED_INDONESIA"] = "ARRIVED_INDONESIA";
  ShopShipmentStatus3["CUSTOMS_CLEARANCE"] = "CUSTOMS_CLEARANCE";
  ShopShipmentStatus3["TRANSFERRED_LOCAL_COURIER"] = "TRANSFERRED_LOCAL_COURIER";
  ShopShipmentStatus3["OUT_FOR_DELIVERY"] = "OUT_FOR_DELIVERY";
  ShopShipmentStatus3["DELIVERED"] = "DELIVERED";
  ShopShipmentStatus3["FAILED_DELIVERY"] = "FAILED_DELIVERY";
  ShopShipmentStatus3["CUSTOMS_HOLD"] = "CUSTOMS_HOLD";
  return ShopShipmentStatus3;
})(ShopShipmentStatus || {});

// src/types.ts
function calculateTieredServiceFee(subtotal) {
  if (subtotal <= 1e5) return 2e3;
  if (subtotal <= 3e5) return 3e3;
  if (subtotal <= 5e5) return 4e3;
  if (subtotal <= 7e5) return 5e3;
  return 1e4;
}

// src/server/config.ts
var import_fs2 = __toESM(require("fs"), 1);
var import_path2 = __toESM(require("path"), 1);
var import_dotenv2 = __toESM(require("dotenv"), 1);

// src/services/shop/config/shopEnv.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
function loadEnvExplicit(filePath) {
  if (!import_fs.default.existsSync(filePath)) return;
  try {
    const raw = import_fs.default.readFileSync(filePath, "utf-8");
    const lines = raw.split(/\r?\n/);
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const eqIdx = trimmed.indexOf("=");
      if (eqIdx <= 0) continue;
      const key = trimmed.slice(0, eqIdx).trim();
      let val = trimmed.slice(eqIdx + 1).trim();
      if (val.startsWith('"') && val.endsWith('"') || val.startsWith("'") && val.endsWith("'")) {
        val = val.slice(1, -1);
      }
      process.env[key] = val;
    }
  } catch {
  }
}
import_dotenv.default.config();
loadEnvExplicit(import_path.default.resolve(process.cwd(), ".env"));
var localEnvPath = import_path.default.resolve(process.cwd(), ".env.local");
if (import_fs.default.existsSync(localEnvPath)) {
  import_dotenv.default.config({ path: localEnvPath, override: true });
  loadEnvExplicit(localEnvPath);
}
var isServerless = Boolean(process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME);
var defaultShopDbFile = isServerless ? import_path.default.join("/tmp", "tumpang_shop_db.json") : import_path.default.join(process.cwd(), "tumpang_shop_db.json");
var runtimeShopAdminEmail = (process.env.SHOP_ADMIN_EMAIL || "shopadmin@tumpanggo.com").toLowerCase().trim();
var runtimeShopAdminPassword = (process.env.SHOP_ADMIN_PASSWORD || "TumpangShopAdmin#2026").trim();
var runtimeShopAuthSecret = (process.env.SHOP_AUTH_SECRET || "").trim();
if (!runtimeShopAuthSecret || runtimeShopAuthSecret.length < 32) {
  runtimeShopAuthSecret = "shop_secret_fallback_dev_min_32_characters_ok";
}
function resolveShopPort() {
  if (process.env.SHOP_PORT) {
    const parsed = parseInt(process.env.SHOP_PORT, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  return 3001;
}
var shopEnv = {
  isProduction: process.env.NODE_ENV === "production",
  port: resolveShopPort(),
  // Database Configuration
  database: {
    type: process.env.SHOP_DATABASE_TYPE || "file",
    filePath: process.env.SHOP_DB_FILE ? import_path.default.resolve(process.cwd(), process.env.SHOP_DB_FILE) : defaultShopDbFile,
    databaseUrl: process.env.SHOP_DATABASE_URL || "",
    firestoreDatabaseId: process.env.SHOP_FIRESTORE_DATABASE_ID || "(default)",
    firestoreCollectionPrefix: process.env.SHOP_FIRESTORE_PREFIX || "shop_",
    enableCloudSync: process.env.SHOP_ENABLE_CLOUD_SYNC === "true" || process.env.NODE_ENV === "production",
    maxRetries: 3,
    retryDelayMs: 1e3
  },
  // Authentication & Security
  auth: {
    jwtSecret: runtimeShopAuthSecret,
    adminEmail: runtimeShopAdminEmail,
    adminPassword: runtimeShopAdminPassword,
    tokenExpiryHours: 24
  },
  // Collections (Firestore / Document Store Schema)
  collections: {
    config: "shop_config",
    categories: "shop_categories",
    products: "shop_products",
    orders: "shop_orders",
    shipments: "shop_shipments",
    auditLogs: "shop_audit_logs",
    migrations: "shop_migrations"
  },
  // Business Operational Defaults
  defaults: {
    storeName: "Tumpang Shop Mart",
    storeAddress: "Area Pasar Tumpang, Kec. Tumpang, Malang",
    storePhone: "081234567890",
    isOpen: true,
    qrisImage: "/qris-merchant.png",
    defaultDeliveryFee: 4e3,
    serviceFee: 1500,
    minOrderAmount: 1e4,
    paymentExpiryMinutes: 30
  }
};
var shopConfig = {
  isProduction: shopEnv.isProduction,
  localDbFile: shopEnv.database.filePath,
  jwtSecret: shopEnv.auth.jwtSecret,
  adminEmail: shopEnv.auth.adminEmail,
  adminPassword: shopEnv.auth.adminPassword,
  collections: shopEnv.collections,
  defaults: shopEnv.defaults
};

// src/server/config.ts
function loadEnvExplicit2(filePath) {
  if (!import_fs2.default.existsSync(filePath)) return;
  try {
    const raw = import_fs2.default.readFileSync(filePath, "utf-8");
    const lines = raw.split(/\r?\n/);
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith("#")) continue;
      const eqIdx = trimmed.indexOf("=");
      if (eqIdx <= 0) continue;
      const key = trimmed.slice(0, eqIdx).trim();
      let val = trimmed.slice(eqIdx + 1).trim();
      if (val.startsWith('"') && val.endsWith('"') || val.startsWith("'") && val.endsWith("'")) {
        val = val.slice(1, -1);
      }
      process.env[key] = val;
    }
  } catch {
  }
}
import_dotenv2.default.config();
loadEnvExplicit2(import_path2.default.resolve(process.cwd(), ".env"));
var localEnvPath2 = import_path2.default.resolve(process.cwd(), ".env.local");
if (import_fs2.default.existsSync(localEnvPath2)) {
  import_dotenv2.default.config({ path: localEnvPath2, override: true });
  loadEnvExplicit2(localEnvPath2);
}
var runtimeJwtSecret = (process.env.FOOD_AUTH_SECRET || "").trim();
if (!runtimeJwtSecret || runtimeJwtSecret.length < 32) {
  runtimeJwtSecret = "dev_secret_fallback_do_not_use_in_prod_min_32_characters_long";
}
var isServerless2 = Boolean(process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME);
var localDbFile = isServerless2 ? import_path2.default.join("/tmp", "tumpang_food_db.json") : import_path2.default.join(process.cwd(), "tumpang_food_db.json");
function cleanEnvSecret(val, fallback = "") {
  if (!val) return fallback;
  let clean = val.trim();
  if (clean.startsWith('"') && clean.endsWith('"') || clean.startsWith("'") && clean.endsWith("'")) {
    clean = clean.slice(1, -1).trim();
  }
  return clean || fallback;
}
var isProductionRuntime = process.env.NODE_ENV === "production" && !process.env.VERCEL_DEV;
var runtimeAdminPassword = cleanEnvSecret(process.env.FOOD_ADMIN_PASSWORD, isProductionRuntime ? "" : "TumpangGoAdmin#2026");
var runtimeAdminEmail = (process.env.FOOD_ADMIN_EMAIL || "tumpanggo@gmail.com").trim().toLowerCase();
var runtimeMasterAdminEmail = (process.env.MASTER_ADMIN_EMAIL || "tumpanggo@gmail.com").trim().toLowerCase();
var runtimeMasterAdminPassword = cleanEnvSecret(process.env.MASTER_ADMIN_PASSWORD || process.env.FOOD_ADMIN_PASSWORD, isProductionRuntime ? "" : "TumpangGoAdmin#2026");
function resolveServerPort() {
  for (let i = 0; i < process.argv.length; i++) {
    if ((process.argv[i] === "--port" || process.argv[i] === "-p") && process.argv[i + 1]) {
      const parsed = parseInt(process.argv[i + 1], 10);
      if (!isNaN(parsed) && parsed > 0) return parsed;
    }
  }
  if (process.env.FOOD_PORT) {
    const parsed = parseInt(process.env.FOOD_PORT, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  if (process.env.PORT && process.env.PORT !== "8080") {
    const parsed = parseInt(process.env.PORT, 10);
    if (!isNaN(parsed) && parsed > 0) return parsed;
  }
  return 3e3;
}
function validateProductionEnvironment() {
  const errors = [];
  const secret = process.env.FOOD_AUTH_SECRET;
  if (!secret || secret.trim().length < 32) {
    errors.push("FOOD_AUTH_SECRET wajib disetel dan memiliki minimal 32 karakter.");
  } else if (secret.includes("dev_secret_fallback") || secret.includes("fallback_do_not_use")) {
    errors.push("FOOD_AUTH_SECRET tidak boleh menggunakan string fallback/development pada mode produksi.");
  }
  const adminEmail = process.env.FOOD_ADMIN_EMAIL;
  if (!adminEmail || !adminEmail.includes("@")) {
    errors.push("FOOD_ADMIN_EMAIL wajib disetel dengan alamat email yang sah.");
  }
  const adminPassword = process.env.FOOD_ADMIN_PASSWORD;
  if (!adminPassword || adminPassword.trim().length < 8) {
    errors.push("FOOD_ADMIN_PASSWORD wajib disetel dengan minimal 8 karakter.");
  } else if (adminPassword === "TumpangGoAdmin#2026") {
    errors.push('FOOD_ADMIN_PASSWORD tidak boleh menggunakan kata sandi default/contoh ("TumpangGoAdmin#2026") pada mode produksi.');
  }
  let projectId = process.env.FIREBASE_PROJECT_ID || process.env.GCP_PROJECT;
  if (!projectId) {
    try {
      const configPath = import_path2.default.join(process.cwd(), "firebase-applet-config.json");
      if (import_fs2.default.existsSync(configPath)) {
        const raw = JSON.parse(import_fs2.default.readFileSync(configPath, "utf-8"));
        projectId = raw.projectId;
      }
    } catch {
    }
  }
  if (!projectId || projectId.trim().length === 0) {
    errors.push("FIREBASE_PROJECT_ID wajib disetel pada lingkungan produksi.");
  }
  const serviceAccount = process.env.FIREBASE_SERVICE_ACCOUNT_KEY || process.env.GOOGLE_SERVICE_ACCOUNT_KEY || process.env.GOOGLE_APPLICATION_CREDENTIALS;
  if (!serviceAccount || serviceAccount.trim().length === 0) {
    errors.push("FIREBASE_SERVICE_ACCOUNT_KEY wajib disetel untuk otentikasi Firebase Admin SDK pada lingkungan produksi.");
  } else {
    const raw = serviceAccount.trim();
    let parsed = null;
    try {
      let cleanRaw = raw;
      if (cleanRaw.startsWith("'") && cleanRaw.endsWith("'") || cleanRaw.startsWith('"') && cleanRaw.endsWith('"')) {
        cleanRaw = cleanRaw.slice(1, -1);
      }
      if (cleanRaw.startsWith("{")) {
        parsed = JSON.parse(cleanRaw);
      } else if (process.env.GOOGLE_APPLICATION_CREDENTIALS && import_fs2.default.existsSync(raw)) {
        parsed = JSON.parse(import_fs2.default.readFileSync(raw, "utf-8"));
      } else {
        const decoded = Buffer.from(cleanRaw, "base64").toString("utf-8");
        if (decoded.trim().startsWith("{")) {
          parsed = JSON.parse(decoded);
        }
      }
    } catch {
    }
    if (!parsed || typeof parsed !== "object") {
      errors.push("FIREBASE_SERVICE_ACCOUNT_KEY tidak berformat JSON atau Base64 yang valid.");
    } else if (!parsed.client_email || !parsed.private_key) {
      errors.push('FIREBASE_SERVICE_ACCOUNT_KEY wajib memiliki field "client_email" dan "private_key".');
    }
  }
  const shopSecret = process.env.SHOP_AUTH_SECRET;
  if (!shopSecret || shopSecret.trim().length < 32) {
    errors.push("SHOP_AUTH_SECRET wajib disetel dan memiliki minimal 32 karakter untuk Tumpang Shop.");
  } else if (shopSecret.includes("shop_secret_fallback") || shopSecret.includes("fallback_key")) {
    errors.push("SHOP_AUTH_SECRET tidak boleh menggunakan string fallback/development pada mode produksi.");
  }
  const shopAdminEmail = process.env.SHOP_ADMIN_EMAIL;
  if (!shopAdminEmail || !shopAdminEmail.includes("@")) {
    errors.push("SHOP_ADMIN_EMAIL wajib disetel dengan alamat email yang sah untuk Tumpang Shop.");
  }
  const shopAdminPassword = process.env.SHOP_ADMIN_PASSWORD;
  if (!shopAdminPassword || shopAdminPassword.trim().length < 8) {
    errors.push("SHOP_ADMIN_PASSWORD wajib disetel dengan minimal 8 karakter untuk Tumpang Shop.");
  } else if (shopAdminPassword === "TumpangShopAdmin#2026") {
    errors.push('SHOP_ADMIN_PASSWORD tidak boleh menggunakan kata sandi default/contoh ("TumpangShopAdmin#2026") pada mode produksi.');
  }
  const portVal = resolveServerPort();
  if (isNaN(portVal) || portVal < 1 || portVal > 65535) {
    errors.push("PORT atau FOOD_PORT harus berupa angka port TCP yang valid (1-65535).");
  }
  return {
    isValid: errors.length === 0,
    errors
  };
}
if (process.env.NODE_ENV === "production") {
  const check = validateProductionEnvironment();
  if (!check.isValid) {
    console.warn(`[TumpangFood Security] Peringatan konfigurasi produksi:
- ${check.errors.join("\n- ")}`);
  }
}
var foodConfig = {
  isProduction: process.env.NODE_ENV === "production",
  // Server port
  port: resolveServerPort(),
  host: "0.0.0.0",
  isServerless: isServerless2,
  // Database settings
  databaseId: (() => {
    const rawEnv = (process.env.FOOD_DATABASE_ID || "").trim();
    if (rawEnv && rawEnv !== "ai-studio-tumpangfood-99caef89-a69c-4fe1-80be-2c79f3dcb85c") {
      return rawEnv;
    }
    try {
      const configPath = import_path2.default.join(process.cwd(), "firebase-applet-config.json");
      if (import_fs2.default.existsSync(configPath)) {
        const rawConfig = JSON.parse(import_fs2.default.readFileSync(configPath, "utf-8"));
        if (rawConfig.firestoreDatabaseId && rawConfig.firestoreDatabaseId !== "ai-studio-tumpangfood-99caef89-a69c-4fe1-80be-2c79f3dcb85c") {
          return rawConfig.firestoreDatabaseId;
        }
      }
    } catch {
    }
    return "(default)";
  })(),
  localDbFile,
  legacyDbFile: import_path2.default.join(process.cwd(), "tumpang_db.json"),
  // Security & Authentication
  jwtSecret: runtimeJwtSecret || "dev_secret_fallback_do_not_use_in_prod",
  get adminEmail() {
    return (process.env.FOOD_ADMIN_EMAIL || runtimeAdminEmail || "tumpanggo@gmail.com").trim().toLowerCase();
  },
  get adminPassword() {
    return cleanEnvSecret(process.env.FOOD_ADMIN_PASSWORD || runtimeAdminPassword, isProductionRuntime ? "" : "TumpangGoAdmin#2026");
  },
  // Master Account (Unrestricted Cross-Portal Access)
  masterAccount: {
    get email() {
      return getMasterAccountCredentials().email;
    },
    get password() {
      return getMasterAccountCredentials().password;
    }
  },
  // System operational defaults
  defaults: {
    serviceFee: 2e3,
    deliveryFeePerKm: 1500,
    defaultDeliveryFee: 5e3,
    commissionPercent: 10,
    paymentExpiryMinutes: 10,
    qrisImage: "/qris-merchant.png"
  }
};
function getMasterAccountCredentials() {
  const email = (process.env.MASTER_ADMIN_EMAIL || runtimeMasterAdminEmail || "tumpanggo@gmail.com").trim().toLowerCase();
  const envPass = process.env.MASTER_ADMIN_PASSWORD || process.env.FOOD_ADMIN_PASSWORD;
  const hasExplicitEnv = Boolean(envPass && envPass.length > 0);
  const password = cleanEnvSecret(envPass || runtimeMasterAdminPassword, isProductionRuntime ? "" : "TumpangGoAdmin#2026");
  const source = hasExplicitEnv ? process.env.MASTER_ADMIN_PASSWORD ? "PROCESS_ENV_MASTER_ADMIN_PASSWORD" : "PROCESS_ENV_FOOD_ADMIN_PASSWORD" : runtimeMasterAdminPassword ? "RUNTIME_ROTATED_SECRET" : "DATABASE_PERSISTED_HASH";
  return {
    email,
    password,
    hasExplicitEnv,
    byteLength: Buffer.byteLength(password, "utf-8"),
    source
  };
}
function isMasterAdminEmail(email) {
  if (!email) return false;
  const clean = email.trim().toLowerCase();
  return clean === foodConfig.masterAccount.email || clean === "tumpanggo@gmail.com" || clean === "tumpanggo" || clean === "suaiimokeras@gmail.com" || clean === "suaiimokeras";
}
function updateRuntimeMasterPassword(newPassword) {
  runtimeMasterAdminPassword = newPassword.trim();
  process.env.MASTER_ADMIN_PASSWORD = newPassword.trim();
}
function reloadEnv() {
  import_dotenv2.default.config();
  loadEnvExplicit2(import_path2.default.resolve(process.cwd(), ".env"));
  const localEnvPath3 = import_path2.default.resolve(process.cwd(), ".env.local");
  if (import_fs2.default.existsSync(localEnvPath3)) {
    import_dotenv2.default.config({ path: localEnvPath3, override: true });
    loadEnvExplicit2(localEnvPath3);
  }
}
var artopayConfig = {
  get isProduction() {
    return process.env.NODE_ENV === "production";
  },
  get environment() {
    const env = (process.env.ARTOPAY_ENVIRONMENT || process.env.ARTOPAY_ENV || "sandbox").toLowerCase().trim();
    return env === "production" ? "production" : "sandbox";
  },
  get apiKey() {
    let key = (process.env.ARTOPAY_API_KEY || "").trim();
    if (key.startsWith("'") && key.endsWith("'") || key.startsWith('"') && key.endsWith('"')) {
      key = key.slice(1, -1).trim();
    }
    return key;
  },
  get secretKey() {
    let key = (process.env.ARTOPAY_SECRET_KEY || "").trim();
    if (key.startsWith("'") && key.endsWith("'") || key.startsWith('"') && key.endsWith('"')) {
      key = key.slice(1, -1).trim();
    }
    return key;
  },
  get publicKey() {
    let key = (process.env.ARTOPAY_PUBLIC_KEY || process.env.VITE_ARTOPAY_PUBLIC_KEY || process.env.ARTOPAY_CLIENT_KEY || process.env.VITE_ARTOPAY_CLIENT_KEY || "").trim();
    if (key.startsWith("'") && key.endsWith("'") || key.startsWith('"') && key.endsWith('"')) {
      key = key.slice(1, -1).trim();
    }
    if (key.startsWith("%") || key.includes("%VITE_") || key === "undefined" || key === "null") {
      return "";
    }
    return key;
  },
  get webhookSecret() {
    let key = (process.env.ARTOPAY_WEBHOOK_SECRET || "").trim();
    if (key.startsWith("'") && key.endsWith("'") || key.startsWith('"') && key.endsWith('"')) {
      key = key.slice(1, -1).trim();
    }
    return key;
  },
  get businessUnitCode() {
    let key = (process.env.ARTOPAY_BUSINESS_UNIT_CODE || process.env.ARTOPAY_BUSINESS_UNIT || "").trim();
    if (key.startsWith("'") && key.endsWith("'") || key.startsWith('"') && key.endsWith('"')) {
      key = key.slice(1, -1).trim();
    }
    return key;
  },
  get baseUrl() {
    const defaultApiUrl = this.environment === "production" ? "https://api.arto-pay.com" : "https://api-sandbox.arto-pay.com";
    return (process.env.ARTOPAY_API_BASE_URL || process.env.ARTOPAY_BASE_URL || defaultApiUrl).trim();
  },
  get payBaseUrl() {
    const defaultPayUrl = this.environment === "production" ? "https://pay.arto-pay.com/arto-pay" : "https://pay-sandbox.arto-pay.com/arto-pay";
    return (process.env.ARTOPAY_PAY_URL || defaultPayUrl).trim();
  },
  defaultExpiryMinutes: 15
};

// src/server/auth.ts
var import_crypto = __toESM(require("crypto"), 1);
function hashPassword(password) {
  const salt = import_crypto.default.randomBytes(16).toString("hex");
  const iterations = 1e4;
  const hash = import_crypto.default.pbkdf2Sync(password, salt, iterations, 64, "sha512").toString("hex");
  return `pbkdf2$${iterations}$${salt}$${hash}`;
}
function verifyPassword(password, storedHash) {
  if (!storedHash || typeof storedHash !== "string" || !password || typeof password !== "string") {
    return { valid: false, needsRehash: false };
  }
  try {
    if (storedHash.startsWith("pbkdf2$")) {
      const parts = storedHash.split("$");
      if (parts.length !== 4) return { valid: false, needsRehash: false };
      const iterations = parseInt(parts[1], 10);
      const salt = parts[2];
      const originalHash = parts[3];
      if (isNaN(iterations) || iterations < 1 || !salt || !originalHash) {
        return { valid: false, needsRehash: false };
      }
      const derived = import_crypto.default.pbkdf2Sync(password, salt, iterations, 64, "sha512").toString("hex");
      const bufDerived = Buffer.from(derived, "hex");
      const bufOriginal = Buffer.from(originalHash, "hex");
      if (bufDerived.length !== bufOriginal.length) {
        return { valid: false, needsRehash: false };
      }
      const valid2 = import_crypto.default.timingSafeEqual(bufDerived, bufOriginal);
      return { valid: valid2, needsRehash: false };
    }
    const valid = password.trim() === storedHash.trim();
    return { valid, needsRehash: valid };
  } catch (err) {
    console.warn("[TumpangFood Auth] Error during password verification:", err);
    return { valid: false, needsRehash: false };
  }
}
function createAuthToken(user, expiresInHours = 72) {
  let secret = foodConfig.jwtSecret;
  if (!secret || secret.length < 32) {
    secret = process.env.FOOD_AUTH_SECRET || "dev_secret_fallback_do_not_use_in_prod_min_32_characters_long";
  }
  if (!secret || secret.length < 32) {
    secret = "dev_secret_fallback_do_not_use_in_prod_min_32_characters_long";
  }
  const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url");
  const payload = Buffer.from(
    JSON.stringify({
      ...user,
      exp: Math.floor(Date.now() / 1e3) + expiresInHours * 3600
    })
  ).toString("base64url");
  const signature = import_crypto.default.createHmac("sha256", secret).update(`${header}.${payload}`).digest("base64url");
  return `${header}.${payload}.${signature}`;
}
function verifyAuthToken(token) {
  if (!token) return null;
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const [header, payload, signature] = parts;
    let isValid = false;
    if (foodConfig.jwtSecret && foodConfig.jwtSecret.length >= 16) {
      const foodSig = import_crypto.default.createHmac("sha256", foodConfig.jwtSecret).update(`${header}.${payload}`).digest("base64url");
      if (signature.length === foodSig.length) {
        isValid = import_crypto.default.timingSafeEqual(Buffer.from(signature), Buffer.from(foodSig));
      }
    }
    if (!isValid && shopConfig.jwtSecret && shopConfig.jwtSecret.length >= 16) {
      const shopSig = import_crypto.default.createHmac("sha256", shopConfig.jwtSecret).update(`${header}.${payload}`).digest("base64url");
      if (signature.length === shopSig.length) {
        isValid = import_crypto.default.timingSafeEqual(Buffer.from(signature), Buffer.from(shopSig));
      }
    }
    if (!isValid) {
      return null;
    }
    const data = JSON.parse(Buffer.from(payload, "base64url").toString("utf-8"));
    if (data.exp && data.exp < Math.floor(Date.now() / 1e3)) {
      return null;
    }
    return {
      userId: data.userId,
      role: data.role,
      email: data.email,
      entityId: data.entityId,
      scope: data.scope,
      isMasterAdmin: data.isMasterAdmin || data.role === "MASTER_ADMIN"
    };
  } catch {
    return null;
  }
}
function authenticateToken(req, res, next) {
  let token = "";
  const authHeader = req.headers["authorization"];
  if (authHeader && authHeader.startsWith("Bearer ")) {
    token = authHeader.substring(7);
  } else if (req.headers["x-auth-token"]) {
    token = String(req.headers["x-auth-token"]);
  }
  if (token) {
    const verified = verifyAuthToken(token);
    if (verified) {
      req.user = verified;
    }
  }
  next();
}
function isAdminEmail(email) {
  if (!email) return false;
  const e = email.trim().toLowerCase();
  return e === foodConfig.masterAccount.email || e === foodConfig.adminEmail || e === "suaiimokeras@gmail.com" || e === "suaiimokeras" || e === "tumpanggo@gmail.com" || e === "tumpanggo" || e === "admin@tumpanggo.com" || e === "sawahjayagroup@gmail.com" || e === "sawahjayatrans@gmail.com" || e === "admin";
}
function requireRole(allowedRoles) {
  return (req, res, next) => {
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: "Akses ditolak: Autentikasi diperlukan. Silakan login terlebih dahulu." });
    }
    if (user.role === "ADMIN" || user.role === "MASTER_ADMIN") {
      return next();
    }
    if (!allowedRoles.includes(user.role)) {
      return res.status(403).json({ error: `Akses ditolak: Peran ${user.role} tidak memiliki izin untuk tindakan ini.` });
    }
    next();
  };
}
function requireMerchantOwner(paramName = "merchantId") {
  return (req, res, next) => {
    const targetMerchantId = req.params[paramName] || req.params.merchantId || req.params.id || req.body[paramName];
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: "Akses ditolak: Autentikasi diperlukan. Silakan login terlebih dahulu." });
    }
    if (user.role === "ADMIN" || user.role === "MASTER_ADMIN" || user.isMasterAdmin) {
      return next();
    }
    if (user.role === "MERCHANT" && (user.entityId === targetMerchantId || user.userId === targetMerchantId)) {
      return next();
    }
    return res.status(403).json({ error: "Akses ditolak: Anda tidak memiliki izin untuk mengakses atau memodifikasi data toko ini." });
  };
}
function requireDriverSelf(paramName = "driverId") {
  return (req, res, next) => {
    const targetDriverId = req.params[paramName] || req.params.driverId || req.params.id || req.body[paramName];
    const user = req.user;
    if (!user) {
      return res.status(401).json({ error: "Akses ditolak: Autentikasi diperlukan. Silakan login terlebih dahulu." });
    }
    if (user.role === "ADMIN" || user.role === "MASTER_ADMIN" || user.isMasterAdmin) {
      return next();
    }
    if (user.role === "DRIVER" && (user.entityId === targetDriverId || user.userId === targetDriverId)) {
      return next();
    }
    return res.status(403).json({ error: "Akses ditolak: Anda tidak memiliki izin untuk tugas kurir ini." });
  };
}

// src/utils/deliveryFee.ts
var FLAT_TUMPANG_DELIVERY_FEE = 5e3;
var TUMPANG_VILLAGES = [
  // 1. Tumpang
  "tumpang",
  "desa tumpang",
  "kelurahan tumpang",
  // 2. Jeru
  "jeru",
  "desa jeru",
  // 3. Malangsuko
  "malangsuko",
  "malang suko",
  "malang-suko",
  "desa malangsuko",
  "desa malang suko",
  // 4. Pulungdowo
  "pulungdowo",
  "pulung dowo",
  "pulung-dowo",
  "desa pulungdowo",
  "desa pulung dowo",
  // 5. Bokor
  "bokor",
  "desa bokor",
  // 6. Slamet
  "slamet",
  "desa slamet",
  // 7. Wringinsongo
  "wringinsongo",
  "wringin songo",
  "wringin-songo",
  "desa wringinsongo",
  "desa wringin songo",
  // 8. Benjor
  "benjor",
  "desa benjor",
  // 9. Duwet
  "duwet",
  "desa duwet",
  // 10. Duwet Krajan
  "duwet krajan",
  "duwetkrajan",
  "duwet-krajan",
  "desa duwet krajan",
  "desa duwetkrajan",
  // 11. Kidal
  "kidal",
  "desa kidal",
  // 12. Kambingan
  "kambingan",
  "desa kambingan",
  // 13. Ngingit
  "ngingit",
  "desa ngingit",
  // 14. Tulusbesar
  "tulusbesar",
  "tulus besar",
  "tulus-besar",
  "desa tulusbesar",
  "desa tulus besar",
  // 15. Pandanajeng
  "pandanajeng",
  "pandan ajeng",
  "pandan-ajeng",
  "desa pandanajeng",
  "desa pandan ajeng"
];
var TUMPANG_LANDMARKS = [
  "candi kidal",
  "candi jago",
  "alun-alun tumpang",
  "alun alun tumpang",
  "taman tumpang",
  "pasar tumpang",
  "terminal tumpang",
  "kantor kecamatan tumpang",
  "kantor camat tumpang",
  "kecamatan tumpang",
  "kec. tumpang",
  "kec tumpang",
  "rs sumber sentosa",
  "rumah sakit sumber sentosa",
  "sumber sentosa",
  "puskesmas tumpang",
  "polsek tumpang",
  "koramil tumpang",
  "lembah tumpang",
  "sman 1 tumpang",
  "smpn 1 tumpang",
  "smpn 2 tumpang",
  "desela",
  "selandor",
  "argosari",
  "argo sari",
  "jilu",
  "glagah",
  // Dusun Glagah di Desa Tulusbesar
  "tumpanggo",
  "tumpang go",
  "65156"
  // Official Postal Code of Kecamatan Tumpang
];
var OUTSIDE_DISTRICT_KEYWORDS = [
  "kecamatan pakis",
  "kec. pakis",
  "pakis",
  "kecamatan poncokusumo",
  "kec. poncokusumo",
  "poncokusumo",
  "kecamatan jabung",
  "kec. jabung",
  "jabung",
  "kecamatan wajak",
  "kec. wajak",
  "wajak",
  "kecamatan tajinan",
  "kec. tajinan",
  "tajinan",
  "kecamatan singosari",
  "kec. singosari",
  "singosari",
  "kecamatan lawang",
  "kec. lawang",
  "lawang",
  "kecamatan kepanjen",
  "kec. kepanjen",
  "kepanjen",
  "kota malang",
  "malang kota",
  "klojen",
  "lowokwaru",
  "sukun",
  "blimbing",
  "kedungkandang",
  "kota batu",
  "batu",
  "surabaya",
  "sidoarjo",
  "pasuruan",
  "probolinggo",
  "blitar"
];
var TUMPANG_GEO_BOUNDS = {
  minLat: -8.12,
  maxLat: -7.85,
  minLng: 112.67,
  maxLng: 112.89
};
function calculateDistanceKm(lat1, lon1, lat2, lon2) {
  if (!lat1 || !lon1 || !lat2 || !lon2) return 0;
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}
function normalizeLocationText(text) {
  return text.toLowerCase().replace(/[^\w\s-]/g, " ").replace(/\s+/g, " ").trim();
}
function isDestinationInKecamatanTumpang(loc) {
  const rawCombined = [loc.address, loc.details, loc.landmark].filter(Boolean).join(" ");
  const normalized = normalizeLocationText(rawCombined);
  if (normalized.includes("65156") || /\b(tumpang)\b/i.test(normalized)) {
    return true;
  }
  const hasVillage = TUMPANG_VILLAGES.some((village) => {
    const vNorm = normalizeLocationText(village);
    if (vNorm.includes(" ")) {
      return normalized.includes(vNorm);
    }
    const regex = new RegExp(`(^|[^a-z])${vNorm}([^a-z]|$)`, "i");
    return regex.test(normalized);
  });
  if (hasVillage) {
    return true;
  }
  const hasLandmark = TUMPANG_LANDMARKS.some((lm) => {
    const lmNorm = normalizeLocationText(lm);
    return normalized.includes(lmNorm);
  });
  if (hasLandmark) {
    return true;
  }
  const hasExplicitOutsideDistrict = OUTSIDE_DISTRICT_KEYWORDS.some((kw) => {
    const kwNorm = normalizeLocationText(kw);
    if (kwNorm.includes(" ")) {
      return normalized.includes(kwNorm);
    }
    const regex = new RegExp(`(^|[^a-z])${kwNorm}([^a-z]|$)`, "i");
    return regex.test(normalized);
  });
  if (hasExplicitOutsideDistrict) {
    return false;
  }
  if (typeof loc.latitude === "number" && typeof loc.longitude === "number" && loc.latitude !== 0 && loc.longitude !== 0) {
    const inBounds = loc.latitude >= TUMPANG_GEO_BOUNDS.minLat && loc.latitude <= TUMPANG_GEO_BOUNDS.maxLat && loc.longitude >= TUMPANG_GEO_BOUNDS.minLng && loc.longitude <= TUMPANG_GEO_BOUNDS.maxLng;
    if (inBounds) {
      return true;
    } else {
      return false;
    }
  }
  return true;
}
function calculateDeliveryFee(params) {
  const isInTumpang = isDestinationInKecamatanTumpang({
    address: params.address,
    details: params.details,
    landmark: params.landmark,
    latitude: params.latitude,
    longitude: params.longitude
  });
  if (isInTumpang) {
    return {
      deliveryFee: FLAT_TUMPANG_DELIVERY_FEE,
      isInTumpang: true,
      explanation: "Tarif flat Rp 5.000 untuk seluruh pengantaran di area Kecamatan Tumpang."
    };
  }
  let distanceKm = 0;
  if (params.merchantLatitude && params.merchantLongitude && params.latitude && params.longitude) {
    distanceKm = calculateDistanceKm(
      params.merchantLatitude,
      params.merchantLongitude,
      params.latitude,
      params.longitude
    );
  }
  const feePerKm = params.systemConfig?.deliveryFeePerKm || 1500;
  const baseFee = params.systemConfig?.defaultDeliveryFee || 5e3;
  const calculatedOutside = Math.round((distanceKm || 5) * feePerKm);
  const outsideFee = Math.max(baseFee, calculatedOutside);
  return {
    deliveryFee: outsideFee,
    isInTumpang: false,
    distanceKm: distanceKm || void 0,
    explanation: `Pengantaran luar Kecamatan Tumpang (${distanceKm ? distanceKm + " km" : "Luar Wilayah"}): Rp ${outsideFee.toLocaleString("id-ID")}`
  };
}
function normalizeOrderDeliveryFee(order) {
  if (!order) return order;
  const inTumpang = isDestinationInKecamatanTumpang({
    address: order.deliveryAddress,
    details: order.deliveryDetails,
    landmark: order.landmark,
    latitude: order.latitude,
    longitude: order.longitude
  });
  if (inTumpang && order.deliveryFee !== FLAT_TUMPANG_DELIVERY_FEE) {
    order.deliveryFee = FLAT_TUMPANG_DELIVERY_FEE;
    order.total = order.subtotal + FLAT_TUMPANG_DELIVERY_FEE + order.serviceFee + (order.uniqueCode || 0);
  }
  return order;
}

// src/server/services/orderService.ts
var OrderService = class {
  /**
   * Validates and recalculates an incoming order against official database records.
   * Prevents customer-side price tampering.
   * Guarantees that preOrderDate is never copied from input to the resulting order.
   */
  static validateAndBuildOrder(input, merchant, menuItems, systemConfig, activeUniqueCodes) {
    if (!merchant) {
      throw new Error("Merchant tidak ditemukan.");
    }
    if (!merchant.active) {
      throw new Error(`Toko "${merchant.name}" saat ini sedang tutup dan tidak menerima pesanan.`);
    }
    if (!input.items || input.items.length === 0) {
      throw new Error("Keranjang belanja kosong. Silakan pilih menu terlebih dahulu.");
    }
    if (!input.customerName || !input.customerPhone || !input.deliveryAddress) {
      throw new Error("Mohon lengkapi Nama Pemesan, Nomor WhatsApp, dan Alamat Pengiriman.");
    }
    const validatedItems = [];
    let calculatedSubtotal = 0;
    for (const orderItemInput of input.items) {
      const quantity = Math.max(1, Math.floor(Number(orderItemInput.quantity) || 1));
      const menuItem = menuItems.find((m) => m.id === orderItemInput.menuItemId && m.merchantId === merchant.id);
      if (!menuItem) {
        throw new Error(`Menu dengan ID "${orderItemInput.menuItemId}" tidak ditemukan pada toko ini.`);
      }
      if (!menuItem.available) {
        throw new Error(`Maaf, menu "${menuItem.name}" saat ini sedang habis.`);
      }
      const officialPrice = Number(menuItem.price) || 0;
      calculatedSubtotal += officialPrice * quantity;
      validatedItems.push({
        menuItemId: menuItem.id,
        name: menuItem.name,
        price: officialPrice,
        quantity
      });
    }
    const calculatedServiceFee = calculateTieredServiceFee(calculatedSubtotal);
    const deliveryCalc = calculateDeliveryFee({
      address: input.deliveryAddress,
      details: input.deliveryDetails,
      landmark: input.landmark,
      latitude: input.latitude,
      longitude: input.longitude,
      merchantLatitude: merchant.latitude,
      merchantLongitude: merchant.longitude,
      systemConfig
    });
    const calculatedDeliveryFee = deliveryCalc.deliveryFee;
    const uniqueCode = this.generateUniqueCode(activeUniqueCodes);
    const total = calculatedSubtotal + calculatedDeliveryFee + calculatedServiceFee + uniqueCode;
    const paymentExpiresAt = new Date(Date.now() + 10 * 60 * 1e3).toISOString();
    return normalizeOrderDeliveryFee({
      uniqueCode,
      total,
      status: "WAITING_PAYMENT" /* WAITING_PAYMENT */,
      paymentStatus: "PENDING" /* PENDING */,
      paymentMethod: "MERCHANT_QRIS",
      merchantId: merchant.id,
      merchantName: merchant.name,
      merchantQrisImage: merchant.qrisImage || "",
      customerName: input.customerName.trim(),
      customerPhone: input.customerPhone.trim(),
      deliveryAddress: input.deliveryAddress.trim(),
      deliveryDetails: input.deliveryDetails ? input.deliveryDetails.trim() : "",
      landmark: input.landmark ? input.landmark.trim() : "",
      latitude: input.latitude,
      longitude: input.longitude,
      items: validatedItems,
      subtotal: calculatedSubtotal,
      deliveryFee: calculatedDeliveryFee,
      serviceFee: calculatedServiceFee,
      paymentExpiresAt
    });
  }
  /**
   * Generates a unique 2-digit verification code avoiding conflicts.
   */
  static generateUniqueCode(activeCodes) {
    for (let attempts = 0; attempts < 100; attempts++) {
      const code = Math.floor(Math.random() * 99) + 1;
      if (!activeCodes.includes(code)) {
        return code;
      }
    }
    return Math.floor(Math.random() * 99) + 1;
  }
  /**
   * Haversine formula to compute distance in km
   */
  static calculateDistanceKm(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.round(R * c * 10) / 10;
  }
  /**
   * Validates state machine status transition
   */
  static isValidStatusTransition(currentStatus, targetStatus, role) {
    if (role === "ADMIN" || role === "MASTER_ADMIN" || role === "SYSTEM") {
      return { allowed: true };
    }
    if (currentStatus === targetStatus) {
      return { allowed: true };
    }
    if (currentStatus === "COMPLETED" /* COMPLETED */ || currentStatus === "CANCELLED" /* CANCELLED */ || currentStatus === "EXPIRED" /* EXPIRED */) {
      return { allowed: false, reason: `Pesanan telah berada pada status final (${currentStatus}).` };
    }
    switch (role) {
      case "CUSTOMER":
        if ((currentStatus === "WAITING_PAYMENT" /* WAITING_PAYMENT */ || currentStatus === "PAYMENT_REJECTED" /* PAYMENT_REJECTED */) && (targetStatus === "WAITING_PAYMENT_VERIFICATION" /* WAITING_PAYMENT_VERIFICATION */ || targetStatus === "CANCELLED" /* CANCELLED */)) {
          return { allowed: true };
        }
        return { allowed: false, reason: "Pelanggan hanya dapat mengunggah bukti pembayaran atau membatalkan pesanan baru/ditolak." };
      case "MERCHANT":
        if (currentStatus === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */ && targetStatus === "COOKING" /* COOKING */) {
          return { allowed: true };
        }
        if (currentStatus === "COOKING" /* COOKING */ && targetStatus === "READY_FOR_PICKUP" /* READY_FOR_PICKUP */) {
          return { allowed: true };
        }
        return { allowed: false, reason: `Merchant tidak diizinkan mengubah status dari ${currentStatus} ke ${targetStatus}.` };
      case "DRIVER":
        if ((currentStatus === "READY_FOR_PICKUP" /* READY_FOR_PICKUP */ || currentStatus === "COOKING" /* COOKING */) && targetStatus === "ORDER_PICKED_UP" /* ORDER_PICKED_UP */) {
          return { allowed: true };
        }
        if ((currentStatus === "ORDER_PICKED_UP" /* ORDER_PICKED_UP */ || currentStatus === "DELIVERED" /* DELIVERED */) && targetStatus === "COMPLETED" /* COMPLETED */) {
          return { allowed: true };
        }
        return { allowed: false, reason: `Driver tidak diizinkan mengubah status dari ${currentStatus} ke ${targetStatus}.` };
      default:
        return { allowed: false, reason: "Peran tidak dikenali." };
    }
  }
};

// src/server/firebaseAdmin.ts
var import_fs3 = __toESM(require("fs"), 1);
var import_path3 = __toESM(require("path"), 1);
var admin = __toESM(require("firebase-admin"), 1);
var import_app = require("firebase-admin/app");
var import_firestore = require("firebase-admin/firestore");
var adminApp = null;
var adminDb = null;
var isConfiguredWithServiceAccount = false;
var isFirestoreVerified = false;
var activeProjectId = "tumpanggo-70479";
var activeClientEmailMasked = null;
var lastDiagnosticReason = "MISSING_CREDENTIALS";
var lastDiagnosticDetail = "Variabel lingkungan FIREBASE_SERVICE_ACCOUNT_KEY belum dikonfigurasi di Environment Variables Vercel.";
var lastRemediationStep = "Tambahkan variabel lingkungan FIREBASE_SERVICE_ACCOUNT_KEY di Vercel Project Settings > Environment Variables berisi JSON Service Account dari Firebase Console.";
var lastProbeResult = null;
function removeUndefinedFields(obj) {
  if (obj === null || typeof obj !== "object") return obj;
  if (Array.isArray(obj)) return obj.map(removeUndefinedFields);
  const cleaned = {};
  for (const [key, val] of Object.entries(obj)) {
    if (val !== void 0) {
      cleaned[key] = removeUndefinedFields(val);
    }
  }
  return cleaned;
}
function sanitizeErrorMessage(msg) {
  if (!msg || typeof msg !== "string") return "Unknown error";
  return msg.replace(/-----BEGIN[^-]+-----[\s\S]+?-----END[^-]+-----/g, "[PROTECTED_PRIVATE_KEY]").replace(/(private_key|token|secret|password)["']?\s*[:=]\s*["']?[^"',\s}]+/gi, "$1: [REDACTED]").replace(/(\/Users\/|\/home\/|\/var\/task\/)[^\s:]+/g, "[system-path]");
}
function maskClientEmail(email) {
  if (!email || !email.includes("@")) return "configured_account";
  const parts = email.split("@");
  const user = parts[0];
  const domain = parts[1];
  const visibleLen = Math.min(3, user.length);
  return `${user.substring(0, visibleLen)}***@${domain}`;
}
function getExpectedProjectId() {
  let expected = (process.env.FIREBASE_PROJECT_ID || process.env.GCP_PROJECT || "").trim();
  if (!expected) {
    try {
      const configPath = import_path3.default.join(process.cwd(), "firebase-applet-config.json");
      if (import_fs3.default.existsSync(configPath)) {
        const raw = JSON.parse(import_fs3.default.readFileSync(configPath, "utf-8"));
        if (raw.projectId) expected = raw.projectId.trim();
      }
    } catch {
    }
  }
  return expected || "tumpanggo-70479";
}
function parseServiceAccountKey(rawInput, expectedProjectId) {
  if (!rawInput || typeof rawInput !== "string" || rawInput.trim().length === 0) {
    return {
      account: null,
      reason: "MISSING_CREDENTIALS",
      error: "Variabel lingkungan FIREBASE_SERVICE_ACCOUNT_KEY belum dikonfigurasi di Environment Variables Vercel.",
      remediation: "Buka Vercel Dashboard -> Project Settings -> Environment Variables, lalu tambahkan FIREBASE_SERVICE_ACCOUNT_KEY berisi JSON Service Account dari Firebase Console."
    };
  }
  let clean = rawInput.trim();
  if (clean.charCodeAt(0) === 65279) {
    clean = clean.slice(1).trim();
  }
  if (clean.startsWith("'") && clean.endsWith("'") || clean.startsWith('"') && clean.endsWith('"')) {
    clean = clean.slice(1, -1).trim();
  }
  let parsed = null;
  let jsonParseError = null;
  if (clean.startsWith("{")) {
    try {
      parsed = JSON.parse(clean);
    } catch (e) {
      jsonParseError = e.message;
      try {
        const normalized = clean.replace(/\r\n/g, "\n");
        parsed = JSON.parse(normalized);
        jsonParseError = null;
      } catch (e2) {
        try {
          if (clean.includes('\\"')) {
            parsed = JSON.parse(clean.replace(/\\"/g, '"'));
            jsonParseError = null;
          }
        } catch {
        }
      }
    }
  } else {
    try {
      const decoded = Buffer.from(clean, "base64").toString("utf-8").trim();
      if (decoded.startsWith("{")) {
        parsed = JSON.parse(decoded);
      }
    } catch {
    }
    if (!parsed && import_fs3.default.existsSync(clean)) {
      try {
        const fileContent = import_fs3.default.readFileSync(clean, "utf-8").trim();
        if (fileContent.startsWith("{")) {
          parsed = JSON.parse(fileContent);
        }
      } catch (fileErr) {
        jsonParseError = fileErr.message;
      }
    }
  }
  if (!parsed || typeof parsed !== "object") {
    return {
      account: null,
      reason: "INVALID_JSON",
      error: `Format FIREBASE_SERVICE_ACCOUNT_KEY tidak dapat diparsing sebagai JSON yang valid${jsonParseError ? `: ${sanitizeErrorMessage(jsonParseError)}` : "."}`,
      remediation: "Periksa nilai FIREBASE_SERVICE_ACCOUNT_KEY di Vercel Environment Variables. Pastikan seluruh isi JSON utuh disalin (tanpa tanda kutip luar tambahan atau karakter yang terpotong)."
    };
  }
  if (!parsed.client_email || typeof parsed.client_email !== "string" || !parsed.client_email.includes("@")) {
    return {
      account: null,
      reason: "MALFORMED_SERVICE_ACCOUNT",
      error: 'JSON Service Account tidak lengkap. Wajib memiliki field "client_email" yang sah.',
      remediation: "Unduh ulang file kunci JSON Service Account baru dari Firebase Console (Project Settings > Service Accounts > Generate new private key)."
    };
  }
  if (!parsed.private_key || typeof parsed.private_key !== "string" || !parsed.private_key.includes("PRIVATE KEY")) {
    return {
      account: null,
      reason: "MALFORMED_SERVICE_ACCOUNT",
      error: 'JSON Service Account tidak memiliki field "private_key" yang sah (wajib mengandung "-----BEGIN PRIVATE KEY-----").',
      remediation: 'Pastikan file Service Account yang disalin memiliki field "private_key" yang utuh.'
    };
  }
  const targetProject = expectedProjectId || getExpectedProjectId();
  if (parsed.project_id && targetProject && parsed.project_id.trim() !== targetProject.trim()) {
    return {
      account: null,
      reason: "PROJECT_ID_MISMATCH",
      error: `Project ID pada Service Account ("${parsed.project_id}") tidak cocok dengan target proyek aplikasi ("${targetProject}").`,
      remediation: `Buka Vercel Dashboard -> Project Settings -> Environment Variables. Sesuaikan variabel FIREBASE_PROJECT_ID agar cocok dengan project ID Service Account ("${parsed.project_id}"), atau unduh Service Account baru dari proyek "${targetProject}" di Firebase Console.`,
      projectId: parsed.project_id,
      clientEmailMasked: maskClientEmail(parsed.client_email)
    };
  }
  parsed.private_key = parsed.private_key.replace(/\\n/g, "\n").replace(/\r\n/g, "\n");
  return {
    account: parsed,
    reason: "OK",
    projectId: parsed.project_id || targetProject,
    clientEmailMasked: maskClientEmail(parsed.client_email)
  };
}
function initFirebaseAdmin(serviceAccountOverride) {
  try {
    const targetProject = getExpectedProjectId();
    activeProjectId = targetProject;
    lastProbeResult = null;
    const rawInput = (serviceAccountOverride || process.env.FIREBASE_SERVICE_ACCOUNT_KEY || process.env.GOOGLE_SERVICE_ACCOUNT_KEY || process.env.FIREBASE_SERVICE_ACCOUNT || process.env.FIREBASE_ADMIN_CREDENTIALS || process.env.SERVICE_ACCOUNT_KEY || process.env.GCP_SERVICE_ACCOUNT_KEY || process.env.GOOGLE_APPLICATION_CREDENTIALS || "").trim();
    isConfiguredWithServiceAccount = false;
    isFirestoreVerified = false;
    activeClientEmailMasked = null;
    if (!rawInput || rawInput.length === 0) {
      adminApp = null;
      adminDb = null;
      lastDiagnosticReason = "MISSING_CREDENTIALS";
      lastDiagnosticDetail = "Variabel lingkungan FIREBASE_SERVICE_ACCOUNT_KEY belum dikonfigurasi di Environment Variables Vercel.";
      lastRemediationStep = "Buka Vercel Dashboard -> Project Settings -> Environment Variables, lalu tambahkan FIREBASE_SERVICE_ACCOUNT_KEY berisi JSON Service Account dari Firebase Console.";
      return { success: false, error: lastDiagnosticDetail, reason: "MISSING_CREDENTIALS" };
    }
    const parseResult = parseServiceAccountKey(rawInput, targetProject);
    if (!parseResult.account) {
      adminApp = null;
      adminDb = null;
      lastDiagnosticReason = parseResult.reason;
      lastDiagnosticDetail = parseResult.error || "Service Account tidak valid.";
      lastRemediationStep = parseResult.remediation;
      return { success: false, error: lastDiagnosticDetail, reason: parseResult.reason };
    }
    const sa = parseResult.account;
    if (sa.project_id) {
      activeProjectId = sa.project_id;
    }
    activeClientEmailMasked = parseResult.clientEmailMasked || maskClientEmail(sa.client_email || "");
    const certFn = import_app.cert || admin.cert || admin.credential?.cert;
    const initAppFn = import_app.initializeApp || admin.initializeApp;
    const getAppsFn = import_app.getApps || admin.getApps;
    if (typeof certFn !== "function") {
      lastDiagnosticReason = "INIT_FAILED";
      lastDiagnosticDetail = "Fungsi cert() dari firebase-admin/app tidak tersedia.";
      lastRemediationStep = "Periksa instalasi paket firebase-admin.";
      return { success: false, error: lastDiagnosticDetail, reason: "INIT_FAILED" };
    }
    const credentialOption = certFn(sa);
    isConfiguredWithServiceAccount = true;
    const currentApps = typeof getAppsFn === "function" ? getAppsFn() : [];
    if (currentApps.length === 0) {
      const initOptions = {
        credential: credentialOption,
        projectId: activeProjectId
      };
      if (typeof initAppFn === "function") {
        adminApp = initAppFn(initOptions);
      }
    } else {
      adminApp = currentApps[0];
    }
    const getFirestoreFn = import_firestore.getFirestore || admin.firestore;
    if (typeof getFirestoreFn === "function" && adminApp) {
      if (!foodConfig.databaseId || foodConfig.databaseId === "(default)") {
        adminDb = getFirestoreFn(adminApp);
      } else {
        adminDb = getFirestoreFn(adminApp, foodConfig.databaseId);
      }
    }
    lastDiagnosticReason = "OK";
    lastDiagnosticDetail = `Kredensial Service Account (${activeClientEmailMasked}) berhasil dimuat untuk proyek "${activeProjectId}". Menunggu verifikasi koneksi.`;
    lastRemediationStep = void 0;
    console.log(`[TumpangFood Admin] Loaded explicit Service Account (Project: ${activeProjectId}, Account: ${activeClientEmailMasked}).`);
    return { success: true, reason: "OK" };
  } catch (e) {
    const safeMsg = sanitizeErrorMessage(e.message);
    console.error("[TumpangFood Admin] Failed to initialize Firebase Admin SDK:", safeMsg);
    adminApp = null;
    adminDb = null;
    isConfiguredWithServiceAccount = false;
    isFirestoreVerified = false;
    lastDiagnosticReason = "INIT_FAILED";
    lastDiagnosticDetail = `Gagal menginisialisasi Firebase Admin SDK: ${safeMsg}`;
    lastRemediationStep = "Periksa format RSA private_key pada Service Account. Pastikan karakter pemisah baris (\\n) tidak rusak.";
    return { success: false, error: lastDiagnosticDetail, reason: "INIT_FAILED" };
  }
}
initFirebaseAdmin();
function getAdminDb() {
  return adminDb;
}
var testMockState = null;
function isFirestoreAdminConfigured() {
  if (testMockState && testMockState.isConfigured !== void 0) {
    return testMockState.isConfigured;
  }
  return adminDb !== null && isConfiguredWithServiceAccount === true && isFirestoreVerified === true;
}
function isUsingServiceAccount() {
  return isConfiguredWithServiceAccount;
}
function getFirestoreDiagnosticStatus() {
  return {
    reason: lastDiagnosticReason,
    detail: lastDiagnosticDetail,
    remediation: lastRemediationStep,
    projectId: activeProjectId,
    authIdentity: activeClientEmailMasked ? `Explicit Service Account (${activeClientEmailMasked})` : "No Service Account Configured",
    isVerified: isFirestoreVerified,
    hasExplicitKey: isConfiguredWithServiceAccount
  };
}
var PROBE_CACHE_TTL_MS = 1e4;
async function testFirestoreConnection(force = false) {
  if (testMockState && testMockState.probeResult !== void 0) {
    return { ...testMockState.probeResult };
  }
  if (!force && lastProbeResult && Date.now() - lastProbeResult.timestamp < PROBE_CACHE_TTL_MS) {
    return { ...lastProbeResult.result };
  }
  if (!adminDb || !isConfiguredWithServiceAccount) {
    isFirestoreVerified = false;
    const res = {
      connected: false,
      canRead: false,
      canWrite: false,
      databaseId: foodConfig.databaseId,
      projectId: activeProjectId,
      usingServiceAccount: false,
      authIdentity: "No Service Account Configured",
      error: lastDiagnosticDetail,
      diagnosticReason: lastDiagnosticReason,
      diagnosticDetail: lastDiagnosticDetail,
      remediationStep: lastRemediationStep
    };
    lastProbeResult = { timestamp: Date.now(), result: res };
    return res;
  }
  let canRead = false;
  let canWrite = false;
  let probeError = void 0;
  let diagnosticReason = "OK";
  const withTimeout = (p, ms = 4e3, label = "Operation") => {
    let timer;
    const timeoutPromise = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms);
      if (timer && typeof timer.unref === "function") timer.unref();
    });
    return Promise.race([
      p.finally(() => {
        if (timer) clearTimeout(timer);
      }),
      timeoutPromise
    ]);
  };
  let diagnosticDetail = "Koneksi cloud Firestore Admin SDK aktif dan berhasil membaca/menulis data.";
  let remediationStep = void 0;
  try {
    await withTimeout(
      adminDb.collection("systemConfig").doc("config_1").get(),
      4e3,
      "Firestore read probe"
    );
    canRead = true;
    canWrite = true;
    isFirestoreVerified = true;
  } catch (err) {
    isFirestoreVerified = false;
    probeError = sanitizeErrorMessage(err?.message || String(err));
    const rawErrCode = err?.code;
    const lower = (probeError + " " + String(rawErrCode || "")).toLowerCase();
    if (rawErrCode === 16 || lower.includes("could not load the default credentials") || lower.includes("unauthenticated")) {
      diagnosticReason = "MISSING_CREDENTIALS";
      diagnosticDetail = "Google Auth Library gagal memuat kredensial default. Serverless Vercel mewajibkan FIREBASE_SERVICE_ACCOUNT_KEY eksplisit.";
      remediationStep = "Setel FIREBASE_SERVICE_ACCOUNT_KEY di Vercel Environment Variables dengan JSON Service Account yang valid.";
    } else if (rawErrCode === 7 || rawErrCode === "7" || rawErrCode === "PERMISSION_DENIED" || lower.includes("permission_denied") || lower.includes("permission denied") || lower.includes("missing or insufficient permissions") || lower.includes("status: 7")) {
      diagnosticReason = "IAM_PERMISSION_DENIED";
      diagnosticDetail = `Service Account (${activeClientEmailMasked || "terpasang"}) ditolak oleh Google Cloud IAM (PERMISSION_DENIED). Akun layanan belum memiliki peran 'Cloud Datastore User' (roles/datastore.user) atau 'Firebase Admin' pada proyek "${activeProjectId}".`;
      remediationStep = `Buka Google Cloud Console -> IAM & Admin -> IAM pada proyek "${activeProjectId}", cari akun layanan "${activeClientEmailMasked || "Service Account"}", dan tambahkan peran "Cloud Datastore User" (roles/datastore.user).`;
    } else if (rawErrCode === 5 || rawErrCode === "5" || rawErrCode === "NOT_FOUND" || lower.includes("not found") || lower.includes("database") || lower.includes("status: 5")) {
      diagnosticReason = "DATABASE_NOT_FOUND";
      diagnosticDetail = `Database Firestore "${foodConfig.databaseId}" tidak ditemukan pada proyek "${activeProjectId}".`;
      remediationStep = `Pastikan database Firestore dengan ID "${foodConfig.databaseId}" sudah dibuat di Firebase Console.`;
    } else if (lower.includes("project") || lower.includes("not exist")) {
      diagnosticReason = "INVALID_PROJECT";
      diagnosticDetail = `Proyek Google Cloud "${activeProjectId}" tidak valid atau tidak dapat diakses.`;
      remediationStep = `Pastikan Service Account dibuat dari project ID "${activeProjectId}" di Firebase Console.`;
    } else if (rawErrCode === 4 || rawErrCode === 14 || rawErrCode === "4" || rawErrCode === "14" || rawErrCode === "DEADLINE_EXCEEDED" || rawErrCode === "UNAVAILABLE" || lower.includes("timed out") || lower.includes("deadline_exceeded") || lower.includes("unavailable") || lower.includes("econnrefused") || lower.includes("etimedout")) {
      diagnosticReason = "NETWORK_OR_TIMEOUT";
      diagnosticDetail = "Gagal menghubungi server Google Cloud Firestore karena koneksi timeout atau gangguan jaringan serverless.";
      remediationStep = "Periksa koneksi jaringan hosting Vercel dan pastikan akses ke firestore.googleapis.com tidak dibatasi firewall.";
    } else {
      diagnosticReason = "UNKNOWN";
      diagnosticDetail = `Terjadi kesalahan saat menghubungi Firestore: ${probeError}`;
      remediationStep = "Periksa log server untuk rincian error gRPC/HTTP Firestore.";
    }
    lastDiagnosticReason = diagnosticReason;
    lastDiagnosticDetail = diagnosticDetail;
    lastRemediationStep = remediationStep;
  }
  if (!probeError) {
    lastDiagnosticReason = "OK";
    lastDiagnosticDetail = diagnosticDetail;
    lastRemediationStep = void 0;
  }
  const isFullyConnected = canRead && !probeError;
  const result = {
    connected: isFullyConnected,
    canRead,
    canWrite: isFullyConnected,
    databaseId: foodConfig.databaseId,
    projectId: activeProjectId,
    usingServiceAccount: isConfiguredWithServiceAccount,
    authIdentity: isConfiguredWithServiceAccount ? `Explicit Service Account (${activeClientEmailMasked || "configured"})` : "No Valid Credentials",
    error: probeError,
    diagnosticReason: isFullyConnected ? "OK" : diagnosticReason,
    diagnosticDetail,
    remediationStep: isFullyConnected ? void 0 : remediationStep
  };
  lastProbeResult = { timestamp: Date.now(), result };
  return result;
}
async function safeAdminSetDoc(collectionName, docId, data) {
  if (testMockState && testMockState.writeSuccess !== void 0) {
    return testMockState.writeSuccess;
  }
  if (!adminDb || !isConfiguredWithServiceAccount) return false;
  try {
    const cleaned = removeUndefinedFields(data);
    await adminDb.collection(collectionName).doc(docId).set(cleaned, { merge: true });
    return true;
  } catch (err) {
    console.warn(`[TumpangFood Admin] safeAdminSetDoc failed for ${collectionName}/${docId}:`, sanitizeErrorMessage(err.message));
    return false;
  }
}
async function safeAdminDeleteDoc(collectionName, docId) {
  if (!adminDb || !isConfiguredWithServiceAccount) return false;
  try {
    await adminDb.collection(collectionName).doc(docId).delete();
    return true;
  } catch (err) {
    console.warn(`[TumpangFood Admin] safeAdminDeleteDoc failed for ${collectionName}/${docId}:`, sanitizeErrorMessage(err.message));
    return false;
  }
}
async function safeAdminGetDoc(collectionName, docId) {
  if (!adminDb || !isConfiguredWithServiceAccount) return null;
  try {
    const snap = await adminDb.collection(collectionName).doc(docId).get();
    if (snap.exists) {
      return snap.data();
    }
    return null;
  } catch (err) {
    console.warn(`[TumpangFood Admin] safeAdminGetDoc failed for ${collectionName}/${docId}:`, sanitizeErrorMessage(err.message));
    return null;
  }
}
async function safeAdminGetDocs(collectionName) {
  if (!adminDb || !isConfiguredWithServiceAccount) return [];
  try {
    const snap = await adminDb.collection(collectionName).get();
    return snap.docs.map((doc) => ({ id: doc.id, ...doc.data() || {} }));
  } catch (err) {
    console.warn(`[TumpangFood Admin] safeAdminGetDocs failed for ${collectionName}:`, sanitizeErrorMessage(err.message));
    return [];
  }
}
async function runAdminTransaction(updateFunction) {
  if (!adminDb || !isConfiguredWithServiceAccount) {
    throw new Error("Firebase Admin Firestore instance is not initialized with valid service account credentials.");
  }
  return await adminDb.runTransaction(updateFunction);
}

// src/server/db.ts
var FOOD_DB_FILE = foodConfig.localDbFile;
var LEGACY_DB_FILE = foodConfig.legacyDbFile;
var safeFirestoreSetDoc = safeAdminSetDoc;
var initialConfig = {
  serviceFee: 2e3,
  deliveryFeePerKm: 1500,
  defaultDeliveryFee: 5e3,
  commissionPercent: 10,
  assignmentMode: "AUTOMATIC" /* AUTOMATIC */,
  qrisImage: "/qris-merchant.png",
  systemOpen: true
};
var FoodDatabase = class {
  constructor() {
    this.isInitialized = false;
    this.lastFileMtime = 0;
    this.initPromise = null;
    this.lastSyncTimestamp = 0;
    this.CACHE_TTL_MS = 15e3;
    this.settlementMutex = Promise.resolve();
    this.data = {
      merchants: [],
      categories: [],
      menuItems: [],
      orders: [],
      drivers: [],
      settlements: [],
      auditLogs: [],
      systemConfig: initialConfig,
      partnerRegistrations: [],
      testimonials: []
    };
    this.loadAndMigrate();
  }
  createBackup() {
    try {
      const backupPath = FOOD_DB_FILE + ".backup.json";
      import_fs4.default.writeFileSync(backupPath, JSON.stringify(this.data, null, 2), "utf-8");
      return true;
    } catch {
      return false;
    }
  }
  /**
   * Loads from food database file or migrates safely from backup / legacy file.
   */
  loadAndMigrate() {
    const backupPath = FOOD_DB_FILE + ".backup.json";
    try {
      if (import_fs4.default.existsSync(FOOD_DB_FILE)) {
        const content = import_fs4.default.readFileSync(FOOD_DB_FILE, "utf-8");
        if (content && content.trim().length > 10) {
          this.data = JSON.parse(content);
          this.ensureStructure();
          this.migratePasswords();
          this.migrateOrdersDeliveryFee();
          this.createBackup();
          console.log("[TumpangFood DB] Loaded primary operational state from tumpang_food_db.json");
          return;
        }
      }
      const candidateSeedPaths = [
        import_path4.default.join(process.cwd(), "tumpang_food_db.json"),
        import_path4.default.join("/var/task", "tumpang_food_db.json")
      ];
      for (const candidate of candidateSeedPaths) {
        if (FOOD_DB_FILE !== candidate && import_fs4.default.existsSync(candidate)) {
          try {
            const seedContent = import_fs4.default.readFileSync(candidate, "utf-8");
            if (seedContent && seedContent.trim().length > 10) {
              this.data = JSON.parse(seedContent);
              this.ensureStructure();
              this.migratePasswords();
              this.migrateOrdersDeliveryFee();
              this.save();
              this.createBackup();
              console.log(`[TumpangFood DB] Successfully bootstrapped serverless database from ${candidate}`);
              return;
            }
          } catch (e) {
            console.warn(`[TumpangFood DB] Failed reading seed database at ${candidate}:`, e.message);
          }
        }
      }
      if (import_fs4.default.existsSync(backupPath)) {
        console.warn("[TumpangFood DB] Primary database corrupted or empty. Recovering from backup snapshot...");
        const backupContent = import_fs4.default.readFileSync(backupPath, "utf-8");
        this.data = JSON.parse(backupContent);
        this.ensureStructure();
        this.save();
        console.log("[TumpangFood DB] Recovery from backup successful.");
        return;
      }
      if (import_fs4.default.existsSync(LEGACY_DB_FILE)) {
        console.log("[TumpangFood DB] Migrating data from legacy tumpang_db.json...");
        const legacyContent = import_fs4.default.readFileSync(LEGACY_DB_FILE, "utf-8");
        this.data = JSON.parse(legacyContent);
        this.ensureStructure();
        this.migratePasswords();
        this.save();
        this.createBackup();
        console.log("[TumpangFood DB] Migration complete! Saved to tumpang_food_db.json.");
      } else {
        this.seedInitial();
        this.save();
        this.createBackup();
      }
    } catch (err) {
      console.error("[TumpangFood DB] Error during load/migrate, attempting emergency recovery:", err);
      if (import_fs4.default.existsSync(backupPath)) {
        try {
          this.data = JSON.parse(import_fs4.default.readFileSync(backupPath, "utf-8"));
          this.ensureStructure();
          this.save();
          return;
        } catch {
        }
      }
      this.seedInitial();
      this.save();
    }
  }
  migratePasswords() {
    let changed = false;
    for (const m of this.data.merchants) {
      if (!m.password) {
        m.password = hashPassword(m.id + "123");
        changed = true;
      } else if (!m.password.startsWith("pbkdf2$")) {
        m.password = hashPassword(m.password);
        changed = true;
      }
    }
    for (const d of this.data.drivers) {
      if (!d.password) {
        d.password = hashPassword(d.id + "123");
        changed = true;
      } else if (!d.password.startsWith("pbkdf2$")) {
        d.password = hashPassword(d.password);
        changed = true;
      }
    }
    if (changed) this.save();
  }
  migrateOrdersDeliveryFee() {
    let changed = false;
    if (!Array.isArray(this.data.orders)) return;
    for (const order of this.data.orders) {
      if (!order) continue;
      const inTumpang = isDestinationInKecamatanTumpang({
        address: order.deliveryAddress,
        details: order.deliveryDetails,
        landmark: order.landmark,
        latitude: order.latitude,
        longitude: order.longitude
      });
      if (inTumpang) {
        if (order.deliveryFee !== FLAT_TUMPANG_DELIVERY_FEE) {
          console.log(`[TumpangFood DB Migration] Updating order #${order.id} delivery fee from ${order.deliveryFee} to flat ${FLAT_TUMPANG_DELIVERY_FEE}`);
          order.deliveryFee = FLAT_TUMPANG_DELIVERY_FEE;
          order.total = order.subtotal + FLAT_TUMPANG_DELIVERY_FEE + order.serviceFee + (order.uniqueCode || 0);
          changed = true;
        }
      }
    }
    if (changed) {
      this.save();
      console.log("[TumpangFood DB Migration] Successfully migrated orders to flat Rp 5.000 for Kecamatan Tumpang.");
    }
  }
  ensureStructure() {
    if (!this.data.merchants) this.data.merchants = [];
    if (!this.data.categories) this.data.categories = [];
    if (!this.data.menuItems) this.data.menuItems = [];
    if (!this.data.orders) this.data.orders = [];
    if (!this.data.drivers) this.data.drivers = [];
    if (!this.data.settlements) this.data.settlements = [];
    if (!this.data.partnerRegistrations) this.data.partnerRegistrations = [];
    if (!this.data.testimonials) this.data.testimonials = [];
    if (!this.data.systemConfig) {
      this.data.systemConfig = initialConfig;
    } else if (!this.data.systemConfig.qrisImage || this.data.systemConfig.qrisImage.includes("unsplash")) {
      this.data.systemConfig.qrisImage = "/qris-merchant.png";
    }
    this.data.merchants.forEach((m) => {
      if (!m.qrisImage || m.qrisImage.includes("unsplash")) {
        m.qrisImage = "/qris-merchant.png";
      }
    });
    this.bootstrapMasterAccount();
    if (this.data.merchants.length === 0) {
      this.seedInitial();
    }
  }
  seedInitial() {
    this.data.systemConfig = initialConfig;
    const now = (/* @__PURE__ */ new Date()).toISOString();
    this.data.merchants = [
      {
        id: "m1",
        name: "Warung Bakso & Mie Ayam Barokah",
        ownerName: "Pak Slamet",
        phone: "081234567891",
        address: "Jl. Raya Tumpang No. 45, Kec. Tumpang, Malang",
        latitude: -7.9984,
        longitude: 112.7663,
        openTime: "09:00",
        closeTime: "21:00",
        bankName: "BRI",
        bankAccount: "1234567890",
        bankHolder: "Pak Slamet",
        active: true,
        rating: 4.8,
        cookTimeEstimate: "15-25 min",
        image: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=500&auto=format&fit=crop&q=60",
        description: "Bakso urat sapi asli, mie ayam ceker spesial khas Tumpang.",
        category: "Makanan Berat",
        email: "m1@tumpanggo.com",
        qrisImage: "/qris-merchant.png",
        createdAt: now,
        updatedAt: now,
        isActivated: true,
        password: hashPassword("m1123")
      },
      {
        id: "m2",
        name: "Ayam Geprek Sambal Korek Tumpang",
        ownerName: "Bu Siti Aminah",
        phone: "081234567892",
        address: "Jl. Pahlawan No. 12, Kec. Tumpang, Malang",
        latitude: -8.0012,
        longitude: 112.7681,
        openTime: "10:00",
        closeTime: "22:00",
        bankName: "BCA",
        bankAccount: "0987654321",
        bankHolder: "Bu Siti Aminah",
        active: true,
        rating: 4.7,
        cookTimeEstimate: "15-20 min",
        image: "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=500&auto=format&fit=crop&q=60",
        description: "Ayam goreng renyah krispi dengan kepedasan sambal korek khas Tumpang.",
        category: "Aneka Ayam",
        email: "m2@tumpanggo.com",
        qrisImage: "/qris-merchant.png",
        createdAt: now,
        updatedAt: now,
        isActivated: true,
        password: hashPassword("m2123")
      }
    ];
    this.data.categories = [
      { id: "cat_m1_1", merchantId: "m1", name: "Menu Utama", orderIndex: 1 },
      { id: "cat_m1_2", merchantId: "m1", name: "Minuman Segar", orderIndex: 2 },
      { id: "cat_m2_1", merchantId: "m2", name: "Paket Geprek", orderIndex: 1 }
    ];
    this.data.menuItems = [
      {
        id: "menu_1",
        merchantId: "m1",
        categoryId: "cat_m1_1",
        name: "Bakso Spesial Tumpang",
        description: "Bakso daging sapi asli dengan kuah kaldu gurih khas Tumpang",
        price: 15e3,
        available: true,
        image: "https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=400&auto=format&fit=crop&q=60",
        createdAt: now,
        updatedAt: now
      },
      {
        id: "menu_2",
        merchantId: "m1",
        categoryId: "cat_m1_1",
        name: "Mie Ayam Ceker Bakso",
        description: "Mie kenyal dengan potongan ayam berbumbu manis gurih dan ceker empuk",
        price: 13e3,
        available: true,
        image: "https://images.unsplash.com/photo-1612927601601-6638404737ce?w=400&auto=format&fit=crop&q=60",
        createdAt: now,
        updatedAt: now
      },
      {
        id: "menu_3",
        merchantId: "m1",
        categoryId: "cat_m1_2",
        name: "Es Jeruk Manis Segar",
        description: "Perasan jeruk peras asli dingin menyegarkan",
        price: 5e3,
        available: true,
        image: "https://images.unsplash.com/photo-1613478223719-2ab802602423?w=400&auto=format&fit=crop&q=60",
        createdAt: now,
        updatedAt: now
      },
      {
        id: "menu_4",
        merchantId: "m2",
        categoryId: "cat_m2_1",
        name: "Paket Ayam Geprek Sambal Bawang + Nasi",
        description: "Ayam geprek pedas gurih lengkap dengan nasi hangat dan lalapan",
        price: 18e3,
        available: true,
        image: "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=400&auto=format&fit=crop&q=60",
        createdAt: now,
        updatedAt: now
      }
    ];
    this.data.drivers = [
      {
        id: "d1",
        name: "Budi Santoso",
        phone: "081234567893",
        email: "driver1@tumpanggo.com",
        active: true,
        online: true,
        latitude: -7.982,
        longitude: 112.631,
        createdAt: now,
        updatedAt: now
      },
      {
        id: "d2",
        name: "Agus Pratama",
        phone: "081234567894",
        email: "driver2@tumpanggo.com",
        active: true,
        online: true,
        latitude: -7.985,
        longitude: 112.635,
        createdAt: now,
        updatedAt: now
      }
    ];
    for (const d of this.data.drivers) {
      d.password = hashPassword(d.id + "123");
    }
  }
  save() {
    try {
      const dir = import_path4.default.dirname(FOOD_DB_FILE);
      if (!import_fs4.default.existsSync(dir)) {
        import_fs4.default.mkdirSync(dir, { recursive: true });
      }
      import_fs4.default.writeFileSync(FOOD_DB_FILE, JSON.stringify(this.data, null, 2), "utf-8");
      try {
        this.lastFileMtime = import_fs4.default.statSync(FOOD_DB_FILE).mtimeMs;
      } catch {
      }
    } catch (e) {
      if (e.code === "EROFS") {
        console.warn("[TumpangFood DB] Read-only filesystem detected. Disk write skipped; persisting in-memory and Firestore.");
      } else {
        console.error("[TumpangFood DB] Failed to save database file:", e);
      }
    }
  }
  async ensureInitialized(forceRefresh = false) {
    if (this.isInitialized && !forceRefresh && Date.now() - this.lastSyncTimestamp < this.CACHE_TTL_MS) {
      return;
    }
    if (!this.initPromise || forceRefresh) {
      this.initPromise = this.init();
    }
    try {
      await this.initPromise;
      this.lastSyncTimestamp = Date.now();
    } catch (err) {
      this.initPromise = null;
      this.isInitialized = false;
      throw err;
    }
  }
  /**
   * Diagnostic assessment of runtime storage status: Cloud Firestore vs Local Resilient Snapshot.
   */
  async getStorageStatus() {
    const firestoreCheck = await testFirestoreConnection();
    return {
      storageMode: firestoreCheck.connected ? "cloud_firestore_active" : "local_resilient_snapshot",
      databaseId: firestoreCheck.databaseId,
      projectId: firestoreCheck.projectId,
      isProduction: foodConfig.isProduction,
      firestoreConfigured: isFirestoreAdminConfigured(),
      usingServiceAccount: firestoreCheck.usingServiceAccount,
      authIdentity: firestoreCheck.authIdentity,
      liveCloudConnected: firestoreCheck.connected,
      canRead: firestoreCheck.canRead,
      canWrite: firestoreCheck.canWrite,
      diagnosticReason: firestoreCheck.diagnosticReason,
      diagnosticDetail: firestoreCheck.diagnosticDetail,
      remediationStep: firestoreCheck.remediationStep,
      cloudError: firestoreCheck.error
    };
  }
  /**
   * Synchronize state with Firebase Firestore as Primary Storage.
   */
  async init() {
    if (!isUsingServiceAccount() || !getAdminDb()) {
      const diag = getFirestoreDiagnosticStatus();
      console.warn(`[TumpangFood DB] Firestore Admin SDK tidak terkonfigurasi (${diag.reason}), beroperasi dengan penyimpanan lokal.`);
      this.isInitialized = true;
      return;
    }
    const probe = await testFirestoreConnection();
    if (!probe.connected) {
      console.warn(`[TumpangFood DB] Firestore Cloud belum terhubung (${probe.diagnosticReason}: ${probe.error || probe.diagnosticDetail}). Beroperasi dengan penyimpanan lokal.`);
      this.isInitialized = true;
      return;
    }
    this.isInitialized = true;
    try {
      console.log("[TumpangFood DB] Syncing with Firestore database via Admin SDK:", foodConfig.databaseId);
      try {
        const remoteConfig = await safeAdminGetDoc("systemConfig", "config_1");
        if (remoteConfig) {
          this.data.systemConfig = { ...initialConfig, ...remoteConfig };
          this.bootstrapMasterAccount();
        } else {
          await safeAdminSetDoc("systemConfig", "config_1", this.data.systemConfig);
        }
      } catch (e) {
        console.warn("[TumpangFood DB] Failed to sync systemConfig with Firestore:", e.message);
      }
      try {
        const remoteMerchants = await safeAdminGetDocs("merchants");
        if (remoteMerchants.length > 0) {
          this.data.merchants = remoteMerchants;
          this.ensureStructure();
        } else if (this.data.merchants.length > 0) {
          for (const m of this.data.merchants) {
            await safeAdminSetDoc("merchants", m.id, m);
          }
        }
      } catch (e) {
        console.warn("[TumpangFood DB] Failed to sync merchants with Firestore:", e.message);
      }
      try {
        const remoteCats = await safeAdminGetDocs("categories");
        if (remoteCats.length > 0) {
          this.data.categories = remoteCats;
        } else if (this.data.categories.length > 0) {
          for (const c of this.data.categories) {
            await safeAdminSetDoc("categories", c.id, c);
          }
        }
      } catch (e) {
        console.warn("[TumpangFood DB] Failed to sync categories with Firestore:", e.message);
      }
      try {
        const remoteItems = await safeAdminGetDocs("menuItems");
        if (remoteItems.length > 0) {
          this.data.menuItems = remoteItems;
        } else if (this.data.menuItems.length > 0) {
          for (const i of this.data.menuItems) {
            await safeAdminSetDoc("menuItems", i.id, i);
          }
        }
      } catch (e) {
        console.warn("[TumpangFood DB] Failed to sync menuItems with Firestore:", e.message);
      }
      try {
        const remoteDrivers = await safeAdminGetDocs("drivers");
        if (remoteDrivers.length > 0) {
          this.data.drivers = remoteDrivers;
        } else if (this.data.drivers.length > 0) {
          for (const d of this.data.drivers) {
            await safeAdminSetDoc("drivers", d.id, d);
          }
        }
      } catch (e) {
        console.warn("[TumpangFood DB] Failed to sync drivers with Firestore:", e.message);
      }
      try {
        const remoteOrders = await safeAdminGetDocs("orders");
        if (remoteOrders.length > 0) {
          this.data.orders = remoteOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        } else if (this.data.orders.length > 0) {
          for (const o of this.data.orders) {
            await safeAdminSetDoc("orders", o.id, o);
          }
        }
      } catch (e) {
        console.warn("[TumpangFood DB] Failed to sync orders with Firestore:", e.message);
      }
      try {
        const remoteSets = await safeAdminGetDocs("settlements");
        if (remoteSets.length > 0) {
          this.data.settlements = remoteSets;
        } else if (this.data.settlements.length > 0) {
          for (const s of this.data.settlements) {
            await safeAdminSetDoc("settlements", s.id, s);
          }
        }
      } catch (e) {
        console.warn("[TumpangFood DB] Failed to sync settlements with Firestore:", e.message);
      }
      try {
        const remoteRegs = await safeAdminGetDocs("partnerRegistrations");
        if (remoteRegs.length > 0) {
          this.data.partnerRegistrations = remoteRegs;
        } else if (this.data.partnerRegistrations.length > 0) {
          for (const r of this.data.partnerRegistrations) {
            await safeAdminSetDoc("partnerRegistrations", r.id, r);
          }
        }
      } catch (e) {
        console.warn("[TumpangFood DB] Failed to sync partnerRegistrations with Firestore:", e.message);
      }
      try {
        const remoteTestis = await safeAdminGetDocs("testimonials");
        if (remoteTestis.length > 0) {
          this.data.testimonials = remoteTestis;
        } else if (this.data.testimonials && this.data.testimonials.length > 0) {
          for (const t of this.data.testimonials) {
            await safeAdminSetDoc("testimonials", t.id, t);
          }
        }
      } catch (e) {
        console.warn("[TumpangFood DB] Failed to sync testimonials with Firestore:", e.message);
      }
      try {
        const remoteLogs = await safeAdminGetDocs("auditLogs");
        if (remoteLogs.length > 0) {
          this.data.auditLogs = remoteLogs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 500);
        }
      } catch (e) {
        console.warn("[TumpangFood DB] Failed to sync auditLogs with Firestore:", e.message);
      }
      this.save();
      this.createBackup();
      console.log("[TumpangFood DB] Firestore Admin synchronization successful (Primary Store Active).");
    } catch (err) {
      if (foodConfig.isProduction) {
        this.isInitialized = false;
        throw new Error(`[Produksi] Sinkronisasi data dengan Firestore Cloud gagal: ${err.message}. Operasi database ditolak demi integritas data.`);
      }
      console.error("[TumpangFood DB] Firestore sync failed, continuing locally:", err.message);
    }
  }
  // --- LOGGING ---
  log(userId, details, role = "SYSTEM") {
    const logItem = {
      id: "log_" + Math.random().toString(36).substring(2, 9),
      action: details.split(" ")[0] || "ACTION",
      userId,
      role,
      details,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.data.auditLogs.unshift(logItem);
    if (this.data.auditLogs.length > 250) {
      this.data.auditLogs = this.data.auditLogs.slice(0, 250);
    }
    this.save();
    safeFirestoreSetDoc("auditLogs", logItem.id, logItem);
    return logItem;
  }
  addAuditLog(entry) {
    const userId = entry.performedBy || entry.userId || "SYSTEM";
    const details = entry.details || (entry.action ? `${entry.action}: ${entry.orderId || ""}` : "Audit log");
    const role = entry.role || "SYSTEM";
    return this.log(userId, details, role);
  }
  getLogs() {
    return this.data.auditLogs;
  }
  // --- MASTER ACCOUNT CREDENTIALS ---
  getMasterAccount() {
    try {
      if (import_fs4.default.existsSync(FOOD_DB_FILE)) {
        const stats = import_fs4.default.statSync(FOOD_DB_FILE);
        if (stats.mtimeMs > this.lastFileMtime) {
          const content = import_fs4.default.readFileSync(FOOD_DB_FILE, "utf-8");
          const parsed = JSON.parse(content);
          if (parsed?.systemConfig?.masterAccount) {
            if (!this.data.systemConfig) {
              this.data.systemConfig = { ...initialConfig };
            }
            this.data.systemConfig.masterAccount = parsed.systemConfig.masterAccount;
            this.lastFileMtime = stats.mtimeMs;
          }
        }
      }
    } catch {
    }
    return this.data.systemConfig?.masterAccount;
  }
  bootstrapMasterAccount() {
    if (!this.data.systemConfig) {
      this.data.systemConfig = { ...initialConfig };
    }
    const creds = getMasterAccountCredentials();
    const currentMaster = this.data.systemConfig.masterAccount;
    if (currentMaster?.passwordHash && currentMaster.passwordHash.startsWith("pbkdf2$")) {
      if (creds.hasExplicitEnv && creds.password && !verifyPassword(creds.password, currentMaster.passwordHash).valid) {
        this.data.systemConfig.masterAccount = {
          email: creds.email,
          passwordHash: hashPassword(creds.password),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        this.save();
        console.log(`[TumpangFood DB] Master Account PBKDF2 hash synchronized from explicit environment variable (${creds.email}).`);
      }
      return;
    }
    const initialPass = creds.password || (foodConfig.isProduction ? "" : "TumpangGoAdmin#2026");
    if (initialPass) {
      this.data.systemConfig.masterAccount = {
        email: creds.email || "tumpanggo@gmail.com",
        passwordHash: hashPassword(initialPass),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      this.save();
      console.log(`[TumpangFood DB] Master Account PBKDF2 hash initialized for ${creds.email || "tumpanggo@gmail.com"}.`);
    }
  }
  updateMasterAccountPassword(newPlaintext) {
    if (!this.data.systemConfig) {
      this.data.systemConfig = { ...initialConfig };
    }
    const { email } = getMasterAccountCredentials();
    const cleanPlaintext = newPlaintext.trim();
    const hashed = hashPassword(cleanPlaintext);
    this.data.systemConfig.masterAccount = {
      email,
      passwordHash: hashed,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.save();
    try {
      safeFirestoreSetDoc("systemConfig", "config_1", this.data.systemConfig).catch(() => {
      });
    } catch {
    }
    return true;
  }
  updateMasterAccountWithHash(email, passwordHash) {
    if (!this.data.systemConfig) {
      this.data.systemConfig = { ...initialConfig };
    }
    this.data.systemConfig.masterAccount = {
      email: email.trim().toLowerCase(),
      passwordHash,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.save();
    try {
      safeFirestoreSetDoc("systemConfig", "config_1", this.data.systemConfig).catch(() => {
      });
    } catch {
    }
    return true;
  }
  // --- CONFIG ---
  getConfig() {
    return this.data.systemConfig;
  }
  async updateConfig(userId, updates) {
    const prevConfig = { ...this.data.systemConfig };
    this.data.systemConfig = { ...this.data.systemConfig, ...updates };
    this.save();
    this.log(userId, `Updated system configuration`, "ADMIN");
    if (foodConfig.isProduction) {
      const persisted = await safeFirestoreSetDoc("systemConfig", "config_1", this.data.systemConfig);
      if (!persisted) {
        this.data.systemConfig = prevConfig;
        this.save();
        throw new Error("[Produksi] Gagal menyimpan konfigurasi sistem ke cloud Firestore. Perubahan dibatalkan demi integritas data.");
      }
    } else {
      safeFirestoreSetDoc("systemConfig", "config_1", this.data.systemConfig);
    }
    return this.data.systemConfig;
  }
  // --- MERCHANTS ---
  getMerchants() {
    if (!this.data || !Array.isArray(this.data.merchants)) {
      return [];
    }
    return this.data.merchants.filter((m) => Boolean(m && typeof m === "object")).map((m) => {
      const { password, ...safe } = m;
      if (!safe.qrisImage || safe.qrisImage.includes("unsplash")) {
        safe.qrisImage = this.data.systemConfig?.qrisImage || "/qris-merchant.png";
      }
      return {
        ...safe,
        id: safe.id || "m_unknown"
      };
    });
  }
  getMerchantById(id) {
    if (!this.data || !Array.isArray(this.data.merchants) || !id) return void 0;
    const m = this.data.merchants.find((m2) => m2 && m2.id === id);
    if (!m) return void 0;
    const { password, ...safe } = m;
    if (!safe.qrisImage || safe.qrisImage.includes("unsplash")) {
      safe.qrisImage = this.data.systemConfig?.qrisImage || "/qris-merchant.png";
    }
    return safe;
  }
  getMerchantByEmailOrPhone(identifier) {
    if (!identifier || !this.data || !Array.isArray(this.data.merchants)) return void 0;
    const clean = identifier.trim().toLowerCase();
    const rawClean = identifier.trim();
    const cleanNumbers = identifier.replace(/[^0-9]/g, "");
    const altPhone = cleanNumbers.startsWith("62") ? "0" + cleanNumbers.slice(2) : cleanNumbers.startsWith("0") ? "62" + cleanNumbers.slice(1) : "";
    return this.data.merchants.find((m) => {
      if (!m) return false;
      const mId = typeof m.id === "string" ? m.id.toLowerCase() : "";
      const mEmail = typeof m.email === "string" ? m.email.trim().toLowerCase() : "";
      const mPhone = typeof m.phone === "string" ? m.phone.trim() : "";
      const mPhoneNumbers = mPhone.replace(/[^0-9]/g, "");
      const matchId = Boolean(mId && mId === clean);
      const matchEmail = Boolean(mEmail && mEmail === clean);
      const matchPhone = Boolean(mPhone && (mPhone === rawClean || mPhone.toLowerCase() === clean));
      const matchCleanPhone = Boolean(cleanNumbers.length >= 8 && mPhoneNumbers && (mPhoneNumbers === cleanNumbers || altPhone && mPhoneNumbers === altPhone));
      return matchId || matchEmail || matchPhone || matchCleanPhone;
    });
  }
  async createMerchant(userId, merchantData) {
    const newMerchant = {
      ...merchantData,
      id: "m_" + Math.random().toString(36).substring(2, 9),
      qrisImage: merchantData.qrisImage || this.data.systemConfig?.qrisImage || "/qris-merchant.png",
      rating: 5,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (newMerchant.password && !newMerchant.password.startsWith("pbkdf2$")) {
      newMerchant.password = hashPassword(newMerchant.password);
    }
    if (isFirestoreAdminConfigured()) {
      const persisted = await safeFirestoreSetDoc("merchants", newMerchant.id, newMerchant);
      if (!persisted && foodConfig.isProduction) {
        throw new Error("[Produksi] Gagal menyimpan merchant ke cloud Firestore. Transaksi dibatalkan demi menjaga integritas data.");
      }
    } else {
      safeFirestoreSetDoc("merchants", newMerchant.id, newMerchant);
    }
    this.data.merchants.push(newMerchant);
    this.save();
    this.log(userId, `Created merchant ${newMerchant.name}`, "ADMIN");
    return newMerchant;
  }
  async updateMerchant(userId, id, updates, role = "MERCHANT") {
    const index = this.data.merchants.findIndex((m) => m.id === id);
    if (index === -1) throw new Error("Merchant not found");
    const prevMerchant = { ...this.data.merchants[index] };
    const updatedData = { ...updates };
    if (updatedData.password && !updatedData.password.startsWith("pbkdf2$")) {
      updatedData.password = hashPassword(updatedData.password);
    }
    if (updatedData.qrisImage !== void 0) {
      updatedData.qrisUpdatedAt = (/* @__PURE__ */ new Date()).toISOString();
    }
    const nextMerchant = {
      ...this.data.merchants[index],
      ...updatedData,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (isFirestoreAdminConfigured()) {
      const persisted = await safeFirestoreSetDoc("merchants", id, nextMerchant);
      if (!persisted && foodConfig.isProduction) {
        throw new Error("[Produksi] Gagal memperbarui merchant pada cloud Firestore. Perubahan dibatalkan demi integritas data.");
      }
    } else {
      safeFirestoreSetDoc("merchants", id, nextMerchant);
    }
    this.data.merchants[index] = nextMerchant;
    this.save();
    this.log(userId, `Updated merchant ${this.data.merchants[index].name}`, role);
    return this.data.merchants[index];
  }
  async deleteMerchant(userId, id) {
    const index = this.data.merchants.findIndex((m) => m.id === id);
    if (index === -1) return false;
    if (foodConfig.isProduction) {
      const deleted = await safeAdminDeleteDoc("merchants", id);
      if (!deleted) {
        throw new Error("[Produksi] Gagal menghapus merchant pada cloud Firestore. Operasi dibatalkan demi integritas data.");
      }
    } else {
      safeAdminDeleteDoc("merchants", id);
    }
    const name = this.data.merchants[index].name;
    this.data.merchants.splice(index, 1);
    this.data.categories = this.data.categories.filter((c) => c.merchantId !== id);
    this.data.menuItems = this.data.menuItems.filter((i) => i.merchantId !== id);
    this.save();
    this.log(userId, `Deleted merchant ${name}`, "ADMIN");
    return true;
  }
  async activateMerchant(email, passwordPlain) {
    const cleanEmail = email.trim().toLowerCase();
    const merchant = this.data.merchants.find((m) => m.email?.trim().toLowerCase() === cleanEmail);
    if (!merchant) {
      return { success: false, error: "Merchant dengan email tersebut tidak ditemukan." };
    }
    const prevMerchant = { ...merchant };
    merchant.active = true;
    merchant.isActivated = true;
    merchant.password = hashPassword(passwordPlain);
    merchant.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    if (foodConfig.isProduction) {
      const persisted = await safeFirestoreSetDoc("merchants", merchant.id, merchant);
      if (!persisted) {
        Object.assign(merchant, prevMerchant);
        throw new Error("[Produksi] Gagal mengaktifkan merchant pada cloud Firestore. Operasi dibatalkan.");
      }
    } else {
      safeFirestoreSetDoc("merchants", merchant.id, merchant);
    }
    if (this.data.partnerRegistrations) {
      const reg = this.data.partnerRegistrations.find((r) => r.email?.trim().toLowerCase() === cleanEmail && r.type === "MERCHANT");
      if (reg) {
        reg.status = "ACTIVATED";
        safeFirestoreSetDoc("partnerRegistrations", reg.id, reg);
      }
    }
    this.save();
    this.log(merchant.id, `Activated merchant store ${merchant.name}`, "MERCHANT");
    return { success: true, merchant };
  }
  // --- CATEGORIES ---
  getCategories(merchantId) {
    return this.data.categories.filter((c) => c.merchantId === merchantId).sort((a, b) => (a.orderIndex || 0) - (b.orderIndex || 0));
  }
  async createCategory(merchantId, name) {
    const existing = this.getCategories(merchantId);
    const orderIndex = existing.length > 0 ? Math.max(...existing.map((e) => e.orderIndex)) + 1 : 1;
    const newCat = {
      id: "cat_" + Math.random().toString(36).substring(2, 9),
      merchantId,
      name: name.trim(),
      orderIndex
    };
    if (isFirestoreAdminConfigured()) {
      const persisted = await safeFirestoreSetDoc("categories", newCat.id, newCat);
      if (!persisted && foodConfig.isProduction) {
        throw new Error("[Produksi] Gagal menyimpan kategori menu ke cloud Firestore. Operasi dibatalkan.");
      }
    } else {
      safeFirestoreSetDoc("categories", newCat.id, newCat);
    }
    this.data.categories.push(newCat);
    this.save();
    this.log(merchantId, `Created category ${name}`, "MERCHANT");
    return newCat;
  }
  async updateCategory(merchantId, id, name) {
    const cat = this.data.categories.find((c) => c.id === id && c.merchantId === merchantId);
    if (!cat) throw new Error("Category not found");
    const prevName = cat.name;
    cat.name = name.trim();
    if (isFirestoreAdminConfigured()) {
      const persisted = await safeFirestoreSetDoc("categories", id, cat);
      if (!persisted && foodConfig.isProduction) {
        cat.name = prevName;
        throw new Error("[Produksi] Gagal memperbarui kategori menu di cloud Firestore. Operasi dibatalkan.");
      }
    } else {
      safeFirestoreSetDoc("categories", id, cat);
    }
    this.save();
    return cat;
  }
  async deleteCategory(merchantId, id) {
    const index = this.data.categories.findIndex((c) => c.id === id && c.merchantId === merchantId);
    if (index === -1) return false;
    if (isFirestoreAdminConfigured()) {
      const deleted = await safeAdminDeleteDoc("categories", id);
      if (!deleted && foodConfig.isProduction) {
        throw new Error("[Produksi] Gagal menghapus kategori menu pada cloud Firestore. Operasi dibatalkan.");
      }
    } else {
      safeAdminDeleteDoc("categories", id);
    }
    this.data.categories.splice(index, 1);
    this.data.menuItems = this.data.menuItems.filter((i) => i.categoryId !== id);
    this.save();
    return true;
  }
  // --- MENU ITEMS ---
  getMenuItemsByMerchant(merchantId) {
    return this.data.menuItems.filter((i) => i.merchantId === merchantId);
  }
  getMenuItemById(id) {
    return this.data.menuItems.find((i) => i.id === id);
  }
  async createMenuItem(merchantId, itemData) {
    const newItem = {
      ...itemData,
      id: "item_" + Math.random().toString(36).substring(2, 9),
      merchantId,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (isFirestoreAdminConfigured()) {
      const persisted = await safeFirestoreSetDoc("menuItems", newItem.id, newItem);
      if (!persisted && foodConfig.isProduction) {
        throw new Error("[Produksi] Gagal menyimpan item menu ke cloud Firestore. Operasi dibatalkan.");
      }
    } else {
      safeFirestoreSetDoc("menuItems", newItem.id, newItem);
    }
    this.data.menuItems.push(newItem);
    this.save();
    this.log(merchantId, `Created menu item ${newItem.name}`, "MERCHANT");
    return newItem;
  }
  async updateMenuItem(merchantId, id, updates) {
    const index = this.data.menuItems.findIndex((i) => i.id === id && i.merchantId === merchantId);
    if (index === -1) throw new Error("Menu item not found");
    const prevItem = { ...this.data.menuItems[index] };
    const nextItem = {
      ...this.data.menuItems[index],
      ...updates,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (isFirestoreAdminConfigured()) {
      const persisted = await safeFirestoreSetDoc("menuItems", id, nextItem);
      if (!persisted && foodConfig.isProduction) {
        throw new Error("[Produksi] Gagal memperbarui item menu pada cloud Firestore. Operasi dibatalkan.");
      }
    } else {
      safeFirestoreSetDoc("menuItems", id, nextItem);
    }
    this.data.menuItems[index] = nextItem;
    this.save();
    this.log(merchantId, `Updated menu item ${this.data.menuItems[index].name}`, "MERCHANT");
    return this.data.menuItems[index];
  }
  async deleteMenuItem(merchantId, id) {
    const index = this.data.menuItems.findIndex((i) => i.id === id && i.merchantId === merchantId);
    if (index === -1) return false;
    if (isFirestoreAdminConfigured()) {
      const deleted = await safeAdminDeleteDoc("menuItems", id);
      if (!deleted && foodConfig.isProduction) {
        throw new Error("[Produksi] Gagal menghapus item menu pada cloud Firestore. Operasi dibatalkan.");
      }
    } else {
      safeAdminDeleteDoc("menuItems", id);
    }
    const name = this.data.menuItems[index].name;
    this.data.menuItems.splice(index, 1);
    this.save();
    this.log(merchantId, `Deleted menu item ${name}`, "MERCHANT");
    return true;
  }
  // --- DRIVERS ---
  getDrivers() {
    return this.data.drivers.map((d) => {
      const { password, ...safe } = d;
      return safe;
    });
  }
  getDriverById(id) {
    const d = this.data.drivers.find((d2) => d2.id === id);
    if (!d) return void 0;
    const { password, ...safe } = d;
    return safe;
  }
  getDriverByEmailOrPhone(identifier) {
    if (!identifier || !this.data || !Array.isArray(this.data.drivers)) return void 0;
    const clean = identifier.trim().toLowerCase();
    const rawClean = identifier.trim();
    const cleanPhone = identifier.replace(/[^0-9]/g, "");
    const altPhone = cleanPhone.startsWith("62") ? "0" + cleanPhone.slice(2) : cleanPhone.startsWith("0") ? "62" + cleanPhone.slice(1) : "";
    return this.data.drivers.find((d) => {
      if (!d) return false;
      const dId = typeof d.id === "string" ? d.id.toLowerCase() : "";
      const dEmail = typeof d.email === "string" ? d.email.trim().toLowerCase() : "";
      const dPhone = typeof d.phone === "string" ? d.phone.trim() : "";
      const dPhoneNumbers = dPhone.replace(/[^0-9]/g, "");
      const matchId = Boolean(dId && dId === clean);
      const matchEmail = Boolean(dEmail && dEmail === clean);
      const matchPhoneExact = Boolean(dPhone && (dPhone === rawClean || dPhone.toLowerCase() === clean));
      const matchCleanPhone = Boolean(cleanPhone.length >= 8 && dPhoneNumbers && (dPhoneNumbers === cleanPhone || altPhone && dPhoneNumbers === altPhone));
      return matchId || matchEmail || matchPhoneExact || matchCleanPhone;
    });
  }
  async createDriver(userId, driverData) {
    const newDriver = {
      ...driverData,
      id: "d_" + Math.random().toString(36).substring(2, 9),
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (isFirestoreAdminConfigured()) {
      const persisted = await safeFirestoreSetDoc("drivers", newDriver.id, newDriver);
      if (!persisted && foodConfig.isProduction) {
        throw new Error("[Produksi] Gagal menyimpan driver ke cloud Firestore. Transaksi dibatalkan.");
      }
    } else {
      safeFirestoreSetDoc("drivers", newDriver.id, newDriver);
    }
    this.data.drivers.push(newDriver);
    this.save();
    this.log(userId, `Created driver ${newDriver.name}`, "ADMIN");
    return newDriver;
  }
  async updateDriver(userId, id, updates, role = "DRIVER") {
    const index = this.data.drivers.findIndex((d) => d.id === id);
    if (index === -1) throw new Error("Driver not found");
    const prevDriver = { ...this.data.drivers[index] };
    const nextDriver = {
      ...this.data.drivers[index],
      ...updates,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (isFirestoreAdminConfigured()) {
      const persisted = await safeFirestoreSetDoc("drivers", id, nextDriver);
      if (!persisted && foodConfig.isProduction) {
        throw new Error("[Produksi] Gagal memperbarui driver pada cloud Firestore. Perubahan dibatalkan.");
      }
    } else {
      safeFirestoreSetDoc("drivers", id, nextDriver);
    }
    this.data.drivers[index] = nextDriver;
    this.save();
    this.log(userId, `Updated driver ${this.data.drivers[index].name}`, role);
    return this.data.drivers[index];
  }
  async deleteDriver(userId, id) {
    const index = this.data.drivers.findIndex((d) => d.id === id);
    if (index === -1) return false;
    if (isFirestoreAdminConfigured()) {
      const deleted = await safeAdminDeleteDoc("drivers", id);
      if (!deleted && foodConfig.isProduction) {
        throw new Error("[Produksi] Gagal menghapus driver pada cloud Firestore. Operasi dibatalkan.");
      }
    } else {
      safeAdminDeleteDoc("drivers", id);
    }
    const name = this.data.drivers[index].name;
    this.data.drivers.splice(index, 1);
    this.save();
    this.log(userId, `Deleted driver ${name}`, "ADMIN");
    return true;
  }
  // --- ORDERS ---
  getOrders() {
    return this.data.orders.map((o) => normalizeOrderDeliveryFee(o));
  }
  getOrderById(id) {
    const o = this.data.orders.find((o2) => o2.id === id);
    return o ? normalizeOrderDeliveryFee(o) : void 0;
  }
  getOrdersByMerchant(merchantId) {
    return this.data.orders.filter((o) => o.merchantId === merchantId).map((o) => normalizeOrderDeliveryFee(o));
  }
  getOrdersByDriver(driverId) {
    return this.data.orders.filter((o) => o.driverId === driverId).map((o) => normalizeOrderDeliveryFee(o));
  }
  getOrdersByCustomerPhone(phone) {
    return this.data.orders.filter((o) => o.customerPhone === phone).map((o) => normalizeOrderDeliveryFee(o));
  }
  async findOrder(id) {
    if (!id) return void 0;
    const cleanId = id.trim();
    let order = this.data.orders.find((o) => o.id === cleanId);
    if (!order && isFirestoreAdminConfigured()) {
      try {
        const remote = await safeAdminGetDoc("orders", cleanId);
        if (remote) {
          order = remote;
          const idx = this.data.orders.findIndex((o) => o.id === cleanId);
          if (idx >= 0) this.data.orders[idx] = order;
          else this.data.orders.unshift(order);
        }
      } catch (e) {
        console.warn(`[TumpangFood DB] Query remote order ${cleanId} failed:`, e.message);
      }
    }
    if (order && (!order.merchantQrisImage || order.merchantQrisImage.includes("unsplash"))) {
      const merchant = this.getMerchantById(order.merchantId);
      if (merchant?.qrisImage) {
        order.merchantQrisImage = merchant.qrisImage;
      }
    }
    if (order && (order.paymentStatus === "PAID" /* PAID */ || ["PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */, "COOKING" /* COOKING */, "READY_FOR_PICKUP" /* READY_FOR_PICKUP */, "ORDER_PICKED_UP" /* ORDER_PICKED_UP */, "DELIVERED" /* DELIVERED */, "COMPLETED" /* COMPLETED */].includes(order.status)) && !order.receipt) {
      const receiptNumber = order.receiptNumber || `TG-RCP-${order.id.replace(/^ord_/, "").toUpperCase()}`;
      const issuedAt = order.paymentVerifiedAt || order.updatedAt || order.createdAt;
      order.receiptNumber = receiptNumber;
      order.receipt = {
        receiptNumber,
        orderId: order.id,
        issuedAt,
        confirmedBy: order.paymentVerifiedBy || "Admin TumpangGo",
        paymentMethod: order.paymentMethod || "MERCHANT_QRIS",
        transactionRef: order.artopayPaymentId || `QRIS-TG-${order.id.replace(/^ord_/, "").toUpperCase()}`,
        subtotal: order.subtotal,
        deliveryFee: order.deliveryFee,
        serviceFee: order.serviceFee,
        uniqueCode: order.uniqueCode || 0,
        total: order.total,
        customerName: order.customerName,
        merchantName: order.merchantName,
        status: "PAID"
      };
    }
    return order ? normalizeOrderDeliveryFee(order) : void 0;
  }
  async createOrder(rawInput) {
    const merchant = this.getMerchantById(rawInput.merchantId);
    if (!merchant) throw new Error("Toko / Merchant tidak ditemukan.");
    if (rawInput.clientRequestId && String(rawInput.clientRequestId).trim().length > 0) {
      const cleanReqId = String(rawInput.clientRequestId).trim();
      const existingReq = this.data.orders.find((o) => o.clientRequestId === cleanReqId);
      if (existingReq) {
        return existingReq;
      }
    }
    const recentDuplicate = this.data.orders.find(
      (o) => o.merchantId === rawInput.merchantId && o.customerPhone === rawInput.customerPhone && Date.now() - new Date(o.createdAt).getTime() < 1e4 && o.status === "WAITING_PAYMENT" /* WAITING_PAYMENT */
    );
    if (recentDuplicate) {
      return recentDuplicate;
    }
    const activeUniqueCodes = this.data.orders.filter((o) => o.status === "WAITING_PAYMENT" /* WAITING_PAYMENT */ || o.status === "WAITING_PAYMENT_VERIFICATION" /* WAITING_PAYMENT_VERIFICATION */).map((o) => o.uniqueCode);
    const validatedOrderData = OrderService.validateAndBuildOrder(
      rawInput,
      merchant,
      this.data.menuItems,
      this.data.systemConfig,
      activeUniqueCodes
    );
    const newOrder = normalizeOrderDeliveryFee({
      ...validatedOrderData,
      id: "ord_" + Math.random().toString(36).substring(2, 9),
      clientRequestId: rawInput.clientRequestId ? String(rawInput.clientRequestId).trim() : void 0,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    this.data.orders.unshift(newOrder);
    this.save();
    this.log("CUSTOMER", `Created order ${newOrder.id} Total: Rp ${newOrder.total.toLocaleString()} (UniqueCode: ${newOrder.uniqueCode})`, "CUSTOMER");
    if (isFirestoreAdminConfigured()) {
      const probe = await testFirestoreConnection();
      if (probe.connected) {
        const persisted = await safeFirestoreSetDoc("orders", newOrder.id, newOrder);
        if (!persisted) {
          this.data.orders.shift();
          this.save();
          throw new Error("Gagal menyimpan pesanan ke cloud Firestore. Transaksi dibatalkan secara aman demi mencegah kehilangan data atau transaksi ganda.");
        }
      } else if (foodConfig.isProduction) {
        this.data.orders.shift();
        this.save();
        throw new Error(`Koneksi cloud Firestore tidak terhubung (${probe.diagnosticReason}: ${probe.error || probe.diagnosticDetail}). Transaksi dibatalkan secara aman.`);
      }
    } else {
      console.warn("[TumpangFood DB] Variabel FIREBASE_SERVICE_ACCOUNT_KEY belum dikonfigurasi di Environment Variables Vercel. Pesanan disimpan pada penyimpanan lokal resilien.");
    }
    return newOrder;
  }
  async updateOrder(userId, id, updates, role = "SYSTEM") {
    const index = this.data.orders.findIndex((o) => o.id === id);
    if (index === -1) throw new Error("Order not found");
    const currentOrder = this.data.orders[index];
    const prevStatus = currentOrder.status;
    if (updates.status && updates.status !== prevStatus) {
      const check = OrderService.isValidStatusTransition(prevStatus, updates.status, role);
      if (!check.allowed) {
        throw new Error(check.reason || "Perubahan status pesanan tidak diizinkan.");
      }
    }
    if (role !== "ADMIN" && role !== "MASTER_ADMIN" && role !== "SYSTEM") {
      delete updates.subtotal;
      delete updates.deliveryFee;
      delete updates.serviceFee;
      delete updates.total;
      delete updates.uniqueCode;
    }
    if (updates.paymentProof && (!updates.paymentStatus || updates.paymentStatus === "WAITING_VERIFICATION" /* WAITING_VERIFICATION */)) {
      updates.paymentStatus = "WAITING_VERIFICATION" /* WAITING_VERIFICATION */;
      updates.status = "WAITING_PAYMENT_VERIFICATION" /* WAITING_PAYMENT_VERIFICATION */;
      updates.paymentProofUploadedAt = updates.paymentProofUploadedAt || (/* @__PURE__ */ new Date()).toISOString();
      updates.paymentRejectionReason = void 0;
    }
    if (updates.status === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */ || updates.paymentStatus === "PAID" /* PAID */) {
      updates.paymentStatus = "PAID" /* PAID */;
      updates.status = "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */;
      updates.paymentVerifiedAt = updates.paymentVerifiedAt || (/* @__PURE__ */ new Date()).toISOString();
      if ((role === "ADMIN" || role === "MASTER_ADMIN" || role === "SYSTEM") && userId) {
        updates.paymentVerifiedBy = userId;
      }
    }
    if (updates.status === "PAYMENT_REJECTED" /* PAYMENT_REJECTED */ || updates.paymentStatus === "REJECTED" /* REJECTED */) {
      updates.paymentStatus = "REJECTED" /* REJECTED */;
      updates.status = "PAYMENT_REJECTED" /* PAYMENT_REJECTED */;
      if ((role === "ADMIN" || role === "MASTER_ADMIN" || role === "SYSTEM") && userId) {
        updates.paymentVerifiedBy = userId;
      }
    }
    if (updates.status === "EXPIRED" /* EXPIRED */ || updates.paymentStatus === "EXPIRED" /* EXPIRED */) {
      updates.paymentStatus = "EXPIRED" /* EXPIRED */;
      updates.status = "EXPIRED" /* EXPIRED */;
    }
    this.data.orders[index] = normalizeOrderDeliveryFee({
      ...currentOrder,
      ...updates,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    this.save();
    if (updates.status && updates.status !== prevStatus) {
      this.log(userId, `Updated order ${id} status from ${prevStatus} to ${updates.status}`, role);
      if (updates.status === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */ && this.data.systemConfig.assignmentMode === "AUTOMATIC" /* AUTOMATIC */) {
        await this.autoAssignDriver(id);
      }
    } else {
      this.log(userId, `Updated order ${id} details`, role);
    }
    if (isFirestoreAdminConfigured()) {
      const probe = await testFirestoreConnection();
      if (probe.connected) {
        const persisted = await safeFirestoreSetDoc("orders", id, this.data.orders[index]);
        if (!persisted) {
          this.data.orders[index] = currentOrder;
          this.save();
          throw new Error("Gagal memperbarui status pesanan pada cloud Firestore. Perubahan status dibatalkan demi integritas data.");
        }
      } else if (foodConfig.isProduction) {
        console.warn(`[TumpangFood DB] Firestore offline saat updateOrder (${probe.diagnosticReason}). Perubahan disimpan pada snapshot lokal resilien.`);
      }
    } else {
      console.warn("[TumpangFood DB] Variabel FIREBASE_SERVICE_ACCOUNT_KEY belum dikonfigurasi. Perubahan status disimpan pada penyimpanan lokal.");
    }
    return this.data.orders[index];
  }
  async verifyOrderPayment(adminId, orderId) {
    const order = this.getOrderById(orderId);
    if (!order) throw new Error("Pesanan tidak ditemukan.");
    if (order.status === "CANCELLED" /* CANCELLED */) {
      throw new Error("Pesanan yang telah dibatalkan tidak dapat diverifikasi.");
    }
    if (order.status === "EXPIRED" /* EXPIRED */) {
      throw new Error("Pesanan telah kedaluwarsa. Pembayaran kedaluwarsa tidak dapat diverifikasi secara otomatis.");
    }
    const receiptNumber = order.receiptNumber || `TG-RCP-${order.id.replace(/^ord_/, "").toUpperCase()}`;
    const issuedAt = order.paymentVerifiedAt || (/* @__PURE__ */ new Date()).toISOString();
    const transactionRef = order.artopayPaymentId || `QRIS-TG-${order.id.replace(/^ord_/, "").toUpperCase()}`;
    const receipt = order.receipt || {
      receiptNumber,
      orderId: order.id,
      issuedAt,
      confirmedBy: adminId || "admin_tumpang",
      paymentMethod: order.paymentMethod || "MERCHANT_QRIS",
      transactionRef,
      subtotal: order.subtotal,
      deliveryFee: order.deliveryFee,
      serviceFee: order.serviceFee,
      uniqueCode: order.uniqueCode || 0,
      total: order.total,
      customerName: order.customerName,
      merchantName: order.merchantName,
      status: "PAID"
    };
    if (order.paymentStatus === "PAID" /* PAID */ && order.status === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */ && order.receipt) {
      return order;
    }
    const updated = await this.updateOrder(
      adminId,
      orderId,
      {
        status: "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */,
        paymentStatus: "PAID" /* PAID */,
        paymentVerifiedAt: issuedAt,
        paymentVerifiedBy: adminId,
        receiptNumber,
        receipt
      },
      "ADMIN"
    );
    this.log(adminId, `Admin ${adminId} memverifikasi pembayaran LUNAS & menerbitkan receipt #${receiptNumber} untuk pesanan #${order.id} (Total: Rp ${order.total.toLocaleString("id-ID")})`, "ADMIN");
    return updated;
  }
  async rejectOrderPayment(adminId, orderId, reason) {
    const order = this.getOrderById(orderId);
    if (!order) throw new Error("Pesanan tidak ditemukan.");
    if (!reason || !reason.trim()) {
      throw new Error("Alasan penolakan bukti pembayaran wajib diisi.");
    }
    const cleanReason = reason.trim();
    const updated = await this.updateOrder(
      adminId,
      orderId,
      {
        status: "PAYMENT_REJECTED" /* PAYMENT_REJECTED */,
        paymentStatus: "REJECTED" /* REJECTED */,
        paymentRejectionReason: cleanReason,
        cancelReason: cleanReason,
        paymentVerifiedBy: adminId
      },
      "ADMIN"
    );
    this.log(adminId, `Admin ${adminId} menolak bukti pembayaran pesanan #${order.id}. Alasan: ${cleanReason}`, "ADMIN");
    return updated;
  }
  async autoAssignDriver(orderId) {
    const order = this.getOrderById(orderId);
    if (!order) return;
    const availableDrivers = this.data.drivers.filter((d) => d.online && d.active);
    if (availableDrivers.length === 0) {
      this.log("SYSTEM", `No active drivers available for auto-assignment of order ${orderId}`, "SYSTEM");
      return;
    }
    const driverTaskCounts = availableDrivers.map((d) => {
      const activeTasks = this.data.orders.filter(
        (o) => o.driverId === d.id && ["PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */, "COOKING" /* COOKING */, "READY_FOR_PICKUP" /* READY_FOR_PICKUP */, "ORDER_PICKED_UP" /* ORDER_PICKED_UP */].includes(o.status)
      ).length;
      return { driver: d, count: activeTasks };
    });
    driverTaskCounts.sort((a, b) => a.count - b.count);
    const selectedDriver = driverTaskCounts[0].driver;
    await this.updateOrder("SYSTEM", orderId, {
      driverId: selectedDriver.id,
      driverName: selectedDriver.name
    }, "SYSTEM");
  }
  async manualAssignDriver(userId, orderId, driverId) {
    const driver = this.getDriverById(driverId);
    if (!driver) throw new Error("Driver not found");
    const updated = await this.updateOrder(userId, orderId, {
      driverId: driver.id,
      driverName: driver.name
    }, "ADMIN");
    this.log(userId, `Assigned driver ${driver.name} to order ${orderId}`, "ADMIN");
    return updated;
  }
  // --- SETTLEMENTS ---
  getSettlements() {
    return this.data.settlements;
  }
  getSettlementsByMerchant(merchantId) {
    return this.data.settlements.filter((s) => s.merchantId === merchantId);
  }
  /**
   * Serializes settlement operations across the process and host instances to prevent concurrent double-settlements
   */
  async runWithSettlementLock(fn) {
    let release;
    const waitPromise = new Promise((resolve) => {
      release = resolve;
    });
    const currentMutex = this.settlementMutex;
    this.settlementMutex = currentMutex.then(() => waitPromise).catch(() => waitPromise);
    await currentMutex;
    const lockPath = import_path4.default.join(import_path4.default.dirname(FOOD_DB_FILE), "settlement_operation.lock");
    let fileLockAcquired = false;
    for (let attempts = 0; attempts < 30; attempts++) {
      try {
        const fd = import_fs4.default.openSync(lockPath, "wx");
        import_fs4.default.writeSync(fd, `${process.pid}:${Date.now()}`);
        import_fs4.default.closeSync(fd);
        fileLockAcquired = true;
        break;
      } catch (err) {
        if (err.code === "EEXIST") {
          try {
            const stats = import_fs4.default.statSync(lockPath);
            if (Date.now() - stats.mtimeMs > 15e3) {
              import_fs4.default.unlinkSync(lockPath);
              continue;
            }
          } catch {
          }
          await new Promise((r) => setTimeout(r, 100));
        } else {
          break;
        }
      }
    }
    try {
      return await fn();
    } finally {
      if (fileLockAcquired) {
        try {
          import_fs4.default.unlinkSync(lockPath);
        } catch {
        }
      }
      release();
    }
  }
  async createSettlement(userId, settlementData) {
    return this.runWithSettlementLock(async () => {
      const targetOrderIds = settlementData.orderIds || [];
      if (!Array.isArray(targetOrderIds) || targetOrderIds.length === 0) {
        throw new Error("Settlement wajib menyertakan setidaknya satu ID pesanan yang memenuhi syarat.");
      }
      const merchant = this.data.merchants.find((m) => m.id === settlementData.merchantId);
      if (!merchant) {
        throw new Error(`Merchant dengan ID "${settlementData.merchantId}" tidak ditemukan.`);
      }
      const verifiedOrders = [];
      for (const ordId of targetOrderIds) {
        const ord = this.data.orders.find((o) => o.id === ordId);
        if (!ord) {
          throw new Error(`Pesanan "${ordId}" tidak ditemukan dalam database.`);
        }
        if (ord.merchantId !== settlementData.merchantId) {
          throw new Error(`Pesanan "${ordId}" bukan milik merchant ${settlementData.merchantId}.`);
        }
        if (ord.status !== "COMPLETED" /* COMPLETED */) {
          throw new Error(`Pesanan "${ordId}" belum selesai (status: ${ord.status}). Hanya pesanan COMPLETED yang dapat dicairkan.`);
        }
        if (ord.isSettled === true || ord.settlementId) {
          throw new Error(`Pesanan "${ordId}" sudah pernah dicairkan dalam settlement sebelumnya. Pencairan ganda dicegah secara atomik.`);
        }
        verifiedOrders.push(ord);
      }
      const orderCount = verifiedOrders.length;
      const totalSales = verifiedOrders.reduce((sum, o) => sum + (Number(o.subtotal) || 0), 0);
      const commissionPercent = this.data.systemConfig.commissionPercent || 10;
      const totalCommission = Math.round(totalSales * commissionPercent / 100);
      const amountToPay = Math.max(0, totalSales - totalCommission);
      const settlementId = "set_" + Math.random().toString(36).substring(2, 9);
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      const newSettlement = {
        id: settlementId,
        merchantId: merchant.id,
        merchantName: merchant.name,
        orderCount,
        totalSales,
        totalCommission,
        amountToPay,
        status: settlementData.status || "WAITING_CONFIRMATION" /* WAITING_CONFIRMATION */,
        bankName: settlementData.bankName || merchant.bankName || "Bank Mandiri",
        bankAccount: settlementData.bankAccount || merchant.bankAccount || "-",
        bankHolder: settlementData.bankHolder || merchant.bankHolder || merchant.ownerName,
        createdAt: nowIso
      };
      const adminDb2 = getAdminDb();
      if (adminDb2) {
        try {
          await runAdminTransaction(async (transaction) => {
            for (const ordId of targetOrderIds) {
              const orderRef = adminDb2.collection("orders").doc(ordId);
              const remoteSnap = await transaction.get(orderRef);
              if (remoteSnap.exists) {
                const remoteData = remoteSnap.data();
                if (remoteData?.isSettled === true || remoteData?.settlementId) {
                  throw new Error(`Pesanan "${ordId}" telah dicairkan oleh instance backend lain. Pencairan ganda lintas-instance dicegah secara atomik.`);
                }
              }
            }
            for (const ord of verifiedOrders) {
              const orderRef = adminDb2.collection("orders").doc(ord.id);
              transaction.set(orderRef, removeUndefinedFields({
                ...ord,
                isSettled: true,
                settlementId,
                settledAt: nowIso,
                updatedAt: nowIso
              }), { merge: true });
            }
            const settlementRef = adminDb2.collection("settlements").doc(newSettlement.id);
            transaction.set(settlementRef, removeUndefinedFields(newSettlement));
          });
        } catch (txErr) {
          if (txErr.message && txErr.message.includes("telah dicairkan")) {
            throw txErr;
          }
          if (foodConfig.isProduction) {
            throw new Error(`[Produksi] Transaksi cloud Firestore gagal: ${txErr.message}. Pencairan dibatalkan demi menjaga integritas data keuangan.`);
          }
          console.warn("[TumpangFood DB] Distributed Firestore Admin transaction fallback in development mode:", txErr.message);
        }
      } else if (foodConfig.isProduction) {
        throw new Error("[Produksi] Firebase Admin Firestore wajib aktif dan terhubung untuk memproses pencairan dana (settlement).");
      }
      for (const ord of verifiedOrders) {
        ord.isSettled = true;
        ord.settlementId = settlementId;
        ord.settledAt = nowIso;
        ord.updatedAt = nowIso;
        safeFirestoreSetDoc("orders", ord.id, ord);
      }
      this.data.settlements.unshift(newSettlement);
      this.save();
      this.createBackup();
      this.log(
        userId,
        `Created settlement ${settlementId} of Rp ${amountToPay.toLocaleString()} for ${merchant.name} (${orderCount} pesanan)`,
        "ADMIN"
      );
      safeFirestoreSetDoc("settlements", newSettlement.id, newSettlement);
      return newSettlement;
    });
  }
  async updateSettlement(userId, id, updates) {
    const index = this.data.settlements.findIndex((s) => s.id === id);
    if (index === -1) throw new Error("Settlement not found");
    const nextSettlement = {
      ...this.data.settlements[index],
      ...updates,
      paidAt: updates.status === "SETTLEMENT_COMPLETED" /* SETTLEMENT_COMPLETED */ ? (/* @__PURE__ */ new Date()).toISOString() : this.data.settlements[index].paidAt
    };
    if (isFirestoreAdminConfigured()) {
      const persisted = await safeFirestoreSetDoc("settlements", id, nextSettlement);
      if (!persisted && foodConfig.isProduction) {
        throw new Error("[Produksi] Gagal memperbarui settlement di cloud Firestore. Perubahan dibatalkan.");
      }
    } else {
      safeFirestoreSetDoc("settlements", id, nextSettlement);
    }
    this.data.settlements[index] = nextSettlement;
    this.save();
    this.createBackup();
    this.log(userId, `Updated settlement ${id} to status ${this.data.settlements[index].status}`, "ADMIN");
    return this.data.settlements[index];
  }
  async confirmSettlement(userId, id) {
    return this.updateSettlement(userId, id, { status: "SETTLEMENT_COMPLETED" /* SETTLEMENT_COMPLETED */ });
  }
  async generateHPlusOneSettlements(userId) {
    return this.runWithSettlementLock(async () => {
      const targetOrders = this.data.orders.filter(
        (o) => o.status === "COMPLETED" /* COMPLETED */ && !o.isSettled && !o.settlementId
      );
      if (targetOrders.length === 0) return [];
      const grouped = /* @__PURE__ */ new Map();
      for (const o of targetOrders) {
        const list = grouped.get(o.merchantId) || [];
        list.push(o);
        grouped.set(o.merchantId, list);
      }
      const createdSettlements = [];
      const commissionPercent = this.data.systemConfig.commissionPercent || 10;
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      for (const [merchantId, orders] of grouped.entries()) {
        const merchant = this.data.merchants.find((m) => m.id === merchantId);
        if (!merchant) continue;
        const orderCount = orders.length;
        const totalSales = orders.reduce((sum, o) => sum + (Number(o.subtotal) || 0), 0);
        const totalCommission = Math.round(totalSales * commissionPercent / 100);
        const amountToPay = Math.max(0, totalSales - totalCommission);
        const settlementId = "set_" + Math.random().toString(36).substring(2, 9);
        const newSettlement = {
          id: settlementId,
          merchantId,
          merchantName: merchant.name,
          orderCount,
          totalSales,
          totalCommission,
          amountToPay,
          status: "WAITING_CONFIRMATION" /* WAITING_CONFIRMATION */,
          bankName: merchant.bankName || "Bank Mandiri",
          bankAccount: merchant.bankAccount || "-",
          bankHolder: merchant.bankHolder || merchant.ownerName,
          createdAt: nowIso
        };
        const adminDb2 = getAdminDb();
        if (adminDb2) {
          try {
            await runAdminTransaction(async (transaction) => {
              for (const o of orders) {
                const orderRef = adminDb2.collection("orders").doc(o.id);
                const snap = await transaction.get(orderRef);
                if (snap.exists) {
                  const data = snap.data();
                  if (data?.isSettled === true || data?.settlementId) {
                    throw new Error(`Order ${o.id} already settled.`);
                  }
                }
              }
              for (const o of orders) {
                const orderRef = adminDb2.collection("orders").doc(o.id);
                transaction.set(orderRef, removeUndefinedFields({
                  ...o,
                  isSettled: true,
                  settlementId,
                  settledAt: nowIso,
                  updatedAt: nowIso
                }), { merge: true });
              }
              const settlementRef = adminDb2.collection("settlements").doc(newSettlement.id);
              transaction.set(settlementRef, removeUndefinedFields(newSettlement));
            });
          } catch (txErr) {
            if (foodConfig.isProduction) {
              throw new Error(`[Produksi] Transaksi cloud Firestore gagal untuk merchant ${merchantId}: ${txErr.message}`);
            }
            console.warn(`[TumpangFood DB] H+1 atomic transaction fallback for ${merchantId}:`, txErr.message);
          }
        } else if (foodConfig.isProduction) {
          throw new Error("[Produksi] Firebase Admin Firestore wajib aktif untuk membuat H+1 settlements.");
        }
        for (const o of orders) {
          o.isSettled = true;
          o.settlementId = settlementId;
          o.settledAt = nowIso;
          o.updatedAt = nowIso;
          safeFirestoreSetDoc("orders", o.id, o);
        }
        this.data.settlements.unshift(newSettlement);
        safeFirestoreSetDoc("settlements", newSettlement.id, newSettlement);
        createdSettlements.push(newSettlement);
      }
      this.save();
      this.createBackup();
      this.log(userId, `Generated H+1 settlements for ${createdSettlements.length} merchants`, "ADMIN");
      return createdSettlements;
    });
  }
  // --- PARTNER REGISTRATIONS ---
  getPartnerRegistrations() {
    return this.data.partnerRegistrations;
  }
  async createPartnerRegistration(regData) {
    const newReg = {
      ...regData,
      id: "reg_" + Math.random().toString(36).substring(2, 9),
      status: "PENDING",
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (isFirestoreAdminConfigured()) {
      const persisted = await safeFirestoreSetDoc("partnerRegistrations", newReg.id, newReg);
      if (!persisted && foodConfig.isProduction) {
        throw new Error("[Produksi] Gagal menyimpan pendaftaran mitra ke cloud Firestore. Transaksi dibatalkan.");
      }
    } else {
      safeFirestoreSetDoc("partnerRegistrations", newReg.id, newReg);
    }
    this.data.partnerRegistrations.push(newReg);
    this.save();
    this.log("CUSTOMER", `Submitted partner registration for ${newReg.name} (${newReg.type})`, "CUSTOMER");
    return newReg;
  }
  async approvePartnerRegistration(userId, id) {
    const reg = this.data.partnerRegistrations.find((r) => r.id === id);
    if (!reg) return { success: false, error: "Registration not found" };
    if (reg.status !== "PENDING") return { success: false, error: "Registration already processed" };
    const prevStatus = reg.status;
    reg.status = "APPROVED";
    if (reg.type === "MERCHANT") {
      const generatedPassword = "TF-" + Math.floor(1e3 + Math.random() * 9e3);
      reg.password = generatedPassword;
      const newMerchant = await this.createMerchant(userId, {
        name: reg.storeName || reg.name + " Store",
        ownerName: reg.name,
        phone: reg.phone,
        address: reg.storeAddress || "Alamat Toko",
        latitude: reg.latitude || -7.9482,
        longitude: reg.longitude || 112.7612,
        openTime: "08:00",
        closeTime: "21:00",
        bankName: "Bank BRI",
        bankAccount: "1234567890",
        bankHolder: reg.name,
        active: true,
        cookTimeEstimate: "15-30 min",
        image: reg.businessPhoto || "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3",
        description: "Toko baru bergabung di Tumpang Food!",
        category: reg.category || "Nasi & Lauk",
        email: reg.email,
        isActivated: true,
        password: hashPassword(generatedPassword),
        businessPhoto: reg.businessPhoto,
        idPhoto: reg.idPhoto,
        contractPhoto: reg.contractPhoto
      });
      reg.storeId = newMerchant.id;
      const defaultCategory = await this.createCategory(newMerchant.id, "Menu Utama");
      await this.createMenuItem(newMerchant.id, {
        categoryId: defaultCategory.id,
        name: "Nasi Goreng Spesial (Contoh)",
        description: "Nasi goreng lezat dengan bumbu khas, telur, dan kerupuk.",
        price: 15e3,
        available: true,
        image: "https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=400&auto=format&fit=crop&q=60&ixlib=rb-4.0.3"
      });
    } else if (reg.type === "DRIVER") {
      await this.createDriver(userId, {
        name: reg.name,
        phone: reg.phone,
        email: reg.email,
        active: true,
        online: false,
        latitude: -7.9482,
        longitude: 112.7612
      });
    }
    if (isFirestoreAdminConfigured()) {
      const persisted = await safeFirestoreSetDoc("partnerRegistrations", reg.id, reg);
      if (!persisted && foodConfig.isProduction) {
        reg.status = prevStatus;
        throw new Error("[Produksi] Gagal memperbarui status registrasi mitra ke cloud Firestore.");
      }
    } else {
      safeFirestoreSetDoc("partnerRegistrations", reg.id, reg);
    }
    this.save();
    this.log(userId, `Approved partner registration ${reg.id} (${reg.name})`, "ADMIN");
    return { success: true, registration: reg };
  }
  async rejectPartnerRegistration(userId, id) {
    const reg = this.data.partnerRegistrations.find((r) => r.id === id);
    if (!reg) return false;
    const prevStatus = reg.status;
    reg.status = "REJECTED";
    if (isFirestoreAdminConfigured()) {
      const persisted = await safeFirestoreSetDoc("partnerRegistrations", reg.id, reg);
      if (!persisted && foodConfig.isProduction) {
        reg.status = prevStatus;
        throw new Error("[Produksi] Gagal menolak pendaftaran mitra pada cloud Firestore.");
      }
    } else {
      safeFirestoreSetDoc("partnerRegistrations", reg.id, reg);
    }
    this.save();
    this.log(userId, `Rejected partner registration ${reg.id} (${reg.name})`, "ADMIN");
    return true;
  }
  // --- REVIEW PENGGUNA TUMPANGGO / TESTIMONIALS ---
  getPublishedTestimonials(categoryFilter) {
    if (!Array.isArray(this.data.testimonials)) return [];
    return this.data.testimonials.filter((t) => {
      const isPublished = t.status === "published" && t.consentApproved === true;
      if (!isPublished) return false;
      if (!categoryFilter || categoryFilter === "all") return true;
      const normItemCat = t.category === "merchant" || t.category === "umkm" ? "merchant" : "pelanggan";
      const normFilter = categoryFilter === "merchant" || categoryFilter === "umkm" ? "merchant" : categoryFilter;
      return normItemCat === normFilter;
    }).sort((a, b) => {
      if (a.displayOrder !== b.displayOrder) {
        return (a.displayOrder || 0) - (b.displayOrder || 0);
      }
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }
  getAllTestimonials(filter) {
    if (!Array.isArray(this.data.testimonials)) return [];
    let list = [...this.data.testimonials];
    if (filter) {
      if (filter.category && filter.category !== "all") {
        const normFilter = filter.category === "merchant" || filter.category === "umkm" ? "merchant" : filter.category;
        list = list.filter((t) => {
          const normItemCat = t.category === "merchant" || t.category === "umkm" ? "merchant" : "pelanggan";
          return normItemCat === normFilter;
        });
      }
      if (filter.status && filter.status !== "all") {
        list = list.filter((t) => t.status === filter.status);
      }
    }
    return list.sort((a, b) => {
      if (a.displayOrder !== b.displayOrder) {
        return (a.displayOrder || 0) - (b.displayOrder || 0);
      }
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }
  async createTestimonial(testimonialData) {
    if (!Array.isArray(this.data.testimonials)) this.data.testimonials = [];
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const rawCat = String(testimonialData.category || "").toLowerCase();
    const normalizedCategory = rawCat === "merchant" || rawCat === "umkm" ? "merchant" : "pelanggan";
    const rawStatus = String(testimonialData.status || "").toLowerCase();
    const validStatus = ["published", "pending", "rejected", "draft"].includes(rawStatus) ? rawStatus : "pending";
    const parsedRating = testimonialData.rating !== void 0 && testimonialData.rating !== null ? Math.min(5, Math.max(1, Math.round(Number(testimonialData.rating)))) : void 0;
    const newTesti = {
      id: "rev_" + Date.now().toString(36) + "_" + Math.random().toString(36).substring(2, 6),
      userName: (testimonialData.userName || "").trim(),
      merchantName: testimonialData.merchantName?.trim() || void 0,
      category: normalizedCategory,
      title: testimonialData.title?.trim() || void 0,
      content: (testimonialData.content || "").trim(),
      avatarUrl: testimonialData.avatarUrl?.trim() || void 0,
      roleDetail: testimonialData.roleDetail?.trim() || void 0,
      rating: parsedRating,
      consentApproved: Boolean(testimonialData.consentApproved),
      status: validStatus,
      displayOrder: Number(testimonialData.displayOrder) || 1,
      createdAt: now,
      updatedAt: now
    };
    if (isFirestoreAdminConfigured()) {
      const persisted = await safeFirestoreSetDoc("testimonials", newTesti.id, newTesti);
      if (!persisted && foodConfig.isProduction) {
        throw new Error("[Produksi] Gagal menyimpan review ke cloud Firestore. Pengiriman ulasan dibatalkan demi menjaga integritas data.");
      }
    } else {
      await safeFirestoreSetDoc("testimonials", newTesti.id, newTesti);
    }
    this.data.testimonials.push(newTesti);
    this.save();
    return newTesti;
  }
  async updateTestimonial(id, updates) {
    if (!Array.isArray(this.data.testimonials)) return null;
    const index = this.data.testimonials.findIndex((t) => t.id === id);
    if (index === -1) return null;
    const prev = this.data.testimonials[index];
    let category = prev.category;
    if (updates.category) {
      category = updates.category === "merchant" || updates.category === "umkm" ? "merchant" : "pelanggan";
    }
    let rating = prev.rating;
    if (updates.rating !== void 0) {
      rating = updates.rating !== null && !isNaN(Number(updates.rating)) ? Math.min(5, Math.max(1, Math.round(Number(updates.rating)))) : void 0;
    }
    let status = prev.status;
    if (updates.status && ["published", "pending", "rejected", "draft"].includes(updates.status)) {
      status = updates.status;
    }
    const updated = {
      ...prev,
      ...updates,
      merchantName: updates.merchantName !== void 0 ? updates.merchantName?.trim() || void 0 : prev.merchantName,
      title: updates.title !== void 0 ? updates.title?.trim() || void 0 : prev.title,
      category,
      rating,
      status,
      id: prev.id,
      // prevent ID overwrite
      createdAt: prev.createdAt,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (isFirestoreAdminConfigured()) {
      const persisted = await safeFirestoreSetDoc("testimonials", updated.id, updated);
      if (!persisted && foodConfig.isProduction) {
        throw new Error("[Produksi] Gagal memperbarui status review di cloud Firestore. Transaksi dibatalkan.");
      }
    } else {
      await safeFirestoreSetDoc("testimonials", updated.id, updated);
    }
    this.data.testimonials[index] = updated;
    this.save();
    return updated;
  }
  async deleteTestimonial(id) {
    if (!Array.isArray(this.data.testimonials)) return false;
    const initialLen = this.data.testimonials.length;
    this.data.testimonials = this.data.testimonials.filter((t) => t.id !== id);
    if (this.data.testimonials.length !== initialLen) {
      if (isFirestoreAdminConfigured()) {
        const deleted = await safeAdminDeleteDoc("testimonials", id);
        if (!deleted && foodConfig.isProduction) {
          throw new Error("[Produksi] Gagal menghapus review di cloud Firestore.");
        }
      } else {
        await safeAdminDeleteDoc("testimonials", id);
      }
      this.save();
      return true;
    }
    return false;
  }
};
var foodDb = new FoodDatabase();

// src/services/shop/api/shopApp.ts
var import_crypto4 = __toESM(require("crypto"), 1);
var import_express = __toESM(require("express"), 1);

// src/services/shop/database/shopDatabase.ts
var import_fs6 = __toESM(require("fs"), 1);
var import_path6 = __toESM(require("path"), 1);

// src/services/shop/shipping/courierAdapters.ts
var TumpangLocalCourierAdapter = class {
  constructor() {
    this.code = "TUMPANG_LOCAL";
    this.name = "Kurir Toko Tumpang Go";
    this.scope = "LOCAL";
    this.originCountry = "ID";
    this.originCity = "Kecamatan Tumpang, Malang";
    this.destinationCountry = "ID";
  }
  isConfigured() {
    return true;
  }
  supportsLiveTracking() {
    return false;
  }
  getAdapterNote() {
    return "Layanan pengantaran langsung armada Toko Tumpang Shop untuk area Tumpang dan sekitarnya. Pembaruan status dikelola langsung oleh admin toko.";
  }
  getServices() {
    return [
      {
        code: "INSTANT_SHOP",
        name: "Kurir Instan Tumpang (Same-Day)",
        scope: "LOCAL",
        baseCost: 4e3,
        estimatedDays: "1-3 jam setelah dikemas",
        isEstimateVerified: true,
        description: "Pengantaran cepat langsung ke rumah Anda di wilayah Tumpang dan sekitarnya."
      },
      {
        code: "REGULAR_SHOP",
        name: "Kurir Reguler Toko (Next-Day)",
        scope: "LOCAL",
        baseCost: 3e3,
        estimatedDays: "1 hari (Kirim besok pagi)",
        isEstimateVerified: true,
        description: "Jadwal pengiriman pagi hari berikutnya dengan biaya lebih hemat."
      },
      {
        code: "PICKUP_SHOP",
        name: "Ambil Sendiri di Toko (Pickup)",
        scope: "LOCAL",
        baseCost: 0,
        estimatedDays: "Siap diambil saat toko buka",
        isEstimateVerified: true,
        description: "Ambil belanjaan langsung ke gerai resmi Tumpang Shop tanpa ongkir."
      }
    ];
  }
  getRelevantStatuses() {
    return [
      { status: "WAITING_DISPATCH" /* WAITING_DISPATCH */, label: "Menunggu Pengiriman", description: "Pesanan telah diverifikasi dan menunggu penugasan kurir toko." },
      { status: "PROCESSING" /* PROCESSING */, label: "Diproses di Gudang", description: "Barang belanjaan sedang dipersiapkan dan dikemas aman." },
      { status: "OUT_FOR_DELIVERY" /* OUT_FOR_DELIVERY */, label: "Dalam Pengantaran", description: "Kurir toko sedang menuju alamat pengantaran penerima." },
      { status: "DELIVERED" /* DELIVERED */, label: "Terkirim", description: "Pesanan telah berhasil diserahkan kepada penerima di alamat tujuan." },
      { status: "FAILED_DELIVERY" /* FAILED_DELIVERY */, label: "Gagal Dikirim", description: "Kurir tidak dapat menemukan alamat atau penerima tidak berada di tempat." }
    ];
  }
};
var DomesticExpeditionAdapter = class {
  constructor() {
    this.code = "DOMESTIC_EXPEDITION";
    this.name = "Ekspedisi Domestik Reguler (J&T / JNE)";
    this.scope = "LOCAL";
    this.originCountry = "ID";
    this.originCity = "Malang, Jawa Timur";
    this.destinationCountry = "ID";
  }
  isConfigured() {
    return false;
  }
  supportsLiveTracking() {
    return false;
  }
  getAdapterNote() {
    return "Adapter ekspedisi domestik telah siap. Kredensial API kurir pihak ketiga (J&T/JNE) belum disetel. Riwayat nomor resi dan tracking dicatat secara manual oleh Admin Tumpang Shop.";
  }
  getServices() {
    return [
      {
        code: "EXPEDITION_REGULAR",
        name: "Ekspedisi Domestik Standar (2-3 Hari)",
        scope: "LOCAL",
        baseCost: 12e3,
        estimatedDays: "2-3 hari kerja (Estimasi manual belum terverifikasi API)",
        isEstimateVerified: false,
        description: "Pengiriman untuk area luar kecamatan Tumpang di Malang Raya dan Jawa Timur."
      }
    ];
  }
  getRelevantStatuses() {
    return [
      { status: "WAITING_DISPATCH" /* WAITING_DISPATCH */, label: "Menunggu Pengiriman", description: "Paket siap diserahkan ke counter ekspedisi." },
      { status: "DISPATCHED" /* DISPATCHED */, label: "Diserahkan ke Ekspedisi", description: "Paket telah diterima di drop point counter ekspedisi." },
      { status: "IN_TRANSIT" /* IN_TRANSIT */, label: "Dalam Perjalanan Antar Kota", description: "Paket sedang dalam perjalanan transit hub logistik." },
      { status: "OUT_FOR_DELIVERY" /* OUT_FOR_DELIVERY */, label: "Dalam Pengantaran Kurir", description: "Kurir ekspedisi membawa paket menuju alamat tujuan." },
      { status: "DELIVERED" /* DELIVERED */, label: "Terkirim", description: "Paket berhasil diterima oleh penerima." }
    ];
  }
};
var ChinaIndonesiaCrossBorderAdapter = class {
  constructor() {
    this.code = "CHINA_ID_CROSSBORDER";
    this.name = "Layanan Impor Cross-Border (China \u{1F1E8}\u{1F1F3} \u2192 Indonesia \u{1F1EE}\u{1F1E9})";
    this.scope = "INTERNATIONAL";
    this.originCountry = "CN";
    this.originCity = "Gudang Konsolidasi Shenzhen / Guangzhou, China";
    this.destinationCountry = "ID";
  }
  isConfigured() {
    return false;
  }
  supportsLiveTracking() {
    return false;
  }
  getAdapterNote() {
    return "Modul pelacakan jalur internasional China \u2192 Indonesia aktif. API live kurir internasional belum dikonfigurasi, seluruh pembaruan tahapan (ekspor, kargo internasional, bea cukai, kurir lokal) diverifikasi dan dicatat manual oleh Admin Tumpang Shop.";
  }
  getServices() {
    return [
      {
        code: "CHINA_AIR_EXPRESS",
        name: "China Air Freight Express (7-12 Hari)",
        scope: "INTERNATIONAL",
        baseCost: 35e3,
        estimatedDays: "7-12 hari kerja (Estimasi unverified bergantung proses bea cukai)",
        isEstimateVerified: false,
        description: "Jalur kargo udara prioritas dari Shenzhen/Guangzhou langsung menuju Bandara Soekarno-Hatta."
      },
      {
        code: "CHINA_SEA_STANDARD",
        name: "China Sea Freight Ekonomis (20-30 Hari)",
        scope: "INTERNATIONAL",
        baseCost: 2e4,
        estimatedDays: "20-30 hari kalender (Estimasi unverified bergantung pelabuhan)",
        isEstimateVerified: false,
        description: "Jalur kargo laut kontainer untuk paket berbobot besar dengan tarif ekonomis."
      }
    ];
  }
  getRelevantStatuses() {
    return [
      { status: "WAITING_DISPATCH" /* WAITING_DISPATCH */, label: "Menunggu Pengiriman", description: "Pesanan diterima pabrik/supplier di China dan menunggu pengemasan ekspor." },
      { status: "PROCESSING" /* PROCESSING */, label: "Diproses di Gudang Asal (China)", description: "Paket tiba di sorting center Shenzhen/Guangzhou untuk pelabelan resi internasional." },
      { status: "DISPATCHED" /* DISPATCHED */, label: "Dikirim dari Negara Asal", description: "Paket telah lolos pemindaian ekspor dan diberangkatkan ke bandara/pelabuhan asal." },
      { status: "IN_TRANSIT" /* IN_TRANSIT */, label: "Dalam Perjalanan Internasional", description: "Paket sedang transit rute kargo internasional menuju Indonesia." },
      { status: "ARRIVED_INDONESIA" /* ARRIVED_INDONESIA */, label: "Tiba di Indonesia", description: "Paket telah mendarat di Port of Entry (Bandara CGK / Pelabuhan Tanjung Priok)." },
      { status: "CUSTOMS_CLEARANCE" /* CUSTOMS_CLEARANCE */, label: "Pemeriksaan Bea Cukai", description: "Paket sedang melalui proses verifikasi kepabeanan dan pembayaran bea impor." },
      { status: "CUSTOMS_HOLD" /* CUSTOMS_HOLD */, label: "Tertahan di Bea Cukai", description: "Paket memerlukan konfirmasi dokumen tambahan atau pembayaran pajak kepabeanan." },
      { status: "TRANSFERRED_LOCAL_COURIER" /* TRANSFERRED_LOCAL_COURIER */, label: "Diteruskan Kurir Lokal", description: "Paket telah selesai diperiksa Bea Cukai dan diserahkan ke kurir domestik Indonesia." },
      { status: "OUT_FOR_DELIVERY" /* OUT_FOR_DELIVERY */, label: "Dalam Pengantaran ke Alamat", description: "Kurir lokal membawa paket menuju alamat penerima di Tumpang." },
      { status: "DELIVERED" /* DELIVERED */, label: "Terkirim ke Penerima", description: "Paket impor berhasil diterima oleh pemesan di Tumpang." }
    ];
  }
};
var CourierAdapterRegistry = class {
  constructor() {
    this.adapters = /* @__PURE__ */ new Map();
    this.register(new TumpangLocalCourierAdapter());
    this.register(new DomesticExpeditionAdapter());
    this.register(new ChinaIndonesiaCrossBorderAdapter());
  }
  register(adapter) {
    this.adapters.set(adapter.code, adapter);
  }
  get(code) {
    return this.adapters.get(code);
  }
  getAll() {
    return Array.from(this.adapters.values());
  }
  getAvailableShippingOptions() {
    const list = [];
    for (const adapter of this.adapters.values()) {
      for (const s of adapter.getServices()) {
        list.push({
          code: s.code,
          courierCode: adapter.code,
          courierName: adapter.name,
          serviceName: s.name,
          scope: s.scope,
          originCountry: adapter.originCountry,
          originCity: adapter.originCity,
          estimatedDays: s.estimatedDays,
          baseCost: s.baseCost,
          description: s.description,
          isAvailable: true,
          isLiveApiIntegrated: adapter.isConfigured(),
          note: adapter.getAdapterNote()
        });
      }
    }
    return list;
  }
};
var courierRegistry = new CourierAdapterRegistry();

// src/services/shop/database/shopSchema.ts
var ShopSchemaValidator = class {
  /**
   * Validate Category Creation/Update
   */
  static validateCategory(data) {
    if (!data.name || typeof data.name !== "string" || data.name.trim().length === 0) {
      return { isValid: false, error: "Nama kategori wajib diisi." };
    }
    if (data.name.trim().length > 100) {
      return { isValid: false, error: "Nama kategori maksimal 100 karakter." };
    }
    return { isValid: true };
  }
  /**
   * Validate Product Creation/Update
   */
  static validateProduct(data) {
    if (!data.name || typeof data.name !== "string" || data.name.trim().length === 0) {
      return { isValid: false, error: "Nama produk belanja wajib diisi." };
    }
    const effectivePrice = typeof data.price === "number" ? data.price : typeof data.basePrice === "number" ? data.basePrice : void 0;
    if (typeof effectivePrice !== "number" || isNaN(effectivePrice) || effectivePrice < 0) {
      return { isValid: false, error: "Harga produk harus berupa angka valid non-negatif." };
    }
    if (typeof data.stock !== "number" || isNaN(data.stock) || data.stock < 0) {
      return { isValid: false, error: "Stok produk harus berupa angka non-negatif." };
    }
    if (!data.categoryId || typeof data.categoryId !== "string") {
      return { isValid: false, error: "Kategori produk belanja wajib dipilih." };
    }
    return { isValid: true };
  }
  /**
   * Validate Order Creation Payload
   */
  static validateOrderPayload(data) {
    if (!data) return { isValid: false, error: "Payload pesanan belanja tidak boleh kosong." };
    if (!data.customerName || typeof data.customerName !== "string" || data.customerName.trim().length === 0) {
      return { isValid: false, error: "Nama pemesan wajib diisi." };
    }
    if (!data.customerPhone || typeof data.customerPhone !== "string" || data.customerPhone.trim().length < 8) {
      return { isValid: false, error: "Nomor WhatsApp pemesan harus sah minimal 8 digit." };
    }
    const address = data.deliveryAddress || data.customerAddress;
    if (!address || typeof address !== "string" || address.trim().length < 3) {
      return { isValid: false, error: "Alamat pengantaran belanja wajib diisi." };
    }
    if (!Array.isArray(data.items) || data.items.length === 0) {
      return { isValid: false, error: "Keranjang belanja tidak boleh kosong." };
    }
    for (const item of data.items) {
      if (!item.productId || typeof item.quantity !== "number" || item.quantity <= 0) {
        return { isValid: false, error: "Setiap item belanja harus memiliki produk dan jumlah yang sah." };
      }
    }
    return { isValid: true };
  }
  /**
   * Validate Shipment Status Update
   */
  static validateShipmentStatus(status) {
    const validStatuses = Object.values(ShopShipmentStatus);
    if (!status || !validStatuses.includes(String(status))) {
      return { isValid: false, error: `Status pengiriman '${status}' tidak dikenali.` };
    }
    return { isValid: true };
  }
};

// src/services/shop/database/shopMigration.ts
var import_fs5 = __toESM(require("fs"), 1);
var import_path5 = __toESM(require("path"), 1);
var ShopMigrationRunner = class {
  constructor(targetDbPath) {
    this.targetDbPath = targetDbPath || shopEnv.database.filePath;
  }
  /**
   * Run all pending migrations on Shop Database
   */
  async runMigrations(currentDb) {
    const appliedMigrations = currentDb.migrations || [];
    let appliedCount = 0;
    let migratedFromLegacy = false;
    let legacyRecordsFound = 0;
    if (!currentDb.migrations) {
      currentDb.migrations = [];
    }
    const legacyAudit = this.auditLegacyData();
    if (legacyAudit.hasShopData) {
      console.log(`[ShopMigration] Ditemukan ${legacyAudit.totalRecords} record Shop di database legacy. Menjalankan migrasi data...`);
      for (const cat of legacyAudit.categories) {
        if (!currentDb.categories.some((c) => c.id === cat.id)) {
          currentDb.categories.push(cat);
          legacyRecordsFound++;
        }
      }
      for (const prod of legacyAudit.products) {
        if (!currentDb.products.some((p) => p.id === prod.id)) {
          currentDb.products.push(prod);
          legacyRecordsFound++;
        }
      }
      for (const ord of legacyAudit.orders) {
        if (!currentDb.orders.some((o) => o.id === ord.id)) {
          currentDb.orders.push(ord);
          legacyRecordsFound++;
        }
      }
      migratedFromLegacy = true;
    }
    if (!currentDb.migrations.some((m) => m.version === 1)) {
      this.ensureBaselineData(currentDb);
      const v1Record = {
        id: "mig_001_baseline_schema",
        version: 1,
        name: "Baseline Shop Marketplace Schema & Default Data",
        appliedAt: (/* @__PURE__ */ new Date()).toISOString(),
        source: "ShopMigrationRunner",
        notes: "Initializes independent tables: config, categories, products, orders, shipments, auditLogs"
      };
      currentDb.migrations.push(v1Record);
      appliedCount++;
    }
    if (!currentDb.migrations.some((m) => m.version === 2)) {
      for (const p of currentDb.products) {
        if (!p.sku) {
          p.sku = `TS-${p.id.replace("sprod_", "").toUpperCase().substring(0, 6)}`;
        }
        if (p.stock === void 0 || p.stock === null) {
          p.stock = 50;
        }
        if (!p.unit) {
          p.unit = "pcs";
        }
      }
      const v2Record = {
        id: "mig_002_sku_inventory_integrity",
        version: 2,
        name: "SKU and Inventory Integrity Backfill",
        appliedAt: (/* @__PURE__ */ new Date()).toISOString(),
        source: "ShopMigrationRunner",
        notes: "Enforces non-null SKU and default stock limits on all active shop products"
      };
      currentDb.migrations.push(v2Record);
      appliedCount++;
    }
    if (!currentDb.migrations.some((m) => m.version === 3)) {
      for (const s of currentDb.shipments) {
        if (!s.scope) {
          s.scope = s.courierCode === "CHINA_ID_CROSSBORDER" ? "INTERNATIONAL" : "LOCAL";
        }
        if (!s.trackingHistory) {
          s.trackingHistory = [];
        }
      }
      const v3Record = {
        id: "mig_003_shipment_scope_indexing",
        version: 3,
        name: "Shipment Scope and Cross-border Indexing",
        appliedAt: (/* @__PURE__ */ new Date()).toISOString(),
        source: "ShopMigrationRunner",
        notes: "Ensures shipment tracking history and scope separation (LOCAL vs INTERNATIONAL)"
      };
      currentDb.migrations.push(v3Record);
      appliedCount++;
    }
    const result = {
      success: true,
      appliedCount,
      migratedFromLegacy,
      legacyRecordsFound,
      message: `Migrasi Tumpang Shop berhasil: ${appliedCount} versi baru diterapkan, ${legacyRecordsFound} data legacy diverifikasi.`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
    return { updatedDb: currentDb, result };
  }
  /**
   * Audit legacy database files for any shop-related data
   */
  auditLegacyData() {
    const candidateFiles = [
      import_path5.default.join(process.cwd(), "tumpang_db.json"),
      import_path5.default.join(process.cwd(), "tumpang_food_db.json.backup.json")
    ];
    let foundCategories = [];
    let foundProducts = [];
    let foundOrders = [];
    for (const f of candidateFiles) {
      if (import_fs5.default.existsSync(f)) {
        try {
          const content = JSON.parse(import_fs5.default.readFileSync(f, "utf-8"));
          if (Array.isArray(content.shop_categories)) foundCategories.push(...content.shop_categories);
          if (Array.isArray(content.shop_products)) foundProducts.push(...content.shop_products);
          if (Array.isArray(content.shop_orders)) foundOrders.push(...content.shop_orders);
        } catch {
        }
      }
    }
    const total = foundCategories.length + foundProducts.length + foundOrders.length;
    return {
      hasShopData: total > 0,
      totalRecords: total,
      categories: foundCategories,
      products: foundProducts,
      orders: foundOrders
    };
  }
  /**
   * Ensure default categories and seed products exist if database is fresh
   */
  ensureBaselineData(db) {
    if (!db.config || !db.config.id) {
      db.config = {
        id: "shop_config_default",
        storeName: shopEnv.defaults.storeName,
        storeAddress: shopEnv.defaults.storeAddress,
        storePhone: shopEnv.defaults.storePhone,
        isOpen: shopEnv.defaults.isOpen,
        qrisImage: shopEnv.defaults.qrisImage,
        defaultDeliveryFee: shopEnv.defaults.defaultDeliveryFee,
        serviceFee: shopEnv.defaults.serviceFee,
        minOrderAmount: shopEnv.defaults.minOrderAmount,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      };
    }
    if (!Array.isArray(db.categories) || db.categories.length === 0) {
      db.categories = [
        {
          id: "scat_sembako",
          name: "Sembako & Kebutuhan Pokok",
          slug: "sembako",
          description: "Beras, minyak goreng, gula, tepung, telur, dan sembako berkualitas.",
          icon: "Package",
          orderIndex: 1,
          isActive: true,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        },
        {
          id: "scat_bumbu",
          name: "Sayur Segar & Bumbu Dapur",
          slug: "bumbu-sayur",
          description: "Bahan segar dari pasar Tumpang langsung ke dapur Anda.",
          icon: "Carrot",
          orderIndex: 2,
          isActive: true,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        },
        {
          id: "scat_khas",
          name: "Oleh-Oleh & Khas Tumpang",
          slug: "khas-tumpang",
          description: "Kopi Semeru Dampit, keripik tempe sagu, dan jajanan khas Tumpang.",
          icon: "Coffee",
          orderIndex: 3,
          isActive: true,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        },
        {
          id: "scat_kebersihan",
          name: "Kebersihan & Rumah Tangga",
          slug: "kebersihan",
          description: "Sabun, deterjen, sampo, dan perlengkapan kebersihan rumah.",
          icon: "Sparkles",
          orderIndex: 4,
          isActive: true,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        }
      ];
    }
    if (!Array.isArray(db.products) || db.products.length === 0) {
      db.products = [
        {
          id: "sprod_beras_5kg",
          sku: "TS-SBK-001",
          name: "Beras Premium Petani Tumpang 5kg",
          description: "Beras pulen pilihan langsung dari petani lokal lereng Bromo Tumpang. Tanpa pengawet dan pemutih.",
          price: 72e3,
          originalPrice: 75e3,
          stock: 45,
          unit: "karung 5kg",
          categoryId: "scat_sembako",
          image: "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80",
          images: ["https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80"],
          isActive: true,
          isFeatured: true,
          minOrder: 1,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        },
        {
          id: "sprod_minyak_goreng_2l",
          sku: "TS-SBK-002",
          name: "Minyak Goreng Refill 2 Liter",
          description: "Minyak goreng sawit jernih kualitas prima untuk aneka gorengan renyah keluarga.",
          price: 34e3,
          stock: 60,
          unit: "pouch 2L",
          categoryId: "scat_sembako",
          image: "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=600&q=80",
          images: ["https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=600&q=80"],
          isActive: true,
          isFeatured: true,
          minOrder: 1,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        },
        {
          id: "sprod_kopi_dampit_250g",
          sku: "TS-KHS-001",
          name: "Kopi Robusta Lereng Semeru Tumpang 250g",
          description: "Biji kopi robusta pilihan dari perkebunan lereng Gunung Semeru. Aroma mantap, rasa legit cokelat khas Malang Timur.",
          price: 38e3,
          stock: 30,
          unit: "pouch 250g",
          categoryId: "scat_khas",
          image: "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?auto=format&fit=crop&w=600&q=80",
          images: ["https://images.unsplash.com/photo-1559056199-641a0ac8b55e?auto=format&fit=crop&w=600&q=80"],
          isActive: true,
          isFeatured: true,
          minOrder: 1,
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          updatedAt: (/* @__PURE__ */ new Date()).toISOString()
        }
      ];
    }
    if (!Array.isArray(db.orders)) db.orders = [];
    if (!Array.isArray(db.shipments)) db.shipments = [];
    if (!Array.isArray(db.auditLogs)) db.auditLogs = [];
  }
};

// src/services/shop/database/shopDatabase.ts
var SHOP_DB_FILE = shopEnv.database.filePath;
var ShopDatabase = class {
  constructor() {
    this.schema = {
      config: {
        id: "shop_config_default",
        storeName: shopEnv.defaults.storeName,
        storeAddress: shopEnv.defaults.storeAddress,
        storePhone: shopEnv.defaults.storePhone,
        isOpen: shopEnv.defaults.isOpen,
        qrisImage: shopEnv.defaults.qrisImage,
        defaultDeliveryFee: shopEnv.defaults.defaultDeliveryFee,
        serviceFee: shopEnv.defaults.serviceFee,
        minOrderAmount: shopEnv.defaults.minOrderAmount,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      categories: [],
      products: [],
      orders: [],
      shipments: [],
      auditLogs: [],
      migrations: []
    };
    this.isInitialized = false;
    this.isCloudSyncing = false;
    this.migrationRunner = new ShopMigrationRunner();
    this.idempotencyCache = /* @__PURE__ */ new Map();
    this.recentOrderFingerprints = /* @__PURE__ */ new Map();
    this.loadFromLocal();
  }
  /**
   * Load state from local JSON file
   */
  loadFromLocal() {
    try {
      if (import_fs6.default.existsSync(SHOP_DB_FILE)) {
        const raw = import_fs6.default.readFileSync(SHOP_DB_FILE, "utf-8");
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === "object") {
          this.schema = {
            config: parsed.config || this.schema.config,
            categories: Array.isArray(parsed.categories) ? parsed.categories : [],
            products: Array.isArray(parsed.products) ? parsed.products : [],
            orders: Array.isArray(parsed.orders) ? parsed.orders : [],
            shipments: Array.isArray(parsed.shipments) ? parsed.shipments : [],
            auditLogs: Array.isArray(parsed.auditLogs) ? parsed.auditLogs : [],
            migrations: Array.isArray(parsed.migrations) ? parsed.migrations : []
          };
        }
      }
    } catch (err) {
      console.warn("[ShopDatabase] Gagal membaca database lokal shop, menggunakan state default:", err?.message || err);
    }
  }
  /**
   * Atomic local persistence
   */
  persistToLocal() {
    try {
      const dir = import_path6.default.dirname(SHOP_DB_FILE);
      if (!import_fs6.default.existsSync(dir)) {
        import_fs6.default.mkdirSync(dir, { recursive: true });
      }
      const tempPath = `${SHOP_DB_FILE}.tmp.${Date.now()}`;
      import_fs6.default.writeFileSync(tempPath, JSON.stringify(this.schema, null, 2), "utf-8");
      import_fs6.default.renameSync(tempPath, SHOP_DB_FILE);
    } catch (err) {
      console.error("[ShopDatabase] Gagal menyimpan ke file lokal:", err?.message || err);
    }
  }
  /**
   * Create non-destructive backup
   */
  createBackup() {
    const backupPath = `${SHOP_DB_FILE}.backup_${Date.now()}.json`;
    try {
      if (import_fs6.default.existsSync(SHOP_DB_FILE)) {
        import_fs6.default.copyFileSync(SHOP_DB_FILE, backupPath);
      }
    } catch (e) {
      console.warn("[ShopDatabase] Backup warning:", e);
    }
    return backupPath;
  }
  /**
   * Ensure database is initialized, migrated, and synced
   */
  async ensureInitialized() {
    if (this.isInitialized) return;
    try {
      const { updatedDb, result } = await this.migrationRunner.runMigrations(this.schema);
      this.schema = updatedDb;
      this.persistToLocal();
      if (result.appliedCount > 0) {
        console.log(`[ShopDatabase] Migrasi database diterapkan: ${result.message}`);
      }
      if (shopEnv.database.enableCloudSync && isFirestoreAdminConfigured()) {
        await this.syncFromCloud();
      }
      this.isInitialized = true;
    } catch (err) {
      console.warn("[ShopDatabase Init Error]", err?.message || err);
      this.isInitialized = true;
    }
  }
  async syncFromCloud() {
    try {
      if (!isFirestoreAdminConfigured()) return;
      const pfx = shopEnv.database.firestoreCollectionPrefix;
      const [cfgDoc, catDocs, prodDocs, ordDocs, shipDocs] = await Promise.all([
        safeAdminGetDoc(`${pfx}config`, "shop_config_default"),
        safeAdminGetDocs(`${pfx}categories`),
        safeAdminGetDocs(`${pfx}products`),
        safeAdminGetDocs(`${pfx}orders`),
        safeAdminGetDocs(`${pfx}shipments`)
      ]);
      if (cfgDoc) {
        this.schema.config = { ...this.schema.config, ...cfgDoc };
      }
      if (catDocs && catDocs.length > 0) {
        this.schema.categories = catDocs;
      }
      if (prodDocs && prodDocs.length > 0) {
        this.schema.products = prodDocs;
      }
      if (ordDocs && ordDocs.length > 0) {
        this.schema.orders = ordDocs;
      }
      if (shipDocs && shipDocs.length > 0) {
        this.schema.shipments = shipDocs;
      }
      this.persistToLocal();
    } catch (err) {
      console.warn("[ShopDatabase Cloud Sync Warning]", err?.message || err);
    }
  }
  /**
   * Health & storage status for Shop service
   */
  async getStorageStatus() {
    const cloudCheck = await testFirestoreConnection();
    const isCloud = cloudCheck.connected;
    return {
      service: "tumpang-shop",
      databaseType: shopEnv.database.type,
      filePath: SHOP_DB_FILE,
      liveCloudConnected: isCloud,
      storageMode: isCloud ? "cloud_firestore_primary" : "isolated_local_database_resilient",
      totalCategories: this.schema.categories.length,
      totalProducts: this.schema.products.length,
      totalOrders: this.schema.orders.length,
      totalShipments: this.schema.shipments.length,
      diagnosticReason: cloudCheck.diagnosticReason,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  /**
   * Audit logging
   */
  logAudit(action, details, actor = "system") {
    const log = {
      id: `slog_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      action,
      details,
      actor,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.schema.auditLogs.unshift(log);
    if (this.schema.auditLogs.length > 500) {
      this.schema.auditLogs = this.schema.auditLogs.slice(0, 500);
    }
    this.persistToLocal();
  }
  // --- CONFIG ---
  getConfig() {
    return { ...this.schema.config };
  }
  async updateConfig(actor, updates) {
    this.schema.config = {
      ...this.schema.config,
      ...updates,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.persistToLocal();
    this.logAudit("UPDATE_SHOP_CONFIG", `Pembaruan konfigurasi toko oleh ${actor}`, actor);
    try {
      const pfx = shopEnv.database.firestoreCollectionPrefix;
      await safeAdminSetDoc(`${pfx}config`, "shop_config_default", this.schema.config);
    } catch {
    }
    return this.getConfig();
  }
  // --- CATEGORIES ---
  getCategories() {
    return [...this.schema.categories].sort((a, b) => a.orderIndex - b.orderIndex);
  }
  getCategoryById(id) {
    return this.schema.categories.find((c) => c.id === id);
  }
  async createCategory(actor, data) {
    const val = ShopSchemaValidator.validateCategory(data);
    if (!val.isValid) throw new Error(val.error);
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const newCategory = {
      id: `scat_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: data.name.trim(),
      slug: data.slug || data.name.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
      description: data.description || "",
      icon: data.icon || "Package",
      orderIndex: data.orderIndex !== void 0 ? data.orderIndex : this.schema.categories.length + 1,
      isActive: data.isActive !== void 0 ? data.isActive : true,
      createdAt: now,
      updatedAt: now
    };
    this.schema.categories.push(newCategory);
    this.persistToLocal();
    this.logAudit("CREATE_CATEGORY", `Kategori ${newCategory.name} dibuat oleh ${actor}`, actor);
    try {
      const pfx = shopEnv.database.firestoreCollectionPrefix;
      await safeAdminSetDoc(`${pfx}categories`, newCategory.id, newCategory);
    } catch {
    }
    return newCategory;
  }
  async updateCategory(actor, id, updates) {
    const index = this.schema.categories.findIndex((c) => c.id === id);
    if (index === -1) throw new Error(`Kategori ${id} tidak ditemukan.`);
    const updated = {
      ...this.schema.categories[index],
      ...updates,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.schema.categories[index] = updated;
    this.persistToLocal();
    this.logAudit("UPDATE_CATEGORY", `Kategori ${updated.name} (${id}) diperbarui oleh ${actor}`, actor);
    try {
      const pfx = shopEnv.database.firestoreCollectionPrefix;
      await safeAdminSetDoc(`${pfx}categories`, id, updated);
    } catch {
    }
    return updated;
  }
  async deleteCategory(actor, id) {
    const index = this.schema.categories.findIndex((c) => c.id === id);
    if (index === -1) return false;
    const [deleted] = this.schema.categories.splice(index, 1);
    this.persistToLocal();
    this.logAudit("DELETE_CATEGORY", `Kategori ${deleted.name} (${id}) dihapus oleh ${actor}`, actor);
    try {
      const pfx = shopEnv.database.firestoreCollectionPrefix;
      await safeAdminDeleteDoc(`${pfx}categories`, id);
    } catch {
    }
    return true;
  }
  // --- PRODUCTS ---
  getProducts(filter) {
    let prods = [...this.schema.products];
    if (filter?.onlyActive !== false) {
      prods = prods.filter((p) => p.isActive);
    }
    if (filter?.categoryId) {
      prods = prods.filter((p) => p.categoryId === filter.categoryId);
    }
    if (filter?.search) {
      const q = filter.search.toLowerCase();
      prods = prods.filter((p) => p.name.toLowerCase().includes(q) || p.description && p.description.toLowerCase().includes(q) || p.sku && p.sku.toLowerCase().includes(q));
    }
    return prods;
  }
  getProductById(id) {
    return this.schema.products.find((p) => p.id === id);
  }
  async createProduct(actor, data) {
    const val = ShopSchemaValidator.validateProduct(data);
    if (!val.isValid) throw new Error(val.error);
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const effectivePrice = typeof data.price === "number" ? data.price : typeof data.basePrice === "number" ? data.basePrice : 0;
    const newProduct = {
      id: `sprod_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      sku: data.sku || `TS-${Date.now().toString().slice(-6)}`,
      name: data.name.trim(),
      description: data.description || "",
      price: Math.round(effectivePrice),
      basePrice: Math.round(effectivePrice),
      originalPrice: data.originalPrice,
      stock: data.stock !== void 0 ? data.stock : 100,
      unit: data.unit || "pcs",
      categoryId: data.categoryId,
      image: data.image || Array.isArray(data.images) && data.images[0] || "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80",
      images: data.images || (data.image ? [data.image] : []),
      isActive: data.isActive !== void 0 ? data.isActive : true,
      isFeatured: data.isFeatured || false,
      minOrder: data.minOrder || 1,
      variants: data.variants || [],
      variations: data.variations || [],
      createdAt: now,
      updatedAt: now
    };
    this.schema.products.push(newProduct);
    this.persistToLocal();
    this.logAudit("CREATE_PRODUCT", `Produk ${newProduct.name} (${newProduct.sku}) dibuat oleh ${actor}`, actor);
    try {
      const pfx = shopEnv.database.firestoreCollectionPrefix;
      await safeAdminSetDoc(`${pfx}products`, newProduct.id, newProduct);
    } catch {
    }
    return newProduct;
  }
  async updateProduct(actor, id, updates) {
    const index = this.schema.products.findIndex((p) => p.id === id);
    if (index === -1) throw new Error(`Produk ${id} tidak ditemukan.`);
    const current = this.schema.products[index];
    const effectivePrice = typeof updates.price === "number" ? updates.price : typeof updates.basePrice === "number" ? updates.basePrice : current.price;
    const updated = {
      ...current,
      ...updates,
      id: current.id,
      price: Math.round(effectivePrice),
      basePrice: Math.round(effectivePrice),
      stock: updates.stock !== void 0 ? updates.stock : current.stock,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.schema.products[index] = updated;
    this.persistToLocal();
    this.logAudit("UPDATE_PRODUCT", `Produk ${updated.name} (${id}) diperbarui oleh ${actor}`, actor);
    try {
      const pfx = shopEnv.database.firestoreCollectionPrefix;
      await safeAdminSetDoc(`${pfx}products`, id, updated);
    } catch {
    }
    return updated;
  }
  async deleteProduct(actor, id) {
    const index = this.schema.products.findIndex((p) => p.id === id);
    if (index === -1) return false;
    const [deleted] = this.schema.products.splice(index, 1);
    this.persistToLocal();
    this.logAudit("DELETE_PRODUCT", `Produk ${deleted.name} (${id}) dihapus oleh ${actor}`, actor);
    try {
      const pfx = shopEnv.database.firestoreCollectionPrefix;
      await safeAdminDeleteDoc(`${pfx}products`, id);
    } catch {
    }
    return true;
  }
  // --- ORDERS ---
  async createOrder(input) {
    if (!this.schema.config.isOpen) {
      throw new Error("Layanan Tumpang Shop saat ini sedang tutup. Silakan coba kembali saat toko dibuka.");
    }
    if (!input.customerName || input.customerName.trim().length === 0) {
      throw new Error("Nama pemesan wajib diisi.");
    }
    if (!input.customerPhone || input.customerPhone.trim().length === 0) {
      throw new Error("Nomor telepon / WhatsApp pemesan wajib diisi.");
    }
    const cleanPhone = input.customerPhone.replace(/[^0-9]/g, "");
    if (cleanPhone.length < 8) {
      throw new Error("Nomor WhatsApp tidak valid. Masukkan minimal 8 digit angka.");
    }
    const deliveryAddress = (input.deliveryAddress || input.customerAddress || "").trim();
    if (!deliveryAddress) {
      throw new Error("Alamat pengantaran belanja wajib diisi.");
    }
    const customerDistrict = (input.customerDistrict || "Kecamatan Tumpang").trim();
    if (!Array.isArray(input.items) || input.items.length === 0) {
      throw new Error("Keranjang belanja kosong. Pilih minimal 1 produk.");
    }
    const reqId = (input.clientRequestId || input.idempotencyKey || "").trim();
    if (reqId) {
      const existingReq = this.schema.orders.find((o) => o.clientRequestId === reqId || o.idempotencyKey === reqId);
      if (existingReq) {
        return existingReq;
      }
    }
    const recentWindow = new Date(Date.now() - 15e3).toISOString();
    const duplicateRecent = this.schema.orders.find(
      (o) => o.customerPhone.replace(/[^0-9]/g, "") === cleanPhone && o.createdAt >= recentWindow && o.items.length === input.items.length && o.items.every((it, idx) => it.productId === input.items[idx]?.productId && it.quantity === input.items[idx]?.quantity)
    );
    if (duplicateRecent) {
      return duplicateRecent;
    }
    const validatedItems = [];
    let subtotal = 0;
    for (const itemInput of input.items) {
      if (!itemInput.productId || !itemInput.quantity || itemInput.quantity < 1) {
        throw new Error("Kuantitas produk tidak valid.");
      }
      const product = this.schema.products.find((p) => p.id === itemInput.productId);
      if (!product) {
        throw new Error(`Produk dengan ID "${itemInput.productId}" tidak ditemukan.`);
      }
      if (!product.isActive) {
        throw new Error(`Produk "${product.name}" sedang tidak aktif atau tidak tersedia.`);
      }
      let unitPrice = product.price;
      let selectedVariation = void 0;
      const variationId = itemInput.variationId || itemInput.variantId;
      const optionId = itemInput.optionId;
      if (variationId && product.variations) {
        const variation = product.variations.find((v) => v.id === variationId);
        if (variation) {
          const option = optionId ? variation.options.find((o) => o.id === optionId) : variation.options[0];
          if (option) {
            if (typeof option.stock === "number" && option.stock < itemInput.quantity) {
              throw new Error(`Stok variasi "${option.name}" untuk produk "${product.name}" tidak mencukupi (Tersisa: ${option.stock}, Diminta: ${itemInput.quantity}).`);
            }
            unitPrice = product.price + (option.priceDelta || 0);
            selectedVariation = {
              variationId: variation.id,
              variationName: variation.name,
              optionId: option.id,
              optionName: option.name
            };
          }
        }
      } else {
        if (product.stock < itemInput.quantity) {
          throw new Error(`Stok untuk produk "${product.name}" tidak mencukupi (Tersisa: ${product.stock}, Diminta: ${itemInput.quantity}).`);
        }
      }
      const itemSubtotal = unitPrice * itemInput.quantity;
      subtotal += itemSubtotal;
      validatedItems.push({
        productId: product.id,
        sku: product.sku,
        name: product.name,
        unit: product.unit,
        selectedVariation,
        price: unitPrice,
        quantity: itemInput.quantity,
        subtotal: itemSubtotal
      });
    }
    const minAmount = this.schema.config.minOrderAmount || 0;
    if (subtotal < minAmount) {
      throw new Error(`Subtotal belanja minimal adalah Rp ${minAmount.toLocaleString("id-ID")}. Subtotal saat ini: Rp ${subtotal.toLocaleString("id-ID")}`);
    }
    const method = (input.shippingMethod || input.shippingOption?.code || "INSTANT").toUpperCase();
    let deliveryFee = input.deliveryFee !== void 0 ? Number(input.deliveryFee) : this.schema.config.defaultDeliveryFee || 4e3;
    let shippingMethodLabel = "Kurir Instan Tumpang Go";
    if (method === "PICKUP") {
      deliveryFee = 0;
      shippingMethodLabel = "Ambil Sendiri di Toko (Pickup)";
    } else if (method === "REGULAR") {
      deliveryFee = input.deliveryFee !== void 0 ? Number(input.deliveryFee) : Math.max(0, Math.round((this.schema.config.defaultDeliveryFee || 4e3) * 0.7));
      shippingMethodLabel = "Kurir Reguler Toko (Next-Day)";
    } else if (method === "EXPEDITION_REGULAR") {
      deliveryFee = input.deliveryFee !== void 0 ? Number(input.deliveryFee) : 12e3;
      shippingMethodLabel = "Ekspedisi Domestik Reguler (J&T / JNE)";
    } else if (method === "CHINA_AIR_EXPRESS") {
      deliveryFee = input.deliveryFee !== void 0 ? Number(input.deliveryFee) : 35e3;
      shippingMethodLabel = "China Air Freight Express (7-12 Hari)";
    } else if (method === "CHINA_SEA_STANDARD") {
      deliveryFee = input.deliveryFee !== void 0 ? Number(input.deliveryFee) : 2e4;
      shippingMethodLabel = "China Sea Freight Ekonomis (20-30 Hari)";
    }
    const serviceFee = input.serviceFee !== void 0 ? Number(input.serviceFee) : this.schema.config.serviceFee || 1500;
    const uniqueCode = input.uniqueCode !== void 0 ? Number(input.uniqueCode) : Math.floor(100 + Math.random() * 899);
    const total = subtotal + deliveryFee + serviceFee + uniqueCode;
    for (const item of validatedItems) {
      const prod = this.schema.products.find((p) => p.id === item.productId);
      if (prod) {
        prod.stock = Math.max(0, prod.stock - item.quantity);
        if (item.selectedVariation && prod.variations) {
          const v = prod.variations.find((v2) => v2.id === item.selectedVariation?.variationId);
          const opt = v?.options.find((o) => o.id === item.selectedVariation?.optionId);
          if (opt && typeof opt.stock === "number") {
            opt.stock = Math.max(0, opt.stock - item.quantity);
          }
        }
        prod.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      }
    }
    const now = /* @__PURE__ */ new Date();
    const expiryMinutes = shopEnv.defaults.paymentExpiryMinutes || 30;
    const expiresAt = new Date(now.getTime() + expiryMinutes * 60 * 1e3).toISOString();
    const datePrefix = now.toISOString().slice(0, 10).replace(/-/g, "");
    const dailyCount = this.schema.orders.filter((o) => o.createdAt && o.createdAt.startsWith(now.toISOString().slice(0, 10))).length + 1;
    const orderNumber = `TS-${datePrefix}-${String(dailyCount).padStart(3, "0")}`;
    const isInternational = method.includes("CHINA") || method.includes("CROSSBORDER") || method === "INTERNATIONAL";
    const shipmentScope = isInternational ? "INTERNATIONAL" : "LOCAL";
    const courierCode = isInternational ? "CHINA_ID_CROSSBORDER" : method === "EXPEDITION_REGULAR" ? "DOMESTIC_EXPEDITION" : "TUMPANG_LOCAL";
    const courierName = isInternational ? "Layanan Impor Cross-Border (China \u{1F1E8}\u{1F1F3} \u2192 Indonesia \u{1F1EE}\u{1F1E9})" : method === "EXPEDITION_REGULAR" ? "Ekspedisi Domestik Reguler (J&T / JNE)" : "Kurir Toko Tumpang Go";
    const trackingPrefix = isInternational ? "CN-ID" : method === "EXPEDITION_REGULAR" ? "TS-EXP" : "TS-LOC";
    const trackingNumber = `${trackingPrefix}-${datePrefix}-${String(dailyCount).padStart(3, "0")}`;
    const originCountry = isInternational ? "CN" : "ID";
    const originCity = isInternational ? "Gudang Konsolidasi Shenzhen, China" : "Kecamatan Tumpang, Malang";
    const destinationCountry = "ID";
    const destinationCity = `${customerDistrict}, Malang`;
    const initialTrackingEvent = {
      id: `tevt_${Date.now()}_1`,
      status: "WAITING_DISPATCH" /* WAITING_DISPATCH */,
      location: originCity,
      description: isInternational ? "Pesanan impor telah dibuat. Menunggu pengemasan dari gudang konsolidasi China." : "Pesanan telah dibuat dan siap dikemas setelah pembayaran diverifikasi.",
      timestamp: now.toISOString()
    };
    const estimatedArrival = isInternational ? method === "CHINA_SEA_STANDARD" ? "20-30 hari kalender (Estimasi unverified)" : "7-12 hari kerja (Estimasi unverified)" : method === "EXPEDITION_REGULAR" ? "2-3 hari kerja (Estimasi manual unverified)" : method === "REGULAR" ? "1 hari (Next-day)" : "1-3 jam (Same-day)";
    const initialShipment = {
      id: `ship_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      orderId: `sord_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      trackingNumber,
      courierCode,
      courierName,
      serviceName: shippingMethodLabel,
      scope: shipmentScope,
      originCountry,
      originCity,
      destinationCountry,
      destinationCity,
      status: "WAITING_DISPATCH" /* WAITING_DISPATCH */,
      isEstimateVerified: !isInternational && method !== "EXPEDITION_REGULAR",
      estimatedArrivalNote: estimatedArrival,
      trackingHistory: [initialTrackingEvent],
      createdAt: now.toISOString(),
      updatedAt: now.toISOString()
    };
    const newOrder = {
      id: initialShipment.orderId,
      orderNumber,
      customerName: input.customerName.trim(),
      customerPhone: input.customerPhone.trim(),
      deliveryAddress,
      customerAddress: deliveryAddress,
      customerDistrict,
      shippingMethod: method,
      shippingMethodLabel,
      deliveryNotes: input.deliveryNotes?.trim() || "",
      clientRequestId: reqId || void 0,
      items: validatedItems,
      subtotal,
      deliveryFee,
      serviceFee,
      uniqueCode,
      total,
      paymentStatus: "UNPAID" /* UNPAID */,
      orderStatus: "NEW" /* NEW */,
      paymentExpiresAt: expiresAt,
      shipment: initialShipment,
      shipmentId: initialShipment.id,
      trackingNumber,
      createdAt: now.toISOString(),
      updatedAt: now.toISOString()
    };
    this.schema.orders.unshift(newOrder);
    this.schema.shipments.unshift(initialShipment);
    this.persistToLocal();
    this.logAudit("CREATE_SHOP_ORDER", `Pesanan dibuat: ${newOrder.orderNumber} (Resi: ${trackingNumber}) senilai Rp ${newOrder.total.toLocaleString("id-ID")}`, "CUSTOMER");
    try {
      const pfx = shopEnv.database.firestoreCollectionPrefix;
      await Promise.all([
        safeAdminSetDoc(`${pfx}orders`, newOrder.id, newOrder),
        safeAdminSetDoc(`${pfx}shipments`, initialShipment.id, initialShipment)
      ]);
    } catch {
    }
    return newOrder;
  }
  async attachShipment(order) {
    const scope = order.shippingOption?.scope || "LOCAL";
    const isInternational = scope === "INTERNATIONAL";
    const courierCode = order.shippingOption?.courierCode || "TUMPANG_LOCAL";
    const courierName = order.shippingOption?.courierName || "Kurir Toko Tumpang Go";
    const serviceName = order.shippingOption?.serviceName || "Kurir Toko Reguler";
    const dateStr = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10).replace(/-/g, "");
    const trackingPrefix = isInternational ? "CN-ID" : "TPG";
    const trackingNumber = `${trackingPrefix}-${dateStr}-${Math.floor(100 + Math.random() * 900)}`;
    const initialHistory = [
      {
        id: `ev_${Date.now()}_1`,
        status: "WAITING_DISPATCH" /* WAITING_DISPATCH */,
        location: isInternational ? "Gudang Asal (China)" : "Toko Tumpang Shop",
        description: isInternational ? "Pesanan diterima pemasok internasional, menunggu pengemasan dan jadwal penerbangan ekspor." : "Pesanan telah masuk ke sistem toko dan menunggu pengemasan produk.",
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }
    ];
    const shipment = {
      id: `ship_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      orderId: order.id,
      trackingNumber,
      courierCode,
      courierName,
      serviceName,
      scope,
      originCountry: isInternational ? "CN" : "ID",
      originCity: isInternational ? "Shenzhen / Guangzhou, China" : "Tumpang, Malang",
      destinationCountry: "ID",
      destinationCity: "Tumpang, Malang",
      status: "WAITING_DISPATCH" /* WAITING_DISPATCH */,
      isEstimateVerified: !isInternational,
      estimatedArrivalNote: isInternational ? "Estimasi belum terverifikasi API live kargo internasional, bergantung pada waktu pembersihan bea cukai." : "Estimasi pengantaran kurir toko terverifikasi.",
      trackingHistory: initialHistory,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    order.shipmentId = shipment.id;
    order.trackingNumber = trackingNumber;
    this.schema.shipments.unshift(shipment);
    try {
      const pfx = shopEnv.database.firestoreCollectionPrefix;
      await safeAdminSetDoc(`${pfx}shipments`, shipment.id, shipment);
    } catch {
    }
  }
  getOrders(filter) {
    let list = [...this.schema.orders];
    if (filter?.paymentStatus) list = list.filter((o) => o.paymentStatus === filter.paymentStatus);
    if (filter?.orderStatus) list = list.filter((o) => o.orderStatus === filter.orderStatus);
    return list;
  }
  getOrderById(id) {
    return this.schema.orders.find((o) => o.id === id);
  }
  getOrderByNumberAndPhone(orderNumberOrId, phone) {
    const cleanPhone = phone.replace(/[^0-9]/g, "");
    return this.schema.orders.find((o) => {
      const matchId = o.id === orderNumberOrId || o.orderNumber === orderNumberOrId;
      const oPhone = o.customerPhone.replace(/[^0-9]/g, "");
      const matchPhone = oPhone === cleanPhone || oPhone.endsWith(cleanPhone) || cleanPhone.endsWith(oPhone);
      return matchId && matchPhone;
    });
  }
  async findOrderById(id) {
    const local = this.getOrderById(id) || this.schema.orders.find((o) => o.orderNumber === id);
    if (local) return local;
    try {
      const pfx = shopEnv.database.firestoreCollectionPrefix;
      const doc = await safeAdminGetDoc(`${pfx}orders`, id);
      if (doc) return doc;
    } catch {
    }
    return void 0;
  }
  async findOrderByNumberAndPhone(numberOrId, phone) {
    return this.getOrderByNumberAndPhone(numberOrId, phone);
  }
  getOrdersByCustomerPhone(phone) {
    const clean = phone.replace(/[^0-9]/g, "");
    return this.schema.orders.filter((o) => {
      const op = o.customerPhone.replace(/[^0-9]/g, "");
      return op === clean || op.endsWith(clean) || clean.endsWith(op);
    });
  }
  async uploadPaymentProof(orderIdOrNumber, paymentProofUrl) {
    const order = this.getOrderById(orderIdOrNumber) || this.schema.orders.find((o) => o.orderNumber === orderIdOrNumber);
    if (!order) throw new Error(`Pesanan ${orderIdOrNumber} tidak ditemukan.`);
    order.paymentProof = paymentProofUrl;
    order.paymentStatus = "WAITING_VERIFICATION" /* WAITING_VERIFICATION */;
    order.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    this.persistToLocal();
    this.logAudit("UPLOAD_PAYMENT_PROOF", `Bukti bayar diunggah untuk #${order.orderNumber}`, order.customerName);
    try {
      const pfx = shopEnv.database.firestoreCollectionPrefix;
      await safeAdminSetDoc(`${pfx}orders`, order.id, order);
    } catch {
    }
    return order;
  }
  async verifyPayment(actor, orderIdOrNumber, approved, reason) {
    const order = this.getOrderById(orderIdOrNumber) || this.schema.orders.find((o) => o.orderNumber === orderIdOrNumber);
    if (!order) throw new Error(`Pesanan ${orderIdOrNumber} tidak ditemukan.`);
    const now = (/* @__PURE__ */ new Date()).toISOString();
    if (approved) {
      order.paymentStatus = "PAID" /* PAID */;
      order.orderStatus = "PROCESSING" /* PROCESSING */;
      order.paidAt = now;
      this.logAudit("VERIFY_PAYMENT_APPROVED", `Pembayaran pesanan #${order.orderNumber} diverifikasi sah oleh ${actor}`, actor);
    } else {
      order.paymentStatus = "REJECTED" /* REJECTED */;
      order.rejectionReason = reason || "Bukti transfer tidak valid atau dana belum masuk.";
      this.logAudit("VERIFY_PAYMENT_REJECTED", `Pembayaran pesanan #${order.orderNumber} ditolak oleh ${actor}: ${order.rejectionReason}`, actor);
    }
    order.updatedAt = now;
    this.persistToLocal();
    try {
      const pfx = shopEnv.database.firestoreCollectionPrefix;
      await safeAdminSetDoc(`${pfx}orders`, order.id, order);
    } catch {
    }
    return order;
  }
  async attachArtopayPayment(orderId, details) {
    const order = this.getOrderById(orderId) || this.schema.orders.find((o) => o.orderNumber === orderId);
    if (!order) throw new Error(`Pesanan Shop ${orderId} tidak ditemukan.`);
    Object.assign(order, details, { updatedAt: (/* @__PURE__ */ new Date()).toISOString() });
    this.persistToLocal();
    try {
      const pfx = shopEnv.database.firestoreCollectionPrefix;
      await safeAdminSetDoc(`${pfx}orders`, order.id, order);
    } catch {
    }
    return order;
  }
  async updateOrderStatus(actor, orderIdOrNumber, status, reason) {
    const order = this.getOrderById(orderIdOrNumber) || this.schema.orders.find((o) => o.orderNumber === orderIdOrNumber);
    if (!order) throw new Error(`Pesanan ${orderIdOrNumber} tidak ditemukan.`);
    const oldStatus = order.orderStatus;
    order.orderStatus = status;
    order.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    if (status === "CANCELLED" /* CANCELLED */ && oldStatus !== "CANCELLED" /* CANCELLED */) {
      order.cancelledAt = (/* @__PURE__ */ new Date()).toISOString();
      order.cancellationReason = reason || "Pesanan dibatalkan oleh pengguna atau admin toko.";
      for (const item of order.items) {
        const prod = this.getProductById(item.productId);
        if (prod) {
          prod.stock += item.quantity;
          prod.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
        }
      }
      this.logAudit("CANCEL_ORDER_STOCK_RESTORED", `Pesanan #${order.orderNumber} dibatalkan. Stok dipulihkan oleh ${actor}`, actor);
    } else {
      this.logAudit("UPDATE_ORDER_STATUS", `Status pesanan #${order.orderNumber} diubah ke ${status} oleh ${actor}`, actor);
    }
    this.persistToLocal();
    try {
      const pfx = shopEnv.database.firestoreCollectionPrefix;
      await safeAdminSetDoc(`${pfx}orders`, order.id, order);
    } catch {
    }
    return order;
  }
  // --- SHIPMENTS ---
  getShipments() {
    return [...this.schema.shipments];
  }
  getShipmentById(id) {
    return this.schema.shipments.find((s) => s.id === id);
  }
  getShipmentByOrderId(orderId) {
    return this.schema.shipments.find((s) => s.orderId === orderId);
  }
  getShipmentByTrackingNumber(trackingNumber) {
    const clean = trackingNumber.trim().toUpperCase();
    return this.schema.shipments.find((s) => s.trackingNumber.toUpperCase() === clean);
  }
  getShippingOptions() {
    return courierRegistry.getAvailableShippingOptions();
  }
  async createShipment(actor, data) {
    const shipment = {
      id: `ship_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      orderId: data.orderId || "",
      trackingNumber: data.trackingNumber || `TPG-${Date.now().toString().slice(-6)}`,
      courierCode: data.courierCode || "TUMPANG_LOCAL",
      courierName: data.courierName || "Kurir Toko Tumpang",
      serviceName: data.serviceName || "Reguler Toko",
      scope: data.scope || "LOCAL",
      originCountry: data.originCountry || "ID",
      originCity: data.originCity || "Tumpang",
      destinationCountry: data.destinationCountry || "ID",
      destinationCity: data.destinationCity || "Tumpang",
      status: data.status || "WAITING_DISPATCH" /* WAITING_DISPATCH */,
      isEstimateVerified: data.isEstimateVerified !== void 0 ? data.isEstimateVerified : true,
      trackingHistory: data.trackingHistory || [],
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.schema.shipments.unshift(shipment);
    this.persistToLocal();
    this.logAudit("CREATE_SHIPMENT", `Pengiriman dibuat #${shipment.trackingNumber} oleh ${actor}`, actor);
    return shipment;
  }
  async updateShipmentStatus(actor, id, status, details) {
    const val = ShopSchemaValidator.validateShipmentStatus(status);
    if (!val.isValid) throw new Error(val.error);
    const shipment = this.getShipmentById(id);
    if (!shipment) throw new Error(`Pengiriman ${id} tidak ditemukan.`);
    const statusLabels = {
      WAITING_DISPATCH: "Menunggu Pengiriman",
      PROCESSING: "Diproses di Gudang",
      DISPATCHED: "Dikirim dari Negara Asal",
      IN_TRANSIT: "Dalam Perjalanan Internasional",
      ARRIVED_INDONESIA: "Tiba di Indonesia",
      CUSTOMS_CLEARANCE: "Pemeriksaan Bea Cukai",
      CUSTOMS_HOLD: "Tertahan di Bea Cukai",
      TRANSFERRED_LOCAL_COURIER: "Diteruskan Kurir Lokal",
      OUT_FOR_DELIVERY: "Dalam Pengantaran",
      DELIVERED: "Terkirim",
      FAILED_DELIVERY: "Gagal Dikirim",
      RETURNED_TO_SENDER: "Dikembalikan ke Pengirim"
    };
    const statusLabel = statusLabels[status] || status;
    shipment.status = status;
    shipment.statusLabel = statusLabel;
    shipment.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    const event = {
      id: `tevt_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      status,
      statusLabel,
      location: details?.location || (shipment.scope === "INTERNATIONAL" ? "Hub Logistik Internasional" : "Area Tumpang"),
      description: details?.description || `Pembaruan status pengiriman: ${statusLabel}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
    shipment.trackingHistory.unshift(event);
    const order = this.getOrderById(shipment.orderId);
    if (order) {
      if (order.shipment) {
        order.shipment.status = status;
        order.shipment.statusLabel = statusLabel;
        order.shipment.trackingHistory = shipment.trackingHistory;
      }
      if (status === "DELIVERED" /* DELIVERED */ && order.orderStatus !== "COMPLETED" /* COMPLETED */) {
        order.orderStatus = "COMPLETED" /* COMPLETED */;
        order.deliveredAt = (/* @__PURE__ */ new Date()).toISOString();
      }
      order.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
    }
    this.persistToLocal();
    this.logAudit("UPDATE_SHIPMENT_STATUS", `Status pengiriman #${shipment.trackingNumber} diubah ke ${status} oleh ${actor}`, actor);
    try {
      const pfx = shopEnv.database.firestoreCollectionPrefix;
      await safeAdminSetDoc(`${pfx}shipments`, shipment.id, shipment);
    } catch {
    }
    return shipment;
  }
  // --- REPORTS & METRICS ---
  getSummaryMetrics() {
    const paidOrders = this.schema.orders.filter((o) => o.paymentStatus === "PAID" /* PAID */);
    const totalRevenue = paidOrders.reduce((sum, o) => sum + (o.total || 0), 0);
    const lowStockList = this.schema.products.filter((p) => p.isActive && p.stock <= 10);
    return {
      totalRevenue,
      totalOrdersCount: this.schema.orders.length,
      paidOrdersCount: paidOrders.length,
      pendingOrdersCount: this.schema.orders.filter((o) => o.paymentStatus === "UNPAID" /* UNPAID */ || o.paymentStatus === "WAITING_VERIFICATION" /* WAITING_VERIFICATION */).length,
      activeProductsCount: this.schema.products.filter((p) => p.isActive).length,
      lowStockProducts: lowStockList.length,
      lowStockList,
      recentOrders: this.schema.orders.slice(0, 10)
    };
  }
  getTransactionReport(startDate, endDate) {
    let orders = [...this.schema.orders];
    if (startDate) {
      const s = new Date(startDate).getTime();
      orders = orders.filter((o) => new Date(o.createdAt).getTime() >= s);
    }
    if (endDate) {
      const e = new Date(endDate).getTime();
      orders = orders.filter((o) => new Date(o.createdAt).getTime() <= e);
    }
    const paidOrders = orders.filter((o) => o.paymentStatus === "PAID" /* PAID */);
    const totalRevenue = paidOrders.reduce((sum, o) => sum + (o.total || 0), 0);
    const summary = {
      totalRevenue,
      totalOrdersCount: orders.length,
      paidOrdersCount: paidOrders.length
    };
    return {
      totalRevenue,
      totalOrdersCount: orders.length,
      paidOrdersCount: paidOrders.length,
      summary,
      orders
    };
  }
};
var shopDb = new ShopDatabase();

// src/services/shop/api/shopAuth.ts
var import_crypto2 = __toESM(require("crypto"), 1);
function createShopAuthToken(user, expiresInHours = 24) {
  const secret = shopEnv.auth.jwtSecret;
  if (!secret || secret.length < 32) {
    throw new Error("SHOP_AUTH_SECRET belum dikonfigurasi dengan aman (minimal 32 karakter).");
  }
  const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url");
  const payload = Buffer.from(
    JSON.stringify({
      userId: user.userId,
      email: user.email,
      role: user.role || "SHOP_ADMIN",
      scope: "shop",
      exp: Math.floor(Date.now() / 1e3) + expiresInHours * 3600
    })
  ).toString("base64url");
  const signature = import_crypto2.default.createHmac("sha256", secret).update(`${header}.${payload}`).digest("base64url");
  return `${header}.${payload}.${signature}`;
}
function verifyShopAuthToken(token) {
  if (!token) return null;
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const [header, payload, signature] = parts;
    const secret = shopEnv.auth.jwtSecret;
    if (!secret) return null;
    const expectedSig = import_crypto2.default.createHmac("sha256", secret).update(`${header}.${payload}`).digest("base64url");
    if (signature.length !== expectedSig.length) return null;
    const isValid = import_crypto2.default.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSig));
    if (!isValid) return null;
    const decoded = JSON.parse(Buffer.from(payload, "base64url").toString("utf-8"));
    if (decoded.exp && decoded.exp < Math.floor(Date.now() / 1e3)) {
      return null;
    }
    return {
      userId: decoded.userId,
      email: decoded.email,
      role: decoded.role,
      scope: "shop"
    };
  } catch {
    return null;
  }
}
function attachShopUser(req, _res, next) {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith("Bearer ")) {
    const token = authHeader.substring(7).trim();
    let verified = verifyShopAuthToken(token);
    if (!verified) {
      const globalUser = verifyAuthToken(token);
      if (globalUser && (globalUser.role === "MASTER_ADMIN" || globalUser.isMasterAdmin)) {
        verified = {
          userId: globalUser.userId,
          email: globalUser.email,
          role: "SHOP_ADMIN",
          scope: "shop"
        };
      }
    }
    if (verified) {
      req.shopUser = verified;
      req.user = verified;
    }
  }
  next();
}
function requireShopAdmin(req, res, next) {
  const user = req.shopUser || req.user;
  if (!user) {
    return res.status(401).json({
      error: "Autentikasi diperlukan. Silakan login sebagai Admin Tumpang Shop."
    });
  }
  if (user.role !== "SHOP_ADMIN" && user.role !== "MASTER_ADMIN") {
    return res.status(403).json({
      error: "Akses ditolak: Operasi ini membutuhkan hak akses Admin Tumpang Shop atau Master Admin."
    });
  }
  next();
}

// src/lib/artopay.ts
var import_crypto3 = __toESM(require("crypto"), 1);
function extractArtoPayCheckoutUrl(data) {
  if (!data || typeof data !== "object") return null;
  const directKeys = [
    "checkoutUrl",
    "checkout_url",
    "paymentUrl",
    "payment_url",
    "paymentLink",
    "payment_link",
    "redirectUrl",
    "redirect_url",
    "invoiceUrl",
    "invoice_url",
    "url"
  ];
  for (const k of directKeys) {
    if (typeof data[k] === "string" && data[k].trim().startsWith("http")) {
      return data[k].trim();
    }
  }
  const envelopeKeys = ["payload", "data", "responseData", "result", "payment", "action", "nextAction", "next_action"];
  for (const ek of envelopeKeys) {
    if (data[ek] && typeof data[ek] === "object") {
      const nested = extractArtoPayCheckoutUrl(data[ek]);
      if (nested) return nested;
    }
  }
  if (Array.isArray(data.actions)) {
    for (const act of data.actions) {
      if (act && typeof act.url === "string" && act.url.trim().startsWith("http")) {
        return act.url.trim();
      }
    }
  }
  return null;
}
function extractArtoPayTransactionId(data) {
  if (!data || typeof data !== "object") return null;
  const directKeys = ["id", "paymentIntentId", "payment_intent_id", "paymentId", "payment_id", "transactionId", "transaction_id", "uuid"];
  for (const k of directKeys) {
    if (typeof data[k] === "string" && data[k].trim().length > 0) {
      return data[k].trim();
    }
  }
  const envelopeKeys = ["payload", "data", "responseData", "result", "payment"];
  for (const ek of envelopeKeys) {
    if (data[ek] && typeof data[ek] === "object") {
      const nested = extractArtoPayTransactionId(data[ek]);
      if (nested) return nested;
    }
  }
  return null;
}
function findArtoPayTransactionIdField(data) {
  if (!data || typeof data !== "object") return null;
  const directKeys = ["id", "paymentIntentId", "payment_intent_id", "paymentId", "payment_id", "transactionId", "transaction_id", "uuid"];
  for (const k of directKeys) {
    if (typeof data[k] === "string" && data[k].trim().length > 0) {
      return k;
    }
  }
  const envelopeKeys = ["payload", "data", "responseData", "result", "payment"];
  for (const ek of envelopeKeys) {
    if (data[ek] && typeof data[ek] === "object") {
      const nested = findArtoPayTransactionIdField(data[ek]);
      if (nested) return `${ek}.${nested}`;
    }
  }
  return null;
}
function findArtoPayCheckoutUrlField(data) {
  if (!data || typeof data !== "object") return null;
  const directKeys = [
    "checkoutUrl",
    "checkout_url",
    "paymentUrl",
    "payment_url",
    "paymentLink",
    "payment_link",
    "redirectUrl",
    "redirect_url",
    "invoiceUrl",
    "invoice_url",
    "url"
  ];
  for (const k of directKeys) {
    if (typeof data[k] === "string" && data[k].trim().startsWith("http")) {
      return k;
    }
  }
  const envelopeKeys = ["payload", "data", "responseData", "result", "payment", "action", "nextAction", "next_action"];
  for (const ek of envelopeKeys) {
    if (data[ek] && typeof data[ek] === "object") {
      const nested = findArtoPayCheckoutUrlField(data[ek]);
      if (nested) return `${ek}.${nested}`;
    }
  }
  if (Array.isArray(data.actions)) {
    for (let i = 0; i < data.actions.length; i++) {
      const act = data.actions[i];
      if (act && typeof act.url === "string" && act.url.trim().startsWith("http")) {
        return `actions[${i}].url`;
      }
    }
  }
  return null;
}
function extractArtoPayClientSecret(data) {
  if (!data || typeof data !== "object") return "";
  const directKeys = ["secret", "clientSecret", "client_secret"];
  for (const k of directKeys) {
    if (typeof data[k] === "string" && data[k].trim().length > 0) return data[k].trim();
  }
  const envelopeKeys = ["payload", "data", "responseData", "result"];
  for (const ek of envelopeKeys) {
    if (data[ek] && typeof data[ek] === "object") {
      const nested = extractArtoPayClientSecret(data[ek]);
      if (nested) return nested;
    }
  }
  return "";
}
function extractArtoPayCustomerToken(data) {
  if (!data || typeof data !== "object") return "";
  const directKeys = ["customerToken", "customer_token", "token"];
  for (const k of directKeys) {
    if (typeof data[k] === "string" && data[k].trim().length > 0) return data[k].trim();
  }
  const envelopeKeys = ["payload", "data", "responseData", "result"];
  for (const ek of envelopeKeys) {
    if (data[ek] && typeof data[ek] === "object") {
      const nested = extractArtoPayCustomerToken(data[ek]);
      if (nested) return nested;
    }
  }
  return "";
}
function extractArtoPayPublicKey(data) {
  if (!data || typeof data !== "object") return "";
  const directKeys = ["publicKey", "public_key", "clientKey", "client_key"];
  for (const k of directKeys) {
    if (typeof data[k] === "string" && data[k].trim().length > 0) return data[k].trim();
  }
  const envelopeKeys = ["payload", "data", "responseData", "result"];
  for (const ek of envelopeKeys) {
    if (data[ek] && typeof data[ek] === "object") {
      const nested = extractArtoPayPublicKey(data[ek]);
      if (nested) return nested;
    }
  }
  return "";
}
function cleanPublicKey(key) {
  if (!key || typeof key !== "string") return void 0;
  let trimmed = key.trim();
  if (trimmed.startsWith("'") && trimmed.endsWith("'") || trimmed.startsWith('"') && trimmed.endsWith('"')) {
    trimmed = trimmed.slice(1, -1).trim();
  }
  if (trimmed.startsWith("%") || trimmed.includes("%VITE_") || trimmed === "undefined" || trimmed === "null" || trimmed.length < 5) {
    return void 0;
  }
  return trimmed;
}
var ArtoPayService = class {
  /**
   * Generates a new Payment Intent through ArtoPay Payment Link API.
   * Conforms to official ArtoPay API spec (/v1.1/payment-intents & /v1/payment-intents).
   * Enforces strict server-side nominal validation.
   * Never generates fake demo IDs or simulated transactions for customer flows.
   */
  static async createPaymentIntent(params) {
    const { orderId, amount, serviceType, customerName, customerPhone, customerEmail } = params;
    const cleanOrderId = typeof orderId === "string" ? orderId.trim() : "";
    if (!cleanOrderId) {
      throw new Error("Order ID wajib disertakan dan berupa string yang valid (tidak boleh kosong).");
    }
    if (!Number.isInteger(amount) || amount <= 0) {
      throw new Error(`Nominal pembayaran tidak valid: Rp ${amount}. Nominal harus berupa bilangan bulat positif.`);
    }
    const currency = (params.currency || "IDR").toUpperCase();
    if (currency !== "IDR") {
      throw new Error(`Mata uang "${currency}" tidak didukung. ArtoPay QRIS hanya mendukung mata uang IDR.`);
    }
    const expiryMinutes = params.expiryMinutes || artopayConfig.defaultExpiryMinutes || 15;
    const expiresAt = new Date(Date.now() + expiryMinutes * 60 * 1e3).toISOString();
    const createdAt = (/* @__PURE__ */ new Date()).toISOString();
    if (!artopayConfig.secretKey && !params.customFetch) {
      throw new Error(
        "Kredensial gateway ArtoPay belum dikonfigurasi (ARTOPAY_SECRET_KEY belum disetel di Environment Variables). Silakan masukkan Secret Key resmi dari Dashboard ArtoPay untuk mengaktifkan pembuatan QRIS dinamis."
      );
    }
    const payload = {
      orderId: cleanOrderId,
      amount: String(amount),
      currency: "IDR",
      customerId: customerPhone ? customerPhone.replace(/\D/g, "") : `cust_${Date.now()}`,
      description: params.description || `Pembayaran tumpangGo ${serviceType} #${cleanOrderId}`,
      customerName: customerName || void 0,
      customerPhone: customerPhone || void 0,
      customerEmail: customerEmail || void 0,
      callbackUrl: params.callbackUrl,
      returnUrl: params.returnUrl,
      metadata: {
        orderId: cleanOrderId,
        serviceType,
        customerName,
        customerPhone,
        customerEmail: customerEmail || void 0
      }
    };
    if (artopayConfig.businessUnitCode) {
      payload.businessUnit = artopayConfig.businessUnitCode;
      payload.businessUnitCode = artopayConfig.businessUnitCode;
    }
    const headers = {
      "Content-Type": "application/json",
      "X-Secret-Key": artopayConfig.secretKey || "mock_secret_key"
    };
    if (artopayConfig.apiKey) {
      headers["X-API-Key"] = artopayConfig.apiKey;
    }
    if (artopayConfig.businessUnitCode) {
      headers["X-Business-Unit"] = artopayConfig.businessUnitCode;
    }
    const fetchClient = params.customFetch || fetch;
    let response = null;
    try {
      response = await fetchClient(`${artopayConfig.baseUrl}/v1.1/payment-intents`, {
        method: "POST",
        headers,
        body: JSON.stringify(payload)
      });
    } catch (err) {
      throw new Error(`Gagal menghubungi server gateway ArtoPay (${artopayConfig.baseUrl}): ${err?.message || "Koneksi jaringan gagal"}`);
    }
    const contentType = response.headers.get("content-type") || "";
    let resJson = null;
    let rawText = "";
    try {
      rawText = await response.text();
      resJson = JSON.parse(rawText);
    } catch {
      console.error("[ArtoPay Error] Respons dari gateway bukan format JSON yang valid:", {
        httpStatus: response.status,
        contentType,
        rawSnippet: rawText.substring(0, 300)
      });
      throw new Error(
        `Gateway ArtoPay mengembalikan respons non-JSON (HTTP ${response.status}, Content-Type: ${contentType}). Isi respons: "${rawText.substring(0, 150)}..."`
      );
    }
    if (!response.ok) {
      const status = response.status;
      const errDetail = resJson?.message || resJson?.responseMessage || resJson?.error || JSON.stringify(resJson);
      console.warn("[ArtoPay Gateway Rejection]", {
        httpStatus: status,
        contentType,
        environment: artopayConfig.environment,
        baseUrl: artopayConfig.baseUrl,
        errorDetail: errDetail
      });
      throw new Error(`Gateway ArtoPay menolak pembuatan transaksi (HTTP ${status}): ${errDetail || "Permintaan tidak dapat diproses"}`);
    }
    const returnedId = extractArtoPayTransactionId(resJson);
    const returnedUrl = extractArtoPayCheckoutUrl(resJson);
    const clientSecret = extractArtoPayClientSecret(resJson);
    const customerToken = extractArtoPayCustomerToken(resJson);
    const returnedPublicKey = extractArtoPayPublicKey(resJson);
    const topKeys = typeof resJson === "object" && resJson !== null ? Object.keys(resJson) : [];
    const nestedData = resJson.payload || resJson.data || resJson.responseData || null;
    const nestedKeys = nestedData && typeof nestedData === "object" ? Object.keys(nestedData) : [];
    const txIdField = findArtoPayTransactionIdField(resJson);
    const checkoutUrlField = findArtoPayCheckoutUrlField(resJson);
    const isHttpSuccess = response.status >= 200 && response.status < 300;
    const gatewayBusinessStatus = resJson.status || nestedData?.status || resJson.responseMessage || void 0;
    const isBusinessSuccess = isHttpSuccess && (gatewayBusinessStatus === "created" || gatewayBusinessStatus === "Success" || gatewayBusinessStatus === "SUCCESS" || resJson.responseCode === "2000000" || resJson.responseCode === "2002700");
    const isHostedPaymentLinkReady = Boolean(returnedUrl);
    const diagnostic = {
      httpStatus: response.status,
      contentType,
      environment: artopayConfig.environment,
      baseUrl: artopayConfig.baseUrl,
      businessCodeProvided: Boolean(artopayConfig.businessUnitCode),
      topLevelKeys: topKeys,
      nestedDataKeys: nestedKeys,
      transactionIdField: txIdField,
      transactionIdExtracted: Boolean(returnedId),
      checkoutUrlField: checkoutUrlField || "none",
      checkoutUrlFound: Boolean(returnedUrl),
      gatewayCode: resJson.code || resJson.responseCode || void 0,
      gatewayMessage: resJson.message || resJson.responseMessage || void 0,
      gatewayStatus: gatewayBusinessStatus,
      isHttpSuccess,
      isBusinessSuccess,
      isHostedPaymentLinkReady
    };
    console.log("[ArtoPay Gateway Diagnostic]", diagnostic);
    if (!returnedId) {
      throw new Error(
        `Gateway ArtoPay merespons berhasil (HTTP ${response.status}), namun tidak mengembalikan ID transaksi yang valid. Field respons: [${topKeys.join(", ")}]`
      );
    }
    if (params.requireHostedCheckoutUrl && !returnedUrl) {
      throw new Error(
        `Gateway ArtoPay merespons berhasil (HTTP ${response.status}), namun payload respons tidak memuat URL checkout resmi (checkoutUrl) untuk mengalihkan pelanggan. ID Transaksi: ${returnedId}. Respons: ${JSON.stringify(resJson).substring(0, 160)}`
      );
    }
    if (!returnedUrl && !clientSecret && !customerToken) {
      throw new Error(
        `Gateway ArtoPay merespons berhasil (HTTP ${response.status}), namun payload respons tidak memuat URL checkout resmi (checkoutUrl) maupun kredensial SDK modal (secret / customerToken). ID Transaksi: ${returnedId}. Respons: ${JSON.stringify(resJson).substring(0, 160)}`
      );
    }
    const finalCheckoutUrl = returnedUrl || "";
    return {
      success: true,
      id: returnedId,
      paymentIntentId: returnedId,
      orderId,
      serviceType,
      amount,
      currency: "IDR",
      checkoutUrl: finalCheckoutUrl,
      qrString: resJson.qrString || nestedData?.qrString || resJson.qrCodeUrl || nestedData?.qrCodeUrl || void 0,
      clientSecret,
      customerToken,
      publicKey: cleanPublicKey(returnedPublicKey || artopayConfig.publicKey) || void 0,
      sandbox: artopayConfig.environment !== "production",
      status: "PENDING",
      expiresAt: resJson.expiresAt || nestedData?.expiresAt || expiresAt,
      createdAt,
      gatewayConfigured: true
    };
  }
  /**
   * Verifies authenticity of ArtoPay Webhook request.
   * Uses HMAC-SHA256 signature verification with timing-attack prevention.
   */
  static verifyWebhookSignature(rawBody, signatureHeader, secretOverride) {
    const secret = secretOverride || artopayConfig.webhookSecret || artopayConfig.secretKey;
    const isProduction = artopayConfig.isProduction || artopayConfig.environment === "production";
    if (!secret) {
      if (isProduction) {
        return { isValid: false, reason: "ARTOPAY_WEBHOOK_SECRET belum dikonfigurasi di server." };
      }
      console.warn("[ArtoPay Security Warning] ARTOPAY_WEBHOOK_SECRET belum disetel pada mode development/sandbox.");
      return { isValid: true };
    }
    if (!signatureHeader || signatureHeader.trim().length === 0) {
      return { isValid: false, reason: "Header tanda tangan webhook (x-artopay-signature) tidak ditemukan." };
    }
    try {
      let timestamp = "";
      let expectedHmac = signatureHeader.trim();
      if (signatureHeader.includes("t=") && signatureHeader.includes("v1=")) {
        const parts = signatureHeader.split(",");
        for (const part of parts) {
          const trimmed = part.trim();
          if (trimmed.startsWith("t=")) timestamp = trimmed.substring(2);
          if (trimmed.startsWith("v1=")) expectedHmac = trimmed.substring(3);
        }
      }
      const payloadToSign = timestamp ? `${timestamp}.${rawBody}` : rawBody;
      const calculatedHmac = import_crypto3.default.createHmac("sha256", secret).update(payloadToSign).digest("hex");
      const hmacBuf = Buffer.from(calculatedHmac, "hex");
      const expectedBuf = Buffer.from(expectedHmac, "hex");
      if (hmacBuf.length !== expectedBuf.length || !import_crypto3.default.timingSafeEqual(hmacBuf, expectedBuf)) {
        return { isValid: false, reason: "Tanda tangan HMAC-SHA256 tidak cocok (Invalid Signature)." };
      }
      if (timestamp) {
        const tsNum = parseInt(timestamp, 10);
        if (!isNaN(tsNum)) {
          const nowSec = Math.floor(Date.now() / 1e3);
          if (Math.abs(nowSec - tsNum) > 300) {
            return { isValid: false, reason: "Stempel waktu (timestamp) webhook kedaluwarsa atau terindikasi replay attack." };
          }
        }
      }
      return { isValid: true };
    } catch (err) {
      return { isValid: false, reason: `Gagal memverifikasi tanda tangan webhook: ${err.message}` };
    }
  }
  /**
   * Actively queries the payment status from ArtoPay Gateway.
   */
  static async checkPaymentStatus(paymentIntentId) {
    if (!paymentIntentId) {
      return { status: "PENDING" };
    }
    if (artopayConfig.secretKey) {
      try {
        const headers = {
          "X-Secret-Key": artopayConfig.secretKey
        };
        const response = await fetch(`${artopayConfig.baseUrl}/v1.1/payment-intents/${paymentIntentId}`, { headers });
        if (response.ok) {
          const json = await response.json();
          const d = json.data || json;
          const gatewayStatus = (d.status || d.transactionStatus || d.transaction_status || "").toUpperCase();
          if (["PAID", "SUCCESS", "SETTLED", "CAPTURE", "SETTLEMENT"].includes(gatewayStatus)) {
            return {
              status: "SUCCESS",
              paidAt: d.paidAt || d.settlementTime || (/* @__PURE__ */ new Date()).toISOString(),
              amount: d.amount ? Number(d.amount) : void 0,
              raw: d
            };
          }
          if (["EXPIRED", "TIMED_OUT", "EXPIRE"].includes(gatewayStatus)) {
            return { status: "EXPIRED", raw: d };
          }
          if (["FAILED", "CANCELLED", "REJECTED", "DENY", "CANCEL", "FAILURE"].includes(gatewayStatus)) {
            return { status: "FAILED", raw: d };
          }
        }
      } catch (err) {
        console.warn(`[ArtoPay Status Check] Error querying ${paymentIntentId}:`, err.message);
      }
    }
    return { status: "PENDING" };
  }
};

// src/services/shop/api/shopApp.ts
var shopApp = (0, import_express.default)();
shopApp.use(import_express.default.json({ limit: "15mb" }));
shopApp.use(import_express.default.urlencoded({ extended: true, limit: "15mb" }));
shopApp.use((req, res, next) => {
  const reqId = req.headers["x-request-id"] || "shop_" + Math.random().toString(36).substring(2, 9);
  req.id = String(reqId);
  res.setHeader("X-Shop-Request-Id", req.id);
  const start = Date.now();
  res.on("finish", () => {
    const duration = Date.now() - start;
    const status = res.statusCode;
    const logFn = status >= 500 ? console.error : status >= 400 ? console.warn : console.log;
    logFn(`[SHOP-API] [${req.id}] ${req.method} ${req.originalUrl || req.url} -> ${status} (${duration}ms)`);
  });
  next();
});
shopApp.use(async (_req, _res, next) => {
  try {
    await shopDb.ensureInitialized();
  } catch (err) {
    console.warn("[Shop App Sync Warning]", err?.message || err);
  }
  next();
});
shopApp.use(attachShopUser);
var router = import_express.default.Router();
router.get("/health", async (_req, res) => {
  try {
    const status = await shopDb.getStorageStatus();
    res.json({
      service: "tumpang-shop-service",
      status: "healthy",
      database: status,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  } catch (err) {
    res.status(500).json({
      service: "tumpang-shop-service",
      status: "error",
      error: err?.message || "Gagal memeriksa kesehatan service shop."
    });
  }
});
router.post(["/auth/login", "/login"], (req, res) => {
  const { username, email, password } = req.body;
  const targetUser = (username || email || "").trim().toLowerCase();
  const rawPassStr = String(password || "");
  const targetPass = rawPassStr.trim();
  if (!targetUser || !targetPass) {
    return res.status(400).json({ error: "Email dan kata sandi wajib diisi." });
  }
  if (shopEnv.isProduction) {
    if (!shopEnv.auth.adminPassword || shopEnv.auth.adminPassword.length < 8) {
      return res.status(500).json({
        error: "Autentikasi Shop Admin dinonaktifkan: SHOP_ADMIN_PASSWORD belum dikonfigurasi di Environment Variables.",
        diagnostic: { code: "CONFIG_ENV_MISSING", reason: "SHOP_ADMIN_PASSWORD_UNSET" }
      });
    }
    if (!shopEnv.auth.jwtSecret || shopEnv.auth.jwtSecret.length < 32) {
      return res.status(500).json({
        error: "Autentikasi Shop Admin dinonaktifkan: SHOP_AUTH_SECRET belum dikonfigurasi di Environment Variables.",
        diagnostic: { code: "CONFIG_ENV_MISSING", reason: "SHOP_AUTH_SECRET_UNSET" }
      });
    }
    if (targetPass === "TumpangShopAdmin#2026") {
      return res.status(401).json({
        error: "Kata sandi default ditolak pada lingkungan produksi demi keamanan. Atur SHOP_ADMIN_PASSWORD di environment variable.",
        diagnostic: { code: "DEFAULT_PASSWORD_REJECTED_IN_PROD" }
      });
    }
  }
  const isMasterUser = isMasterAdminEmail(targetUser);
  if (isMasterUser) {
    const creds = getMasterAccountCredentials();
    const activeMasterPassword = creds.password;
    const dbMaster = foodDb.getMasterAccount();
    let isMasterPassValid = false;
    if (dbMaster?.passwordHash && dbMaster.passwordHash.startsWith("pbkdf2$")) {
      const { valid: validTrimmed } = verifyPassword(targetPass, dbMaster.passwordHash);
      const { valid: validRaw } = verifyPassword(rawPassStr, dbMaster.passwordHash);
      if (validTrimmed || validRaw) isMasterPassValid = true;
    }
    if (!isMasterPassValid && creds.hasExplicitEnv && activeMasterPassword) {
      const hashTarget = import_crypto4.default.createHash("sha256").update(activeMasterPassword).digest();
      const hashTrimmed = import_crypto4.default.createHash("sha256").update(targetPass).digest();
      const hashRaw = import_crypto4.default.createHash("sha256").update(rawPassStr).digest();
      if (import_crypto4.default.timingSafeEqual(hashTrimmed, hashTarget) || import_crypto4.default.timingSafeEqual(hashRaw, hashTarget)) {
        isMasterPassValid = true;
        foodDb.updateMasterAccountPassword(activeMasterPassword);
      }
    }
    if (isMasterPassValid) {
      const token2 = createShopAuthToken({
        userId: "master-admin",
        role: "SHOP_ADMIN",
        email: targetUser
      });
      shopDb.logAudit("SHOP_ADMIN_LOGIN", `Master Account ${targetUser} login ke portal Shop`, "master-admin");
      return res.json({
        token: token2,
        role: "SHOP_ADMIN",
        isMasterAdmin: true,
        user: {
          id: "master-admin",
          name: "Master Account TumpangGo",
          email: targetUser
        }
      });
    } else {
      const hasDbHash = Boolean(dbMaster?.passwordHash && dbMaster.passwordHash.startsWith("pbkdf2$"));
      return res.status(401).json({
        error: "Email atau kata sandi tidak valid. Silakan periksa kembali.",
        diagnostic: {
          code: "PASSWORD_MISMATCH",
          reason: hasDbHash ? "PASSWORD_HASH_MISMATCH" : "NO_PASSWORD_CONFIGURED",
          emailMatched: true,
          dbHashPresent: hasDbHash,
          envConfigLoaded: creds.hasExplicitEnv,
          configSource: creds.source,
          envPasswordByteLength: creds.byteLength
        }
      });
    }
  }
  const isMatchingEmail = targetUser === shopEnv.auth.adminEmail || targetUser === "shopadmin";
  const isMatchingPassword = shopEnv.auth.adminPassword && (targetPass === shopEnv.auth.adminPassword || rawPassStr === shopEnv.auth.adminPassword);
  if (!isMatchingEmail || !isMatchingPassword) {
    return res.status(401).json({
      error: "Kredensial Administrator Tumpang Shop salah. Pastikan menggunakan akun khusus Tumpang Shop.",
      diagnostic: {
        code: !isMatchingEmail ? "EMAIL_NOT_MATCHED" : "PASSWORD_MISMATCH",
        reason: !isMatchingEmail ? "SHOP_ADMIN_EMAIL_NOT_RECOGNIZED" : "SHOP_ADMIN_PASSWORD_INVALID",
        emailMatched: isMatchingEmail
      }
    });
  }
  const token = createShopAuthToken({
    userId: "shop_admin_master",
    role: "SHOP_ADMIN",
    email: targetUser
  });
  shopDb.logAudit("SHOP_ADMIN_LOGIN", `Admin ${targetUser} berhasil login ke portal Shop`, "shop_admin_master");
  return res.json({
    token,
    role: "SHOP_ADMIN",
    user: {
      id: "shop_admin_master",
      name: "Administrator Tumpang Shop",
      email: shopEnv.auth.adminEmail
    }
  });
});
router.get("/auth/me", requireShopAdmin, (req, res) => {
  return res.json({
    user: req.shopUser || req.user,
    store: shopDb.getConfig().storeName
  });
});
router.get("/config", (_req, res) => {
  try {
    res.json(shopDb.getConfig());
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat konfigurasi toko belanja." });
  }
});
var handleUpdateConfig = async (req, res) => {
  try {
    const actor = req.shopUser?.email || "admin_shop";
    const updated = await shopDb.updateConfig(actor, req.body);
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal memperbarui pengaturan toko belanja." });
  }
};
router.put("/config", requireShopAdmin, handleUpdateConfig);
router.put("/admin/config", requireShopAdmin, handleUpdateConfig);
router.get("/categories", (_req, res) => {
  try {
    const categories = shopDb.getCategories().filter((c) => c.isActive);
    res.json(categories);
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat kategori toko belanja." });
  }
});
router.get("/admin/categories", requireShopAdmin, (_req, res) => {
  res.json(shopDb.getCategories());
});
var handleCreateCategory = async (req, res) => {
  try {
    const actor = req.shopUser?.email || "admin_shop";
    const created = await shopDb.createCategory(actor, req.body);
    res.status(201).json(created);
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal membuat kategori baru." });
  }
};
router.post("/categories", requireShopAdmin, handleCreateCategory);
router.post("/admin/categories", requireShopAdmin, handleCreateCategory);
var handleUpdateCategory = async (req, res) => {
  try {
    const actor = req.shopUser?.email || "admin_shop";
    const updated = await shopDb.updateCategory(actor, req.params.id, req.body);
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal memperbarui kategori." });
  }
};
router.put("/categories/:id", requireShopAdmin, handleUpdateCategory);
router.put("/admin/categories/:id", requireShopAdmin, handleUpdateCategory);
var handleDeleteCategory = async (req, res) => {
  try {
    const actor = req.shopUser?.email || "admin_shop";
    const success = await shopDb.deleteCategory(actor, req.params.id);
    if (!success) {
      return res.status(404).json({ error: `Kategori ${req.params.id} tidak ditemukan.` });
    }
    res.json({ success: true, message: "Kategori berhasil dihapus." });
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal menghapus kategori." });
  }
};
router.delete("/categories/:id", requireShopAdmin, handleDeleteCategory);
router.delete("/admin/categories/:id", requireShopAdmin, handleDeleteCategory);
router.get("/products", (req, res) => {
  try {
    const categoryParam = req.query.category;
    let targetCatId = categoryParam;
    if (categoryParam) {
      const matchSlug = shopDb.getCategories().find((c) => c.slug === categoryParam || c.id === categoryParam);
      if (matchSlug) targetCatId = matchSlug.id;
    }
    const products = shopDb.getProducts({
      categoryId: targetCatId,
      search: req.query.q,
      onlyActive: true
    });
    res.json(products);
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat katalog produk toko belanja." });
  }
});
router.get("/products/:id", (req, res) => {
  try {
    const product = shopDb.getProductById(req.params.id);
    if (!product) {
      return res.status(404).json({ error: "Produk belanja tidak ditemukan." });
    }
    res.json(product);
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal mengambil detail produk belanja." });
  }
});
router.get("/admin/products", requireShopAdmin, (req, res) => {
  try {
    const products = shopDb.getProducts({
      categoryId: req.query.category,
      search: req.query.q,
      onlyActive: false
    });
    res.json(products);
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat produk admin." });
  }
});
var handleCreateProduct = async (req, res) => {
  try {
    const actor = req.shopUser?.email || "admin_shop";
    const created = await shopDb.createProduct(actor, req.body);
    res.status(201).json(created);
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal membuat produk baru." });
  }
};
router.post("/products", requireShopAdmin, handleCreateProduct);
router.post("/admin/products", requireShopAdmin, handleCreateProduct);
var handleUpdateProduct = async (req, res) => {
  try {
    const actor = req.shopUser?.email || "admin_shop";
    const updated = await shopDb.updateProduct(actor, req.params.id, req.body);
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal memperbarui produk." });
  }
};
router.put("/products/:id", requireShopAdmin, handleUpdateProduct);
router.put("/admin/products/:id", requireShopAdmin, handleUpdateProduct);
var handleDeleteProduct = async (req, res) => {
  try {
    const actor = req.shopUser?.email || "admin_shop";
    const success = await shopDb.deleteProduct(actor, req.params.id);
    if (!success) {
      return res.status(404).json({ error: `Produk ${req.params.id} tidak ditemukan.` });
    }
    res.json({ success: true, message: "Produk berhasil dihapus." });
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal menghapus produk." });
  }
};
router.delete("/products/:id", requireShopAdmin, handleDeleteProduct);
router.delete("/admin/products/:id", requireShopAdmin, handleDeleteProduct);
router.post("/orders", async (req, res) => {
  try {
    const newOrder = await shopDb.createOrder(req.body);
    res.status(201).json(newOrder);
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal membuat pesanan belanja." });
  }
});
router.get("/orders/track/:id", async (req, res) => {
  try {
    const phone = req.query.phone;
    if (!phone) {
      return res.status(403).json({
        error: "Privasi Terlindungi: Nomor WhatsApp pemesan diperlukan untuk melacak pesanan belanja."
      });
    }
    const order = await shopDb.findOrderByNumberAndPhone(req.params.id, phone.trim());
    if (!order) {
      return res.status(404).json({
        error: "Pesanan tidak ditemukan atau nomor WhatsApp tidak cocok dengan data pemesanan."
      });
    }
    res.json(order);
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal melacak pesanan." });
  }
});
router.post("/orders/lookup", async (req, res) => {
  try {
    const { orderNumber, customerPhone } = req.body;
    if (!orderNumber || !customerPhone) {
      return res.status(400).json({ error: "Nomor pesanan dan nomor WhatsApp pemesan wajib diisi." });
    }
    const order = await shopDb.findOrderByNumberAndPhone(String(orderNumber).trim(), String(customerPhone).trim());
    if (!order) {
      return res.status(404).json({ error: "Pesanan tidak ditemukan. Periksa kembali nomor pesanan dan WhatsApp Anda." });
    }
    res.json(order);
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal mencari pesanan." });
  }
});
router.get("/orders/customer/:phone", (req, res) => {
  try {
    const phone = req.params.phone;
    if (!phone || phone.length < 8) {
      return res.status(400).json({ error: "Nomor WhatsApp tidak valid." });
    }
    const orders = shopDb.getOrdersByCustomerPhone(phone.trim());
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat riwayat pesanan pelanggan." });
  }
});
router.post("/orders/:id/payment-proof", async (req, res) => {
  try {
    const { paymentProof, customerPhone } = req.body;
    if (!paymentProof || typeof paymentProof !== "string" || paymentProof.trim().length === 0) {
      return res.status(400).json({ error: "Gambar atau bukti transfer wajib dilampirkan." });
    }
    if (customerPhone) {
      const existing = await shopDb.findOrderByNumberAndPhone(req.params.id, customerPhone);
      if (!existing) {
        return res.status(403).json({ error: "Verifikasi gagal: Nomor telepon tidak cocok dengan pemesan." });
      }
    }
    const updated = await shopDb.uploadPaymentProof(req.params.id, paymentProof.trim());
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal mengunggah bukti pembayaran." });
  }
});
router.get("/orders", requireShopAdmin, (req, res) => {
  try {
    const paymentStatus = req.query.paymentStatus;
    const orderStatus = req.query.orderStatus;
    const orders = shopDb.getOrders({ paymentStatus, orderStatus });
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat daftar pesanan." });
  }
});
router.post("/orders/:id/verify-payment", requireShopAdmin, async (req, res) => {
  try {
    const { approved, reason } = req.body;
    if (typeof approved !== "boolean") {
      return res.status(400).json({ error: "Status persetujuan (approved: boolean) wajib ditentukan." });
    }
    const actor = req.shopUser?.email || "admin_shop";
    const updated = await shopDb.verifyPayment(actor, req.params.id, approved, reason);
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal memproses verifikasi pembayaran." });
  }
});
router.patch("/orders/:id/status", requireShopAdmin, async (req, res) => {
  try {
    const { status, reason } = req.body;
    if (!status) {
      return res.status(400).json({ error: "Status pesanan baru wajib ditentukan." });
    }
    const actor = req.shopUser?.email || "admin_shop";
    const updated = await shopDb.updateOrderStatus(actor, req.params.id, status, reason);
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal mengubah status pesanan." });
  }
});
router.get("/shipping/options", (_req, res) => {
  try {
    const options = shopDb.getShippingOptions();
    res.json(options);
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat opsi pengiriman." });
  }
});
router.get("/shipping/track/:trackingNumber", async (req, res) => {
  try {
    const trackingNumber = req.params.trackingNumber;
    const phone = req.query.phone;
    if (!phone) {
      return res.status(403).json({
        error: "Privasi Terlindungi: Nomor WhatsApp penerima/pemesan diperlukan untuk melacak status paket."
      });
    }
    const shipment = shopDb.getShipmentByTrackingNumber(trackingNumber);
    if (!shipment) {
      return res.status(404).json({
        error: `Nomor resi ${trackingNumber} tidak ditemukan di sistem logistik Tumpang Shop.`
      });
    }
    const associatedOrder = await shopDb.findOrderById(shipment.orderId);
    if (!associatedOrder) {
      return res.status(404).json({ error: "Pesanan terkait paket ini tidak ditemukan." });
    }
    const cleanInputPhone = phone.replace(/[^0-9]/g, "");
    const cleanOrderPhone = associatedOrder.customerPhone.replace(/[^0-9]/g, "");
    const isAuthorized = cleanOrderPhone === cleanInputPhone || cleanOrderPhone.endsWith(cleanInputPhone) || cleanInputPhone.endsWith(cleanOrderPhone);
    if (!isAuthorized) {
      return res.status(403).json({
        error: "Nomor WhatsApp tidak cocok dengan penerima nomor resi ini."
      });
    }
    res.json(shipment);
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal melacak nomor resi paket." });
  }
});
router.get("/admin/shipments", requireShopAdmin, (_req, res) => {
  res.json(shopDb.getShipments());
});
router.get("/admin/shipments/:id", requireShopAdmin, (req, res) => {
  const shipment = shopDb.getShipmentById(req.params.id);
  if (!shipment) return res.status(404).json({ error: "Data pengiriman tidak ditemukan." });
  res.json(shipment);
});
router.get("/admin/shipments/order/:orderId", requireShopAdmin, (req, res) => {
  const shipment = shopDb.getShipmentByOrderId(req.params.orderId);
  if (!shipment) return res.status(404).json({ error: "Pengiriman untuk pesanan ini belum dibuat." });
  res.json(shipment);
});
router.post("/admin/shipments", requireShopAdmin, async (req, res) => {
  try {
    const actor = req.shopUser?.email || "admin_shop";
    const created = await shopDb.createShipment(actor, req.body);
    res.status(201).json(created);
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal membuat data pengiriman." });
  }
});
router.patch("/admin/shipments/:id/status", requireShopAdmin, async (req, res) => {
  try {
    const { status, location, description, note } = req.body;
    if (!status) return res.status(400).json({ error: "Status pengiriman baru wajib ditentukan." });
    const actor = req.shopUser?.email || "admin_shop";
    const updated = await shopDb.updateShipmentStatus(actor, req.params.id, status, {
      location,
      description,
      note
    });
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message || "Gagal memperbarui status pengiriman." });
  }
});
router.get("/reports/summary", requireShopAdmin, (_req, res) => {
  res.json(shopDb.getSummaryMetrics());
});
router.get("/reports/transactions", requireShopAdmin, (req, res) => {
  try {
    const startDate = req.query.startDate;
    const endDate = req.query.endDate;
    const report = shopDb.getTransactionReport(startDate, endDate);
    res.json(report);
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat laporan transaksi." });
  }
});
router.post("/payments/artopay/intent", async (req, res) => {
  try {
    const { orderId, customerPhone, clientAmount } = req.body;
    if (!orderId) {
      return res.status(400).json({ error: "Order ID wajib diisi." });
    }
    let order = await shopDb.findOrderById(orderId);
    if (!order && customerPhone) {
      order = await shopDb.findOrderByNumberAndPhone(orderId, String(customerPhone).trim());
    }
    if (!order) {
      return res.status(404).json({ error: `Pesanan Tumpang Shop dengan ID "${orderId}" tidak ditemukan.` });
    }
    if (order.paymentStatus === "PAID" /* PAID */) {
      return res.status(400).json({ error: "Pesanan belanja ini sudah lunas." });
    }
    if (order.paymentStatus === "EXPIRED" /* EXPIRED */ || order.orderStatus === "CANCELLED" /* CANCELLED */) {
      return res.status(400).json({ error: "Pesanan belanja sudah kedaluwarsa atau dibatalkan." });
    }
    const serverAmount = Math.round(Number(order.total));
    if (clientAmount !== void 0 && Number(clientAmount) !== serverAmount) {
      return res.status(400).json({
        error: `Manipulasi nominal terdeteksi: nominal client (${clientAmount}) berbeda dengan total server (${serverAmount}).`
      });
    }
    const proto = req.headers["x-forwarded-proto"] || req.protocol || "http";
    const host = req.get("host") || "localhost:3000";
    const origin = `${proto}://${host}`;
    const intent = await ArtoPayService.createPaymentIntent({
      orderId: order.orderNumber || order.id,
      amount: serverAmount,
      currency: "IDR",
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      serviceType: "SHOP",
      description: `Pembayaran Tumpang Shop #${order.orderNumber || order.id}`,
      expiryMinutes: 20,
      callbackUrl: `${origin}/api/artopay/webhook`,
      returnUrl: `${origin}/?page=shop&orderId=${order.orderNumber || order.id}&tab=tracking`,
      allowSdkModal: true
    });
    await shopDb.attachArtopayPayment(order.id, {
      paymentMethod: "ARTOPAY_QRIS",
      artopayPaymentId: intent.paymentIntentId,
      artopayCheckoutUrl: intent.checkoutUrl,
      artopayStatus: "PENDING",
      artopayExpiredAt: intent.expiresAt,
      artopayClientSecret: intent.clientSecret,
      artopayCustomerToken: intent.customerToken,
      artopayPublicKey: intent.publicKey,
      artopayOrderId: intent.orderId,
      artopaySandbox: intent.sandbox
    });
    return res.json(intent);
  } catch (err) {
    return res.status(500).json({ error: err.message || "Gagal membuat payment intent ArtoPay untuk pesanan Shop." });
  }
});
router.post("/payments/artopay/webhook-sync", async (req, res) => {
  try {
    const { orderId, paymentIntentId, amountPaid } = req.body;
    let order = await shopDb.findOrderById(orderId) || shopDb.getOrders().find((o) => o.orderNumber === orderId || o.artopayPaymentId === paymentIntentId);
    if (!order) {
      return res.status(404).json({ error: `Pesanan Shop ${orderId} tidak ditemukan.` });
    }
    if (order.artopayPaymentId && paymentIntentId && order.artopayPaymentId !== paymentIntentId) {
      return res.status(400).json({ error: "ID transaksi ArtoPay tidak cocok." });
    }
    const serverTotal = Math.round(Number(order.total));
    if (amountPaid !== void 0 && Math.round(Number(amountPaid)) !== serverTotal) {
      return res.status(400).json({ error: `Nominal bayar tidak cocok dengan total pesanan server.` });
    }
    await shopDb.verifyPayment("SYSTEM_ARTOPAY_INTERSERVICE", order.id, true);
    await shopDb.attachArtopayPayment(order.id, {
      artopayStatus: "SUCCESS",
      artopayPaidAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    shopDb.logAudit("INTERSERVICE_PAYMENT_SYNC", `Webhook pembayaran disinkronisasi untuk #${order.orderNumber}`, "SYSTEM");
    return res.json({ success: true, orderId: order.id, status: "PAID" });
  } catch (err) {
    return res.status(500).json({ error: err.message || "Gagal sinkronisasi pembayaran inter-service." });
  }
});
shopApp.use("/", router);
shopApp.use("/api/shop", router);
shopApp.use((err, _req, res, _next) => {
  console.error("[Shop App Unhandled Error]", err);
  const status = typeof err.status === "number" && err.status >= 400 && err.status < 600 ? err.status : 500;
  res.status(status).json({
    error: err.message || "Terjadi kesalahan pada backend Tumpang Shop."
  });
});

// src/services/shop/client/shopApiClient.ts
var ShopApiClient = class {
  constructor(serviceUrl) {
    this.serviceUrl = serviceUrl || process.env.SHOP_SERVICE_URL || "";
  }
  /**
   * Safe Inter-service Health Check
   */
  async getHealth() {
    if (this.serviceUrl) {
      const res = await fetch(`${this.serviceUrl}/health`);
      return res.json();
    }
    return shopDb.getStorageStatus();
  }
  /**
   * Safe Inter-service Order Lookup
   */
  async findOrder(orderId, phone) {
    if (phone) {
      return shopDb.findOrderByNumberAndPhone(orderId, phone);
    }
    return shopDb.findOrderById(orderId);
  }
  /**
   * Safe Inter-service Payment Intent Processing
   */
  async createArtopayPaymentIntent(payload) {
    if (this.serviceUrl) {
      const res = await fetch(`${this.serviceUrl}/payments/artopay/intent`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: "Error dari Shop Service" }));
        throw new Error(err.error || `HTTP ${res.status}`);
      }
      return res.json();
    }
    let order = await shopDb.findOrderById(payload.orderId);
    if (!order && payload.customerPhone) {
      order = await shopDb.findOrderByNumberAndPhone(payload.orderId, String(payload.customerPhone).trim());
    }
    if (!order) {
      throw new Error(`Pesanan Tumpang Shop dengan ID "${payload.orderId}" tidak ditemukan.`);
    }
    return { order, verifiedOrderId: order.orderNumber || order.id };
  }
  /**
   * Safe Inter-service Payment Sync (e.g. Webhook processing)
   */
  async syncPaymentStatus(payload) {
    if (this.serviceUrl) {
      const res = await fetch(`${this.serviceUrl}/payments/artopay/webhook-sync`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      return res.json();
    }
    let order = await shopDb.findOrderById(payload.orderId) || shopDb.getOrders().find((o) => o.orderNumber === payload.orderId || o.artopayPaymentId === payload.paymentIntentId);
    if (!order) {
      throw new Error(`Pesanan Shop ${payload.orderId} tidak ditemukan.`);
    }
    await shopDb.verifyPayment("SYSTEM_INTERSERVICE_SYNC", order.id, true);
    await shopDb.attachArtopayPayment(order.id, {
      artopayStatus: "SUCCESS",
      artopayPaidAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    return { success: true, orderId: order.id };
  }
  /**
   * Safe Inter-service Update of ArtoPay details
   */
  async attachPaymentDetails(orderId, details) {
    return shopDb.attachArtopayPayment(orderId, details);
  }
};
var shopApiClient = new ShopApiClient();

// src/server/routes/authRoutes.ts
var import_fs7 = __toESM(require("fs"), 1);
var import_path7 = __toESM(require("path"), 1);
var import_crypto5 = __toESM(require("crypto"), 1);
var import_express2 = require("express");
var authRouter = (0, import_express2.Router)();
authRouter.post(["/login", "/auth/login"], async (req, res) => {
  try {
    const rawUser = req.body?.username || req.body?.email || req.body?.user;
    const rawPass = req.body?.password;
    const role = req.body?.role;
    if (!rawUser || !rawPass) {
      return res.status(400).json({ error: "Username/Email dan kata sandi wajib diisi." });
    }
    const cleanUser = String(rawUser).trim().toLowerCase();
    const rawPassStr = String(rawPass);
    const cleanPass = rawPassStr.trim();
    const isMasterUser = isMasterAdminEmail(cleanUser);
    if (isMasterUser) {
      console.log(`[MasterAuth Diagnostic] Master Account login attempt for: [PROTECTED_EMAIL] (portal: ${role || "DEFAULT"})`);
      const creds = getMasterAccountCredentials();
      const activeMasterPassword = creds.password;
      const dbMaster = foodDb.getMasterAccount();
      let isMasterPassValid = false;
      let matchedVia = "";
      if (dbMaster?.passwordHash && dbMaster.passwordHash.startsWith("pbkdf2$")) {
        const { valid: validTrimmed } = verifyPassword(cleanPass, dbMaster.passwordHash);
        const { valid: validRaw } = verifyPassword(rawPassStr, dbMaster.passwordHash);
        if (validTrimmed || validRaw) {
          isMasterPassValid = true;
          matchedVia = "PBKDF2_DB_HASH";
        }
      }
      if (!isMasterPassValid && creds.hasExplicitEnv && activeMasterPassword) {
        const hashTarget = import_crypto5.default.createHash("sha256").update(activeMasterPassword).digest();
        const hashTrimmed = import_crypto5.default.createHash("sha256").update(cleanPass).digest();
        const hashRaw = import_crypto5.default.createHash("sha256").update(rawPassStr).digest();
        if (import_crypto5.default.timingSafeEqual(hashTrimmed, hashTarget) || import_crypto5.default.timingSafeEqual(hashRaw, hashTarget)) {
          isMasterPassValid = true;
          matchedVia = "ACTIVE_ENV_PASSWORD";
          foodDb.updateMasterAccountPassword(activeMasterPassword);
        }
      }
      if (!isMasterPassValid) {
        const hasDbHash = Boolean(dbMaster?.passwordHash && dbMaster.passwordHash.startsWith("pbkdf2$"));
        console.warn(`[MasterAuth Diagnostic] GAGAL: Verifikasi kata sandi Master Account ditolak (inputBytes: ${Buffer.byteLength(cleanPass, "utf-8")}, dbHashPresent: ${hasDbHash}, envConfigLoaded: ${creds.hasExplicitEnv})`);
        return res.status(401).json({
          error: "Email atau kata sandi tidak valid. Silakan periksa kembali.",
          diagnostic: {
            code: "PASSWORD_MISMATCH",
            reason: hasDbHash ? "PASSWORD_HASH_MISMATCH" : "NO_PASSWORD_CONFIGURED",
            emailMatched: true,
            dbHashPresent: hasDbHash,
            envConfigLoaded: creds.hasExplicitEnv,
            configSource: creds.source,
            envPasswordByteLength: creds.byteLength
          }
        });
      }
      console.log(`[MasterAuth Diagnostic] BERHASIL: Verifikasi kata sandi Master Account valid (via: ${matchedVia}).`);
      const firstMerchant = foodDb.getMerchants()[0];
      const firstDriver = foodDb.getDrivers()[0];
      const targetEntityId = role === "MERCHANT" ? req.body.targetMerchantId || firstMerchant?.id || "" : role === "DRIVER" ? req.body.targetDriverId || firstDriver?.id || "" : void 0;
      let token = "";
      try {
        token = createAuthToken({
          userId: "master-admin",
          role: "MASTER_ADMIN",
          email: cleanUser,
          isMasterAdmin: true,
          entityId: targetEntityId
        });
      } catch (tokenErr) {
        console.error("[MasterAuth Diagnostic] GAGAL: Pembuatan token otentikasi gagal:", tokenErr?.message);
        return res.status(500).json({
          error: "Gagal menerbitkan token otentikasi Master Account.",
          diagnostic: { code: "TOKEN_CREATION_FAILED", reason: tokenErr?.message }
        });
      }
      console.log("[MasterAuth Diagnostic] BERHASIL: Token Master Account berhasil diterbitkan.");
      foodDb.log("master-admin", `Master Account logged in with unrestricted cross-portal access (entry portal: ${role || "ALL"})`, "MASTER_ADMIN");
      return res.json({
        token,
        role: "MASTER_ADMIN",
        isMasterAdmin: true,
        targetPortal: role || "ADMIN",
        user: {
          id: "master-admin",
          name: "Master Account TumpangGo",
          email: cleanUser,
          role: "MASTER_ADMIN",
          isMasterAdmin: true,
          entityId: targetEntityId,
          activeMerchantId: firstMerchant?.id || "",
          activeDriverId: firstDriver?.id || ""
        },
        availablePortals: ["ADMIN", "MERCHANT", "DRIVER", "CUSTOMER", "SHOP_ADMIN"]
      });
    }
    if (role === "ADMIN") {
      if (foodConfig.isProduction) {
        if (!foodConfig.adminPassword || foodConfig.adminPassword.length < 8) {
          return res.status(500).json({
            error: "Autentikasi admin dinonaktifkan: FOOD_ADMIN_PASSWORD belum dikonfigurasi di Environment Variables Vercel.",
            diagnostic: { code: "CONFIG_ENV_MISSING", reason: "FOOD_ADMIN_PASSWORD_UNSET" }
          });
        }
        if (!foodConfig.jwtSecret || foodConfig.jwtSecret.length < 32) {
          return res.status(500).json({
            error: "Autentikasi admin dinonaktifkan: FOOD_AUTH_SECRET belum dikonfigurasi di Environment Variables Vercel.",
            diagnostic: { code: "CONFIG_ENV_MISSING", reason: "FOOD_AUTH_SECRET_UNSET" }
          });
        }
        if (cleanPass === "TumpangGoAdmin#2026") {
          return res.status(401).json({
            error: "Kata sandi default ditolak pada lingkungan produksi demi keamanan. Atur FOOD_ADMIN_PASSWORD di environment variable.",
            diagnostic: { code: "DEFAULT_PASSWORD_REJECTED_IN_PROD" }
          });
        }
      }
      const isTargetAdmin = isAdminEmail(cleanUser);
      if (!isTargetAdmin) {
        return res.status(401).json({
          error: "Email atau kata sandi Administrator salah.",
          diagnostic: { code: "EMAIL_NOT_MATCHED", reason: "ADMIN_EMAIL_NOT_RECOGNIZED", emailMatched: false }
        });
      }
      const isValidAdminPass = Boolean(
        foodConfig.adminPassword && (verifyPassword(cleanPass, foodConfig.adminPassword).valid || verifyPassword(rawPassStr, foodConfig.adminPassword).valid || cleanPass === foodConfig.adminPassword || rawPassStr === foodConfig.adminPassword)
      );
      if (!isValidAdminPass) {
        return res.status(401).json({
          error: "Email atau kata sandi Administrator salah.",
          diagnostic: { code: "PASSWORD_MISMATCH", reason: "ADMIN_PASSWORD_INVALID", emailMatched: true }
        });
      }
      const token = createAuthToken({
        userId: "admin",
        role: "ADMIN",
        email: cleanUser
      });
      foodDb.log("admin", `Admin ${cleanUser} logged in successfully`, "ADMIN");
      return res.json({
        token,
        role: "ADMIN",
        user: { id: "admin", name: "Administrator Tumpang Go", username: cleanUser, role: "ADMIN" }
      });
    }
    if (role === "MERCHANT") {
      const merchant = foodDb.getMerchantByEmailOrPhone(cleanUser);
      if (!merchant) {
        return res.status(401).json({
          error: "Email atau No. Telepon ini tidak terdaftar sebagai Merchant Toko.",
          diagnostic: { code: "EMAIL_NOT_MATCHED", reason: "MERCHANT_NOT_FOUND", emailMatched: false }
        });
      }
      let isPasswordValid = false;
      if (merchant.password) {
        const { valid, needsRehash } = verifyPassword(cleanPass, merchant.password);
        isPasswordValid = valid;
        if (needsRehash) {
          foodDb.updateMerchant("SYSTEM", merchant.id, { password: hashPassword(cleanPass) }, "MERCHANT").catch(() => {
          });
        }
      } else {
        return res.status(401).json({
          error: "Akun toko belum memiliki kata sandi aktif. Silakan lakukan aktivasi akun terlebih dahulu.",
          diagnostic: { code: "ACCOUNT_NOT_ACTIVATED", reason: "MERCHANT_PASSWORD_EMPTY" }
        });
      }
      if (!isPasswordValid) {
        return res.status(401).json({
          error: "Kata sandi toko salah. Silakan periksa kembali.",
          diagnostic: { code: "PASSWORD_MISMATCH", reason: "MERCHANT_PASSWORD_INVALID", emailMatched: true }
        });
      }
      const token = createAuthToken({
        userId: merchant.id,
        role: "MERCHANT",
        email: merchant.email,
        entityId: merchant.id
      });
      foodDb.log(merchant.id, `Merchant ${merchant.name} logged in`, "MERCHANT");
      return res.json({
        token,
        role: "MERCHANT",
        user: { id: merchant.id, name: merchant.name, phone: merchant.phone, email: merchant.email }
      });
    }
    if (role === "DRIVER") {
      const driver = foodDb.getDriverByEmailOrPhone(cleanUser);
      if (!driver) {
        return res.status(401).json({
          error: "No. WhatsApp atau Email ini tidak terdaftar sebagai Driver / Kurir.",
          diagnostic: { code: "EMAIL_NOT_MATCHED", reason: "DRIVER_NOT_FOUND", emailMatched: false }
        });
      }
      let isDriverPassValid = false;
      if (driver.password) {
        const { valid, needsRehash } = verifyPassword(cleanPass, driver.password);
        isDriverPassValid = valid;
        if (needsRehash) {
          foodDb.updateDriver("SYSTEM", driver.id, { password: hashPassword(cleanPass) }, "DRIVER").catch(() => {
          });
        }
      } else {
        return res.status(401).json({
          error: "Akun driver belum memiliki kata sandi aktif. Silakan hubungi admin untuk aktivasi.",
          diagnostic: { code: "ACCOUNT_NOT_ACTIVATED", reason: "DRIVER_PASSWORD_EMPTY" }
        });
      }
      if (!isDriverPassValid) {
        return res.status(401).json({
          error: "Kata sandi driver salah. Silakan periksa kembali.",
          diagnostic: { code: "PASSWORD_MISMATCH", reason: "DRIVER_PASSWORD_INVALID", emailMatched: true }
        });
      }
      const token = createAuthToken({
        userId: driver.id,
        role: "DRIVER",
        email: driver.email,
        entityId: driver.id
      });
      foodDb.log(driver.id, `Driver ${driver.name} logged in`, "DRIVER");
      return res.json({
        token,
        role: "DRIVER",
        user: { id: driver.id, name: driver.name, phone: driver.phone }
      });
    }
    return res.status(400).json({ error: "Peran akun tidak dikenali." });
  } catch (err) {
    console.error("[TumpangFood Login Handler Error]", err?.message || err);
    return res.status(500).json({
      error: "Terjadi kendala pada server saat memproses autentikasi. Silakan coba kembali.",
      code: "AUTH_SERVER_ERROR"
    });
  }
});
authRouter.post("/merchants/register", async (req, res) => {
  const { name, ownerName, phone, email, category, address, description, password } = req.body;
  if (!name || !ownerName || !phone || !password) {
    return res.status(400).json({ error: "Mohon lengkapi Nama Toko, Nama Pemilik, No. WhatsApp, dan Kata Sandi." });
  }
  try {
    const cleanPhone = String(phone).trim();
    const cleanEmail = email ? String(email).trim().toLowerCase() : "";
    const existingMerchants = foodDb.getMerchants();
    const duplicate = existingMerchants.find(
      (m) => m.phone && m.phone === cleanPhone || cleanEmail && m.email && m.email.toLowerCase() === cleanEmail
    );
    if (duplicate) {
      return res.status(400).json({ error: "No. HP/WhatsApp atau Email ini sudah terdaftar sebagai Merchant." });
    }
    const newMerchant = await foodDb.createMerchant("SYSTEM_REGISTER", {
      name: String(name).trim(),
      ownerName: String(ownerName).trim(),
      phone: cleanPhone,
      email: cleanEmail || void 0,
      category: category || "Nasi & Lauk",
      address: address ? String(address).trim() : "Kecamatan Tumpang, Kabupaten Malang",
      description: description ? String(description).trim() : "Mitra Kuliner UMKM Kecamatan Tumpang",
      image: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=500&auto=format&fit=crop&q=60",
      bannerImage: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop&q=60",
      openTime: "08:00",
      closeTime: "21:00",
      bankName: "Bank BRI",
      bankAccount: "1234567890",
      bankHolder: String(ownerName).trim(),
      active: true,
      isActivated: true,
      cookTimeEstimate: "15-30 min",
      password: String(password).trim(),
      latitude: -7.9482,
      longitude: 112.7612
    });
    const token = createAuthToken({
      userId: newMerchant.id,
      role: "MERCHANT",
      email: newMerchant.email,
      entityId: newMerchant.id
    });
    return res.status(201).json({
      success: true,
      message: "Pendaftaran Merchant berhasil!",
      merchant: newMerchant,
      token
    });
  } catch (e) {
    return res.status(500).json({ error: e.message || "Gagal mendaftarkan toko." });
  }
});
authRouter.post("/merchants/activate", async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "Email dan password wajib diisi." });
  }
  try {
    const result = await foodDb.activateMerchant(email, password);
    if (result.success) {
      res.json({ success: true, merchant: result.merchant });
    } else {
      res.status(400).json({ error: result.error });
    }
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
authRouter.get(["/me", "/auth/me"], (req, res) => {
  const user = req.user;
  if (!user) {
    console.warn("[MasterAuth Diagnostic] Sesi gagal dipulihkan: token tidak ditemukan atau tidak valid pada header request.");
    return res.status(401).json({ authenticated: false, error: "Sesi belum terautentikasi atau telah kedaluwarsa." });
  }
  const isMaster = user.role === "MASTER_ADMIN" || Boolean(user.isMasterAdmin) || isMasterAdminEmail(user.email);
  const firstMerchant = foodDb.getMerchants()[0];
  const firstDriver = foodDb.getDrivers()[0];
  console.log(`[MasterAuth Diagnostic] Sesi berhasil dipulihkan (isMaster: ${isMaster}, role: ${user.role})`);
  return res.json({
    authenticated: true,
    user: {
      id: user.userId,
      role: isMaster ? "MASTER_ADMIN" : user.role,
      email: user.email,
      entityId: user.entityId || (isMaster ? firstMerchant?.id : void 0),
      isMasterAdmin: Boolean(isMaster),
      activeMerchantId: firstMerchant?.id || "",
      activeDriverId: firstDriver?.id || ""
    },
    availablePortals: isMaster ? ["ADMIN", "MERCHANT", "DRIVER", "CUSTOMER", "SHOP_ADMIN"] : [user.role]
  });
});
authRouter.post(["/master/rotate-password", "/auth/master/rotate-password"], requireRole(["MASTER_ADMIN"]), (req, res) => {
  const { newPassword, currentPassword } = req.body;
  if (!newPassword || typeof newPassword !== "string" || newPassword.trim().length < 8) {
    return res.status(400).json({ error: "Kata sandi baru minimal harus terdiri dari 8 karakter." });
  }
  const cleanCurrent = String(currentPassword || "").trim();
  const envMasterPass = (process.env.MASTER_ADMIN_PASSWORD || "").trim();
  const dbMaster = foodDb.getMasterAccount();
  const configMasterPass = (foodConfig.masterAccount.password || "").trim();
  let isCurrentValid = false;
  if (dbMaster?.passwordHash && verifyPassword(cleanCurrent, dbMaster.passwordHash).valid) {
    isCurrentValid = true;
  } else if (envMasterPass && verifyPassword(cleanCurrent, envMasterPass).valid) {
    isCurrentValid = true;
  } else if (configMasterPass && verifyPassword(cleanCurrent, configMasterPass).valid) {
    isCurrentValid = true;
  }
  if (!isCurrentValid) {
    return res.status(401).json({ error: "Kata sandi saat ini tidak cocok." });
  }
  updateRuntimeMasterPassword(newPassword.trim());
  foodDb.updateMasterAccountPassword(newPassword.trim());
  foodDb.log("master-admin", "Master Account password rotated and saved to database successfully", "MASTER_ADMIN");
  return res.json({ success: true, message: "Kata sandi Master Account berhasil diperbarui." });
});
authRouter.post(["/master/emergency-reset", "/auth/master/emergency-reset"], async (req, res) => {
  const recoveryKey = String(req.headers["x-master-recovery-key"] || "").trim();
  let authBearer = "";
  const authHeader = req.headers["authorization"];
  if (authHeader && authHeader.startsWith("Bearer ")) {
    authBearer = authHeader.substring(7).trim();
  }
  const providedKey = recoveryKey || authBearer;
  if (!providedKey) {
    return res.status(401).json({
      error: "Akses ditolak: Otorisasi pemulihan administratif diperlukan. Sertakan header X-Master-Recovery-Key.",
      diagnostic: { code: "ADMINISTRATIVE_AUTHORIZATION_REQUIRED" }
    });
  }
  const envKey = (process.env.MASTER_RECOVERY_KEY || "").trim();
  let isAuthorized = false;
  let isOneTimeFile = false;
  const tokenFilePath = import_path7.default.resolve(process.cwd(), ".master_recovery_token");
  if (envKey && envKey.length >= 16) {
    const bufProvided = Buffer.from(providedKey);
    const bufEnv = Buffer.from(envKey);
    if (bufProvided.length === bufEnv.length && import_crypto5.default.timingSafeEqual(bufProvided, bufEnv)) {
      isAuthorized = true;
    }
  }
  if (!isAuthorized && import_fs7.default.existsSync(tokenFilePath)) {
    try {
      const fileContent = import_fs7.default.readFileSync(tokenFilePath, "utf-8").trim();
      if (fileContent && fileContent.length >= 16) {
        const bufProvided = Buffer.from(providedKey);
        const bufFile = Buffer.from(fileContent);
        if (bufProvided.length === bufFile.length && import_crypto5.default.timingSafeEqual(bufProvided, bufFile)) {
          isAuthorized = true;
          isOneTimeFile = true;
        }
      }
    } catch {
    }
  }
  if (!isAuthorized) {
    console.warn("[MasterRecovery] Otorisasi pemulihan ditolak: kunci pemulihan administratif tidak cocok.");
    return res.status(401).json({
      error: "Kunci pemulihan administratif tidak valid atau telah kedaluwarsa.",
      diagnostic: { code: "INVALID_RECOVERY_KEY" }
    });
  }
  const { newPassword } = req.body;
  if (!newPassword || typeof newPassword !== "string" || newPassword.trim().length < 8) {
    return res.status(400).json({
      error: "Kata sandi baru minimal harus terdiri dari 8 karakter.",
      diagnostic: { code: "PASSWORD_TOO_SHORT" }
    });
  }
  const cleanPass = newPassword.trim();
  const creds = getMasterAccountCredentials();
  foodDb.updateMasterAccountPassword(cleanPass);
  updateRuntimeMasterPassword(cleanPass);
  if (isOneTimeFile && import_fs7.default.existsSync(tokenFilePath)) {
    try {
      import_fs7.default.unlinkSync(tokenFilePath);
    } catch {
    }
  }
  foodDb.log("master-recovery", "Master Account password recovered successfully via trusted administrative process", "MASTER_ADMIN");
  console.log("[MasterRecovery] BERHASIL: Kata sandi Master Account berhasil dipulihkan dan disimpan ke database persisten.");
  return res.json({
    success: true,
    message: "Kredensial Master Account berhasil dipulihkan secara aman.",
    email: creds.email,
    hashAlgorithm: "PBKDF2-SHA512 (iterations: 10000)"
  });
});

// src/server/routes/merchantRoutes.ts
var import_path8 = __toESM(require("path"), 1);
var import_fs8 = __toESM(require("fs"), 1);
var import_express3 = require("express");
var merchantRouter = (0, import_express3.Router)();
merchantRouter.get("/", (req, res, next) => {
  try {
    const list = foodDb.getMerchants();
    res.json(list);
  } catch (err) {
    next(err);
  }
});
merchantRouter.get("/:id", (req, res, next) => {
  try {
    const m = foodDb.getMerchantById(req.params.id);
    if (!m) return res.status(404).json({ error: "Merchant not found" });
    res.json(m);
  } catch (err) {
    next(err);
  }
});
merchantRouter.get("/:id/qris", (req, res) => {
  try {
    const m = foodDb.getMerchantById(req.params.id);
    if (!m) return res.status(404).json({ error: "Merchant tidak ditemukan." });
    const rawQris = m.qrisImage;
    const hasQris = Boolean(rawQris && typeof rawQris === "string" && rawQris.trim().length > 3 && !rawQris.includes("unsplash"));
    res.json({
      merchantId: m.id,
      merchantName: m.name,
      hasQris,
      qrisImage: hasQris ? rawQris : null,
      qrisImageUrl: hasQris ? `/api/merchants/${m.id}/qris-image` : null
    });
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat status QRIS toko." });
  }
});
merchantRouter.get("/:id/qris-image", async (req, res) => {
  try {
    const m = foodDb.getMerchantById(req.params.id);
    if (!m) return res.status(404).json({ error: "Merchant tidak ditemukan." });
    const rawQris = m.qrisImage;
    if (!rawQris || typeof rawQris !== "string" || rawQris.trim().length < 3 || rawQris.includes("unsplash")) {
      return res.status(404).json({ error: `Toko "${m.name}" belum memiliki QRIS statis resmi.` });
    }
    const cleanQris = rawQris.trim();
    if (cleanQris.startsWith("data:image/")) {
      const matches = cleanQris.match(/^data:(image\/[a-zA-Z0-9.+_-]+);base64,(.+)$/);
      if (matches) {
        res.setHeader("Content-Type", matches[1]);
        res.setHeader("Cache-Control", "public, max-age=86400");
        return res.send(Buffer.from(matches[2], "base64"));
      }
    }
    if (cleanQris.startsWith("/")) {
      const candidatePaths = [
        import_path8.default.resolve(process.cwd(), "dist", cleanQris.replace(/^\//, "")),
        import_path8.default.resolve(process.cwd(), "public", cleanQris.replace(/^\//, "")),
        import_path8.default.resolve("/var/task", "dist", cleanQris.replace(/^\//, "")),
        import_path8.default.resolve("/var/task", "public", cleanQris.replace(/^\//, ""))
      ];
      for (const p of candidatePaths) {
        if (import_fs8.default.existsSync(p) && import_fs8.default.statSync(p).isFile()) {
          const ext = import_path8.default.extname(p).toLowerCase();
          const mime = ext === ".png" ? "image/png" : ext === ".webp" ? "image/webp" : "image/jpeg";
          res.setHeader("Content-Type", mime);
          res.setHeader("Cache-Control", "public, max-age=86400");
          return res.sendFile(p);
        }
      }
    }
    if (cleanQris.startsWith("http://") || cleanQris.startsWith("https://")) {
      return res.redirect(cleanQris);
    }
    return res.status(404).json({ error: "Gambar QRIS tidak dapat diakses." });
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat gambar QRIS." });
  }
});
merchantRouter.post("/", requireRole(["ADMIN"]), async (req, res) => {
  const merchantData = req.body;
  try {
    const actorId = req.user?.userId || "admin";
    const created = await foodDb.createMerchant(actorId, merchantData);
    res.status(201).json(created);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.put("/:id", requireMerchantOwner("id"), async (req, res) => {
  const updates = { ...req.body };
  delete updates.id;
  try {
    const actorId = req.user?.userId || req.user?.entityId || req.params.id;
    const actorRole = req.user?.role === "ADMIN" || req.user?.role === "MASTER_ADMIN" || req.user?.isMasterAdmin ? "ADMIN" : "MERCHANT";
    const updated = await foodDb.updateMerchant(actorId, req.params.id, updates, actorRole);
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.put("/:id/qris", requireMerchantOwner("id"), async (req, res) => {
  const { qrisImage } = req.body;
  if (!qrisImage || typeof qrisImage !== "string" || qrisImage.trim().length < 10) {
    return res.status(400).json({ error: "Gambar QRIS statis wajib diunggah dalam format gambar yang sah." });
  }
  const cleanQris = qrisImage.trim();
  if (!cleanQris.startsWith("data:image/") && !cleanQris.startsWith("http://") && !cleanQris.startsWith("https://")) {
    return res.status(400).json({ error: "Format QRIS tidak didukung. Unggah gambar berformat JPEG, PNG, atau WebP." });
  }
  if (cleanQris.length > 7 * 1024 * 1024) {
    return res.status(400).json({ error: "Ukuran file gambar QRIS melebihi batas maksimal 5MB. Silakan gunakan gambar yang lebih kecil." });
  }
  try {
    const actorId = req.user?.userId || req.user?.entityId || req.params.id;
    const actorRole = req.user?.role === "ADMIN" || req.user?.role === "MASTER_ADMIN" || req.user?.isMasterAdmin ? "ADMIN" : "MERCHANT";
    const updated = await foodDb.updateMerchant(
      actorId,
      req.params.id,
      {
        qrisImage: cleanQris,
        qrisUpdatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      actorRole
    );
    res.json({
      success: true,
      message: "QRIS statis merchant berhasil disimpan.",
      qrisImage: updated.qrisImage,
      qrisUpdatedAt: updated.qrisUpdatedAt,
      merchant: updated
    });
  } catch (e) {
    res.status(400).json({ error: e.message || "Gagal menyimpan QRIS merchant." });
  }
});
merchantRouter.delete("/:id/qris", requireMerchantOwner("id"), async (req, res) => {
  try {
    const actorId = req.user?.userId || req.user?.entityId || req.params.id;
    const actorRole = req.user?.role === "ADMIN" || req.user?.role === "MASTER_ADMIN" || req.user?.isMasterAdmin ? "ADMIN" : "MERCHANT";
    const updated = await foodDb.updateMerchant(
      actorId,
      req.params.id,
      {
        qrisImage: "",
        qrisUpdatedAt: (/* @__PURE__ */ new Date()).toISOString()
      },
      actorRole
    );
    res.json({
      success: true,
      message: "QRIS statis merchant berhasil dihapus.",
      merchant: updated
    });
  } catch (e) {
    res.status(400).json({ error: e.message || "Gagal menghapus QRIS merchant." });
  }
});
merchantRouter.delete("/:id", requireRole(["ADMIN"]), async (req, res) => {
  const actorId = req.user?.userId || "admin";
  try {
    const success = await foodDb.deleteMerchant(actorId, req.params.id);
    if (success) res.json({ success: true });
    else res.status(404).json({ error: "Merchant not found" });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.get("/:id/categories", (req, res, next) => {
  try {
    res.json(foodDb.getCategories(req.params.id));
  } catch (err) {
    next(err);
  }
});
merchantRouter.post("/:id/categories", requireMerchantOwner("id"), async (req, res) => {
  const { name } = req.body;
  if (!name || !name.trim()) {
    return res.status(400).json({ error: "Nama kategori wajib diisi." });
  }
  try {
    const created = await foodDb.createCategory(req.params.id, name.trim());
    res.status(201).json(created);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.put("/:merchantId/categories/:id", requireMerchantOwner("merchantId"), async (req, res) => {
  const { name } = req.body;
  if (!name || !name.trim()) {
    return res.status(400).json({ error: "Nama kategori wajib diisi." });
  }
  try {
    const updated = await foodDb.updateCategory(req.params.merchantId, req.params.id, name.trim());
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.delete("/:merchantId/categories/:id", requireMerchantOwner("merchantId"), async (req, res) => {
  try {
    const success = await foodDb.deleteCategory(req.params.merchantId, req.params.id);
    if (success) res.json({ success: true });
    else res.status(404).json({ error: "Category not found" });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.get("/:id/menu", (req, res, next) => {
  try {
    res.json(foodDb.getMenuItemsByMerchant(req.params.id));
  } catch (err) {
    next(err);
  }
});
merchantRouter.post("/:id/menu", requireMerchantOwner("id"), async (req, res) => {
  try {
    const created = await foodDb.createMenuItem(req.params.id, req.body);
    res.status(201).json(created);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.put("/:merchantId/menu/:id", requireMerchantOwner("merchantId"), async (req, res) => {
  try {
    const updated = await foodDb.updateMenuItem(req.params.merchantId, req.params.id, req.body);
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.delete("/:merchantId/menu/:id", requireMerchantOwner("merchantId"), async (req, res) => {
  try {
    const success = await foodDb.deleteMenuItem(req.params.merchantId, req.params.id);
    if (success) res.json({ success: true });
    else res.status(404).json({ error: "Menu item not found" });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
merchantRouter.get("/:merchantId/orders", requireMerchantOwner("merchantId"), (req, res) => {
  res.json(foodDb.getOrdersByMerchant(req.params.merchantId));
});
merchantRouter.get("/:merchantId/settlements", requireMerchantOwner("merchantId"), (req, res) => {
  res.json(foodDb.getSettlementsByMerchant(req.params.merchantId));
});

// src/server/routes/driverRoutes.ts
var import_express4 = require("express");
var driverRouter = (0, import_express4.Router)();
driverRouter.get("/", (req, res) => {
  const drivers = foodDb.getDrivers();
  const sanitized = drivers.map((d) => ({
    id: d.id,
    name: d.name,
    phone: d.phone,
    active: d.active
  }));
  res.json(sanitized);
});
driverRouter.get("/:id", requireDriverSelf("id"), (req, res) => {
  const d = foodDb.getDriverById(req.params.id);
  if (!d) return res.status(404).json({ error: "Driver not found" });
  res.json(d);
});
driverRouter.post("/", requireRole(["ADMIN"]), async (req, res) => {
  const { userId, ...driverData } = req.body;
  try {
    const created = await foodDb.createDriver(req.user?.userId || userId || "admin", driverData);
    res.status(201).json(created);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
driverRouter.put("/:id", requireDriverSelf("id"), async (req, res) => {
  const { userId, role, ...updates } = req.body;
  try {
    const updated = await foodDb.updateDriver(
      req.user?.userId || userId || req.params.id,
      req.params.id,
      updates,
      req.user?.role || role || "DRIVER"
    );
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
driverRouter.delete("/:id", requireRole(["ADMIN"]), async (req, res) => {
  const { userId } = req.body;
  try {
    const success = await foodDb.deleteDriver(req.user?.userId || userId || "admin", req.params.id);
    if (success) res.json({ success: true });
    else res.status(404).json({ error: "Driver not found" });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
driverRouter.get("/:driverId/orders", requireDriverSelf("driverId"), (req, res) => {
  res.json(foodDb.getOrdersByDriver(req.params.driverId));
});

// src/server/routes/orderRoutes.ts
var import_path9 = __toESM(require("path"), 1);
var import_fs9 = __toESM(require("fs"), 1);
var import_express5 = require("express");
var import_sharp = __toESM(require("sharp"), 1);
var orderRouter = (0, import_express5.Router)();
orderRouter.get("/", (req, res) => {
  const user = req.user;
  if (!user) {
    return res.status(401).json({ error: "Autentikasi diperlukan untuk melihat daftar pesanan." });
  }
  if (user.role === "ADMIN" || user.role === "MASTER_ADMIN") {
    return res.json(foodDb.getOrders());
  }
  if (user.role === "MERCHANT" && user.entityId) {
    return res.json(foodDb.getOrdersByMerchant(user.entityId));
  }
  if (user.role === "DRIVER" && user.entityId) {
    return res.json(foodDb.getOrdersByDriver(user.entityId));
  }
  return res.status(403).json({ error: "Akses ditolak." });
});
orderRouter.get("/:id/receipt", async (req, res) => {
  try {
    const o = await foodDb.findOrder(req.params.id);
    if (!o) return res.status(404).json({ error: "Pesanan tidak ditemukan." });
    const isPaid = o.paymentStatus === "PAID" /* PAID */ || ["PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */, "COOKING" /* COOKING */, "READY_FOR_PICKUP" /* READY_FOR_PICKUP */, "ORDER_PICKED_UP" /* ORDER_PICKED_UP */, "DELIVERED" /* DELIVERED */, "COMPLETED" /* COMPLETED */].includes(o.status);
    if (!isPaid) {
      return res.status(403).json({
        error: "E-Receipt belum dapat diterbitkan. Pembayaran belum diverifikasi atau belum lunas.",
        code: "PAYMENT_NOT_VERIFIED",
        orderId: o.id,
        paymentStatus: o.paymentStatus || "PENDING",
        orderStatus: o.status
      });
    }
    const user = req.user;
    const isPrivilegedUser = user && (user.role === "ADMIN" || user.role === "MASTER_ADMIN" || user.role === "MERCHANT" && user.entityId === o.merchantId || user.role === "DRIVER" && user.entityId === o.driverId || user.role === "CUSTOMER" && (user.userId === o.customerId || user.email && o.customerPhone && user.email === o.customerPhone));
    if (!isPrivilegedUser) {
      const queryPhone = req.query.phone ? String(req.query.phone).trim() : "";
      const headerPhone = req.headers["x-customer-phone"] ? String(req.headers["x-customer-phone"]).trim() : "";
      const providedPhone = queryPhone || headerPhone;
      const normOrderPhone = String(o.customerPhone || "").replace(/\D/g, "");
      const normProvidedPhone = providedPhone.replace(/\D/g, "");
      const phoneMatches = Boolean(
        normProvidedPhone.length >= 4 && (normOrderPhone.endsWith(normProvidedPhone) || normProvidedPhone.endsWith(normOrderPhone))
      );
      if (!phoneMatches) {
        return res.status(403).json({
          error: "Akses ditolak: Verifikasi nomor WhatsApp pemesan diperlukan untuk mengakses rincian E-Receipt.",
          code: "RECEIPT_VERIFICATION_REQUIRED",
          orderId: o.id
        });
      }
    }
    let receipt = o.receipt;
    if (!receipt) {
      const receiptNumber = o.receiptNumber || `TG-RCP-${o.id.replace(/^ord_/, "").toUpperCase()}`;
      const issuedAt = o.paymentVerifiedAt || o.updatedAt || o.createdAt;
      receipt = {
        receiptNumber,
        orderId: o.id,
        issuedAt,
        confirmedBy: o.paymentVerifiedBy || "Admin TumpangGo",
        paymentMethod: o.paymentMethod || "MERCHANT_QRIS",
        transactionRef: o.artopayPaymentId || `QRIS-TG-${o.id.replace(/^ord_/, "").toUpperCase()}`,
        subtotal: o.subtotal,
        deliveryFee: o.deliveryFee,
        serviceFee: o.serviceFee,
        uniqueCode: o.uniqueCode || 0,
        total: o.total,
        customerName: o.customerName,
        merchantName: o.merchantName,
        status: "PAID"
      };
    }
    res.json({
      receipt,
      order: {
        id: o.id,
        customerName: o.customerName,
        customerPhoneMasked: o.customerPhone ? o.customerPhone.substring(0, 4) + "****" + o.customerPhone.slice(-3) : "",
        deliveryAddress: o.deliveryAddress,
        merchantId: o.merchantId,
        merchantName: o.merchantName,
        items: o.items,
        subtotal: o.subtotal,
        deliveryFee: o.deliveryFee,
        serviceFee: o.serviceFee,
        uniqueCode: o.uniqueCode || 0,
        total: o.total,
        paymentStatus: o.paymentStatus,
        status: o.status,
        paymentMethod: o.paymentMethod || "MERCHANT_QRIS",
        paymentVerifiedAt: o.paymentVerifiedAt,
        paymentVerifiedBy: o.paymentVerifiedBy || "Admin TumpangGo",
        createdAt: o.createdAt
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat E-Receipt." });
  }
});
orderRouter.get("/:id", async (req, res) => {
  const o = await foodDb.findOrder(req.params.id);
  if (!o) return res.status(404).json({ error: "Pesanan tidak ditemukan." });
  res.json(o);
});
orderRouter.get("/:id/qris", async (req, res) => {
  try {
    const order = await foodDb.findOrder(req.params.id);
    if (!order) return res.status(404).json({ error: "Pesanan tidak ditemukan." });
    const merchant = foodDb.getMerchantById(order.merchantId);
    const rawQris = order.merchantQrisImage || merchant?.qrisImage;
    const hasQris = Boolean(rawQris && typeof rawQris === "string" && rawQris.trim().length > 3 && !rawQris.includes("unsplash"));
    res.json({
      orderId: order.id,
      merchantId: order.merchantId,
      merchantName: order.merchantName,
      total: order.total,
      hasQris,
      qrisImage: hasQris ? rawQris : null,
      qrisImageUrl: hasQris ? `/api/orders/${order.id}/qris-image` : null
    });
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat status QRIS pesanan." });
  }
});
orderRouter.get("/:id/qris-image", async (req, res) => {
  try {
    const order = await foodDb.findOrder(req.params.id);
    if (!order) return res.status(404).json({ error: "Pesanan tidak ditemukan." });
    const merchant = foodDb.getMerchantById(order.merchantId);
    const rawQris = order.merchantQrisImage || merchant?.qrisImage;
    if (!rawQris || typeof rawQris !== "string" || rawQris.trim().length < 3 || rawQris.includes("unsplash")) {
      return res.status(404).json({ error: `Toko "${order.merchantName}" belum memiliki QRIS statis resmi.` });
    }
    const cleanQris = rawQris.trim();
    if (cleanQris.startsWith("data:image/")) {
      const matches = cleanQris.match(/^data:(image\/[a-zA-Z0-9.+_-]+);base64,(.+)$/);
      if (matches) {
        res.setHeader("Content-Type", matches[1]);
        res.setHeader("Cache-Control", "public, max-age=86400");
        return res.send(Buffer.from(matches[2], "base64"));
      }
    }
    if (cleanQris.startsWith("/")) {
      const candidatePaths = [
        import_path9.default.resolve(process.cwd(), "dist", cleanQris.replace(/^\//, "")),
        import_path9.default.resolve(process.cwd(), "public", cleanQris.replace(/^\//, "")),
        import_path9.default.resolve("/var/task", "dist", cleanQris.replace(/^\//, "")),
        import_path9.default.resolve("/var/task", "public", cleanQris.replace(/^\//, ""))
      ];
      for (const p of candidatePaths) {
        if (import_fs9.default.existsSync(p) && import_fs9.default.statSync(p).isFile()) {
          const ext = import_path9.default.extname(p).toLowerCase();
          const mime = ext === ".png" ? "image/png" : ext === ".webp" ? "image/webp" : "image/jpeg";
          res.setHeader("Content-Type", mime);
          res.setHeader("Cache-Control", "public, max-age=86400");
          return res.sendFile(p);
        }
      }
    }
    if (cleanQris.startsWith("http://") || cleanQris.startsWith("https://")) {
      return res.redirect(cleanQris);
    }
    return res.status(404).json({ error: "Gambar QRIS pesanan tidak dapat diakses." });
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat gambar QRIS pesanan." });
  }
});
orderRouter.get("/:id/payment-proof", async (req, res) => {
  try {
    const order = await foodDb.findOrder(req.params.id);
    if (!order) return res.status(404).json({ error: "Pesanan tidak ditemukan." });
    const proof = order.paymentProof;
    if (!proof || typeof proof !== "string" || proof.trim().length < 10) {
      return res.status(404).json({ error: "Bukti pembayaran belum diunggah untuk pesanan ini." });
    }
    const cleanProof = proof.trim();
    if (cleanProof.startsWith("data:image/")) {
      const matches = cleanProof.match(/^data:(image\/[a-zA-Z0-9.+_-]+);base64,(.+)$/);
      if (matches) {
        res.setHeader("Content-Type", matches[1]);
        res.setHeader("Cache-Control", "private, max-age=3600");
        return res.send(Buffer.from(matches[2], "base64"));
      }
    }
    if (cleanProof.startsWith("http://") || cleanProof.startsWith("https://")) {
      return res.redirect(cleanProof);
    }
    return res.status(404).json({ error: "Format bukti pembayaran tidak valid." });
  } catch (err) {
    res.status(500).json({ error: err.message || "Gagal memuat bukti pembayaran." });
  }
});
orderRouter.get("/customer/:phone", (req, res) => {
  res.json(foodDb.getOrdersByCustomerPhone(req.params.phone));
});
orderRouter.post("/", async (req, res) => {
  const reqId = req.id || req.headers["x-request-id"] || "req_" + Math.random().toString(36).substring(2, 9);
  try {
    const { merchantId, customerName, customerPhone, deliveryAddress, items } = req.body || {};
    if (!merchantId || typeof merchantId !== "string" || merchantId.trim().length === 0) {
      console.warn(`[Order Validation Error] [${reqId}] Merchant ID is missing`);
      return res.status(400).json({
        error: "Toko / Merchant kuliner wajib dipilih.",
        code: "MISSING_MERCHANT_ID",
        stage: "ORDER_VALIDATION",
        requestId: reqId
      });
    }
    if (!customerName || !customerPhone || !deliveryAddress) {
      console.warn(`[Order Validation Error] [${reqId}] Customer details missing (Name: ${Boolean(customerName)}, Phone: ${Boolean(customerPhone)}, Address: ${Boolean(deliveryAddress)})`);
      return res.status(400).json({
        error: "Nama pemesan, nomor WhatsApp, dan alamat pengantaran wajib diisi lengkap.",
        code: "MISSING_CUSTOMER_DETAILS",
        stage: "ORDER_VALIDATION",
        requestId: reqId
      });
    }
    if (!items || !Array.isArray(items) || items.length === 0) {
      console.warn(`[Order Validation Error] [${reqId}] Cart items empty`);
      return res.status(400).json({
        error: "Keranjang belanja Anda kosong. Silakan pilih menu makanan terlebih dahulu.",
        code: "EMPTY_CART",
        stage: "ORDER_VALIDATION",
        requestId: reqId
      });
    }
    const created = await foodDb.createOrder(req.body);
    console.log(`[Order Placed Successfully] [${reqId}] ID: ${created.id}, Total: Rp ${created.total.toLocaleString("id-ID")}, Merchant: ${created.merchantId}, UniqueCode: ${created.uniqueCode}`);
    return res.status(201).json(created);
  } catch (e) {
    const errorMsg = e.message || "Gagal membuat pesanan.";
    const isDbError = errorMsg.includes("Firestore") || errorMsg.includes("database") || errorMsg.includes("penyimpanan");
    console.error(`[Order Creation Failed] [${reqId}] Stage: ${isDbError ? "DATABASE_PERSISTENCE" : "ORDER_VALIDATION"}, Error: ${errorMsg}`);
    return res.status(isDbError ? 500 : 400).json({
      error: errorMsg,
      code: isDbError ? "DATABASE_PERSISTENCE_ERROR" : "ORDER_VALIDATION_ERROR",
      stage: isDbError ? "DATABASE_PERSISTENCE" : "ORDER_VALIDATION",
      requestId: reqId
    });
  }
});
orderRouter.put("/:id", async (req, res) => {
  const user = req.user;
  const currentOrder = await foodDb.findOrder(req.params.id);
  if (!currentOrder) {
    return res.status(404).json({ error: "Pesanan tidak ditemukan." });
  }
  const { userId, role, customerPhone, cancelReason, overrideExpired, ...rawUpdates } = req.body;
  const updates = { ...rawUpdates };
  delete updates.isSettled;
  delete updates.settlementId;
  delete updates.settledAt;
  delete updates.total;
  delete updates.subtotal;
  delete updates.serviceFee;
  delete updates.deliveryFee;
  delete updates.merchantId;
  delete updates.id;
  if (updates.status === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */ || updates.paymentStatus === "PAID" /* PAID */) {
    if (!user || user.role !== "ADMIN" && user.role !== "MASTER_ADMIN") {
      return res.status(403).json({
        error: "Akses ditolak: Hanya Admin yang berwenang memverifikasi pembayaran menjadi lunas (PAID)."
      });
    }
  }
  if (updates.status === "PAYMENT_REJECTED" /* PAYMENT_REJECTED */ || updates.paymentStatus === "REJECTED" /* REJECTED */) {
    if (!user || user.role !== "ADMIN" && user.role !== "MASTER_ADMIN") {
      return res.status(403).json({
        error: "Akses ditolak: Hanya Admin yang berwenang menolak bukti pembayaran."
      });
    }
  }
  if (!user) {
    const isCustomerCancel = updates.status === "CANCELLED" /* CANCELLED */ && customerPhone && String(customerPhone).trim() === String(currentOrder.customerPhone).trim() && (currentOrder.status === "WAITING_PAYMENT" /* WAITING_PAYMENT */ || currentOrder.status === "WAITING_PAYMENT_VERIFICATION" /* WAITING_PAYMENT_VERIFICATION */);
    if (!isCustomerCancel) {
      return res.status(401).json({
        error: "Akses ditolak: Autentikasi diperlukan untuk mengubah status atau data pesanan."
      });
    }
    try {
      const updated = await foodDb.updateOrder(
        "CUSTOMER",
        req.params.id,
        {
          status: "CANCELLED" /* CANCELLED */,
          cancelReason: cancelReason || "Dibatalkan oleh Pelanggan"
        },
        "CUSTOMER"
      );
      return res.json(updated);
    } catch (e) {
      return res.status(400).json({ error: e.message });
    }
  }
  if (user.role === "MERCHANT") {
    if (user.entityId !== currentOrder.merchantId && user.userId !== currentOrder.merchantId) {
      return res.status(403).json({
        error: "Akses ditolak: Anda tidak memiliki izin untuk mengelola pesanan milik toko lain."
      });
    }
    if (updates.status) {
      const allowedMerchantStatuses = [
        "COOKING" /* COOKING */,
        "READY_FOR_PICKUP" /* READY_FOR_PICKUP */,
        "CANCELLED" /* CANCELLED */
      ];
      if (!allowedMerchantStatuses.includes(updates.status)) {
        return res.status(403).json({
          error: `Merchant tidak diizinkan mengubah status pesanan ke ${updates.status}.`
        });
      }
    }
  }
  if (user.role === "DRIVER") {
    const isAssigned = currentOrder.driverId === user.entityId || currentOrder.driverId === user.userId;
    const canAcceptTask = !currentOrder.driverId && currentOrder.status === "READY_FOR_PICKUP" /* READY_FOR_PICKUP */;
    if (!isAssigned && !canAcceptTask) {
      return res.status(403).json({
        error: "Akses ditolak: Pesanan ini bukan tugas pengantaran Anda."
      });
    }
    if (updates.status) {
      const allowedDriverStatuses = [
        "ORDER_PICKED_UP" /* ORDER_PICKED_UP */,
        "COMPLETED" /* COMPLETED */
      ];
      if (!allowedDriverStatuses.includes(updates.status)) {
        return res.status(403).json({
          error: `Driver tidak diizinkan mengubah status pesanan ke ${updates.status}.`
        });
      }
    }
  }
  if (currentOrder.status === "EXPIRED" /* EXPIRED */ || currentOrder.status === "CANCELLED" /* CANCELLED */) {
    if (updates.status && updates.status !== currentOrder.status) {
      if ((user.role === "ADMIN" || user.role === "MASTER_ADMIN") && currentOrder.status === "EXPIRED" /* EXPIRED */) {
        if (!overrideExpired) {
          return res.status(400).json({
            error: "Pesanan telah KEDALUWARSA (EXPIRED). Verifikasi pembayaran tidak dapat dilakukan secara tidak sengaja. Sertakan persetujuan eksplisit pembayaran terlambat (overrideExpired: true) beserta catatan administrasi."
          });
        }
        foodDb.log(
          user.userId,
          `Admin explicitly approved late payment for expired order ${currentOrder.id}`,
          "ADMIN"
        );
      } else {
        return res.status(400).json({
          error: `Pesanan yang telah ${currentOrder.status} tidak dapat diaktifkan kembali secara langsung.`
        });
      }
    }
  }
  if (cancelReason) {
    updates.cancelReason = cancelReason;
  }
  try {
    const updated = await foodDb.updateOrder(
      user.userId || user.entityId || "system",
      req.params.id,
      updates,
      user.role
    );
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
orderRouter.post("/:id/assign-driver", requireRole(["ADMIN"]), async (req, res) => {
  const { driverId } = req.body;
  if (!driverId) {
    return res.status(400).json({ error: "Driver ID wajib disertakan." });
  }
  try {
    const updated = await foodDb.manualAssignDriver(req.user?.userId || "admin", req.params.id, driverId);
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
orderRouter.post("/:id/upload-payment", async (req, res) => {
  const { paymentProof } = req.body;
  if (!paymentProof || typeof paymentProof !== "string" || paymentProof.trim().length < 10) {
    return res.status(400).json({ error: "Bukti pembayaran wajib diunggah dalam format gambar atau foto yang sah." });
  }
  const cleanProof = paymentProof.trim();
  const isDataUri = cleanProof.startsWith("data:image/");
  const isHttpUrl = cleanProof.startsWith("http://") || cleanProof.startsWith("https://");
  if (!isDataUri && !isHttpUrl) {
    return res.status(400).json({ error: "Format file tidak didukung. Mohon unggah bukti berformat gambar (JPG, PNG, atau WebP)." });
  }
  if (isDataUri && cleanProof.length > 11 * 1024 * 1024) {
    return res.status(400).json({ error: "Ukuran file gambar bukti transfer melebihi batas maksimal 8MB. Silakan pilih foto dengan resolusi lebih kecil." });
  }
  const order = await foodDb.findOrder(req.params.id);
  if (!order) {
    return res.status(404).json({ error: "Pesanan tidak ditemukan." });
  }
  const now = Date.now();
  const expiryTime = order.paymentExpiresAt ? new Date(order.paymentExpiresAt).getTime() : 0;
  if (expiryTime && now > expiryTime && order.status === "WAITING_PAYMENT" /* WAITING_PAYMENT */) {
    await foodDb.updateOrder("SYSTEM", order.id, {
      status: "EXPIRED" /* EXPIRED */,
      paymentStatus: "EXPIRED" /* EXPIRED */
    }, "SYSTEM");
    return res.status(400).json({
      error: "Waktu pembayaran untuk pesanan ini telah kedaluwarsa. Pesanan ditandai sebagai KEDALUWARSA dan tidak dapat diproses lagi."
    });
  }
  if (order.status === "EXPIRED" /* EXPIRED */) {
    return res.status(400).json({
      error: "Pesanan ini telah kedaluwarsa dan tidak dapat menerima bukti pembayaran lagi."
    });
  }
  if (order.status === "CANCELLED" /* CANCELLED */) {
    return res.status(400).json({
      error: "Pesanan ini telah dibatalkan dan tidak dapat menerima bukti pembayaran."
    });
  }
  let finalProof = cleanProof;
  const proofUrl = `/api/orders/${order.id}/payment-proof`;
  if (isDataUri) {
    try {
      const match = cleanProof.match(/^data:image\/([a-zA-Z0-9.+_-]+);base64,(.+)$/);
      if (match) {
        const rawBuffer = Buffer.from(match[2], "base64");
        const optimizedBuffer = await (0, import_sharp.default)(rawBuffer).rotate().resize({ width: 1200, height: 1200, fit: "inside", withoutEnlargement: true }).webp({ quality: 80 }).toBuffer();
        finalProof = `data:image/webp;base64,${optimizedBuffer.toString("base64")}`;
      }
    } catch (sharpErr) {
      console.warn("[OrderRoutes] Sharp optimization warning, falling back to original client image:", sharpErr?.message || sharpErr);
      if (sharpErr?.message?.includes("unsupported") || sharpErr?.message?.includes("Input buffer")) {
        return res.status(400).json({ error: "File gambar yang dipilih tidak valid atau rusak. Silakan pilih foto screenshot yang sah." });
      }
    }
  }
  try {
    const updated = await foodDb.updateOrder(
      "CUSTOMER",
      req.params.id,
      {
        paymentProof: finalProof,
        paymentProofUrl: proofUrl,
        paymentProofUploadedAt: (/* @__PURE__ */ new Date()).toISOString(),
        paymentStatus: "WAITING_VERIFICATION" /* WAITING_VERIFICATION */,
        status: "WAITING_PAYMENT_VERIFICATION" /* WAITING_PAYMENT_VERIFICATION */,
        paymentRejectionReason: void 0
      },
      "CUSTOMER"
    );
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message || "Gagal menyimpan bukti pembayaran." });
  }
});
orderRouter.post("/:id/verify-payment", requireRole(["ADMIN"]), async (req, res) => {
  try {
    const adminId = req.user?.userId || req.user?.email || "admin";
    const updated = await foodDb.verifyOrderPayment(adminId, req.params.id);
    res.json({ success: true, order: updated });
  } catch (e) {
    res.status(400).json({ error: e.message || "Gagal memverifikasi pembayaran." });
  }
});
orderRouter.post("/:id/reject-payment", requireRole(["ADMIN"]), async (req, res) => {
  const { reason } = req.body;
  if (!reason || !String(reason).trim()) {
    return res.status(400).json({ error: "Alasan penolakan bukti pembayaran wajib disertakan agar pelanggan dapat memperbaikinya." });
  }
  try {
    const adminId = req.user?.userId || req.user?.email || "admin";
    const updated = await foodDb.rejectOrderPayment(adminId, req.params.id, String(reason).trim());
    res.json({ success: true, order: updated });
  } catch (e) {
    res.status(400).json({ error: e.message || "Gagal menolak bukti pembayaran." });
  }
});
orderRouter.post("/:id/upload-delivery", requireRole(["DRIVER", "ADMIN", "MASTER_ADMIN"]), async (req, res) => {
  const { deliveryProof } = req.body;
  if (!deliveryProof) {
    return res.status(400).json({ error: "Bukti foto pengantaran wajib disertakan." });
  }
  const order = await foodDb.findOrder(req.params.id);
  if (!order) {
    return res.status(404).json({ error: "Pesanan tidak ditemukan." });
  }
  const user = req.user;
  if (user.role === "DRIVER") {
    if (order.driverId !== user.entityId && order.driverId !== user.userId) {
      return res.status(403).json({ error: "Akses ditolak: Anda bukan kurir yang ditugaskan untuk pesanan ini." });
    }
  }
  try {
    const updated = await foodDb.updateOrder(
      user.userId || user.entityId || "driver",
      req.params.id,
      {
        deliveryProof,
        status: "COMPLETED" /* COMPLETED */
      },
      user.role
    );
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

// src/server/routes/adminRoutes.ts
var import_express6 = require("express");
var adminRouter = (0, import_express6.Router)();
adminRouter.get("/config", (req, res) => {
  res.json(foodDb.getConfig());
});
adminRouter.put("/config", requireRole(["ADMIN"]), async (req, res) => {
  const { userId, ...updates } = req.body;
  try {
    const config = await foodDb.updateConfig(req.user?.userId || userId || "admin", updates);
    res.json(config);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
adminRouter.get("/partner-registrations", requireRole(["ADMIN"]), (req, res) => {
  res.json(foodDb.getPartnerRegistrations());
});
adminRouter.post("/partner-registrations", async (req, res) => {
  try {
    const created = await foodDb.createPartnerRegistration(req.body);
    res.status(201).json(created);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
adminRouter.put("/partner-registrations/:id/approve", requireRole(["ADMIN"]), async (req, res) => {
  const { userId } = req.body;
  try {
    const result = await foodDb.approvePartnerRegistration(req.user?.userId || userId || "admin", req.params.id);
    if (result.success) {
      res.json({ success: true, registration: result.registration });
    } else {
      res.status(400).json({ error: result.error });
    }
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
adminRouter.post("/partner-registrations/:id/reject", requireRole(["ADMIN"]), async (req, res) => {
  const { userId } = req.body;
  try {
    const success = await foodDb.rejectPartnerRegistration(req.user?.userId || userId || "admin", req.params.id);
    if (success) {
      res.json({ success: true });
    } else {
      res.status(404).json({ error: "Registration not found" });
    }
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
adminRouter.get("/settlements", requireRole(["ADMIN"]), (req, res) => {
  res.json(foodDb.getSettlements());
});
adminRouter.post("/settlements", requireRole(["ADMIN"]), async (req, res) => {
  const settlementData = req.body;
  try {
    const actorId = req.user?.userId || "admin";
    const created = await foodDb.createSettlement(actorId, settlementData);
    res.status(201).json(created);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
adminRouter.put("/settlements/:id", requireRole(["ADMIN"]), async (req, res) => {
  const updates = req.body;
  try {
    const actorId = req.user?.userId || "admin";
    const updated = await foodDb.updateSettlement(actorId, req.params.id, updates);
    res.json(updated);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
adminRouter.post("/settlements/generate", requireRole(["ADMIN"]), async (req, res) => {
  try {
    const actorId = req.user?.userId || "admin";
    const created = await foodDb.generateHPlusOneSettlements(actorId);
    res.json({ count: created.length, settlements: created });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
adminRouter.post("/settlements/:id/confirm", requireRole(["ADMIN"]), async (req, res) => {
  try {
    const actorId = req.user?.userId || "admin";
    const confirmed = await foodDb.confirmSettlement(actorId, req.params.id);
    res.json(confirmed);
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
adminRouter.get("/logs", requireRole(["ADMIN"]), (req, res) => {
  res.json(foodDb.getLogs());
});
var handleGetPublishedReviews = (req, res) => {
  try {
    const category = req.query.category;
    const list = foodDb.getPublishedTestimonials(category);
    res.json(list);
  } catch (e) {
    res.status(500).json({ error: e.message || "Gagal memuat review pengguna" });
  }
};
adminRouter.get("/testimonials", handleGetPublishedReviews);
adminRouter.get("/reviews", handleGetPublishedReviews);
function sanitizeInput(str) {
  if (typeof str !== "string") return "";
  return str.replace(/<[^>]*>?/gm, "").trim();
}
var handleSubmitReview = async (req, res) => {
  try {
    const rawName = sanitizeInput(req.body.userName);
    const rawCategory = String(req.body.category || "").toLowerCase().trim();
    const rawMerchantName = sanitizeInput(req.body.merchantName);
    const rawTitle = sanitizeInput(req.body.title);
    const rawContent = sanitizeInput(req.body.content);
    const rawRating = req.body.rating;
    const consentApproved = Boolean(req.body.consentApproved);
    if (!rawName || rawName.length < 2) {
      return res.status(400).json({ error: "Nama pemberi review wajib diisi (minimal 2 karakter)." });
    }
    if (rawName.length > 100) {
      return res.status(400).json({ error: "Nama pemberi review maksimal 100 karakter." });
    }
    if (rawCategory !== "merchant" && rawCategory !== "pelanggan" && rawCategory !== "umkm") {
      return res.status(400).json({ error: "Kategori ulasan tidak valid. Pilih Merchant atau Pelanggan." });
    }
    const normalizedCategory = rawCategory === "merchant" || rawCategory === "umkm" ? "merchant" : "pelanggan";
    if (normalizedCategory === "merchant") {
      if (!rawMerchantName || rawMerchantName.length < 2) {
        return res.status(400).json({ error: "Nama usaha atau merchant wajib diisi untuk ulasan merchant (minimal 2 karakter)." });
      }
      if (rawMerchantName.length > 100) {
        return res.status(400).json({ error: "Nama usaha atau merchant maksimal 100 karakter." });
      }
    }
    if (rawRating === void 0 || rawRating === null || rawRating === "") {
      return res.status(400).json({ error: "Rating bintang wajib dipilih (1 sampai 5)." });
    }
    const numRating = Number(rawRating);
    if (!Number.isInteger(numRating) || numRating < 1 || numRating > 5) {
      return res.status(400).json({ error: "Rating harus berupa bilangan bulat antara 1 sampai 5." });
    }
    if (rawTitle && rawTitle.length > 100) {
      return res.status(400).json({ error: "Judul review maksimal 100 karakter." });
    }
    if (!rawContent || rawContent.length < 10) {
      return res.status(400).json({ error: "Isi komentar/pengalaman wajib diisi minimal 10 karakter." });
    }
    if (rawContent.length > 1e3) {
      return res.status(400).json({ error: "Isi komentar/pengalaman maksimal 1000 karakter." });
    }
    if (!consentApproved) {
      return res.status(400).json({ error: "Anda harus menyetujui bahwa ulasan ini merupakan pengalaman nyata bersama TumpangGo." });
    }
    const roleDetail = normalizedCategory === "merchant" ? rawMerchantName ? `Pemilik ${rawMerchantName}` : "Mitra Kuliner Tumpang" : "Pelanggan TumpangGo";
    const created = await foodDb.createTestimonial({
      userName: rawName,
      merchantName: normalizedCategory === "merchant" ? rawMerchantName : void 0,
      category: normalizedCategory,
      title: rawTitle || void 0,
      content: rawContent,
      avatarUrl: void 0,
      roleDetail,
      rating: numRating,
      consentApproved: true,
      status: "pending",
      // Menunggu kurasi admin
      displayOrder: 99
    });
    res.status(201).json({
      success: true,
      message: "Review Anda berhasil dikirim dan sedang menunggu moderasi admin sebelum dipublikasikan.",
      testimonial: created,
      review: created
    });
  } catch (e) {
    res.status(500).json({ error: e.message || "Gagal mengirim review pengguna." });
  }
};
adminRouter.post("/testimonials/submit", handleSubmitReview);
adminRouter.post("/reviews/submit", handleSubmitReview);
var handleGetAdminReviews = (req, res) => {
  try {
    const category = req.query.category;
    const status = req.query.status;
    const list = foodDb.getAllTestimonials({ category, status });
    res.json(list);
  } catch (e) {
    res.status(500).json({ error: e.message || "Gagal memuat daftar review admin." });
  }
};
adminRouter.get("/admin/testimonials", requireRole(["ADMIN", "MASTER_ADMIN"]), handleGetAdminReviews);
adminRouter.get("/admin/reviews", requireRole(["ADMIN", "MASTER_ADMIN"]), handleGetAdminReviews);
var handleCreateAdminReview = async (req, res) => {
  try {
    const actorId = req.user?.userId || "admin";
    const { userName, merchantName, title, category, content, avatarUrl, roleDetail, rating, consentApproved, status, displayOrder } = req.body;
    if (!userName || !content) {
      return res.status(400).json({ error: "Nama dan isi review wajib diisi." });
    }
    const rawCat = String(category || "").toLowerCase();
    const normalizedCategory = rawCat === "merchant" || rawCat === "umkm" ? "merchant" : "pelanggan";
    const parsedRating = rating !== void 0 && rating !== null ? Math.min(5, Math.max(1, Math.round(Number(rating)))) : void 0;
    const validStatus = ["published", "pending", "rejected", "draft"].includes(status) ? status : "published";
    const created = await foodDb.createTestimonial({
      userName: sanitizeInput(userName),
      merchantName: merchantName ? sanitizeInput(merchantName) : void 0,
      category: normalizedCategory,
      title: title ? sanitizeInput(title) : void 0,
      content: sanitizeInput(content),
      avatarUrl: avatarUrl?.trim() || void 0,
      roleDetail: roleDetail ? sanitizeInput(roleDetail) : void 0,
      rating: parsedRating,
      consentApproved: Boolean(consentApproved),
      status: validStatus,
      displayOrder: Number(displayOrder) || 1
    });
    foodDb.log(actorId, `Created review ${created.id} for ${created.userName} (${created.category})`, "ADMIN");
    res.status(201).json(created);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
adminRouter.post("/admin/testimonials", requireRole(["ADMIN", "MASTER_ADMIN"]), handleCreateAdminReview);
adminRouter.post("/admin/reviews", requireRole(["ADMIN", "MASTER_ADMIN"]), handleCreateAdminReview);
var handleUpdateAdminReview = async (req, res) => {
  try {
    const actorId = req.user?.userId || "admin";
    const payload = { ...req.body };
    if (payload.userName) payload.userName = sanitizeInput(payload.userName);
    if (payload.merchantName !== void 0) payload.merchantName = payload.merchantName ? sanitizeInput(payload.merchantName) : void 0;
    if (payload.title !== void 0) payload.title = payload.title ? sanitizeInput(payload.title) : void 0;
    if (payload.content) payload.content = sanitizeInput(payload.content);
    if (payload.roleDetail !== void 0) payload.roleDetail = payload.roleDetail ? sanitizeInput(payload.roleDetail) : void 0;
    const updated = await foodDb.updateTestimonial(req.params.id, payload);
    if (!updated) {
      return res.status(404).json({ error: "Review tidak ditemukan." });
    }
    foodDb.log(actorId, `Updated review ${req.params.id} (Status: ${updated.status})`, "ADMIN");
    res.json(updated);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
adminRouter.put("/admin/testimonials/:id", requireRole(["ADMIN", "MASTER_ADMIN"]), handleUpdateAdminReview);
adminRouter.put("/admin/reviews/:id", requireRole(["ADMIN", "MASTER_ADMIN"]), handleUpdateAdminReview);
var handleDeleteAdminReview = async (req, res) => {
  try {
    const actorId = req.user?.userId || "admin";
    const deleted = await foodDb.deleteTestimonial(req.params.id);
    if (!deleted) {
      return res.status(404).json({ error: "Review tidak ditemukan." });
    }
    foodDb.log(actorId, `Deleted review ${req.params.id}`, "ADMIN");
    res.json({ success: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
};
adminRouter.delete("/admin/testimonials/:id", requireRole(["ADMIN", "MASTER_ADMIN"]), handleDeleteAdminReview);
adminRouter.delete("/admin/reviews/:id", requireRole(["ADMIN", "MASTER_ADMIN"]), handleDeleteAdminReview);

// src/server/routes/artopayRoutes.ts
var import_express7 = require("express");
var artopayRouter = (0, import_express7.Router)();
var processedWebhookKeys = /* @__PURE__ */ new Set();
artopayRouter.get("/config-status", (_req, res) => {
  reloadEnv();
  const hasSecretKey = Boolean(artopayConfig.secretKey);
  const hasPublicKey = Boolean(artopayConfig.publicKey);
  const hasWebhookSecret = Boolean(artopayConfig.webhookSecret);
  const isProduction = artopayConfig.isProduction || artopayConfig.environment === "production";
  const missing = [];
  if (!hasSecretKey) missing.push("ARTOPAY_SECRET_KEY");
  if (!hasPublicKey) missing.push("ARTOPAY_PUBLIC_KEY");
  if (!hasWebhookSecret) missing.push("ARTOPAY_WEBHOOK_SECRET");
  const secretPrefix = artopayConfig.secretKey ? `${artopayConfig.secretKey.substring(0, 7)}...` : void 0;
  const publicPrefix = artopayConfig.publicKey ? `${artopayConfig.publicKey.substring(0, 7)}...` : void 0;
  let keyEnvironmentConsistency = "CONSISTENT";
  if (artopayConfig.environment === "sandbox") {
    if (artopayConfig.secretKey && artopayConfig.secretKey.startsWith("sk_live_") || artopayConfig.publicKey && artopayConfig.publicKey.startsWith("pk_live_")) {
      keyEnvironmentConsistency = "MISMATCH_PROD_IN_SANDBOX";
    }
  } else {
    if (artopayConfig.secretKey && artopayConfig.secretKey.startsWith("sk_test_") || artopayConfig.publicKey && artopayConfig.publicKey.startsWith("pk_test_")) {
      keyEnvironmentConsistency = "MISMATCH_TEST_IN_PROD";
    }
  }
  return res.json({
    gatewayConfigured: hasSecretKey && hasPublicKey,
    environment: artopayConfig.environment,
    isProduction,
    hasSecretKey,
    hasPublicKey,
    hasWebhookSecret,
    secretKeyPrefix: secretPrefix,
    publicKeyPrefix: publicPrefix,
    keyEnvironmentConsistency,
    missingCredentials: missing,
    status: hasSecretKey && hasPublicKey ? "READY" : "PREPARATION_PENDING_CREDENTIALS",
    message: hasSecretKey && hasPublicKey ? "Gateway ArtoPay telah terkonfigurasi dan siap memproses transaksi." : "Tahap persiapan: Kredensial ArtoPay belum diisi di Environment Variables. Alur aplikasi, validasi server, dan database telah siap.",
    oapiChecklist: {
      environmentMatchesMerchantAccount: keyEnvironmentConsistency === "CONSISTENT",
      merchantStatusMustBeActive: true,
      allowedOriginConfiguredInGateway: true
    }
  });
});
artopayRouter.get("/config", (_req, res) => {
  reloadEnv();
  return res.json({
    publicKey: artopayConfig.publicKey || "",
    environment: artopayConfig.environment,
    sandbox: artopayConfig.environment !== "production",
    gatewayConfigured: Boolean(artopayConfig.secretKey && artopayConfig.publicKey)
  });
});
artopayRouter.post("/payment-intent", async (req, res) => {
  try {
    reloadEnv();
    const { orderId, serviceType, customerPhone, amount: clientAmount } = req.body;
    const cleanOrderId = typeof orderId === "string" ? orderId.trim() : "";
    if (!cleanOrderId) {
      return res.status(400).json({ error: "orderId wajib diisi dan berupa string non-kosong." });
    }
    const type = (serviceType || "").toUpperCase();
    if (type !== "FOOD" && type !== "SHOP") {
      return res.status(400).json({ error: 'serviceType harus bernilai "FOOD" atau "SHOP".' });
    }
    if (type === "FOOD") {
      const order = await foodDb.findOrder(cleanOrderId);
      if (!order) {
        return res.status(404).json({ error: `Pesanan Tumpang Food dengan ID "${cleanOrderId}" tidak ditemukan.` });
      }
      const verifiedOrderId = String(order.id || "").trim();
      if (!verifiedOrderId) {
        return res.status(400).json({ error: "ID pesanan Tumpang Food tidak valid di database." });
      }
      if (order.status !== "WAITING_PAYMENT" /* WAITING_PAYMENT */) {
        if (order.status === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */ || order.status === "COOKING" /* COOKING */ || order.status === "READY_FOR_PICKUP" /* READY_FOR_PICKUP */ || order.status === "ORDER_PICKED_UP" /* ORDER_PICKED_UP */ || order.status === "DELIVERED" /* DELIVERED */ || order.status === "COMPLETED" /* COMPLETED */) {
          return res.status(400).json({ error: "Pesanan ini sudah terbayar / lunas." });
        }
        if (order.status === "CANCELLED" /* CANCELLED */ || order.status === "EXPIRED" /* EXPIRED */) {
          return res.status(400).json({ error: `Pesanan tidak dapat dibayar karena berstatus ${order.status}.` });
        }
      }
      if (order.paymentExpiresAt && new Date(order.paymentExpiresAt).getTime() < Date.now()) {
        return res.status(400).json({ error: "Batas waktu pembayaran pesanan telah habis (Expired)." });
      }
      const serverAmount = Math.round(Number(order.total));
      if (clientAmount !== void 0 && Number(clientAmount) !== serverAmount) {
        return res.status(400).json({
          error: `Manipulasi nominal terdeteksi: nominal client (${clientAmount}) berbeda dengan total server (${serverAmount}).`
        });
      }
      const proto = req.headers["x-forwarded-proto"] || req.protocol || "http";
      const host = req.get("host") || "localhost:3000";
      const origin = `${proto}://${host}`;
      const intent = await ArtoPayService.createPaymentIntent({
        orderId: verifiedOrderId,
        amount: serverAmount,
        currency: "IDR",
        customerName: order.customerName,
        customerPhone: order.customerPhone,
        customerEmail: order.customerEmail || void 0,
        serviceType: "FOOD",
        description: `Pembayaran Tumpang Food #${verifiedOrderId} (${order.merchantName})`,
        expiryMinutes: 15,
        callbackUrl: req.body.callbackUrl || `${origin}/api/artopay/webhook`,
        returnUrl: req.body.returnUrl || `${origin}/?tab=tracking&orderId=${verifiedOrderId}`,
        allowSdkModal: true
      });
      await foodDb.updateOrder("SYSTEM_ARTOPAY", order.id, {
        paymentMethod: "ARTOPAY_QRIS",
        artopayPaymentId: intent.paymentIntentId,
        artopayCheckoutUrl: intent.checkoutUrl,
        artopayStatus: "PENDING",
        artopayExpiredAt: intent.expiresAt,
        artopayClientSecret: intent.clientSecret,
        artopayCustomerToken: intent.customerToken,
        artopayPublicKey: intent.publicKey,
        artopayOrderId: intent.orderId,
        artopaySandbox: intent.sandbox
      }, "SYSTEM");
      return res.status(200).json(intent);
    } else {
      let order = await shopApiClient.findOrder(cleanOrderId, customerPhone ? String(customerPhone).trim() : void 0);
      if (!order) {
        return res.status(404).json({ error: `Pesanan Tumpang Shop dengan ID "${cleanOrderId}" tidak ditemukan.` });
      }
      const verifiedOrderId = String(order.id || order.orderNumber || "").trim();
      if (!verifiedOrderId) {
        return res.status(400).json({ error: "ID pesanan Tumpang Shop tidak valid di database." });
      }
      if (order.paymentStatus === "PAID" /* PAID */) {
        return res.status(400).json({ error: "Pesanan belanja ini sudah lunas." });
      }
      if (order.paymentStatus === "EXPIRED" /* EXPIRED */ || order.orderStatus === "CANCELLED" /* CANCELLED */) {
        return res.status(400).json({ error: "Pesanan belanja sudah kedaluwarsa atau dibatalkan." });
      }
      if (order.paymentExpiresAt && new Date(order.paymentExpiresAt).getTime() < Date.now()) {
        return res.status(400).json({ error: "Batas waktu pembayaran belanja telah habis (Expired)." });
      }
      const serverAmount = Math.round(Number(order.total));
      if (clientAmount !== void 0 && Number(clientAmount) !== serverAmount) {
        return res.status(400).json({
          error: `Manipulasi nominal terdeteksi: nominal client (${clientAmount}) berbeda dengan total server (${serverAmount}).`
        });
      }
      const proto = req.headers["x-forwarded-proto"] || req.protocol || "http";
      const host = req.get("host") || "localhost:3000";
      const origin = `${proto}://${host}`;
      const intent = await ArtoPayService.createPaymentIntent({
        orderId: verifiedOrderId,
        amount: serverAmount,
        currency: "IDR",
        customerName: order.customerName,
        customerPhone: order.customerPhone,
        customerEmail: order.customerEmail || void 0,
        serviceType: "SHOP",
        description: `Pembayaran Tumpang Shop #${order.orderNumber || verifiedOrderId}`,
        expiryMinutes: 20,
        callbackUrl: req.body.callbackUrl || `${origin}/api/artopay/webhook`,
        returnUrl: req.body.returnUrl || `${origin}/?page=shop&orderId=${order.orderNumber || verifiedOrderId}&tab=tracking`,
        allowSdkModal: true
      });
      await shopApiClient.attachPaymentDetails(order.id, {
        paymentMethod: "ARTOPAY_QRIS",
        artopayPaymentId: intent.paymentIntentId,
        artopayCheckoutUrl: intent.checkoutUrl,
        artopayStatus: "PENDING",
        artopayExpiredAt: intent.expiresAt,
        artopayClientSecret: intent.clientSecret,
        artopayCustomerToken: intent.customerToken,
        artopayPublicKey: intent.publicKey,
        artopayOrderId: intent.orderId,
        artopaySandbox: intent.sandbox
      });
      return res.status(200).json(intent);
    }
  } catch (err) {
    console.error("[ArtoPay Create Intent Error]", err);
    return res.status(500).json({ error: err.message || "Gagal membuat transaksi ArtoPay." });
  }
});
artopayRouter.post("/webhook", async (req, res) => {
  try {
    const rawBody = req.rawBody || (typeof req.body === "string" ? req.body : JSON.stringify(req.body));
    const signature = req.headers["x-artopay-signature"] || req.headers["x-signature"] || req.headers["artopay-signature"];
    const sigCheck = ArtoPayService.verifyWebhookSignature(rawBody, signature);
    if (!sigCheck.isValid) {
      console.warn(`[ArtoPay Webhook Unauthorized] Invalid signature: ${sigCheck.reason}`);
      return res.status(401).json({ error: "Tanda tangan webhook tidak sah (Unauthorized).", detail: sigCheck.reason });
    }
    const payload = req.body;
    const event = payload.event || "payment.update";
    const data = payload.data || payload;
    const paymentIntentId = String(data.paymentIntentId || data.id || "").trim();
    const orderId = String(data.orderId || data.referenceId || "").trim();
    const serviceType = (data.serviceType || "").toUpperCase();
    const amount = Number(data.amount);
    const currency = (data.currency || "IDR").toUpperCase();
    const rawStatus = (data.status || "").toUpperCase();
    if (!paymentIntentId || !orderId) {
      return res.status(400).json({ error: "Format payload webhook tidak lengkap: paymentIntentId atau orderId hilang." });
    }
    const idempotencyKey = `${paymentIntentId}_${rawStatus}`;
    if (processedWebhookKeys.has(idempotencyKey)) {
      return res.status(200).json({
        received: true,
        idempotent: true,
        message: "Notifikasi webhook untuk status ini sudah diproses sebelumnya."
      });
    }
    let foodOrder = await foodDb.findOrder(orderId);
    let shopOrder = void 0;
    if (!foodOrder) {
      shopOrder = await shopApiClient.findOrder(orderId);
    }
    if (!foodOrder && !shopOrder) {
      foodOrder = foodDb.getOrders().find((o) => o.artopayPaymentId === paymentIntentId);
      if (!foodOrder) {
        shopOrder = await shopApiClient.findOrder(paymentIntentId);
      }
    }
    if (!foodOrder && !shopOrder) {
      return res.status(404).json({
        error: `Pesanan dengan ID "${orderId}" atau paymentIntentId "${paymentIntentId}" tidak ditemukan.`
      });
    }
    const isFood = !!foodOrder;
    const targetOrder = isFood ? foodOrder : shopOrder;
    const serverTotal = Math.round(Number(targetOrder.total));
    if (targetOrder.artopayPaymentId && targetOrder.artopayPaymentId !== paymentIntentId) {
      console.warn(`[ArtoPay Security Alert] Mismatch between recorded transaction ID (${targetOrder.artopayPaymentId}) and webhook transaction ID (${paymentIntentId}) for order ${orderId}`);
      return res.status(400).json({
        error: "ID transaksi ArtoPay tidak cocok dengan identitas transaksi yang tersimpan pada pesanan ini."
      });
    }
    if (Number.isNaN(amount) || amount !== serverTotal) {
      console.error(`[ArtoPay Security Alert] Nominal mismatch on order ${orderId}! Expected Rp ${serverTotal}, received Rp ${amount}`);
      return res.status(400).json({
        error: `Nominal pembayaran (Rp ${amount}) tidak cocok dengan total tagihan pesanan (Rp ${serverTotal}).`
      });
    }
    if (currency !== "IDR") {
      return res.status(400).json({ error: `Mata uang tidak valid (${currency}). Harus IDR.` });
    }
    const isPaid = ["PAID", "SUCCESS", "SETTLED", "CAPTURE", "SETTLEMENT"].includes(rawStatus);
    const isFailedOrExpired = ["EXPIRED", "FAILED", "CANCELLED", "REJECTED", "DENY", "CANCEL"].includes(rawStatus);
    if (isFood) {
      const alreadyPaid = targetOrder.status === "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */ || targetOrder.status === "COOKING" /* COOKING */ || targetOrder.status === "READY_FOR_PICKUP" /* READY_FOR_PICKUP */ || targetOrder.status === "ORDER_PICKED_UP" /* ORDER_PICKED_UP */ || targetOrder.status === "DELIVERED" /* DELIVERED */ || targetOrder.status === "COMPLETED" /* COMPLETED */;
      if (isPaid && alreadyPaid) {
        processedWebhookKeys.add(idempotencyKey);
        return res.status(200).json({
          received: true,
          idempotent: true,
          message: "Pesanan makanan ini sudah berstatus lunas / terverifikasi sebelumnya."
        });
      }
      if (isPaid) {
        if (targetOrder.status === "WAITING_PAYMENT" /* WAITING_PAYMENT */ || targetOrder.status === "WAITING_PAYMENT_VERIFICATION" /* WAITING_PAYMENT_VERIFICATION */) {
          await foodDb.updateOrder("SYSTEM_ARTOPAY_WEBHOOK", targetOrder.id, {
            status: "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */,
            paymentMethod: "ARTOPAY_QRIS",
            artopayPaymentId: paymentIntentId,
            artopayStatus: "SUCCESS",
            paymentVerifiedAt: data.paidAt || (/* @__PURE__ */ new Date()).toISOString()
          }, "SYSTEM");
          foodDb.log(
            "SYSTEM_ARTOPAY_WEBHOOK",
            `Pembayaran ArtoPay terverifikasi via webhook (ID: ${paymentIntentId}, Rp ${amount}) - Order ${targetOrder.id}`,
            "SYSTEM"
          );
          console.log(`[ArtoPay Webhook] Food Order ${targetOrder.id} successfully marked as PAID.`);
        }
      } else if (isFailedOrExpired) {
        if (targetOrder.status === "WAITING_PAYMENT" /* WAITING_PAYMENT */) {
          await foodDb.updateOrder("SYSTEM_ARTOPAY_WEBHOOK", targetOrder.id, {
            artopayStatus: rawStatus === "EXPIRED" ? "EXPIRED" : "FAILED"
          }, "SYSTEM");
        }
      }
    } else {
      if (isPaid && targetOrder.paymentStatus === "PAID" /* PAID */) {
        processedWebhookKeys.add(idempotencyKey);
        return res.status(200).json({
          received: true,
          idempotent: true,
          message: "Pesanan belanja ini sudah berstatus lunas sebelumnya."
        });
      }
      if (isPaid) {
        if (targetOrder.paymentStatus !== "PAID" /* PAID */) {
          await shopApiClient.syncPaymentStatus({
            orderId: targetOrder.id,
            paymentIntentId,
            amountPaid: Number(amount)
          });
          console.log(`[ArtoPay Webhook] Shop Order ${targetOrder.orderNumber} successfully marked as PAID.`);
        }
      } else if (isFailedOrExpired) {
        if (targetOrder.paymentStatus === "UNPAID" /* UNPAID */) {
          await shopApiClient.attachPaymentDetails(targetOrder.id, {
            paymentMethod: "ARTOPAY_QRIS",
            artopayPaymentId: paymentIntentId,
            artopayCheckoutUrl: targetOrder.artopayCheckoutUrl || "",
            artopayStatus: rawStatus === "EXPIRED" ? "EXPIRED" : "FAILED",
            artopayExpiredAt: targetOrder.artopayExpiredAt
          });
        }
      }
    }
    processedWebhookKeys.add(idempotencyKey);
    return res.status(200).json({
      received: true,
      success: true,
      orderId: targetOrder.id,
      paymentIntentId,
      status: isPaid ? "PAID" : rawStatus
    });
  } catch (err) {
    console.error("[ArtoPay Webhook Exception]", err);
    return res.status(500).json({ error: err.message || "Gagal memproses webhook ArtoPay." });
  }
});
artopayRouter.get("/status/:orderId", async (req, res) => {
  try {
    const orderId = req.params.orderId.trim();
    const serviceType = (req.query.serviceType || "").toUpperCase();
    let foodOrder = void 0;
    let shopOrder = void 0;
    if (serviceType === "SHOP") {
      shopOrder = await shopApiClient.findOrder(orderId);
    } else if (serviceType === "FOOD") {
      foodOrder = await foodDb.findOrder(orderId);
    } else {
      foodOrder = await foodDb.findOrder(orderId);
      if (!foodOrder) {
        shopOrder = await shopApiClient.findOrder(orderId);
      }
    }
    if (!foodOrder && !shopOrder) {
      return res.status(404).json({ error: "Pesanan tidak ditemukan." });
    }
    const isFood = !!foodOrder;
    const targetOrder = isFood ? foodOrder : shopOrder;
    const isCurrentlyPaid = isFood ? targetOrder.status !== "WAITING_PAYMENT" /* WAITING_PAYMENT */ && targetOrder.status !== "WAITING_PAYMENT_VERIFICATION" /* WAITING_PAYMENT_VERIFICATION */ && targetOrder.status !== "CANCELLED" /* CANCELLED */ && targetOrder.status !== "EXPIRED" /* EXPIRED */ : targetOrder.paymentStatus === "PAID" /* PAID */;
    if (!isCurrentlyPaid && targetOrder.artopayPaymentId) {
      const liveCheck = await ArtoPayService.checkPaymentStatus(targetOrder.artopayPaymentId);
      if (liveCheck.status === "SUCCESS") {
        if (isFood) {
          await foodDb.updateOrder("SYSTEM_ARTOPAY_POLL", targetOrder.id, {
            status: "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */,
            paymentMethod: "ARTOPAY_QRIS",
            artopayStatus: "SUCCESS",
            paymentVerifiedAt: liveCheck.paidAt || (/* @__PURE__ */ new Date()).toISOString()
          }, "SYSTEM");
        } else {
          await shopApiClient.syncPaymentStatus({
            orderId: targetOrder.id,
            paymentIntentId: targetOrder.artopayPaymentId,
            amountPaid: Number(targetOrder.total)
          });
        }
        return res.json({
          orderId: targetOrder.id,
          serviceType: isFood ? "FOOD" : "SHOP",
          isPaid: true,
          status: isFood ? "PAYMENT_VERIFIED" /* PAYMENT_VERIFIED */ : "PAID" /* PAID */,
          artopayStatus: "SUCCESS"
        });
      }
    }
    return res.json({
      orderId: targetOrder.id,
      serviceType: isFood ? "FOOD" : "SHOP",
      isPaid: isCurrentlyPaid,
      status: isFood ? targetOrder.status : targetOrder.paymentStatus,
      artopayStatus: targetOrder.artopayStatus || (isCurrentlyPaid ? "SUCCESS" : "PENDING"),
      checkoutUrl: targetOrder.artopayCheckoutUrl,
      paymentIntentId: targetOrder.artopayPaymentId,
      amount: targetOrder.total
    });
  } catch (err) {
    return res.status(500).json({ error: err.message || "Gagal memeriksa status pembayaran ArtoPay." });
  }
});

// src/server/app.ts
var app = (0, import_express8.default)();
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin) {
    res.setHeader("Access-Control-Allow-Origin", origin);
  } else {
    res.setHeader("Access-Control-Allow-Origin", "*");
  }
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, x-auth-token, x-auth-email, x-request-id, x-requested-with, accept, origin");
  res.setHeader("Access-Control-Allow-Credentials", "true");
  res.setHeader("Access-Control-Max-Age", "86400");
  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }
  next();
});
app.use((req, res, next) => {
  const matchedPath = req.headers["x-matched-path"] || req.headers["x-original-url"] || req.headers["x-forwarded-uri"];
  if (matchedPath && matchedPath.startsWith("/api") && req.url.startsWith("/api/index")) {
    req.url = matchedPath;
  }
  if (req.url.startsWith("/api/index?") || req.url === "/api/index") {
    try {
      const urlObj = new URL(req.url, "http://localhost");
      const customPath = urlObj.searchParams.get("__path") || urlObj.searchParams.get("path");
      if (customPath) {
        urlObj.searchParams.delete("__path");
        urlObj.searchParams.delete("path");
        const remainingQuery = urlObj.searchParams.toString();
        const basePath = customPath.startsWith("/") ? customPath : `/api/${customPath}`;
        req.url = basePath + (remainingQuery ? `?${remainingQuery}` : "");
      }
    } catch {
    }
  }
  next();
});
app.use((req, res, next) => {
  const reqId = req.headers["x-request-id"] || "req_" + Math.random().toString(36).substring(2, 9) + Date.now().toString(36);
  req.id = String(reqId);
  res.setHeader("X-Request-Id", req.id);
  if (req.path.startsWith("/api")) {
    const start = Date.now();
    res.on("finish", () => {
      const duration = Date.now() - start;
      const status = res.statusCode;
      const logFn = status >= 500 ? console.error : status >= 400 ? console.warn : console.log;
      logFn(`[API] [${req.id}] ${req.method} ${req.path} -> ${status} (${duration}ms)`);
    });
  }
  next();
});
app.use((req, _res, next) => {
  if (req.body !== void 0 && req.body !== null) {
    if (typeof req.body === "string") {
      try {
        req.body = JSON.parse(req.body);
      } catch {
      }
    }
    req._body = true;
  }
  next();
});
app.use(import_express8.default.json({
  limit: "15mb",
  verify: (req, _res, buf) => {
    try {
      req.rawBody = buf.toString("utf-8");
    } catch {
    }
  }
}));
app.use(import_express8.default.urlencoded({ extended: true, limit: "15mb" }));
app.use((err, req, _res, next) => {
  if (err?.message?.includes("stream is not readable") || err?.type === "stream.not.readable") {
    return next();
  }
  next(err);
});
app.use(async (req, res, next) => {
  try {
    await foodDb.ensureInitialized();
  } catch (err) {
    console.warn("[TumpangFood Database Sync Warning]", err?.message || err);
  }
  next();
});
app.use(authenticateToken);
app.get("/api/health", async (req, res) => {
  try {
    const [foodStorageStatus, shopStorageStatus] = await Promise.all([
      foodDb.getStorageStatus(),
      shopApiClient.getHealth()
    ]);
    const isHealthy = foodStorageStatus.liveCloudConnected;
    const isProd = foodConfig.isProduction;
    res.status(isProd && !isHealthy ? 503 : 200).json({
      status: isHealthy ? "healthy" : isProd ? "database_disconnected" : "ok_development_resilient_mode",
      server: "online",
      database: isHealthy ? "connected" : "disconnected",
      system: "tumpang-go-ecosystem",
      environment: process.env.NODE_ENV || "development",
      diagnosticReason: foodStorageStatus.diagnosticReason,
      diagnosticDetail: foodStorageStatus.diagnosticDetail,
      remediationStep: foodStorageStatus.remediationStep,
      foodDatabase: foodStorageStatus,
      shopDatabase: shopStorageStatus,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  } catch (err) {
    console.error("[TumpangFood Health Check Error]", err);
    res.status(500).json({
      status: "error",
      server: "online",
      database: "error",
      system: "tumpang-food",
      error: "Health check diagnostic encountered an internal error.",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
});
app.get("/api/health/firestore-probe", async (req, res) => {
  try {
    const probe = await testFirestoreConnection();
    res.status(probe.connected ? 200 : 503).json({
      system: "tumpang-food",
      probeOrigin: "Dedicated Admin SDK Diagnostic Probe",
      result: probe,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  } catch (err) {
    console.error("[TumpangFood Probe Error]", err);
    res.status(500).json({
      system: "tumpang-food",
      error: err.message || "Diagnostic probe error",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
});
app.use("/api", authRouter);
app.use("/api/merchants", merchantRouter);
app.use("/api/drivers", driverRouter);
app.use("/api/orders", orderRouter);
app.use("/api", adminRouter);
app.use("/api/shop", shopApp);
app.use("/api/artopay", artopayRouter);
app.all(["/api", "/api/*"], (req, res) => {
  res.status(404).json({ error: `API endpoint ${req.method} ${req.path} tidak ditemukan.` });
});
app.use((err, req, res, _next) => {
  const reqId = req.id || "req_unknown";
  const status = typeof err.status === "number" && err.status >= 400 && err.status < 600 ? err.status : 500;
  console.error(`[TumpangFood Server Error] [ReqID: ${reqId}] ${req.method} ${req.originalUrl} -> HTTP ${status}`);
  if (err.stack) {
    console.error(`[TumpangFood StackTrace] [ReqID: ${reqId}]:
${err.stack}`);
  } else {
    console.error(`[TumpangFood ErrorDetails] [ReqID: ${reqId}]:`, err);
  }
  let safeMessage = "Terjadi kesalahan internal pada server Tumpang Food.";
  if (status === 404) {
    safeMessage = err.message || "Data atau endpoint tidak ditemukan.";
  } else if (status === 400 || status === 422) {
    safeMessage = err.message || "Permintaan tidak valid.";
  } else if (status === 401 || status === 403) {
    safeMessage = err.message || "Akses tidak diizinkan.";
  } else if (req.path === "/api/merchants" || req.path.startsWith("/api/merchants")) {
    safeMessage = "Gagal memuat daftar toko kuliner dari database server.";
  }
  res.status(status).json({
    error: safeMessage,
    code: err.code || (status === 500 ? "INTERNAL_SERVER_ERROR" : "REQUEST_ERROR"),
    requestId: reqId
  });
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  app
});
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Shop Types and Interfaces
 * Dedicated models for Marketplace: Products, Categories, Orders, and Config.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Shop - Independent Environment & Connection Configuration
 * Dedicated exclusively to Tumpang Shop microservice.
 * Completely decoupled from Tumpang Food and any other future services.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Configuration Module
 * Isolates runtime environment variables, database identifiers, and system defaults.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Authentication & RBAC Authorization Module
 * Provides password hashing, token creation/verification, and strict security middleware.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * TumpangGo Single Source of Truth for Delivery Fee & Geographic Boundaries
 * Mandatory Business Rule:
 * All delivery destinations within Kecamatan Tumpang are strictly charged a flat fee of Rp 5.000 per order,
 * regardless of distance, village/kelurahan, merchant location, map calculations, or internal zones.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Order Validation & Transaction Service
 * Enforces price recalculations, menu availability checks, and order state machine rules.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Firebase Admin SDK Module
 * Server-side trusted administrative database client.
 * Implements IAM credential loading, custom database targeting, and atomic transactions.
 * Strict zero-ADC enforcement on serverless environments to prevent "Could not load the default credentials".
 * Granular diagnostics for missing keys, JSON parse errors, project mismatches, IAM denials, and timeouts.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Isolated Database Module
 * Manages persistent storage, data integrity, and Firestore synchronization.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Shop Modular Courier Adapter Architecture
 * Dedicated shipping adapter layer for Shop service.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Shop - Database Schema & Validation Rules
 * Explicit schema definitions and data validation for Shop business entities.
 * Strictly decoupled from Food entities.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Shop - Independent Database Migration Engine
 * Handles automated schema migrations, audit of legacy database files,
 * data integrity verification, and non-destructive data seeding.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Shop Standalone Database Engine
 * Completely decoupled from Tumpang Food and other services.
 * Manages all Shop marketplace state, products, categories, orders, shipments, and migrations.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Shop - Independent Authentication & Authorization Module
 * Handles token issuance, verification, and role-based access control (RBAC)
 * strictly for Tumpang Shop administrative and customer operations.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * ArtoPay Payment Gateway Service Module
 * Handles Payment Intent creation, dynamic QRIS generation,
 * webhook HMAC signature validation, idempotency guards, and payment verification.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Shop - Standalone Backend Application
 * Isolated Express microservice application for Tumpang Shop marketplace.
 * Operates with its own routing, authentication, business logic, and database.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Shop - Explicit Inter-Service Client
 * Enables other services (e.g., Tumpang Food, Main Gateway, Payment Webhooks)
 * to communicate with Tumpang Shop via explicit API calls, without direct database access.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Authentication Routes
 * Handles secure user login, token issuance, and partner onboarding.
 * Strictly enforces valid credentials with PBKDF2 hashing and no fallback bypasses.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Merchant Routes
 * Manages merchant profiles, menu catalogs, orders, and license redemptions.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Driver Routes
 * Handles courier profile operations, status toggles, and delivery assignments.
 * Protected with RBAC so drivers can only view and manage their own profile and tasks.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Order Routes
 * Handles order placements, recalculations, driver assignments, and payment proofs.
 * Enforces payment expiration rules, terminal state guards, and RBAC order visibility.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Administrative Routes
 * Manages system parameters, partner onboarding, payouts, and licenses.
 * Strictly protected with Admin-only RBAC middleware.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * ArtoPay Payment Gateway API Routes
 * Endpoints for Payment Intent creation, Webhook handling, and on-demand status verification.
 */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Tumpang Food Express Application
 * Decoupled and modular backend application assembly.
 */
//# sourceMappingURL=_app.cjs.map
