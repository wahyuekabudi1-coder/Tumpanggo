const CACHE_NAME = 'tumpang-food-v8';
const ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/apple-touch-icon.png'
];

// Install Event
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS).catch((err) => {
        console.warn('[SW] Cache addAll skipped:', err);
      });
    })
  );
  self.skipWaiting();
});

// Activate Event
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Fetch Event (Network First, with strict bypass for dev modules and APIs)
self.addEventListener('fetch', (event) => {
  const url = event.request.url;

  // Immediately bypass non-GET requests
  if (event.request.method !== 'GET') {
    return;
  }

  // Bypass any cross-origin requests
  if (!url.startsWith(self.location.origin)) {
    return;
  }

  // Bypass QRIS assets, QRIS streaming endpoints, API endpoints, WebSocket, and dev server internals
  if (
    url.includes('qris-merchant') ||
    url.includes('qris-image') ||
    url.includes('/qris') ||
    url.includes('/api/') ||
    url.includes('/@vite') ||
    url.includes('/@fs') ||
    url.includes('/__vite') ||
    url.includes('/src/') ||
    url.includes('.tsx') ||
    url.includes('.ts') ||
    url.includes('node_modules') ||
    self.location.hostname.includes('run.app') ||
    self.location.hostname === 'localhost' ||
    self.location.hostname === '127.0.0.1'
  ) {
    return;
  }

  event.respondWith(
    fetch(event.request)
      .then((networkResponse) => {
        if (networkResponse.status === 200 && networkResponse.type === 'basic') {
          const responseClone = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseClone);
          });
        }
        return networkResponse;
      })
      .catch(() => {
        return caches.match(event.request).then((cachedResponse) => {
          if (cachedResponse) {
            return cachedResponse;
          }
          if (event.request.headers.get('accept')?.includes('text/html')) {
            return caches.match('/');
          }
        });
      })
  );
});
