import React, { useState, useEffect, useRef } from 'react';
import { 
  Merchant, MenuItem, Category, Order, OrderItem, OrderStatus, PaymentStatus, SystemConfig, calculateTieredServiceFee
} from '../types.ts';
import MapPicker from './MapPicker.tsx';
import Logo from './Logo.tsx';
import BannerCarousel from './BannerCarousel.tsx';
import TumpangNiagaComingSoon from './TumpangNiagaComingSoon.tsx';
import HiddenPortalBar from './HiddenPortalBar.tsx';
import ErrorBoundary from './ErrorBoundary.tsx';
import { useHiddenTrigger } from '../hooks/useHiddenTrigger.ts';
import { compressImage, compressBase64 } from '../utils/imageCompressor.ts';
import { safeStorage } from '../utils/safeStorage.ts';
import { apiFetch as fetch, extractArrayResponse, getApiBaseUrl } from '../utils/apiClient.ts';
import { calculateDeliveryFee, FLAT_TUMPANG_DELIVERY_FEE, isDestinationInKecamatanTumpang, normalizeOrderDeliveryFee } from '../utils/deliveryFee.ts';
import { useSEO } from '../hooks/useSEO.ts';
import UmkmEducationModule, { UMKM_ARTICLES } from './UmkmEducationModule.tsx';
import UserTestimonialsSection from './UserTestimonialsSection.tsx';
import { HelpCenterView } from './HelpCenterView.tsx';
import { SocialMediaButtons } from './SocialMediaButtons.tsx';
import PartnerPortalHub from './PartnerPortalHub.tsx';
import { 
  Search, ShoppingBag, Store, MapPin, Clock, Star, ArrowLeft, Plus, Minus, Trash2, Check, 
  CheckCircle2, ArrowRight, Share2, Phone, Calendar, ClipboardList, RefreshCw, X,
  Download, Smartphone, Info, Home, UserPlus, Bike, Users, XCircle, Key, ShieldCheck,
  Wifi, Utensils, Car, Wallet, QrCode, Send, CreditCard, ArrowUpRight, ArrowDownLeft,
  ExternalLink, Globe, Lock, Crown, Sparkles, Building2, BadgeCheck, Award, TrendingUp, ChevronLeft, ChevronRight, Heart, AlertCircle, ZoomIn, Upload,
  BookOpen, HelpCircle, ChevronDown, ChevronUp, Receipt, Copy
} from 'lucide-react';
import EReceiptModal from './EReceiptModal.tsx';
import FloatingCart from './FloatingCart.tsx';
import { calculateRemainingCooking, formatWibTime } from '../utils/cookingTimer.ts';
import { useCookingTicker } from '../hooks/useCookingCountdown.ts';

interface CustomerViewProps {
  onSwitchView?: (view: string) => void;
  systemConfig: SystemConfig;
  onOpenAuthModal?: () => void;
  onSelectRole?: (role: 'CUSTOMER' | 'MERCHANT' | 'DRIVER' | 'ADMIN', id?: string, initialTab?: 'login' | 'register', email?: string) => void;
  onInstantDashboard?: (role: 'ADMIN' | 'MERCHANT' | 'DRIVER') => void;
  initialTab?: string;
}

export const CULINARY_CATEGORIES = [
  { id: 'all', name: 'Semua', emoji: '🍔' },
  { id: 'bakso_mie', name: 'Bakso & Mie', emoji: '🍜' },
  { id: 'nasi_lauk', name: 'Nasi & Lauk', emoji: '🍛' },
  { id: 'sate_bakaran', name: 'Sate & Bakaran', emoji: '🍢' },
  { id: 'cemilan', name: 'Cemilan & Jajanan', emoji: '🍘' },
  { id: 'minuman', name: 'Minuman Segar', emoji: '🥤' }
];

export default function CustomerView({ onSwitchView, systemConfig, onOpenAuthModal, onSelectRole, onInstantDashboard, initialTab }: CustomerViewProps) {
  // Navigation / Tab state: 'home' | 'merchant-detail' | 'cart' | 'checkout' | 'payment' | 'tracking' | 'history' | 'partner-register' | 'edukasi' | 'help'
  const [activeTab, setActiveTab] = useState<string>(() => {
    if (initialTab) return initialTab;
    if (typeof window !== 'undefined') {
      const p = new URLSearchParams(window.location.search).get('page');
      if (p === 'bantuan' || p === 'help' || p === 'pusat-bantuan') return 'help';
      if (p === 'edukasi') return 'edukasi';
      if (p === 'merchant-register' || p === 'partner-register') return 'partner-register';
    }
    return 'home';
  });
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);
  const cookingTickerNow = useCookingTicker();

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab]);
  
  // Home layout sub-view: 'main' (GoFood/ShopeeFood style landing) | 'food' (existing food view) | 'taxi' (Taksi Lokal view) | 'niaga' (Tumpang Niaga Coming Soon) | 'pay' (Tumpang Pay view) | 'bike' (Tumpang Bike coming soon)
  const [homeSubView, setHomeSubView] = useState<'main' | 'food' | 'taxi' | 'niaga' | 'pay' | 'bike'>('main');

  // Menentukan apakah pengguna sedang berada di dalam alur / layout layanan Tumpang Food
  const isTumpangFoodFlow = 
    homeSubView === 'food' || 
    activeTab === 'merchant-detail' || 
    activeTab === 'cart' || 
    activeTab === 'checkout' || 
    activeTab === 'payment';

  // Waitlist / Coming Soon Notifications states
  const [notifyBikePhone, setNotifyBikePhone] = useState<string>('');
  const [notifyBikeSubmitted, setNotifyBikeSubmitted] = useState<boolean>(false);
  const [notifyTaxiPhone, setNotifyTaxiPhone] = useState<string>('');
  const [notifyTaxiSubmitted, setNotifyTaxiSubmitted] = useState<boolean>(false);

  // Tumpang Pay States
  const [payBalance, setPayBalance] = useState<number>(() => {
    try {
      const saved = safeStorage.getItem('tumpang_pay_balance');
      return saved ? Number(saved) : 0;
    } catch {
      return 0;
    }
  });

  const [payTransactions, setPayTransactions] = useState<any[]>(() => {
    try {
      const saved = safeStorage.getItem('tumpang_pay_transactions');
      const parsed = saved ? JSON.parse(saved) : null;
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });

  const [payActiveScreen, setPayActiveScreen] = useState<'main' | 'topup' | 'transfer' | 'qris' | 'success_slip' | 'buylink_invoice'>('main');
  const [payTopUpAmount, setPayTopUpAmount] = useState<string>('');
  const [payTopUpMethod, setPayTopUpMethod] = useState<string>('qris');
  const [payTransferTargetPhone, setPayTransferTargetPhone] = useState<string>('');
  const [payTransferTargetName, setPayTransferTargetName] = useState<string>('');
  const [payTransferAmount, setPayTransferAmount] = useState<string>('');
  const [payTransferNote, setPayTransferNote] = useState<string>('');
  const [payQrisMerchantName, setPayQrisMerchantName] = useState<string>('');
  const [payQrisAmount, setPayQrisAmount] = useState<string>('');
  const [payLastTransaction, setPayLastTransaction] = useState<any | null>(null);

  // buylink.id/tumpangGo store states
  const [buylinkPhone, setBuylinkPhone] = useState<string>('');

  // Secret Portal Access State (Managed cleanly via useHiddenTrigger: 10-13 clicks active, 14 reset, resets on reload)
  const { isUnlocked: portalAccessUnlocked, handleCopyrightClick } = useHiddenTrigger();
  const [buylinkCategory, setBuylinkCategory] = useState<'saldo' | 'pulsa' | 'data' | 'pln'>('saldo');
  const [buylinkSelectedProduct, setBuylinkSelectedProduct] = useState<any | null>(null);
  const [buylinkPaymentMethod, setBuylinkPaymentMethod] = useState<string>('qris');
  const [buylinkInvoice, setBuylinkInvoice] = useState<any | null>(null);
  const [buylinkCountdown, setBuylinkCountdown] = useState<number>(900); // 15 mins (in seconds)

  useEffect(() => {
    let interval: any = null;
    if (payActiveScreen === 'buylink_invoice' && buylinkCountdown > 0) {
      interval = setInterval(() => {
        setBuylinkCountdown(prev => {
          if (prev <= 1) {
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [payActiveScreen, buylinkCountdown]);

  const [isDriverModalOpen, setIsDriverModalOpen] = useState<boolean>(false);
  const [driverName, setDriverName] = useState<string>('');
  const [driverPhone, setDriverPhone] = useState<string>('');
  const [driverVehicle, setDriverVehicle] = useState<'motorcycle' | 'car'>('motorcycle');
  const [driverPlate, setDriverPlate] = useState<string>('');
  const [driverRegSubmitted, setDriverRegSubmitted] = useState<boolean>(false);
  const [isDriverLicUploaded, setIsDriverLicUploaded] = useState<boolean>(false);

  const [isApkModalOpen, setIsApkModalOpen] = useState<boolean>(false);
  const [apkDownloadProgress, setApkDownloadProgress] = useState<number>(0);
  const [isApkDownloaded, setIsApkDownloaded] = useState<boolean>(false);
  const [isMapModalOpen, setIsMapModalOpen] = useState<boolean>(false);

  // Taksi Lokal States
  const [taxiPickUp, setTaxiPickUp] = useState<string>('terminal');
  const [taxiDropOff, setTaxiDropOff] = useState<string>('pasar');
  const [taxiRideType, setTaxiRideType] = useState<'motorcycle' | 'car'>('motorcycle');
  const [taxiCustomerName, setTaxiCustomerName] = useState<string>('');
  const [taxiCustomerPhone, setTaxiCustomerPhone] = useState<string>('');
  const [taxiBookingStatus, setTaxiBookingStatus] = useState<'idle' | 'searching' | 'active' | 'completed'>('idle');
  const [assignedTaxiDriver, setAssignedTaxiDriver] = useState<any>(null);
  const [taxiTripProgress, setTaxiTripProgress] = useState<string>('');
  const [taxiProgressStep, setTaxiProgressStep] = useState<number>(0);
  const [taxiRating, setTaxiRating] = useState<number>(5);
  const [taxiRatingSubmitted, setTaxiRatingSubmitted] = useState<boolean>(false);
  const [taxiTripsHistory, setTaxiTripsHistory] = useState<any[]>(() => {
    try {
      const saved = safeStorage.getItem('tumpang_taxi_trips');
      const parsed = saved ? JSON.parse(saved) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });


  // Pusat Bantuan Direct Action
  const handleOpenHelpCenter = () => {
    setActiveTab('help');
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const TUMPANG_LOCATIONS = [
    { id: 'terminal', name: 'Terminal Tumpang', address: 'Jl. Raya Tumpang No.1, Tumpang', lat: -7.9463, lng: 112.7602 },
    { id: 'pasar', name: 'Pasar Tumpang', address: 'Jl. Raya Tumpang, Area Pasar, Tumpang', lat: -7.9472, lng: 112.7610 },
    { id: 'candi_kidal', name: 'Candi Kidal', address: 'Kidal, Kecamatan Tumpang', lat: -7.9615, lng: 112.7121 },
    { id: 'candi_jago', name: 'Candi Jago', address: 'Dusun Jago, Tumpang', lat: -7.9498, lng: 112.7628 },
    { id: 'alun_alun', name: 'Alun-Alun / Taman Tumpang', address: 'Kecamatan Tumpang', lat: -7.9455, lng: 112.7595 },
    { id: 'coban_pelangi', name: 'Coban Pelangi', address: 'Gubugklakah, Tumpang', lat: -7.9712, lng: 112.8250 },
    { id: 'desela', name: 'DeSela (Destinasi Selandor)', address: 'Slamet, Kecamatan Tumpang', lat: -7.9250, lng: 112.7480 },
    { id: 'kantor_kec', name: 'Kantor Kecamatan Tumpang', address: 'Jl. Raya Tumpang, Tumpang', lat: -7.9442, lng: 112.7588 },
    { id: 'jeru', name: 'Desa Wisata Jeru', address: 'Jeru, Kecamatan Tumpang', lat: -7.9550, lng: 112.7410 }
  ];

  const LOCAL_TAXI_DRIVERS: { id: string; name: string; phone: string; vehicle: string; rating: number; avatar: string }[] = [];

  const calculateDistance = (loc1Id: string, loc2Id: string) => {
    const l1 = TUMPANG_LOCATIONS.find(l => l.id === loc1Id);
    const l2 = TUMPANG_LOCATIONS.find(l => l.id === loc2Id);
    if (!l1 || !l2) return 0;
    if (l1.id === l2.id) return 0.5; // same spot distance
    
    const deg2rad = (deg: number) => deg * (Math.PI / 180);
    const R = 6371; // Radius of the earth in km
    const dLat = deg2rad(l2.lat - l1.lat);
    const dLon = deg2rad(l2.lng - l1.lng);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(deg2rad(l1.lat)) * Math.cos(deg2rad(l2.lat)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const d = R * c; // Distance in km
    return parseFloat(d.toFixed(1));
  };

  const getTaxiPrice = (dist: number, type: 'motorcycle' | 'car') => {
    if (type === 'motorcycle') {
      const price = 6000 + (dist * 2000);
      return Math.max(8000, Math.round(price / 1000) * 1000);
    } else {
      const price = 12000 + (dist * 4500);
      return Math.max(15000, Math.round(price / 1000) * 1000);
    }
  };

  // Taxi booking simulation timer
  const searchTimeoutRef = useRef<any>(null);
  const tripIntervalRef = useRef<any>(null);

  const handleStartTaxiBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!taxiCustomerName || !taxiCustomerPhone) {
      alert('Nama dan No. WhatsApp wajib diisi untuk memesan Tumpang Taksi!');
      return;
    }
    
    setTaxiBookingStatus('searching');
    setTaxiProgressStep(0);
    setTaxiTripProgress('Mencari driver terdekat di wilayah Tumpang...');
    
    // Simulate search
    if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
    searchTimeoutRef.current = setTimeout(() => {
      // Pick a driver matching the ride type
      const suitableDrivers = LOCAL_TAXI_DRIVERS.filter(d => 
        taxiRideType === 'car' ? (d.vehicle.includes('Avanza') || d.vehicle.includes('Xenia')) : !d.vehicle.includes('Avanza') && !d.vehicle.includes('Xenia')
      );
      if (suitableDrivers.length === 0) {
        setTaxiBookingStatus('idle');
        alert('Mohon maaf, saat ini armada driver untuk rute ini belum tersedia di wilayah Tumpang. Silakan coba kembali beberapa saat lagi.');
        return;
      }
      const randomDriver = suitableDrivers[Math.floor(Math.random() * suitableDrivers.length)];
      
      setAssignedTaxiDriver(randomDriver);
      setTaxiBookingStatus('active');
      setTaxiProgressStep(1);
      setTaxiTripProgress('Driver ditemukan! Sedang menuju lokasi penjemputan Anda.');
      
      // Start journey updates
      let step = 1;
      if (tripIntervalRef.current) clearInterval(tripIntervalRef.current);
      tripIntervalRef.current = setInterval(() => {
        step += 1;
        setTaxiProgressStep(step);
        if (step === 2) {
          setTaxiTripProgress('Driver telah sampai di lokasi jemput. Harap menemui driver.');
        } else if (step === 3) {
          setTaxiTripProgress('Perjalanan sedang berlangsung. Nikmati rute Anda aman bersama taksi lokal.');
        } else if (step === 4) {
          // Completed!
          clearInterval(tripIntervalRef.current);
          setTaxiBookingStatus('completed');
          setTaxiTripProgress('Perjalanan selesai! Terima kasih telah menggunakan layanan Tumpang Taksi.');
          setTaxiRatingSubmitted(false);
          setTaxiRating(5);
          
          // Save to history
          const dist = calculateDistance(taxiPickUp, taxiDropOff);
          const price = getTaxiPrice(dist, taxiRideType);
          const pLoc = TUMPANG_LOCATIONS.find(l => l.id === taxiPickUp)?.name || taxiPickUp;
          const dLoc = TUMPANG_LOCATIONS.find(l => l.id === taxiDropOff)?.name || taxiDropOff;
          
          const newTrip = {
            id: 'TX-' + Math.floor(1000 + Math.random() * 9000),
            customerName: taxiCustomerName,
            customerPhone: taxiCustomerPhone,
            pickUp: pLoc,
            dropOff: dLoc,
            rideType: taxiRideType === 'motorcycle' ? 'Ojek Motor 🏍️' : 'Taksi Mobil 🚗',
            driverName: randomDriver.name,
            driverVehicle: randomDriver.vehicle,
            distance: dist,
            price: price,
            date: new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })
          };
          
          setTaxiTripsHistory(prev => {
            const updated = [newTrip, ...prev];
            safeStorage.setItem('tumpang_taxi_trips', JSON.stringify(updated));
            return updated;
          });
        }
      }, 4000); // changes step every 4 seconds
      
    }, 3000); // searches for 3 seconds
  };

  const handleCancelTaxiBooking = () => {
    if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
    if (tripIntervalRef.current) clearInterval(tripIntervalRef.current);
    setTaxiBookingStatus('idle');
    setAssignedTaxiDriver(null);
    setTaxiProgressStep(0);
    setTaxiTripProgress('');
  };

  useEffect(() => {
    return () => {
      if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
      if (tripIntervalRef.current) clearInterval(tripIntervalRef.current);
    };
  }, []);

  useEffect(() => {
    let interval: any;
    if (isApkModalOpen && apkDownloadProgress < 100 && !isApkDownloaded) {
      interval = setInterval(() => {
        setApkDownloadProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setIsApkDownloaded(true);
            return 100;
          }
          const nextVal = prev + Math.floor(Math.random() * 12) + 8;
          return nextVal > 100 ? 100 : nextVal;
        });
      }, 200);
    }
    return () => clearInterval(interval);
  }, [isApkModalOpen, isApkDownloaded]);

  const [merchants, setMerchants] = useState<Merchant[]>([]);
  const [merchantsLoading, setMerchantsLoading] = useState<boolean>(true);
  const [merchantsError, setMerchantsError] = useState<string | null>(null);
  const [selectedMerchant, setSelectedMerchant] = useState<Merchant | null>(null);
  const [selectedMerchantMenu, setSelectedMerchantMenu] = useState<MenuItem[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedMerchantCategory, setSelectedMerchantCategory] = useState<string>('all');

  // Deep linking URL query parameters for SEO and direct social traffic
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const serviceParam = params.get('service') || params.get('view');
      const pageParam = params.get('page');
      if (serviceParam === 'food') {
        setHomeSubView('food');
        setActiveTab('home');
      }
      if (pageParam === 'edukasi' || pageParam === 'panduan' || pageParam === 'artikel') {
        setActiveTab('edukasi');
      } else if (pageParam === 'merchant-register' || pageParam === 'partner-register') {
        setActiveTab('partner-register');
      } else if (pageParam === 'bantuan' || pageParam === 'faq' || pageParam === 'help') {
        setActiveTab('home');
        setOpenFaqIndex(0);
        setTimeout(() => {
          const el = document.getElementById('section-faq-title') || document.querySelector('[aria-labelledby="section-faq-title"]');
          if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 150);
      }

      const trackParam = params.get('track') || params.get('orderId') || params.get('nomorOrder');
      if (trackParam) {
        const cleanTrackId = trackParam.trim().replace(/^#/, '');
        setTrackingOrderId(cleanTrackId);
        setActiveTab('tracking');
        fetch(`/api/orders/${encodeURIComponent(cleanTrackId)}`)
          .then(res => {
            if (res.ok) return res.json();
            throw new Error('Pesanan tidak ditemukan. Periksa kembali kode order Anda.');
          })
          .then(data => {
            if (data && (data.id || data.orderNumber)) {
              setActiveOrder(normalizeOrderDeliveryFee(data));
              setTrackingOrderId(data.orderNumber || data.id);
            }
          })
          .catch((err) => {
            setTrackingError(err.message || 'Pesanan tidak ditemukan. Periksa kembali kode order Anda.');
          });
      }
    } catch {}
  }, []);

  // Check if current URL is directly targeting bantuan page
  const isBantuanPage = typeof window !== 'undefined' && new URLSearchParams(window.location.search).get('page') === 'bantuan';

  // Dynamic SEO Synchronization
  useSEO({
    title: (isBantuanPage || activeTab === 'help')
      ? 'Pusat Bantuan Resmi & Panduan Layanan | TumpangGo'
      : activeTab === 'edukasi'
      ? 'Panduan & Edukasi Digitalisasi UMKM Lokal | TumpangGo'
      : activeTab === 'partner-register'
        ? 'Pendaftaran Kemitraan UMKM | Bawa Usaha Lokal Naik Kelas – TumpangGo'
        : activeTab === 'merchant-detail' && selectedMerchant
          ? `${selectedMerchant.name} – Menu Kuliner Lokal & Pesan Online | TumpangGo`
          : homeSubView === 'food'
            ? 'Pesan Kuliner Lokal Tumpang Online | Menu Favorit UMKM – TumpangGo'
            : 'TumpangGo – Saatnya Usaha Lokal Naik Kelas | Kuliner & Layanan Digital Tumpang Malang',
    description: (isBantuanPage || activeTab === 'help')
      ? 'Pusat Bantuan TumpangGo: Temukan informasi dan panduan menggunakan TumpangGo, FAQ pelanggan, panduan kemitraan UMKM, tarif ongkir flat hemat Rp 5.000, serta pelaporan kendala.'
      : activeTab === 'edukasi'
      ? 'Pelajari strategi digital marketing, konsistensi rasa kuliner, dan panduan adopsi teknologi bagi UMKM lokal dan pengusaha milenial di Tumpang.'
      : activeTab === 'partner-register'
        ? 'Daftarkan usaha kuliner Anda di TumpangGo. Buka peluang pasar baru dan jangkau lebih banyak pelanggan di Kecamatan Tumpang.'
        : activeTab === 'merchant-detail' && selectedMerchant
          ? `Pesan aneka menu dari ${selectedMerchant.name} di Tumpang Malang dengan ongkir flat hemat Rp 5.000 via TumpangGo.`
          : homeSubView === 'food'
            ? 'Temukan kuliner khas Kecamatan Tumpang Malang dari resto dan warung UMKM terdekat. Pesan mudah dengan ongkir hemat flat Rp 5.000.'
            : 'TumpangGo hadir mendukung usaha lokal naik kelas di era digital. Pesan kuliner lokal Tumpang Malang dengan ongkir hemat flat Rp 5.000 dan pembayaran QRIS praktis.',
    canonicalPath: (isBantuanPage || activeTab === 'help')
      ? '/?page=bantuan'
      : activeTab === 'edukasi'
      ? '/?page=edukasi'
      : activeTab === 'partner-register'
        ? '/?page=merchant-register'
        : homeSubView === 'food'
          ? '/?service=food'
          : '/',
    isNoIndex: false,
  });
  
  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  
  // Cart state
  const [cart, setCart] = useState<OrderItem[]>(() => {
    try {
      const saved = safeStorage.getItem('tumpang_cart');
      const parsed = saved ? JSON.parse(saved) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });
  const [cartMerchantId, setCartMerchantId] = useState<string | null>(() => {
    try {
      return safeStorage.getItem('tumpang_cart_merchant_id') || null;
    } catch {
      return null;
    }
  });
  const [cartMerchant, setCartMerchant] = useState<Merchant | null>(() => {
    try {
      const saved = safeStorage.getItem('tumpang_cart_merchant');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [showClearCartConfirm, setShowClearCartConfirm] = useState<{ pendingItem: MenuItem; pendingMerchant: Merchant } | null>(null);
  const [selectedMenuItemDetail, setSelectedMenuItemDetail] = useState<{ item: MenuItem; merchant: Merchant } | null>(null);

  useEffect(() => {
    try {
      safeStorage.setItem('tumpang_cart', JSON.stringify(cart));
      if (cartMerchantId) safeStorage.setItem('tumpang_cart_merchant_id', cartMerchantId);
      else safeStorage.removeItem('tumpang_cart_merchant_id');
      if (cartMerchant) safeStorage.setItem('tumpang_cart_merchant', JSON.stringify(cartMerchant));
      else safeStorage.removeItem('tumpang_cart_merchant');
    } catch (e) {
      console.error(e);
    }
  }, [cart, cartMerchantId, cartMerchant]);

  // Checkout form state
  const [checkoutName, setCheckoutName] = useState('');
  const [checkoutPhone, setCheckoutPhone] = useState('');
  const [checkoutAddress, setCheckoutAddress] = useState('');
  const [checkoutDetails, setCheckoutDetails] = useState('');
  const [checkoutLandmark, setCheckoutLandmark] = useState('');
  const [checkoutLat, setCheckoutLat] = useState(-7.9482);
  const [checkoutLng, setCheckoutLng] = useState(112.7612);
  const [isSubmittingOrder, setIsSubmittingOrder] = useState<boolean>(false);
  const [checkoutErrorMsg, setCheckoutErrorMsg] = useState<string | null>(null);

  // Active Order / Tracking state
  const [activeOrder, setActiveOrder] = useState<Order | null>(() => {
    try {
      const saved = safeStorage.getItem('tumpang_active_order');
      if (!saved) return null;
      const parsed = JSON.parse(saved);
      return parsed ? normalizeOrderDeliveryFee(parsed) : null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    try {
      if (activeOrder) {
        const normalized = normalizeOrderDeliveryFee(activeOrder);
        safeStorage.setItem('tumpang_active_order', JSON.stringify(normalized));
      } else {
        safeStorage.removeItem('tumpang_active_order');
      }
    } catch (e) {
      console.error(e);
    }
  }, [activeOrder]);

  const [trackingOrderId, setTrackingOrderId] = useState<string>('');
  const [trackingError, setTrackingError] = useState<string | null>(null);
  const [trackingLoading, setTrackingLoading] = useState<boolean>(false);
  const [copiedTrackingId, setCopiedTrackingId] = useState<string | null>(null);
  const [copiedCustomerTrackingLink, setCopiedCustomerTrackingLink] = useState<string | null>(null);

  const handleCopyCustomerOrderNumber = async (orderNum: string) => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(orderNum);
      }
      setCopiedTrackingId(orderNum);
      setTimeout(() => setCopiedTrackingId(null), 2500);
    } catch {}
  };

  const handleCopyCustomerTrackingLink = async (orderNum: string) => {
    try {
      const trackingUrl = `${window.location.origin}/?track=${encodeURIComponent(orderNum)}`;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(trackingUrl);
      }
      setCopiedCustomerTrackingLink(orderNum);
      setTimeout(() => setCopiedCustomerTrackingLink(null), 2500);
    } catch {}
  };
  const [paymentProofFile, setPaymentProofFile] = useState<string | null>(null);
  const [paymentProofFileName, setPaymentProofFileName] = useState<string | null>(null);
  const [paymentProofFileSize, setPaymentProofFileSize] = useState<string | null>(null);
  const [uploadLoading, setUploadLoading] = useState(false);
  const [proofUploadError, setProofUploadError] = useState<string | null>(null);
  const [proofUploadSuccess, setProofUploadSuccess] = useState<string | null>(null);
  const [proofZoomModalImage, setProofZoomModalImage] = useState<string | null>(null);
  const [showReceiptModal, setShowReceiptModal] = useState<boolean>(false);
  // Dedicated granular states for QRIS loading, fallback stages, and bounded retries
  const [qrisImageStage, setQrisImageStage] = useState<'primary' | 'fallback'>('primary');
  const [qrisRetryCount, setQrisRetryCount] = useState<number>(0);
  const [qrisRetryTimestamp, setQrisRetryTimestamp] = useState<number | null>(null);
  const [qrisLoading, setQrisLoading] = useState<boolean>(true);
  const [qrisLoadFailed, setQrisLoadFailed] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (activeOrder?.id) {
      setQrisImageStage('primary');
      setQrisRetryCount(0);
      setQrisRetryTimestamp(null);
      setQrisLoading(true);
      setQrisLoadFailed(false);
    }
  }, [activeOrder?.id]);

  // History search state
  const [historyPhone, setHistoryPhone] = useState('');
  const [historyOrders, setHistoryOrders] = useState<Order[]>([]);
  const [historySearched, setHistorySearched] = useState(false);
  const [historyLoading, setHistoryLoading] = useState(false);

  // Partner registration states
  const [partnerName, setPartnerName] = useState('');
  const [partnerPhone, setPartnerPhone] = useState('');
  const [partnerEmail, setPartnerEmail] = useState('');
  const [partnerType, setPartnerType] = useState<'MERCHANT' | 'DRIVER'>('MERCHANT');
  const [partnerStoreName, setPartnerStoreName] = useState('');
  const [partnerStoreAddress, setPartnerStoreAddress] = useState('');
  const [partnerCategory, setPartnerCategory] = useState('Bakso & Mie');
  const [partnerVehicle, setPartnerVehicle] = useState('');
  const [partnerArea, setPartnerArea] = useState('');
  const [partnerSubmitLoading, setPartnerSubmitLoading] = useState(false);
  const [partnerSubmitSuccess, setPartnerSubmitSuccess] = useState(false);

  // Active registration tracking states
  const [submittedPartnerId, setSubmittedPartnerId] = useState<string | null>(
    safeStorage.getItem('tumpang_submitted_partner_id')
  );
  const [submittedPartnerEmail, setSubmittedPartnerEmail] = useState<string | null>(
    safeStorage.getItem('tumpang_submitted_partner_email')
  );
  const [activeRegistration, setActiveRegistration] = useState<any>(null);
  const [checkingRegistration, setCheckingRegistration] = useState(false);

  // Fetch partner registration status
  const checkMyPartnerRegistration = async () => {
    const id = safeStorage.getItem('tumpang_submitted_partner_id');
    const email = safeStorage.getItem('tumpang_submitted_partner_email');
    if (!id && !email) {
      setActiveRegistration(null);
      return;
    }
    setCheckingRegistration(true);
    try {
      const res = await fetch('/api/partner-registrations');
      if (res.ok) {
        const data = await res.json();
        const list = Array.isArray(data) ? data : (Array.isArray(data?.data) ? data.data : []);
        const match = list.find((r: any) => r && (r.id === id || r.email?.trim().toLowerCase() === email?.trim().toLowerCase()));
        if (match) {
          setActiveRegistration(match);
        } else {
          setActiveRegistration(null);
        }
      }
    } catch (e) {
      console.error('Error checking partner registration:', e);
    } finally {
      setCheckingRegistration(false);
    }
  };

  const resetPartnerForm = () => {
    // Clear local storage tracking
    safeStorage.removeItem('tumpang_submitted_partner_id');
    safeStorage.removeItem('tumpang_submitted_partner_email');
    
    // Clear tracking states
    setSubmittedPartnerId(null);
    setSubmittedPartnerEmail(null);
    setActiveRegistration(null);
    setPartnerSubmitSuccess(false);
    
    // Reset form inputs
    setPartnerName('');
    setPartnerPhone('');
    setPartnerEmail('');
    setPartnerType('MERCHANT');
    setPartnerStoreName('');
    setPartnerStoreAddress('');
    setPartnerCategory('Bakso & Mie');
    setPartnerVehicle('');
    setPartnerArea('');
    
    // Reset steps and files
    setPartnerStep(1);
    setBusinessPhoto('');
    setIdPhoto('');
    setContractPhoto('');
    setSignatureSigned(false);
    setPartnerTermsAccepted(false);
  };

  useEffect(() => {
    if (activeTab === 'partner-register') {
      checkMyPartnerRegistration();
    } else if (activeTab === 'history') {
      try {
        const localHistoryRaw = safeStorage.getItem('tumpang_local_order_history');
        if (localHistoryRaw) {
          const list: Order[] = JSON.parse(localHistoryRaw);
          if (Array.isArray(list) && list.length > 0) {
            setHistoryOrders(list.map(o => normalizeOrderDeliveryFee(o)));
            setHistorySearched(true);
          }
        }
      } catch {}
    }
  }, [activeTab]);

  // High-fidelity Multi-step and Attachment states
  const [partnerStep, setPartnerStep] = useState<number>(1);
  const [businessPhoto, setBusinessPhoto] = useState<string>('');
  const [idPhoto, setIdPhoto] = useState<string>('');
  const [contractPhoto, setContractPhoto] = useState<string>('');
  const [partnerLat, setPartnerLat] = useState<number>(-7.9482);
  const [partnerLng, setPartnerLng] = useState<number>(112.7612);
  const [signatureSigned, setSignatureSigned] = useState<boolean>(false);
  const [partnerTermsAccepted, setPartnerTermsAccepted] = useState<boolean>(false);

  // Canvas Drawing Signature logic
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.strokeStyle = '#0f172a'; // Slate-900
    
    let clientX, clientY;
    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }
    
    const rect = canvas.getBoundingClientRect();
    ctx.beginPath();
    ctx.moveTo(clientX - rect.left, clientY - rect.top);
    setIsDrawing(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    let clientX, clientY;
    if ('touches' in e) {
      clientX = e.touches[0].clientX;
      clientY = e.touches[0].clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }
    
    const rect = canvas.getBoundingClientRect();
    ctx.lineTo(clientX - rect.left, clientY - rect.top);
    ctx.stroke();
  };

  const stopDrawing = async () => {
    setIsDrawing(false);
    const canvas = canvasRef.current;
    if (canvas) {
      const dataUrl = canvas.toDataURL('image/jpeg', 0.5);
      try {
        const compressed = await compressBase64(dataUrl, 600, 600, 0.5);
        setContractPhoto(compressed);
      } catch (e) {
        setContractPhoto(dataUrl);
      }
      setSignatureSigned(true);
    }
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        setContractPhoto('');
        setSignatureSigned(false);
      }
    }
  };

  const handlePartnerFileChange = async (e: React.ChangeEvent<HTMLInputElement>, setter: (val: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const compressed = await compressImage(file, 800, 800, 0.6);
        setter(compressed);
      } catch (err) {
        console.error('Error compressing file:', err);
        // Fallback to standard reader
        const reader = new FileReader();
        reader.onloadend = () => {
          if (typeof reader.result === 'string') {
            setter(reader.result);
          }
        };
        reader.readAsDataURL(file);
      }
    }
  };

  const handlePartnerRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (partnerType === 'MERCHANT') {
      if (!partnerName || !partnerPhone || !partnerEmail) {
        alert('Mohon lengkapi Nama, No WhatsApp, dan Email Anda.');
        return;
      }
      if (!partnerStoreName || !partnerStoreAddress) {
        alert('Mohon lengkapi Nama Toko dan Alamat Toko Anda.');
        return;
      }
    } else {
      // Driver mode
      if (!partnerName || !partnerPhone || !partnerVehicle || !partnerArea) {
        alert('Mohon lengkapi Nama, No WhatsApp, Nomor Plat, dan Wilayah Operasional Anda.');
        return;
      }
    }
    if (!partnerTermsAccepted) {
      alert('Anda harus menyetujui Syarat dan Ketentuan Kemitraan Tumpang Food terlebih dahulu.');
      return;
    }

    setPartnerSubmitLoading(true);
    try {
      const payload: any = {
        name: partnerName,
        phone: partnerPhone,
        type: partnerType,
        status: 'PENDING',
        latitude: partnerLat,
        longitude: partnerLng,
        businessPhoto: businessPhoto,
        idPhoto: idPhoto,
        contractPhoto: contractPhoto,
      };

      if (partnerType === 'MERCHANT') {
        payload.email = partnerEmail.trim().toLowerCase();
        payload.storeName = partnerStoreName;
        payload.storeAddress = partnerStoreAddress;
        payload.category = partnerCategory;
      } else {
        payload.vehicleNumber = partnerVehicle;
        payload.operatingArea = partnerArea;
        // Optional: save empty string for email
        payload.email = '';
      }

      const res = await fetch('/api/partner-registrations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const data = await res.json();
        if (data && data.id) {
          safeStorage.setItem('tumpang_submitted_partner_id', data.id);
          safeStorage.setItem('tumpang_submitted_partner_email', payload.email || payload.phone);
          setSubmittedPartnerId(data.id);
          setSubmittedPartnerEmail(payload.email || payload.phone);
          // Set active registration immediately
          setActiveRegistration(data);
        }
        setPartnerSubmitSuccess(true);
        // Clear form
        setPartnerName('');
        setPartnerPhone('');
        setPartnerEmail('');
        setPartnerStoreName('');
        setPartnerStoreAddress('');
        setPartnerVehicle('');
        setPartnerArea('');
        setBusinessPhoto('');
        setIdPhoto('');
        setContractPhoto('');
        setSignatureSigned(false);
        setPartnerTermsAccepted(false);
        setPartnerStep(1);
      } else {
        const err = await res.json();
        alert(err.error || 'Gagal mengirimkan pendaftaran.');
      }
    } catch (e) {
      console.error(e);
      alert('Terjadi kesalahan saat mengirim pendaftaran.');
    } finally {
      setPartnerSubmitLoading(false);
    }
  };

  // PWA states and handlers
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [showIOSPrompt, setShowIOSPrompt] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);
  const [showPWAInfo, setShowPWAInfo] = useState(false);
  const [dismissedPrompt, setDismissedPrompt] = useState(() => {
    return safeStorage.getItem('tumpang_pwa_dismissed') === 'true';
  });

  useEffect(() => {
    // Check if already running in standalone mode (installed)
    const checkStandalone = window.matchMedia('(display-mode: standalone)').matches || 
                           (window.navigator as any).standalone === true;
    setIsStandalone(checkStandalone);

    // Check if iOS
    const checkiOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    setIsIOS(checkiOS);

    // Event listener for Android/Chrome beforeinstallprompt
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setIsInstallable(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // Event listener for successful install
    const handleAppInstalled = () => {
      console.log('App was successfully installed');
      setIsInstallable(false);
      setDeferredPrompt(null);
      setIsStandalone(true);
      setInstallSuccess(true);
      setTimeout(() => setInstallSuccess(false), 6000);
    };

    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      console.log(`User response to the install prompt: ${outcome}`);
      setDeferredPrompt(null);
      setIsInstallable(false);
    } else if (isIOS) {
      setShowIOSPrompt(true);
    } else {
      // Manual/Fallback explanation
      setShowPWAInfo(true);
    }
  };

  const dismissInstallPrompt = () => {
    setDismissedPrompt(true);
    safeStorage.setItem('tumpang_pwa_dismissed', 'true');
  };

  // Fetch initial data
  useEffect(() => {
    fetchMerchants();
  }, []);

  const fetchMerchants = async () => {
    setMerchantsLoading(true);
    setMerchantsError(null);
    try {
      const res = await fetch('/api/merchants');
      if (!res.ok) {
        const errJson = await res.json().catch(() => null);
        const errMsg = errJson?.error || errJson?.detail || errJson?.message || (errJson?.requestId ? `Gagal memuat toko (HTTP ${res.status} - ID: ${errJson.requestId})` : `Gagal memuat toko (HTTP ${res.status})`);
        throw new Error(errMsg);
      }
      const data = await res.json();
      const list = extractArrayResponse<Merchant>(data, 'merchants');
      setMerchants(list);
    } catch (e: any) {
      console.error('Error fetching merchants:', e);
      setMerchants([]);
      setMerchantsError(e.message || 'Gagal memuat daftar toko kuliner.');
    } finally {
      setMerchantsLoading(false);
    }
  };

  const loadMerchantDetail = async (merchant: Merchant) => {
    setSelectedMerchant(merchant);
    try {
      // Get menu
      const menuRes = await fetch(`/api/merchants/${merchant.id}/menu`);
      if (menuRes.ok) {
        const menuData = await menuRes.json();
        const menuList = extractArrayResponse<MenuItem>(menuData, 'menuItems');
        setSelectedMerchantMenu(menuList);
      } else {
        setSelectedMerchantMenu([]);
      }

      // Get categories
      const catRes = await fetch(`/api/merchants/${merchant.id}/categories`);
      if (catRes.ok) {
        const catData = await catRes.json();
        const catList = extractArrayResponse<Category>(catData, 'categories');
        setCategories(catList);
      } else {
        setCategories([]);
      }
      
      setSelectedCategory('all');
      setActiveTab('merchant-detail');
      setHomeSubView('food');
    } catch (e) {
      console.error('Error loading merchant detail:', e);
      setSelectedMerchantMenu([]);
      setCategories([]);
    }
  };

  // Cart operations
  const addToCart = (item: MenuItem, merchant: Merchant) => {
    if (!merchant.active) {
      alert('Toko sedang tutup. Anda tidak dapat memesan dari toko yang sedang tutup.');
      return;
    }

    if (cartMerchantId && cartMerchantId !== merchant.id) {
      setShowClearCartConfirm({ pendingItem: item, pendingMerchant: merchant });
      return;
    }

    setCart(prev => {
      const existing = prev.find(i => i.menuItemId === item.id);
      if (existing) {
        return prev.map(i => i.menuItemId === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { 
        menuItemId: item.id, 
        name: item.name, 
        price: item.price, 
        quantity: 1
      }];
    });
    setCartMerchantId(merchant.id);
    setCartMerchant(merchant);
  };

  const handleClearCartAndAdd = () => {
    if (!showClearCartConfirm) return;
    const { pendingItem, pendingMerchant } = showClearCartConfirm;

    setCart([{ 
      menuItemId: pendingItem.id, 
      name: pendingItem.name, 
      price: pendingItem.price, 
      quantity: 1
    }]);
    setCartMerchantId(pendingMerchant.id);
    setCartMerchant(pendingMerchant);
    setShowClearCartConfirm(null);
  };

  const updateCartQuantity = (menuItemId: string, change: number) => {
    setCart(prev => {
      const updated = prev.map(i => {
        if (i.menuItemId === menuItemId) {
          const qty = i.quantity + change;
          return qty > 0 ? { ...i, quantity: qty } : null;
        }
        return i;
      }).filter(Boolean) as OrderItem[];

      if (updated.length === 0) {
        setCartMerchantId(null);
        setCartMerchant(null);
      }
      return updated;
    });
  };

  const removeFromCart = (menuItemId: string) => {
    setCart(prev => {
      const safePrev = Array.isArray(prev) ? prev : [];
      const updated = safePrev.filter(i => i && i.menuItemId !== menuItemId);
      if (updated.length === 0) {
        setCartMerchantId(null);
        setCartMerchant(null);
      }
      return updated;
    });
  };

  // Calculations
  const getSubtotal = () => {
    return cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  };

  const getDeliveryCalculation = () => {
    return calculateDeliveryFee({
      address: checkoutAddress,
      details: checkoutDetails,
      landmark: checkoutLandmark,
      latitude: checkoutLat,
      longitude: checkoutLng,
      merchantLatitude: cartMerchant?.latitude,
      merchantLongitude: cartMerchant?.longitude,
      systemConfig
    });
  };

  const getDeliveryFee = () => {
    return getDeliveryCalculation().deliveryFee;
  };

  const getServiceFee = (subtotalVal?: number) => {
    const subtotal = subtotalVal !== undefined ? subtotalVal : getSubtotal();
    return calculateTieredServiceFee(subtotal);
  };

  // Submit checkout with idempotency and robust error diagnostics
  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmittingOrder) return;

    if (!checkoutName || !checkoutPhone || !checkoutAddress) {
      alert('Mohon lengkapi Nama, No WhatsApp, dan Alamat Pengantaran');
      return;
    }

    if (cart.length === 0 || !cartMerchantId) {
      alert('Keranjang Anda kosong');
      return;
    }

    setIsSubmittingOrder(true);
    setCheckoutErrorMsg(null);

    const clientRequestId = 'req_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);

    const payload = {
      customerName: checkoutName,
      customerPhone: checkoutPhone,
      deliveryAddress: checkoutAddress,
      deliveryDetails: checkoutDetails,
      landmark: checkoutLandmark,
      latitude: checkoutLat,
      longitude: checkoutLng,
      items: cart,
      merchantId: cartMerchantId,
      subtotal: getSubtotal(),
      deliveryFee: getDeliveryFee(),
      serviceFee: getServiceFee(),
      clientRequestId
    };

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'X-Request-Id': clientRequestId
        },
        body: JSON.stringify(payload)
      });
      const order = await res.json().catch(() => null);
      
      if (res.ok && order && order.id) {
        const normalized = normalizeOrderDeliveryFee(order);
        setActiveOrder(normalized);
        setTrackingOrderId(normalized.id);
        setCheckoutErrorMsg(null);
        // Save to on-device order history (client-side device convenience)
        try {
          const localHistoryRaw = safeStorage.getItem('tumpang_local_order_history');
          const localHistory: any[] = localHistoryRaw ? JSON.parse(localHistoryRaw) : [];
          const updatedHistory = [normalized, ...localHistory.filter(o => o.id !== normalized.id)].slice(0, 50);
          safeStorage.setItem('tumpang_local_order_history', JSON.stringify(updatedHistory));
        } catch {}
        // Clear cart
        setCart([]);
        setCartMerchantId(null);
        setCartMerchant(null);
        setActiveTab('payment');
      } else {
        const errorMsg = order?.error || order?.message || order?.cancelReason || 'Gagal membuat pesanan. Silakan periksa kembali data pesanan Anda.';
        setCheckoutErrorMsg(errorMsg);
        alert(errorMsg);
      }
    } catch (e: any) {
      console.error('Checkout error:', e);
      const networkMsg = 'Terjadi kesalahan koneksi saat memproses pesanan ke server. Silakan coba kembali.';
      setCheckoutErrorMsg(networkMsg);
      alert(networkMsg);
    } finally {
      setIsSubmittingOrder(false);
    }
  };

  // Handle proof upload
  const handlePaymentProofUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentProofFile) {
      setProofUploadError('Silakan pilih foto atau tangkapan layar (screenshot) bukti pembayaran terlebih dahulu.');
      return;
    }

    if (!activeOrder) return;
    setUploadLoading(true);
    setProofUploadError(null);
    setProofUploadSuccess(null);

    try {
      const res = await fetch(`/api/orders/${activeOrder.id}/upload-payment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paymentProof: paymentProofFile })
      });
      const updatedOrder = await res.json();
      if (res.ok) {
        const normalized = normalizeOrderDeliveryFee(updatedOrder);
        setActiveOrder(normalized);
        setProofUploadSuccess('Bukti pembayaran berhasil diunggah! Menunggu verifikasi admin.');
        setProofUploadError(null);
        setPaymentProofFile(null);
        setPaymentProofFileName(null);
        setPaymentProofFileSize(null);
        // Update on-device order history
        try {
          const localHistoryRaw = safeStorage.getItem('tumpang_local_order_history');
          if (localHistoryRaw) {
            const localHistory: any[] = JSON.parse(localHistoryRaw);
            const updatedHistory = localHistory.map(o => o.id === normalized.id ? { ...o, ...normalized } : o);
            safeStorage.setItem('tumpang_local_order_history', JSON.stringify(updatedHistory));
          }
        } catch {}
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      } else {
        setProofUploadError(updatedOrder.error || 'Gagal mengunggah bukti pembayaran.');
      }
    } catch (err: any) {
      console.error('Error uploading payment:', err);
      setProofUploadError('Terjadi kendala koneksi saat mengirim bukti pembayaran ke server.');
    } finally {
      setUploadLoading(false);
    }
  };

  // Handle file selection, validate format & size, then compress client-side
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setProofUploadError(null);
    setProofUploadSuccess(null);

    // 1. Validation: Format must be JPG/JPEG, PNG, or WEBP
    const validMimes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    const validExtensions = /\.(jpe?g|png|webp)$/i;
    if (!validMimes.includes(file.type.toLowerCase()) && !validExtensions.test(file.name)) {
      setProofUploadError('Format file tidak didukung. Mohon pilih foto berformat JPG, JPEG, PNG, atau WEBP.');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    // 2. Validation: Maximum file size 10MB
    const MAX_SIZE = 10 * 1024 * 1024;
    if (file.size > MAX_SIZE) {
      setProofUploadError('Ukuran file foto melebihi batas maksimal 10MB. Silakan pilih foto dengan resolusi lebih kecil.');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    setPaymentProofFileName(file.name);
    setPaymentProofFileSize((file.size / 1024).toFixed(1) + ' KB');

    try {
      // Client-side canvas compression for responsive speed & Firestore safety
      const compressed = await compressImage(file, 1000, 1000, 0.75);
      setPaymentProofFile(compressed);
    } catch (err) {
      console.error('Error compressing payment proof:', err);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPaymentProofFile(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleClearSelectedProof = () => {
    setPaymentProofFile(null);
    setPaymentProofFileName(null);
    setPaymentProofFileSize(null);
    setProofUploadError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Live order refresh
  const refreshActiveOrder = async (overrideId?: string | React.SyntheticEvent) => {
    const rawTarget = typeof overrideId === 'string' ? overrideId : trackingOrderId;
    const targetId = String(rawTarget || '').trim().replace(/^#+/, '').trim();
    if (!targetId) {
      setTrackingError('Masukkan kode order terlebih dahulu.');
      return;
    }
    setTrackingLoading(true);
    setTrackingError(null);
    try {
      const res = await fetch(`/api/orders/${encodeURIComponent(targetId)}`);
      if (res.ok) {
        const order = await res.json();
        setActiveOrder(normalizeOrderDeliveryFee(order));
        setTrackingOrderId(order.orderNumber || order.id);
        setTrackingError(null);
      } else {
        setActiveOrder(null);
        const errData = await res.json().catch(() => null);
        if (res.status === 404) {
          setTrackingError('Pesanan tidak ditemukan. Periksa kembali kode order Anda.');
        } else {
          setTrackingError(errData?.error || 'Pesanan tidak ditemukan. Periksa kembali kode order Anda.');
        }
      }
    } catch (e) {
      console.error('Error refreshing order:', e);
      setTrackingError('Terjadi gangguan pada server. Silakan coba beberapa saat lagi.');
    } finally {
      setTrackingLoading(false);
    }
  };


  // Search History (Local Device Convenience + Protected Server Endpoint)
  const searchHistory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!historyPhone) return;
    setHistoryLoading(true);
    try {
      const res = await fetch(`/api/orders/customer/${encodeURIComponent(historyPhone)}`);
      if (res.ok) {
        const data = await res.json();
        const list = extractArrayResponse<Order>(data, 'orders');
        setHistoryOrders(list.map(o => normalizeOrderDeliveryFee(o)));
        setHistorySearched(true);
      } else {
        // Fallback gracefully to device local storage convenience
        const localHistoryRaw = safeStorage.getItem('tumpang_local_order_history');
        const localOrders: Order[] = localHistoryRaw ? JSON.parse(localHistoryRaw) : [];
        const cleanPhone = historyPhone.trim().replace(/[^0-9]/g, '');
        const matched = localOrders.filter(o => {
          const oPhone = (o.customerPhone || '').replace(/[^0-9]/g, '');
          return oPhone === cleanPhone || (cleanPhone.length >= 8 && oPhone.includes(cleanPhone));
        });
        setHistoryOrders(matched.map(o => normalizeOrderDeliveryFee(o)));
        setHistorySearched(true);
      }
    } catch (err) {
      console.error('History fetch error:', err);
      try {
        const localHistoryRaw = safeStorage.getItem('tumpang_local_order_history');
        const localOrders: Order[] = localHistoryRaw ? JSON.parse(localHistoryRaw) : [];
        const cleanPhone = historyPhone.trim().replace(/[^0-9]/g, '');
        const matched = localOrders.filter(o => {
          const oPhone = (o.customerPhone || '').replace(/[^0-9]/g, '');
          return oPhone === cleanPhone || (cleanPhone.length >= 8 && oPhone.includes(cleanPhone));
        });
        setHistoryOrders(matched.map(o => normalizeOrderDeliveryFee(o)));
      } catch {
        setHistoryOrders([]);
      }
      setHistorySearched(true);
    } finally {
      setHistoryLoading(false);
    }
  };

  const getMerchantCategory = (m: Merchant): string => {
    if (m.category) return m.category;
    const name = m.name.toLowerCase();
    if (name.includes('bakso') || name.includes('mie') || name.includes('pangsit')) {
      return 'Bakso & Mie';
    }
    if (name.includes('sate') || name.includes('bakar')) {
      return 'Sate & Bakaran';
    }
    if (name.includes('nasi') || name.includes('warung') || name.includes('kedai') || name.includes('dapur')) {
      return 'Nasi & Lauk';
    }
    if (name.includes('es') || name.includes('kopi') || name.includes('jus') || name.includes('boba') || name.includes('teh')) {
      return 'Minuman Segar';
    }
    if (name.includes('martabak') || name.includes('snack') || name.includes('cemilan') || name.includes('roti') || name.includes('kue')) {
      return 'Cemilan & Jajanan';
    }
    return m.category || 'Kuliner UMKM';
  };

  // Filter merchants by search query and category
  const filteredMerchants = (Array.isArray(merchants) ? merchants : []).filter(m => {
    if (!m) return false;
    const query = searchQuery.toLowerCase();
    const name = (m.name || '').toLowerCase();
    const description = (m.description || '').toLowerCase();
    const address = (m.address || '').toLowerCase();
    const matchesSearch = name.includes(query) || description.includes(query) || address.includes(query);
    
    if (selectedMerchantCategory === 'all') {
      return matchesSearch;
    }
    
    const mCategory = getMerchantCategory(m);
    const selectedCatObj = (Array.isArray(CULINARY_CATEGORIES) ? CULINARY_CATEGORIES : []).find(c => c && c.id === selectedMerchantCategory);
    if (!selectedCatObj) return matchesSearch;
    
    return matchesSearch && mCategory === selectedCatObj.name;
  });

  let activeThemeStyles: React.CSSProperties | undefined = undefined;
  if (homeSubView === 'food') {
    activeThemeStyles = {
      '--color-rose-50': '#FEF2F2',
      '--color-rose-100': '#FEE2E2',
      '--color-rose-200': '#FECACA',
      '--color-rose-300': '#FCA5A5',
      '--color-rose-500': '#EE2737',
      '--color-rose-600': '#DC2626',
      '--color-rose-700': '#B91C1C',
      '--color-rose-800': '#991B1B',
      '--color-rose-900': '#7F1D1D',
    } as React.CSSProperties;
  } else if (homeSubView === 'taxi') {
    activeThemeStyles = {
      '--color-rose-50': '#FFFDF0',
      '--color-rose-100': '#FEF9C3',
      '--color-rose-200': '#FEF08A',
      '--color-rose-300': '#FDE047',
      '--color-rose-500': '#FFB300',
      '--color-rose-600': '#D97706',
      '--color-rose-700': '#B45309',
      '--color-rose-800': '#92400E',
      '--color-rose-900': '#78350F',
    } as React.CSSProperties;
  } else if (homeSubView === 'niaga') {
    activeThemeStyles = {
      '--color-rose-50': '#EFF6FF',
      '--color-rose-100': '#DBEAFE',
      '--color-rose-200': '#BFDBFE',
      '--color-rose-300': '#93C5FD',
      '--color-rose-500': '#0F82FF',
      '--color-rose-600': '#2563EB',
      '--color-rose-700': '#1D4ED8',
      '--color-rose-800': '#1E40AF',
      '--color-rose-900': '#1E3A8A',
    } as React.CSSProperties;
  } else if (homeSubView === 'pay') {
    activeThemeStyles = {
      '--color-rose-50': '#FAF5FF',
      '--color-rose-100': '#F3E8FF',
      '--color-rose-200': '#E9D5FF',
      '--color-rose-300': '#D8B4FE',
      '--color-rose-500': '#6D28D9',
      '--color-rose-600': '#7C3AED',
      '--color-rose-700': '#6D28D9',
      '--color-rose-800': '#5B21B6',
      '--color-rose-900': '#4C1D95',
    } as React.CSSProperties;
  }

  const getHeaderTheme = () => {
    switch (homeSubView) {
      case 'food':
        return {
          borderClass: 'border-b-4 border-[#EE2737] shadow-lg shadow-rose-600/30',
          badgeClass: 'bg-rose-50 text-rose-800 border-rose-200',
          installBtnClass: 'bg-gradient-to-r from-[#EE2737] to-rose-700 hover:from-rose-700 hover:to-rose-800 text-white shadow-md shadow-rose-600/30 ring-2 ring-rose-500/30',
          badgeText: '',
        };
      case 'taxi':
        return {
          borderClass: 'border-b-4 border-amber-500 shadow-lg shadow-amber-500/30',
          badgeClass: 'bg-amber-50 text-amber-800 border-amber-200',
          installBtnClass: 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white shadow-md shadow-amber-500/30 ring-2 ring-amber-500/30',
          badgeText: '',
        };
      case 'niaga':
        return {
          borderClass: 'border-b-4 border-[#0F82FF] shadow-lg shadow-blue-600/30',
          badgeClass: 'bg-blue-50 text-blue-800 border-blue-200',
          installBtnClass: 'bg-gradient-to-r from-[#0F82FF] to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white shadow-md shadow-blue-500/30 ring-2 ring-blue-500/30',
          badgeText: '',
        };
      case 'pay':
        return {
          borderClass: 'border-b-4 border-purple-600 shadow-lg shadow-purple-600/30',
          badgeClass: 'bg-purple-50 text-purple-800 border-purple-200',
          installBtnClass: 'bg-gradient-to-r from-[#6D28D9] to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white shadow-md shadow-purple-500/30 ring-2 ring-purple-500/30',
          badgeText: '',
        };
      case 'bike':
        return {
          borderClass: 'border-b-4 border-teal-600 shadow-lg shadow-teal-600/30',
          badgeClass: 'bg-teal-50 text-teal-800 border-teal-200',
          installBtnClass: 'bg-gradient-to-r from-teal-600 to-teal-700 hover:from-teal-700 hover:to-teal-800 text-white shadow-md shadow-teal-500/30 ring-2 ring-teal-500/30',
          badgeText: '',
        };
      case 'main':
      default:
        return {
          borderClass: 'border-b-4 border-[#185338] shadow-lg shadow-emerald-800/20',
          badgeClass: 'bg-emerald-50 text-emerald-800 border-emerald-200',
          installBtnClass: 'bg-gradient-to-r from-[#185338] to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white shadow-md shadow-emerald-600/30 ring-2 ring-emerald-500/30',
          badgeText: '',
        };
    }
  };

  const headerTheme = getHeaderTheme();

  const renderFooter = (idSuffix: string = '') => (
    <footer className="w-full mt-5 text-slate-700 relative overflow-hidden rounded-2xl border border-slate-100 shadow-xs">
      {/* Top White Section with Logo & Social Media */}
      <div className="py-3 px-4 flex flex-col items-center justify-center text-center bg-white gap-2">
        <Logo size={96} />

        {/* Pusat Bantuan Quick Navigation */}
        <div className="flex flex-col items-center gap-2 mt-1 w-full max-w-sm">
          <button
            type="button"
            onClick={() => {
              setActiveTab('help');
              if (typeof window !== 'undefined') {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }
            }}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold border border-emerald-200 transition-colors shadow-2xs cursor-pointer"
          >
            <HelpCircle className="w-3.5 h-3.5 text-emerald-600" />
            <span>Pusat Bantuan TumpangGo</span>
          </button>
          
          <div className="pt-0.5">
            <SocialMediaButtons variant="compact" />
          </div>
        </div>
      </div>

      {/* Green Divider Line */}
      <div className="w-full h-[1px] bg-[#224B33]/20"></div>

      {/* Bottom Green Section - Hijau Adventure */}
      <div className="bg-[#224B33] text-white py-3 px-4 flex flex-col items-center justify-center text-center">
        <p className="text-xs text-emerald-50 font-medium max-w-sm leading-snug">
          Super-App lokal Kecamatan Tumpang untuk UMKM, kurir instan, dan layanan digital.
        </p>

        {/* Plain Copyright text - completely normal, no hover effects or glow */}
        <p 
          onClick={handleCopyrightClick}
          className="text-[10px] text-emerald-200/70 font-normal mt-1.5 select-none cursor-default"
        >
          © 2026 TumpangGo. All rights reserved.
        </p>

        {/* Portal Login & Akses Dashboard (Secret - Unlocked strictly between 10 to 13 clicks on copyright) */}
        {portalAccessUnlocked && (
          <HiddenPortalBar 
            currentPortal="CUSTOMER"
            onNavigatePortal={(portal) => {
              if (onSelectRole) onSelectRole(portal);
            }}
            idSuffix={idSuffix}
            variant="emerald"
          />
        )}
      </div>
    </footer>
  );

  return (
    <div 
      className={`max-w-md mx-auto bg-slate-50 min-h-screen shadow-xl relative font-sans transition-all duration-300 ${
        isTumpangFoodFlow ? 'pb-20' : 'pb-3'
      }`}
      style={activeThemeStyles}
    >
      {/* Header */}
      <header className={`bg-white px-4 py-1 sticky top-0 z-50 rounded-b-2xl shadow-sm transition-all duration-300 ${headerTheme.borderClass}`}>
        <div className="flex justify-between items-center h-13">
          <div 
            onClick={() => {
              setHomeSubView('main');
              setActiveTab('home');
            }}
            className="flex items-center cursor-pointer group active:scale-98 transition-transform h-full"
            title="Kembali ke Beranda Utama"
          >
            <Logo size={82} className="-my-3" />
          </div>
          <div className="flex items-center gap-1.5">
            {!isStandalone && (
              <button 
                onClick={handleInstallClick}
                className={`text-[10px] px-2.5 py-1.5 rounded-full font-extrabold flex items-center gap-1 cursor-pointer transition-all active:scale-95 ${headerTheme.installBtnClass}`}
                title="Install Aplikasi Tumpanku di Layar Utama"
              >
                <Download className="w-3 h-3 animate-bounce" />
                <span>Install TumpangGo</span>
              </button>
            )}
            {/* Service text badges cleared as requested */}
            {headerTheme.badgeText && (
              <div className={`text-[10px] px-3 py-1.5 rounded-full font-bold border shadow-sm transition-all duration-300 ${headerTheme.badgeClass}`}>
                {headerTheme.badgeText}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="p-4">
        {showClearCartConfirm && (
          <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-[100] backdrop-blur-sm">
            <div className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-2xl border border-slate-100">
              <h4 className="font-display font-bold text-lg text-slate-800">Ganti Toko?</h4>
              <p className="text-slate-500 text-sm mt-2 leading-relaxed">
                Keranjang Anda berisi menu dari <span className="font-semibold text-slate-800">{cartMerchant?.name}</span>. 
                Memasukkan menu dari <span className="font-semibold text-slate-800">{showClearCartConfirm.pendingMerchant.name}</span> akan mengosongkan keranjang sebelumnya.
              </p>
              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => setShowClearCartConfirm(null)}
                  className="flex-1 py-2.5 text-sm font-semibold text-slate-600 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors"
                >
                  Batal
                </button>
                <button
                  onClick={handleClearCartAndAdd}
                  className="flex-1 py-2.5 text-sm font-semibold text-white bg-rose-600 rounded-xl hover:bg-rose-700 transition-colors shadow-lg shadow-rose-600/20"
                >
                  Ganti & Tambah
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Detail Menu Popup Modal */}
        {selectedMenuItemDetail && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4 animate-fadeIn">
            <div className="bg-white rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl flex flex-col max-h-[90vh] border border-slate-100">
              {/* Header Image & Close Button */}
              <div className="relative h-48 bg-slate-100 flex-shrink-0">
                {selectedMenuItemDetail.item.image ? (
                  <img 
                    src={selectedMenuItemDetail.item.image} 
                    alt={selectedMenuItemDetail.item.name} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-rose-50 text-rose-300">
                    <Utensils className="w-12 h-12" />
                  </div>
                )}
                <button
                  type="button"
                  onClick={() => setSelectedMenuItemDetail(null)}
                  className="absolute top-3 right-3 bg-slate-900/60 hover:bg-slate-900/80 text-white rounded-full p-1.5 backdrop-blur-md transition-all cursor-pointer"
                  title="Tutup"
                >
                  <X className="w-4 h-4" />
                </button>
                
                {/* Merchant Tag */}
                <div className="absolute bottom-3 left-3 bg-white/95 backdrop-blur-md text-slate-800 text-[10px] font-bold px-2.5 py-1 rounded-full shadow-md flex items-center gap-1 border border-slate-100">
                  <Store className="w-3 h-3 text-rose-500" />
                  {selectedMenuItemDetail.merchant.name}
                </div>
              </div>

              {/* Content */}
              <div className="p-4 overflow-y-auto flex-1 flex flex-col gap-3">
                <div>
                  <div className="flex justify-between items-start gap-2">
                    <h3 className="font-display font-bold text-base text-slate-900 leading-snug">
                      {selectedMenuItemDetail.item.name}
                    </h3>
                    <span className="font-display font-extrabold text-rose-600 text-base flex-shrink-0">
                      Rp {selectedMenuItemDetail.item.price.toLocaleString('id-ID')}
                    </span>
                  </div>
                </div>

                {/* Detailed Description Box */}
                <div className="bg-slate-50 border border-slate-200/80 rounded-xl p-3.5 flex flex-col gap-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 uppercase tracking-wider">
                    <Info className="w-3.5 h-3.5 text-rose-500" />
                    Rincian & Komposisi Menu
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line font-normal">
                    {selectedMenuItemDetail.item.description || 'Merchant belum menuliskan rincian khusus untuk menu ini.'}
                  </p>
                </div>

                <p className="text-[10px] text-slate-400 italic">
                  * Rincian menu ditulis langsung oleh pemilik toko ({selectedMenuItemDetail.merchant.name}).
                </p>
              </div>

              {/* Footer / Add to Cart */}
              <div className="p-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => {
                    addToCart(selectedMenuItemDetail.item, selectedMenuItemDetail.merchant);
                    setSelectedMenuItemDetail(null);
                  }}
                  disabled={!selectedMenuItemDetail.item.available || !selectedMenuItemDetail.merchant.active}
                  className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer ${
                    !selectedMenuItemDetail.item.available || !selectedMenuItemDetail.merchant.active
                      ? 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
                      : 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-600/20'
                  }`}
                >
                  <ShoppingBag className="w-4 h-4" />
                  + Tambah ke Keranjang
                </button>
              </div>
            </div>
          </div>
        )}

        {/* PWA Install Success Alert */}
        {installSuccess && (
          <div className="fixed top-4 left-1/2 -translate-x-1/2 bg-emerald-600 text-white font-semibold py-3.5 px-6 rounded-2xl shadow-xl z-[120] flex items-center gap-2.5 border border-emerald-500 text-xs w-[90%] max-w-sm animate-bounce">
            <CheckCircle2 className="w-5 h-5 text-white flex-shrink-0 animate-pulse" />
            <span>Aplikasi Tumpang Food berhasil dipasang di layar utama Anda! 🎉</span>
          </div>
        )}

        {/* iOS PWA Install Instruction Modal */}
        {showIOSPrompt && (
          <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-[110] backdrop-blur-sm">
            <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-slate-100">
              <div className="flex justify-between items-start">
                <div className="w-10 h-10 rounded-xl bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-600">
                  <Smartphone className="w-5 h-5" />
                </div>
                <button 
                  onClick={() => setShowIOSPrompt(false)}
                  className="text-slate-400 hover:text-slate-600 p-1 bg-slate-50 hover:bg-slate-100 rounded-full transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              
              <h4 className="font-display font-bold text-base text-slate-800 mt-4">Pasang Tumpang Food di iPhone</h4>
              <p className="text-slate-500 text-xs mt-1.5 leading-relaxed">
                Safari di iPhone tidak mendukung instalasi otomatis satu-klik, namun Anda bisa memasangnya secara manual dengan langkah mudah berikut:
              </p>

              <div className="space-y-3.5 mt-5 text-xs text-slate-700">
                <div className="flex gap-3">
                  <div className="w-5 h-5 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center font-bold flex-shrink-0 text-[10px]">1</div>
                  <p className="leading-relaxed">Buka situs ini menggunakan browser <span className="font-bold text-slate-800">Safari</span> di iPhone Anda.</p>
                </div>
                <div className="flex gap-3">
                  <div className="w-5 h-5 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center font-bold flex-shrink-0 text-[10px]">2</div>
                  <p className="leading-relaxed flex-1">Ketuk tombol <span className="font-bold text-slate-800 bg-slate-100 px-1.5 py-0.5 rounded text-[10px] inline-flex items-center gap-1">Bagikan (Share) <Share2 className="w-3 h-3 text-blue-500" /></span> di bar navigasi Safari.</p>
                </div>
                <div className="flex gap-3">
                  <div className="w-5 h-5 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center font-bold flex-shrink-0 text-[10px]">3</div>
                  <p className="leading-relaxed text-slate-700">Gulir ke bawah dan pilih menu <span className="font-bold text-slate-800 bg-slate-100 px-1.5 py-0.5 rounded text-[10px]">Tambahkan ke Layar Utama (Add to Home Screen)</span>.</p>
                </div>
                <div className="flex gap-3">
                  <div className="w-5 h-5 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center font-bold flex-shrink-0 text-[10px]">4</div>
                  <p className="leading-relaxed">Ketuk <span className="font-bold text-rose-600">Tambah</span> di sudut kanan atas. Selesai! Aplikasi siap dibuka dari layar utama HP.</p>
                </div>
              </div>

              <button
                onClick={() => setShowIOSPrompt(false)}
                className="w-full mt-6 py-2.5 text-sm font-semibold text-white bg-rose-600 rounded-xl hover:bg-rose-700 transition-colors shadow-lg shadow-rose-600/20 cursor-pointer"
              >
                Saya Mengerti
              </button>
            </div>
          </div>
        )}

        {/* PWA Educational Information Modal */}
        {showPWAInfo && (
          <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-[110] backdrop-blur-sm">
            <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-slate-100 max-h-[85vh] overflow-y-auto">
              <div className="flex justify-between items-start">
                <div className="w-10 h-10 rounded-xl bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-600">
                  <Info className="w-5 h-5" />
                </div>
                <button 
                  onClick={() => setShowPWAInfo(false)}
                  className="text-slate-400 hover:text-slate-600 p-1 bg-slate-50 hover:bg-slate-100 rounded-full transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              
              <h4 className="font-display font-bold text-base text-slate-800 mt-4">Apa itu Fitur Aplikasi (PWA)?</h4>
              <p className="text-slate-500 text-xs mt-1.5 leading-relaxed">
                <span className="font-semibold text-rose-600">PWA (Progressive Web App)</span> adalah teknologi modern yang memungkinkan website Tumpang Food diubah menjadi aplikasi ponsel/komputer yang ringan.
              </p>

              <div className="mt-5 space-y-4">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <h5 className="font-bold text-xs text-slate-800 flex items-center gap-1.5">
                    🚀 Ringan & Hemat Memori
                  </h5>
                  <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                    Tidak perlu mengunduh puluhan megabyte dari Play Store/App Store. Aplikasi ini terpasang dalam hitungan detik dan sangat hemat kuota data Anda.
                  </p>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <h5 className="font-bold text-xs text-slate-800 flex items-center gap-1.5">
                    📱 Langsung di Layar Utama HP
                  </h5>
                  <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                    Tumpang Food akan memiliki ikon cantik di layar utama ponsel/komputer Anda, dapat dibuka sekali ketuk tanpa repot membuka browser atau mengetik alamat web.
                  </p>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                  <h5 className="font-bold text-xs text-slate-800 flex items-center gap-1.5">
                    ⚙️ Cara Pasang Manual
                  </h5>
                  <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                    Jika tombol pasang tidak muncul, ketuk tombol <span className="font-bold text-slate-800">Titik Tiga (⋮)</span> di kanan atas browser Chrome Anda, lalu pilih <span className="font-bold text-rose-600">"Instal Aplikasi"</span> atau <span className="font-bold text-rose-600">"Tambahkan ke Layar Utama"</span>.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowPWAInfo(false)}
                className="w-full mt-6 py-2.5 text-sm font-semibold text-white bg-rose-600 rounded-xl hover:bg-rose-700 transition-colors shadow-lg shadow-rose-600/20 cursor-pointer"
              >
                Tutup & Kembali
              </button>
            </div>
          </div>
        )}

        {/* 1. HOME TAB */}
        {activeTab === 'home' && (
          <div className="flex flex-col gap-5">
            {/* If we are on the main landing dashboard */}
            {homeSubView === 'main' && (
              <div className="flex flex-col gap-5 pb-1">
                {/* Compact Simple PWA Bar */}
                {!isStandalone && !dismissedPrompt && (
                  <div className="bg-gradient-to-r from-rose-50 to-amber-50 border border-rose-200/80 rounded-xl px-3 py-2 flex items-center justify-between gap-2 shadow-sm">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-7 h-7 rounded-lg bg-rose-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                        <Smartphone className="w-3.5 h-3.5" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-slate-800 truncate leading-tight">
                          Pasang Aplikasi Tumpang Go
                        </p>
                        <p className="text-[10px] text-slate-500 truncate hidden sm:block">
                          Akses cepat langsung dari layar HP Anda
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button 
                        onClick={handleInstallClick}
                        className="bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg shadow-sm flex items-center gap-1 transition-all cursor-pointer active:scale-95"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Install TumpangGo</span>
                      </button>
                      <button 
                        onClick={() => setShowPWAInfo(true)}
                        className="text-slate-400 hover:text-slate-600 p-1 rounded-lg transition-colors cursor-pointer"
                        title="Info PWA"
                      >
                        <Info className="w-3.5 h-3.5" />
                      </button>
                      <button 
                        onClick={dismissInstallPrompt}
                        className="text-slate-400 hover:text-slate-600 p-1 rounded-lg transition-colors cursor-pointer"
                        title="Tutup"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}

                {/* Hero Banner Auto-Sliding Carousel (Gambar Slide) */}
                <BannerCarousel mode="main" altPrefix="Banner Platform Digital Warga Tumpang" />

                {/* Main Menu Grid (Shopee Food / GoFood Style) */}
                <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-sm flex flex-col gap-4">
                  <div className="flex justify-between items-center">
                    <h2 className="font-display font-extrabold text-xs text-slate-400 uppercase tracking-wider">Layanan Tumpang Super-App</h2>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-2.5 sm:gap-4">
                    {/* 1. Tumpang Food Menu */}
                    <button
                      id="btn-main-menu-food"
                      onClick={() => setHomeSubView('food')}
                      className="flex flex-col items-center gap-1.5 cursor-pointer group active:scale-95 transition-all"
                    >
                      <div className="w-13 h-13 rounded-2xl bg-[#EE2737] flex items-center justify-center text-white shadow-lg shadow-rose-500/20 group-hover:scale-105 transition-transform ring-2 ring-rose-500/20">
                        <Utensils className="w-5 h-5 text-white" />
                      </div>
                      <span className="font-extrabold text-[10px] text-slate-800 tracking-tight text-center">Tumpang Food</span>
                    </button>

                    {/* 2. Tumpang Pay Menu */}
                    <button
                      id="btn-main-menu-pay"
                      onClick={() => {
                        window.open('https://buylink.id/tumpangGo', '_blank');
                        setHomeSubView('pay');
                        setPayActiveScreen('main');
                      }}
                      className="flex flex-col items-center gap-1.5 cursor-pointer group active:scale-95 transition-all"
                    >
                      <div className="w-13 h-13 rounded-2xl bg-[#6D28D9] flex items-center justify-center text-white shadow-lg shadow-purple-500/20 group-hover:scale-105 transition-transform ring-2 ring-purple-500/20">
                        <Wallet className="w-5 h-5 text-white" />
                      </div>
                      <span className="font-extrabold text-[10px] text-slate-800 tracking-tight text-center">Tumpang Pay</span>
                    </button>

                    {/* 3. Tumpang Niaga Menu */}
                    <button
                      id="btn-main-menu-niaga"
                      onClick={() => setHomeSubView('niaga')}
                      className="flex flex-col items-center gap-1.5 cursor-pointer group active:scale-95 transition-all"
                    >
                      <div className="relative">
                        <div className="w-13 h-13 rounded-2xl bg-[#0F82FF] flex items-center justify-center text-white shadow-lg shadow-blue-500/20 group-hover:scale-105 transition-transform ring-2 ring-blue-500/20">
                          <ShoppingBag className="w-5 h-5 text-white" />
                        </div>
                        <span className="absolute -top-1 -right-2 bg-blue-600 text-white text-[7px] font-black px-1.5 py-0.5 rounded-full shadow-xs uppercase tracking-tight">
                          Segera
                        </span>
                      </div>
                      <span className="font-extrabold text-[10px] text-slate-800 tracking-tight text-center">Tumpang Niaga</span>
                    </button>

                    {/* 4. Edukasi UMKM Menu - Disembunyikan sementara sesuai instruksi (dapat diaktifkan kembali tanpa membangun ulang) */}
                    {false as boolean && (
                      <button
                        id="btn-main-menu-edukasi"
                        onClick={() => setActiveTab('edukasi')}
                        className="flex flex-col items-center gap-1.5 cursor-pointer group active:scale-95 transition-all"
                      >
                        <div className="w-13 h-13 rounded-2xl bg-[#185338] flex items-center justify-center text-white shadow-lg shadow-emerald-700/20 group-hover:scale-105 transition-transform ring-2 ring-emerald-600/30">
                          <BookOpen className="w-5 h-5 text-amber-300" />
                        </div>
                        <span className="font-extrabold text-[10px] text-slate-800 tracking-tight text-center">Edukasi UMKM</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Rekomendasi Kuliner Populer Tumpang */}
                <div className="bg-white rounded-3xl border border-slate-100/90 p-4 sm:p-5 shadow-xs relative my-2">
                  
                  {/* Section Header */}
                  <div className="flex items-center justify-between mb-3.5">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-emerald-100/80 flex items-center justify-center shrink-0 shadow-2xs">
                        <Sparkles className="w-5 h-5 text-emerald-700" />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <h2 className="font-display font-extrabold text-sm sm:text-base text-slate-900 leading-tight">
                            Rekomendasi Kuliner
                          </h2>
                          <span className="bg-emerald-100 text-emerald-800 text-[9px] font-black px-2 py-0.5 rounded-full flex items-center gap-0.5 shadow-2xs uppercase tracking-tight border border-emerald-200">
                            Pilihan
                          </span>
                        </div>
                        <p className="text-[11px] sm:text-xs text-slate-500 font-medium mt-0.5">
                          Pilihan resto dan kuliner favorit warga Tumpang
                        </p>
                      </div>
                    </div>
                    <button 
                      onClick={() => setHomeSubView('food')} 
                      className="text-xs sm:text-sm font-extrabold text-[#185338] hover:underline flex items-center gap-0.5 shrink-0 cursor-pointer"
                    >
                      Lihat Semua <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Merchant Cards Grid */}
                  {merchants.length === 0 ? (
                    <div className="text-center py-7 px-4 bg-slate-50/80 rounded-2xl border border-slate-100 flex flex-col items-center justify-center gap-2">
                      <Store className="w-8 h-8 text-slate-300" />
                      <p className="text-xs font-bold text-slate-700">Belum ada mitra kuliner terdaftar</p>
                      <p className="text-[11px] text-slate-500 max-w-xs leading-relaxed">
                        Saat ini belum ada toko makanan yang terdaftar. Pemilik usaha kuliner di Kecamatan Tumpang dapat mendaftar langsung untuk mulai berjualan.
                      </p>
                      <button
                        type="button"
                        onClick={() => onSelectRole?.('MERCHANT', undefined, 'login')}
                        className="mt-1 px-4 py-2 bg-[#185338] hover:bg-[#154a32] text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer"
                      >
                        Daftar Sebagai Mitra UMKM
                      </button>
                    </div>
                  ) : (
                    <>
                      <div className="grid grid-cols-2 gap-3 sm:gap-4">
                        {merchants.slice(0, 4).map((merchant, idx) => (
                          <div 
                            key={`featured-${merchant.id}`}
                            onClick={() => {
                              loadMerchantDetail(merchant);
                              setActiveTab('merchant-detail');
                            }}
                            className="bg-white border border-slate-100 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-all cursor-pointer group flex flex-col relative"
                          >
                            {/* Image Container */}
                            <div className="relative h-32 sm:h-40 bg-slate-100 overflow-hidden">
                              <img 
                                src={merchant.bannerImage || merchant.image} 
                                alt={merchant.name} 
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                                onError={(e) => {
                                  e.currentTarget.src = 'https://images.unsplash.com/photo-1541832676-9b763b0239ab?w=600&auto=format&fit=crop&q=80';
                                }}
                              />
                              {/* Top-Left Pilihan badge */}
                              <div className="absolute top-2.5 left-2.5 bg-emerald-800/90 text-white text-[9px] sm:text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 shadow-md">
                                <span>Favorit</span>
                              </div>
                              {/* Top-Right Favorite button */}
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                }}
                                className="absolute top-2.5 right-2.5 w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-slate-900/30 backdrop-blur-md flex items-center justify-center text-white hover:bg-slate-900/50 hover:scale-110 transition-all cursor-pointer"
                              >
                                <Heart className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
                              </button>
                            </div>

                            {/* Card Details */}
                            <div className="p-3 sm:p-3.5 flex-1 flex flex-col justify-between bg-white">
                              <div>
                                <h5 className="font-extrabold text-xs sm:text-sm text-slate-900 line-clamp-1 group-hover:text-emerald-800 transition-colors">
                                  {merchant.name}
                                </h5>
                                
                                {/* Status, Distance, Rating */}
                                <div className="flex items-center gap-1.5 mt-1.5 text-[10px] sm:text-xs">
                                  <span className={`font-extrabold px-1.5 py-0.5 rounded-md border shrink-0 text-[9px] sm:text-[10px] ${
                                    merchant.active !== false 
                                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200/50' 
                                      : 'bg-slate-50 text-slate-500 border-slate-200'
                                  }`}>
                                    {merchant.active !== false ? 'Buka' : 'Tutup'}
                                  </span>
                                  <div className="ml-auto flex items-center gap-0.5 sm:gap-1 text-slate-800 font-extrabold">
                                    <Star className="w-3 h-3 sm:w-3.5 sm:h-3.5 fill-amber-400 text-amber-400 shrink-0" />
                                    <span>{merchant.rating ? merchant.rating.toFixed(1) : 'Baru'}</span>
                                  </div>
                                </div>
                              </div>

                              {/* Time estimate */}
                              {merchant.cookTimeEstimate && (
                                <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center gap-1.5 text-[10px] sm:text-xs text-slate-500 font-medium">
                                  <Clock className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-slate-400 shrink-0" />
                                  <span>{merchant.cookTimeEstimate}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Pagination Dots */}
                      <div className="flex justify-center items-center gap-1.5 mt-3.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#185338]"></span>
                        <span className="w-2 h-2 rounded-full bg-slate-200"></span>
                        <span className="w-2 h-2 rounded-full bg-slate-200"></span>
                      </div>
                    </>
                  )}

                </div>

                {/* Promo Cards Showcase */}
                <div className="flex flex-col gap-3">
                  <h4 className="font-display font-extrabold text-xs text-slate-400 uppercase tracking-wider">Promo Khusus Hari Ini</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-gradient-to-br from-purple-500/10 to-indigo-500/5 border border-purple-500/10 p-4 rounded-2xl flex flex-col gap-2">
                      <span className="text-[9px] bg-purple-500/20 text-purple-700 font-extrabold px-2 py-0.5 rounded self-start uppercase">TUMPANG PAY</span>
                      <h5 className="font-bold text-xs text-slate-800 leading-snug">Transaksi Praktis & Cepat!</h5>
                      <p className="text-[10px] text-slate-500 leading-relaxed">Beli saldo & voucher digital secara langsung di Tumpang Pay.</p>
                    </div>
                    <div className="bg-gradient-to-br from-emerald-500/10 to-teal-500/5 border border-emerald-500/10 p-4 rounded-2xl flex flex-col gap-2">
                      <span className="text-[9px] bg-emerald-500/20 text-emerald-700 font-extrabold px-2 py-0.5 rounded self-start uppercase">TUMPANG FOOD</span>
                      <h5 className="font-bold text-xs text-slate-800 leading-snug">Bebas Ongkir UMKM Terdekat</h5>
                      <p className="text-[10px] text-slate-500 leading-relaxed">Nikmati makanan khas dimasak UMKM Tumpang gratis biaya antar.</p>
                    </div>
                  </div>
                </div>

                {/* Rekomendasi UMKM Kuliner Terpopuler */}
                {merchants.length > 0 && (
                  <div className="flex flex-col gap-3">
                    <div className="flex justify-between items-center">
                      <h4 className="font-display font-extrabold text-xs text-slate-400 uppercase tracking-wider">Rekomendasi Kuliner Terlaris</h4>
                      <button 
                        onClick={() => setHomeSubView('food')} 
                        className="text-[10px] text-emerald-700 font-bold hover:underline flex items-center gap-0.5"
                      >
                        Lihat Semua <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>

                    <div className="grid grid-cols-3 gap-2 sm:gap-3">
                      {merchants.slice(0, 3).map(m => (
                        <div 
                          key={m.id}
                          onClick={() => {
                            loadMerchantDetail(m);
                            setActiveTab('merchant-detail');
                          }}
                          className="bg-white border border-slate-100 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-all cursor-pointer group flex flex-col"
                        >
                          <div className="relative h-20 sm:h-24 bg-slate-100 overflow-hidden">
                            <img src={m.image} alt={m.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" referrerPolicy="no-referrer" />
                            <div className="absolute top-1.5 right-1.5 sm:top-2 sm:right-2 bg-slate-900/70 backdrop-blur-sm text-amber-400 text-[9px] sm:text-[10px] px-1.5 py-0.5 rounded-md flex items-center gap-0.5 font-bold">
                              <Star className="w-2.5 h-2.5 sm:w-3 sm:h-3 fill-amber-400 stroke-amber-400" />
                              <span>{m.rating ? m.rating.toFixed(1) : 'Baru'}</span>
                            </div>
                          </div>
                          <div className="p-2 sm:p-3 flex-1 flex flex-col justify-between">
                            <div>
                              <h5 className="font-bold text-[11px] sm:text-xs text-slate-800 line-clamp-1 group-hover:text-rose-600 transition-colors">{m.name}</h5>
                              <p className="text-[9px] sm:text-[10px] text-slate-400 line-clamp-1 mt-0.5">{m.description}</p>
                            </div>
                            <span className="text-[9px] text-slate-500 font-bold mt-1.5 sm:mt-2 flex items-center gap-1">
                              <Clock className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-slate-300" /> {m.openTime} - {m.closeTime}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Section Edukasi & Strategi UMKM Naik Kelas */}
                <section aria-labelledby="section-edukasi-title" className="bg-white rounded-3xl border border-slate-100 p-4 sm:p-5 shadow-xs flex flex-col gap-3.5 my-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
                        <BookOpen className="w-4 h-4 text-emerald-800" />
                      </div>
                      <div>
                        <h2 id="section-edukasi-title" className="font-display font-extrabold text-sm sm:text-base text-slate-900 leading-tight">
                          Edukasi &amp; Tips UMKM Naik Kelas
                        </h2>
                        <p className="text-[11px] sm:text-xs text-slate-500 font-medium">
                          Strategi bisnis digital untuk pengusaha milenial &amp; lokal
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => setActiveTab('edukasi')}
                      className="text-xs font-extrabold text-emerald-800 hover:underline flex items-center gap-0.5 shrink-0 cursor-pointer"
                    >
                      Semua <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 gap-2.5">
                    {UMKM_ARTICLES.slice(0, 3).map((article) => (
                      <div
                        key={`home-article-${article.id}`}
                        onClick={() => setActiveTab('edukasi')}
                        className="bg-slate-50 hover:bg-emerald-50/50 border border-slate-100/80 rounded-2xl p-3 sm:p-3.5 transition-all cursor-pointer flex flex-col gap-1 group"
                      >
                        <div className="flex items-center justify-between text-[10px]">
                          <span className="font-black uppercase px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800">
                            {article.category}
                          </span>
                          <span className="text-slate-400 font-medium flex items-center gap-1">
                            <Clock className="w-3 h-3" /> {article.readTime}
                          </span>
                        </div>
                        <h3 className="font-extrabold text-xs sm:text-sm text-slate-900 group-hover:text-emerald-800 transition-colors line-clamp-1 pt-0.5">
                          {article.title}
                        </h3>
                        <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                          {article.summary}
                        </p>
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={() => setActiveTab('edukasi')}
                    className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs py-2.5 px-4 rounded-xl transition-all text-center flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <BookOpen className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Baca Semua Panduan &amp; Tips Usaha ({UMKM_ARTICLES.length} Artikel)</span>
                  </button>
                </section>

                {/* Section Tanya Jawab / FAQ Seputar TumpangGo */}
                <section aria-labelledby="section-faq-title" className="bg-white rounded-3xl border border-slate-100 p-4 sm:p-5 shadow-xs flex flex-col gap-3.5 my-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
                      <HelpCircle className="w-4 h-4 text-amber-800" />
                    </div>
                    <div>
                      <h2 id="section-faq-title" className="font-display font-extrabold text-sm sm:text-base text-slate-900 leading-tight">
                        Tanya Jawab Seputar TumpangGo
                      </h2>
                      <p className="text-[11px] sm:text-xs text-slate-500 font-medium">
                        Informasi penting mengenai layanan, pemesanan, dan kemitraan
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    {[
                      {
                        q: 'Apa itu platform TumpangGo?',
                        a: 'TumpangGo adalah ekosistem digital lokal yang menghubungkan warga Kecamatan Tumpang, Kabupaten Malang dengan aneka kuliner UMKM lokal, kurir pengantaran cepat, serta layanan pembayaran QRIS praktis.'
                      },
                      {
                        q: 'Berapa tarif ongkir pengantaran kuliner di TumpangGo?',
                        a: 'Tarif pengantaran makanan di TumpangGo sangat bersahabat yaitu flat Rp 5.000 se-Kecamatan Tumpang, didukung oleh pengemudi kurir lokal yang mengenal jalan dan lingkungan sekitar.'
                      },
                      {
                        q: 'Bagaimana cara pelaku UMKM mendaftar menjadi mitra?',
                        a: 'Pelaku usaha kuliner dan warung lokal di Kecamatan Tumpang dapat mendaftar langsung secara online melalui tombol "Mulai Kembangkan Usaha" atau menu "Menjadi Mitra UMKM" di halaman ini tanpa dipungut biaya pendaftaran.'
                      },
                      {
                        q: 'Apa saja metode pembayaran yang didukung?',
                        a: 'TumpangGo menyediakan pilihan pembayaran QRIS resmi toko merchant yang menerima semua bank dan dompet digital (BCA, BRI, Mandiri, BNI, GoPay, OVO, Dana, ShopeePay), serta verifikasi cepat oleh admin.'
                      }
                    ].map((faq, idx) => {
                      const isOpen = openFaqIndex === idx;
                      return (
                        <div
                          key={`faq-${idx}`}
                          className="border border-slate-100 rounded-2xl overflow-hidden transition-all"
                        >
                          <button
                            type="button"
                            onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                            className="w-full text-left p-3.5 bg-slate-50 hover:bg-slate-100/80 transition-colors flex items-center justify-between gap-2 cursor-pointer"
                          >
                            <h3 className="font-extrabold text-xs text-slate-800 leading-snug">
                              {faq.q}
                            </h3>
                            {isOpen ? (
                              <ChevronUp className="w-4 h-4 text-emerald-700 shrink-0" />
                            ) : (
                              <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                            )}
                          </button>
                          {isOpen && (
                            <div className="p-3.5 bg-white text-[11px] sm:text-xs text-slate-600 leading-relaxed border-t border-slate-100">
                              {faq.a}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </section>

                {/* 1. Section Menjadi Mitra UMKM */}
                <div 
                  onClick={() => onSelectRole('MERCHANT', undefined, 'login')}
                  className="bg-[#185338] text-white rounded-[24px] sm:rounded-3xl p-5 sm:p-6 shadow-md relative overflow-hidden cursor-pointer hover:bg-[#154a32] transition-colors group my-2"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3.5 sm:gap-4">
                      <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-[#236b49] border border-emerald-600/30 flex items-center justify-center shrink-0 shadow-inner group-hover:scale-105 transition-transform">
                        <Store className="w-7 h-7 sm:w-8 sm:h-8 text-amber-300 fill-amber-300/10" />
                      </div>
                      <div>
                        <h3 className="font-display font-extrabold text-base sm:text-lg text-white leading-tight">
                          Menjadi Mitra UMKM
                        </h3>
                        <p className="text-xs sm:text-sm text-emerald-100/90 font-medium mt-0.5">
                          Jualan online lebih mudah.
                        </p>
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6 text-white/90 shrink-0 group-hover:translate-x-1 transition-transform" />
                  </div>

                  <button
                    id="btn-register-umkm"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectRole('MERCHANT', undefined, 'login');
                    }}
                    className="w-full bg-[#fbc043] hover:bg-[#f3b325] text-slate-950 font-extrabold text-xs sm:text-sm py-3 sm:py-3.5 px-4 rounded-xl sm:rounded-2xl transition-all shadow-sm flex items-center justify-center cursor-pointer active:scale-98 mt-4 sm:mt-5"
                  >
                    Klik di sini
                  </button>
                </div>

                {/* 2. Section Cerita Pengguna TumpangGo */}
                <UserTestimonialsSection />

                {/* 3. Footer Section */}
                {renderFooter()}

              </div>
            )}

            {/* If we are on the existing Food view */}
            {homeSubView === 'food' && (
              <div className="flex flex-col gap-5">
                {/* Back button to return to the landing home menu */}
                <button
                  onClick={() => {
                    setHomeSubView('main');
                    setActiveTab('home');
                  }}
                  className="flex items-center gap-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 py-2.5 px-4 rounded-xl self-start transition-all cursor-pointer active:scale-95 border border-slate-200/50 mb-1"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Kembali ke Layanan Utama</span>
                </button>

                {/* Active Food Order Banner (if user has an ongoing food order) */}
                {activeOrder && activeOrder.status !== OrderStatus.CANCELLED && activeOrder.status !== OrderStatus.COMPLETED && (
                  <div className="bg-gradient-to-br from-rose-600 via-rose-700 to-red-800 text-white p-4 rounded-2xl shadow-md border border-rose-500/50 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center text-white shrink-0">
                        <Clock className="w-5 h-5 animate-spin" />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] uppercase font-extrabold text-rose-200 tracking-wider">Pesanan Makanan Aktif</span>
                          <span className="bg-white/20 text-white text-[8px] font-bold px-1.5 py-0.5 rounded-full">{activeOrder.merchantName}</span>
                        </div>
                        <h5 className="text-xs font-bold mt-0.5 leading-snug">
                          {activeOrder.status === OrderStatus.WAITING_PAYMENT ? 'Menunggu Pembayaran (Transfer / QRIS)' :
                           activeOrder.status === OrderStatus.WAITING_PAYMENT_VERIFICATION ? 'Menunggu Verifikasi Pembayaran' :
                           activeOrder.status === OrderStatus.COOKING ? 'Toko Sedang Memasak Pesanan' :
                           activeOrder.status === OrderStatus.READY_FOR_PICKUP ? 'Pesanan Siap Diambil Kurir' :
                           activeOrder.status === OrderStatus.ORDER_PICKED_UP ? 'Kurir Sedang Mengantar Pesanan' : 'Pesanan Sedang Diproses'}
                        </h5>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        setTrackingOrderId(activeOrder.id);
                        setActiveTab('tracking');
                      }}
                      className="bg-white text-rose-700 hover:bg-rose-50 font-extrabold text-xs px-3.5 py-2 rounded-xl shrink-0 shadow-md transition-all cursor-pointer active:scale-95 flex items-center gap-1"
                    >
                      <span>Lacak</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

            {/* Promo Banner Carousel */}
            <BannerCarousel 
              mode="food" 
              altPrefix="Banner Promo Tumpang Food" 
              onAction={(action) => {
                if (action === 'register_merchant') {
                  setActiveTab('partner-register');
                }
              }}
            />

            {/* Search bar */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari Bakso, Sate, Warung..."
                className="w-full bg-white border border-slate-200 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-rose-500 transition-colors shadow-sm"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Culinary Categories Selector */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-display font-bold text-xs text-slate-700 uppercase tracking-wider">Kategori Kuliner Tumpang</h4>
                {selectedMerchantCategory !== 'all' && (
                  <button 
                    onClick={() => setSelectedMerchantCategory('all')}
                    className="text-[10px] text-rose-600 font-bold hover:underline"
                  >
                    Reset Filter
                  </button>
                )}
              </div>
              <div className="flex gap-2 overflow-x-auto pb-1.5 -mx-4 px-4 scrollbar-thin scrollbar-thumb-slate-200">
                {CULINARY_CATEGORIES.map(cat => {
                  const isActive = selectedMerchantCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedMerchantCategory(cat.id)}
                      className={`flex items-center gap-1.5 px-4 py-2.5 rounded-full text-xs font-bold whitespace-nowrap transition-all duration-200 cursor-pointer ${
                        isActive
                          ? 'bg-rose-600 text-white shadow-md shadow-rose-600/25 scale-[1.02] border border-rose-600'
                          : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200 shadow-sm'
                      }`}
                    >
                      <span className="text-sm">{cat.emoji}</span>
                      <span>{cat.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Merchant List */}
            <div>
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-display font-bold text-base text-slate-800">Daftar Toko Kuliner UMKM</h3>
                <span className="text-[11px] font-semibold text-slate-500">{filteredMerchants.length} Toko</span>
              </div>

              {merchantsLoading ? (
                <div className="text-center py-10 bg-white rounded-2xl border border-slate-200 shadow-sm animate-pulse">
                  <RefreshCw className="w-8 h-8 text-rose-500 animate-spin mx-auto mb-2" />
                  <p className="text-slate-600 text-sm font-semibold">Memuat daftar toko kuliner...</p>
                </div>
              ) : merchantsError ? (
                <div className="text-center py-8 px-4 bg-rose-50 rounded-2xl border border-rose-200 shadow-sm">
                  <AlertCircle className="w-8 h-8 text-rose-500 mx-auto mb-2" />
                  <p className="text-slate-800 text-sm font-bold">Gagal memuat toko kuliner</p>
                  <p className="text-rose-700 text-xs mt-1 max-w-sm mx-auto">{merchantsError}</p>
                  <button 
                    onClick={() => fetchMerchants()} 
                    className="mt-3 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-sm transition-colors cursor-pointer"
                  >
                    Coba Lagi
                  </button>
                </div>
              ) : filteredMerchants.length === 0 ? (
                <div className="text-center py-10 bg-white rounded-2xl border border-slate-200 shadow-sm">
                  <Store className="w-10 h-10 text-slate-300 mx-auto" />
                  <p className="text-slate-400 text-sm mt-2">Tidak menemukan toko kuliner yang cocok.</p>
                </div>
              ) : (
                <div className="flex flex-col gap-3.5">
                  {filteredMerchants.map((merchant) => (
                    <div 
                      key={merchant.id}
                      onClick={() => loadMerchantDetail(merchant)}
                      className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition-shadow cursor-pointer group flex flex-col"
                    >
                      {/* Image */}
                      <div className="relative w-full h-36 bg-slate-100 overflow-hidden">
                        <img 
                          src={merchant.bannerImage || merchant.image} 
                          alt={merchant.name} 
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          onError={(e) => {
                            e.currentTarget.src = 'https://images.unsplash.com/photo-1541832676-9b763b0239ab?w=600&auto=format&fit=crop&q=80';
                          }}
                        />
                        {/* Open/Close Badge */}
                        <div className="absolute top-3 right-3">
                          <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full shadow-md uppercase tracking-wider ${
                            merchant.active 
                              ? 'bg-emerald-500 text-white' 
                              : 'bg-slate-600 text-white'
                          }`}>
                            {merchant.active ? 'Buka' : 'Tutup'}
                          </span>
                        </div>
                        {/* Rating */}
                        <div className="absolute bottom-3 left-3 bg-slate-900/80 backdrop-blur-sm text-amber-400 text-xs px-2 py-1 rounded-lg flex items-center gap-1 font-bold">
                          <Star className="w-3.5 h-3.5 fill-amber-400 stroke-amber-400" />
                          <span>{merchant.rating ? merchant.rating.toFixed(1) : 'Baru'}</span>
                        </div>
                      </div>

                      {/* Info */}
                      <div className="p-4">
                        <div className="flex justify-between items-start gap-2">
                          <h4 className="font-display font-bold text-base text-slate-800 group-hover:text-rose-600 transition-colors leading-snug flex items-center gap-1.5 flex-wrap">
                            <span>{merchant.name}</span>
                          </h4>
                          <span className="bg-rose-50 text-rose-600 font-extrabold text-[9px] px-2 py-0.5 rounded uppercase tracking-wider whitespace-nowrap border border-rose-100 flex items-center gap-0.5">
                            {CULINARY_CATEGORIES.find(c => c.name === getMerchantCategory(merchant))?.emoji || '🍛'}{' '}
                            {getMerchantCategory(merchant)}
                          </span>
                        </div>
                        <p className="text-slate-500 text-xs line-clamp-1.5 mt-1 leading-relaxed">
                          {merchant.description}
                        </p>
                        
                        <div className="flex items-center gap-3 mt-3 pt-3 border-t border-slate-100 text-[11px] text-slate-500 font-medium">
                          <span className="flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5 text-slate-400" />
                            {merchant.openTime} - {merchant.closeTime}
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5 text-slate-400 line-clamp-1" />
                            {merchant.address.split(',')[0]}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer Section */}
            {renderFooter('-food')}
          </div>
        )}

        {/* If we are on the Tumpang Taksi view */}
        {homeSubView === 'taxi' && (
          <div className="flex flex-col gap-5 pb-24">
            {/* Back button to return to the landing home menu */}
            <button
              onClick={() => setHomeSubView('main')}
              className="flex items-center gap-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 py-2.5 px-4 rounded-xl self-start transition-all cursor-pointer active:scale-95 border border-slate-200/50 mb-1"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Kembali ke Layanan Utama</span>
            </button>

            {/* Hero Banner Tumpang Taksi Carousel */}
            <BannerCarousel altPrefix="Banner Tumpang Taxi" />
            <div className="relative bg-gradient-to-br from-amber-500 via-yellow-500 to-orange-600 text-white p-6 rounded-3xl shadow-lg shadow-amber-500/20 overflow-hidden">
              <div className="absolute top-0 right-0 w-36 h-36 bg-white/10 rounded-full -mr-8 -mt-8 blur-md"></div>
              <div className="absolute left-[-20px] bottom-[-20px] w-32 h-32 bg-amber-500/25 rounded-full blur-2xl"></div>
              <div className="relative z-10 max-w-[80%]">
                <span className="bg-white/20 text-[9px] uppercase font-black tracking-wider px-3 py-1 rounded-full border border-white/10">Tumpang Taxi</span>
                <h3 className="font-display font-black text-xl leading-tight mt-3">Segera Hadir / Coming Soon!</h3>
                <p className="text-xs text-amber-50 mt-1.5 leading-relaxed">Taksi Mobil Lokal Kecamatan Tumpang. Solusi perjalanan keluarga, wisata, atau barang berat dengan armada mobil yang bersih, nyaman, dan sopir lokal ramah.</p>
              </div>
              <div className="absolute right-[-10px] bottom-[-10px] opacity-25">
                <Car className="w-32 h-32 rotate-12" />
              </div>
            </div>

            {/* Main Coming Soon Card */}
            <div className="bg-white border border-amber-100 rounded-3xl p-6 shadow-sm flex flex-col gap-5">
              <div className="text-center pb-2 border-b border-slate-100">
                <div className="w-16 h-16 rounded-full bg-amber-50 border-2 border-amber-500 flex items-center justify-center text-3xl mx-auto mb-3 shadow-md shadow-amber-500/10">
                  🚗
                </div>
                <h4 className="font-display font-black text-base text-slate-800 uppercase tracking-tight">Tumpang Taxi</h4>
                <p className="text-[10px] text-amber-600 font-bold uppercase mt-0.5 tracking-wider">Layanan Taksi Mobil Nyaman Kecamatan Tumpang</p>
              </div>

              {/* Highlights */}
              <div className="flex flex-col gap-3">
                <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Kenapa Memilih Tumpang Taxi?</h5>
                
                <div className="flex items-start gap-3 p-2.5 rounded-2xl hover:bg-amber-50/25 transition-all">
                  <span className="text-lg bg-amber-50 p-2 rounded-xl text-amber-600">✨</span>
                  <div>
                    <h6 className="text-xs font-black text-slate-800">Armada Luas & Bersih</h6>
                    <p className="text-[10px] text-slate-500 leading-relaxed mt-0.5">Pilihan mobil AC berkapasitas besar hingga 6 penumpang, menjamin kenyamanan maksimal selama perjalanan.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-2.5 rounded-2xl hover:bg-amber-50/25 transition-all">
                  <span className="text-lg bg-amber-50 p-2 rounded-xl text-amber-600">🤝</span>
                  <div>
                    <h6 className="text-xs font-black text-slate-800">Tarif Jujur Tanpa Surcharge</h6>
                    <p className="text-[10px] text-slate-500 leading-relaxed mt-0.5">Tarif transparan per kilometer tanpa biaya tambahan tersembunyi. Lebih hemat dibanding taksi konvensional.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-2.5 rounded-2xl hover:bg-amber-50/25 transition-all">
                  <span className="text-lg bg-amber-50 p-2 rounded-xl text-amber-600">💼</span>
                  <div>
                    <h6 className="text-xs font-black text-slate-800">Siap Sewa & Antar Luar Kota</h6>
                    <p className="text-[10px] text-slate-500 leading-relaxed mt-0.5">Melayani perjalanan wisata, antar-jemput bandara, stasiun, hingga sewa harian lengkap dengan sopirnya.</p>
                  </div>
                </div>
              </div>

              {/* Waitlist Form */}
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100 flex flex-col gap-3">
                {!notifyTaxiSubmitted ? (
                  <>
                    <div className="text-left">
                      <span className="text-[10px] font-black text-amber-600 bg-amber-100/50 px-2 py-0.5 rounded-md uppercase tracking-wider">MINTA NOTIFIKASI</span>
                      <h5 className="text-xs font-black text-slate-800 mt-1">Dapatkan Notifikasi Saat Rilis!</h5>
                      <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">Masukkan nomor WhatsApp Anda untuk didaftarkan sebagai penerima voucher diskon Tumpang Taxi pertama kali rilis.</p>
                    </div>

                    <div className="flex flex-col gap-2 mt-1">
                      <input 
                        type="tel"
                        value={notifyTaxiPhone}
                        onChange={(e) => setNotifyTaxiPhone(e.target.value)}
                        placeholder="Masukkan Nomor WhatsApp Anda..."
                        className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-3.5 text-xs font-semibold focus:outline-none focus:border-amber-500 transition-colors"
                      />
                      <button
                        onClick={() => {
                          if (!notifyTaxiPhone.trim()) {
                            alert('Mohon masukkan Nomor WhatsApp Anda yang aktif!');
                            return;
                          }
                          setNotifyTaxiSubmitted(true);
                        }}
                        className="w-full bg-[#D97706] hover:bg-amber-700 text-white font-black py-2.5 rounded-xl text-xs uppercase tracking-wider transition-colors shadow-md shadow-amber-500/10 cursor-pointer"
                      >
                        Hubungi Saya Saat Rilis
                      </button>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-2 flex flex-col items-center gap-2 animate-in zoom-in-95 duration-200">
                    <span className="text-2xl">🎉</span>
                    <h5 className="text-xs font-black text-amber-700">Terima Kasih, Anda Sudah Terdaftar!</h5>
                    <p className="text-[10px] text-slate-500 max-w-xs leading-relaxed">Nomor WhatsApp Anda ({notifyTaxiPhone}) berhasil disimpan. Voucher promo eksklusif Tumpang Taxi akan dikirimkan otomatis ke WhatsApp Anda saat peluncuran!</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Tumpang Niaga - Coming Soon Teaser View */}
        {homeSubView === 'niaga' && (
          <TumpangNiagaComingSoon onBackToMain={() => setHomeSubView('main')} />
        )}

        {/* If we are on the Tumpang Bike view */}
        {homeSubView === 'bike' && (
          <div className="flex flex-col gap-5 pb-24">
            {/* Back button to return to the landing home menu */}
            <button
              onClick={() => setHomeSubView('main')}
              className="flex items-center gap-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 py-2.5 px-4 rounded-xl self-start transition-all cursor-pointer active:scale-95 border border-slate-200/50 mb-1"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Kembali ke Layanan Utama</span>
            </button>

            {/* Hero Banner Tumpang Bike Carousel */}
            <BannerCarousel altPrefix="Banner Tumpang Bike" />
            <div className="relative bg-gradient-to-br from-emerald-600 via-green-500 to-teal-700 text-white p-6 rounded-3xl shadow-lg shadow-emerald-500/20 overflow-hidden">
              <div className="absolute top-0 right-0 w-36 h-36 bg-white/10 rounded-full -mr-8 -mt-8 blur-md"></div>
              <div className="absolute left-[-20px] bottom-[-20px] w-32 h-32 bg-emerald-500/25 rounded-full blur-2xl"></div>
              <div className="relative z-10 max-w-[80%]">
                <span className="bg-white/20 text-[9px] uppercase font-black tracking-wider px-3 py-1 rounded-full border border-white/10">Tumpang Bike</span>
                <h3 className="font-display font-black text-xl leading-tight mt-3">Segera Hadir / Coming Soon!</h3>
                <p className="text-xs text-emerald-50 mt-1.5 leading-relaxed">Ojek Motor Otonom & Handal se-Kecamatan Tumpang. Segera hadir untuk memberikan kemudahan mobilitas Anda dengan tarif hemat & penjemputan cepat!</p>
              </div>
              <div className="absolute right-[-10px] bottom-[-10px] opacity-25">
                <Bike className="w-32 h-32 rotate-12" />
              </div>
            </div>

            {/* Main Coming Soon Card */}
            <div className="bg-white border border-emerald-100 rounded-3xl p-6 shadow-sm flex flex-col gap-5">
              <div className="text-center pb-2 border-b border-slate-100">
                <div className="w-16 h-16 rounded-full bg-emerald-50 border-2 border-emerald-500 flex items-center justify-center text-3xl mx-auto mb-3 shadow-md shadow-emerald-500/10">
                  🏍️
                </div>
                <h4 className="font-display font-black text-base text-slate-800 uppercase tracking-tight">Tumpang Bike</h4>
                <p className="text-[10px] text-emerald-600 font-bold uppercase mt-0.5 tracking-wider">Layanan Ojek Motor Masa Depan Tumpang</p>
              </div>

              {/* Highlights */}
              <div className="flex flex-col gap-3">
                <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Kenapa Memilih Tumpang Bike?</h5>
                
                <div className="flex items-start gap-3 p-2.5 rounded-2xl hover:bg-emerald-50/20 transition-all">
                  <span className="text-lg bg-emerald-50 p-2 rounded-xl text-emerald-600">⚡</span>
                  <div>
                    <h6 className="text-xs font-black text-slate-800">Penjemputan Kilat</h6>
                    <p className="text-[10px] text-slate-500 leading-relaxed mt-0.5">Kurang dari 5 menit, driver lokal terdekat berdomisili Tumpang siap meluncur menjemput Anda.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-2.5 rounded-2xl hover:bg-emerald-50/20 transition-all">
                  <span className="text-lg bg-emerald-50 p-2 rounded-xl text-emerald-600">🪙</span>
                  <div>
                    <h6 className="text-xs font-black text-slate-800">Tarif Super Hemat</h6>
                    <p className="text-[10px] text-slate-500 leading-relaxed mt-0.5">Mulai dari Rp 5.000 saja per perjalanan dalam area Kecamatan Tumpang. Tarif jujur tanpa ada markup.</p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-2.5 rounded-2xl hover:bg-emerald-50/20 transition-all">
                  <span className="text-lg bg-emerald-50 p-2 rounded-xl text-emerald-600">🛡️</span>
                  <div>
                    <h6 className="text-xs font-black text-slate-800">Aman & Terpercaya</h6>
                    <p className="text-[10px] text-slate-500 leading-relaxed mt-0.5">Seluruh mitra ojek lokal adalah warga lokal Tumpang asli yang ramah, santun, dan terverifikasi identitasnya.</p>
                  </div>
                </div>
              </div>

              {/* Waitlist / Notify Me Form */}
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100 flex flex-col gap-3">
                {!notifyBikeSubmitted ? (
                  <>
                    <div className="text-left">
                      <span className="text-[10px] font-black text-emerald-600 bg-emerald-100/50 px-2 py-0.5 rounded-md uppercase tracking-wider">MINTA NOTIFIKASI</span>
                      <h5 className="text-xs font-black text-slate-800 mt-1">Dapatkan Notifikasi Saat Rilis!</h5>
                      <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">Masukkan nomor WhatsApp Anda untuk menjadi yang pertama menerima voucher promo gratis ongkir saat resmi meluncur.</p>
                    </div>

                    <div className="flex flex-col gap-2 mt-1">
                      <input 
                        type="tel"
                        value={notifyBikePhone}
                        onChange={(e) => setNotifyBikePhone(e.target.value)}
                        placeholder="Masukkan Nomor WhatsApp Anda..."
                        className="w-full bg-white border border-slate-200 rounded-xl py-2.5 px-3.5 text-xs font-semibold focus:outline-none focus:border-emerald-500 transition-colors"
                      />
                      <button
                        onClick={() => {
                          if (!notifyBikePhone.trim()) {
                            alert('Mohon masukkan Nomor WhatsApp Anda yang aktif!');
                            return;
                          }
                          setNotifyBikeSubmitted(true);
                        }}
                        className="w-full bg-[#10B981] hover:bg-emerald-600 text-white font-black py-2.5 rounded-xl text-xs uppercase tracking-wider transition-colors shadow-md shadow-emerald-500/10 cursor-pointer"
                      >
                        Hubungi Saya Saat Rilis
                      </button>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-2 flex flex-col items-center gap-2 animate-in zoom-in-95 duration-200">
                    <span className="text-2xl">🎉</span>
                    <h5 className="text-xs font-black text-emerald-700">Terima Kasih, Anda Sudah Terdaftar!</h5>
                    <p className="text-[10px] text-slate-500 max-w-xs leading-relaxed">Nomor WhatsApp Anda ({notifyBikePhone}) berhasil dimasukkan ke dalam daftar tunggu prioritas Tumpang Bike. Kami akan mengirimkan pesan instan begitu layanan diluncurkan!</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* If we are on the Tumpang Pay view */}
        {homeSubView === 'pay' && (
          <div className="flex flex-col gap-6 pb-24 animate-in fade-in duration-300">
            {/* Back button directly */}
            <div className="flex items-center justify-between gap-2">
              <button
                onClick={() => setHomeSubView('main')}
                className="flex items-center gap-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 py-2.5 px-4 rounded-xl transition-all cursor-pointer active:scale-95 border border-slate-200/50"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Kembali ke Layanan Utama</span>
              </button>
              
              <span className="text-[10px] bg-purple-100 text-purple-800 font-black px-2.5 py-1 rounded-lg border border-purple-200 uppercase tracking-wider">
                Web Portal 🌐
              </span>
            </div>

            {/* Hero Banner Tumpang Pay Carousel */}
            <BannerCarousel altPrefix="Banner Tumpang Pay" />

            {/* Simulated Web Address / Bio-Link Bar */}
            <div 
              onClick={() => window.open('https://buylink.id/tumpangGo', '_blank')}
              className="bg-slate-100 border border-slate-200/80 rounded-2xl p-3 flex items-center gap-2.5 shadow-sm cursor-pointer hover:bg-slate-200/60 transition-all duration-150 active:scale-[0.99] group"
              title="Buka https://buylink.id/tumpangGo"
            >
              <div className="flex gap-1.5 shrink-0">
                <span className="w-2 h-2 rounded-full bg-red-400 group-hover:scale-110 transition-transform"></span>
                <span className="w-2 h-2 rounded-full bg-yellow-400 group-hover:scale-110 transition-transform"></span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 group-hover:scale-110 transition-transform"></span>
              </div>
              <div className="flex-1 bg-white border border-slate-150 rounded-lg px-3 py-2 flex items-center justify-between text-[11px] font-mono text-slate-500 font-bold select-all shadow-inner group-hover:border-purple-300 group-hover:bg-purple-50/20 transition-all duration-150">
                <div className="flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-purple-600 animate-pulse shrink-0" />
                  <span className="font-semibold tracking-tight text-slate-700 truncate group-hover:text-purple-700 transition-colors">
                    https://<span className="text-purple-600 font-black group-hover:underline">buylink.id/tumpangGo</span>
                  </span>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <span className="text-[8px] bg-emerald-100 text-emerald-800 font-black px-1.5 py-0.5 rounded uppercase tracking-wider">Aman</span>
                  <Lock className="w-3 h-3 text-emerald-600" strokeWidth={3} />
                  <ExternalLink className="w-3.5 h-3.5 text-purple-400 group-hover:text-purple-600 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                </div>
              </div>
            </div>

            {/* Direct Link Information Panel */}
            <div className="bg-white border border-slate-150 rounded-3xl p-6 shadow-sm flex flex-col items-center text-center gap-5 my-2">
              <div className="w-16 h-16 rounded-2xl bg-purple-50 flex items-center justify-center text-purple-600 shadow-inner">
                <Globe className="w-8 h-8 text-purple-600 animate-pulse" />
              </div>
              <div>
                <h4 className="font-sans font-black text-slate-800 text-base uppercase tracking-tight">Menuju Web Portal Tumpang Go</h4>
                <p className="text-xs text-slate-500 mt-1.5 max-w-sm leading-relaxed font-medium">
                  Anda akan dialihkan ke portal transaksi resmi Tumpang Go di BuyLink untuk melakukan pembelian & top-up instan.
                </p>
              </div>
              
              {/* Direct Link Action Button */}
              <button
                onClick={() => window.open('https://buylink.id/tumpangGo', '_blank')}
                className="w-full bg-gradient-to-r from-purple-600 to-indigo-700 hover:from-purple-700 hover:to-indigo-800 text-white font-black py-4 px-6 rounded-2xl text-xs uppercase tracking-wider shadow-lg shadow-purple-500/10 transition-all cursor-pointer active:scale-95 flex items-center justify-center gap-2"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Buka Portal Tumpang Go</span>
              </button>
            </div>
          </div>
        )}



            {/* DRIVER REGISTRATION MODAL */}
            {isDriverModalOpen && (
              <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden border border-slate-150 animate-in zoom-in-95 duration-200">
                  {/* Top Header Graphic banner */}
                  <div className="bg-gradient-to-r from-emerald-600 to-teal-700 p-5 text-white relative">
                    <button 
                      onClick={() => setIsDriverModalOpen(false)}
                      className="absolute top-4 right-4 p-1 rounded-lg bg-black/10 hover:bg-black/20 text-white transition-colors cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                    <span className="text-[9px] uppercase font-black bg-white/20 px-2.5 py-1 rounded-full tracking-wider">PROGRAM KEMITRAAN</span>
                    <h3 className="font-sans font-black text-base mt-2">Daftar Mitra Driver Tumpang Go</h3>
                    <p className="text-[10px] text-white/80 mt-1">Gabung ojek/taksi lokal & raih penghasilan tambahan tanpa potongan aplikasi!</p>
                  </div>

                  {!driverRegSubmitted ? (
                    <div className="p-5 flex flex-col gap-4">
                      <div>
                        <label className="block text-[10px] font-extrabold text-slate-400 uppercase tracking-wider mb-1.5">Nama Lengkap Anda</label>
                        <input 
                          type="text" 
                          value={driverName}
                          onChange={(e) => setDriverName(e.target.value)}
                          placeholder="Contoh: Muhammad Slamet"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-xs font-bold focus:outline-none focus:border-emerald-600 transition-colors"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-extrabold text-slate-400 uppercase tracking-wider mb-1.5">Nomor WhatsApp Aktif</label>
                        <input 
                          type="tel" 
                          value={driverPhone}
                          onChange={(e) => setDriverPhone(e.target.value)}
                          placeholder="Contoh: 081234567890"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-xs font-bold focus:outline-none focus:border-emerald-600 transition-colors"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] font-extrabold text-slate-400 uppercase tracking-wider mb-1.5">Jenis Kendaraan</label>
                          <select 
                            value={driverVehicle}
                            onChange={(e) => setDriverVehicle(e.target.value as 'motorcycle' | 'car')}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-3 text-xs font-bold focus:outline-none focus:border-emerald-600 transition-colors cursor-pointer"
                          >
                            <option value="motorcycle">🏍️ Sepeda Motor (Ojek)</option>
                            <option value="car">🚗 Mobil (Taksi)</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-[10px] font-extrabold text-slate-400 uppercase tracking-wider mb-1.5">Nomor Plat Kendaraan</label>
                          <input 
                            type="text" 
                            value={driverPlate}
                            onChange={(e) => setDriverPlate(e.target.value)}
                            placeholder="Contoh: N 5432 AA"
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 px-4 text-xs font-bold focus:outline-none focus:border-emerald-600 transition-colors uppercase"
                          />
                        </div>
                      </div>

                      {/* File Upload Box (Interactive drag/drop) */}
                      <div>
                        <label className="block text-[10px] font-extrabold text-slate-400 uppercase tracking-wider mb-1.5">Upload Dokumen (Foto KTP & SIM)</label>
                        <div 
                          onClick={() => setIsDriverLicUploaded(true)}
                          className={`border-2 border-dashed rounded-2xl p-4 text-center cursor-pointer transition-all flex flex-col items-center justify-center min-h-[90px] ${
                            isDriverLicUploaded 
                              ? 'border-emerald-500 bg-emerald-50/50 text-emerald-800' 
                              : 'border-slate-250 bg-slate-50 hover:bg-slate-100/60 text-slate-500'
                          }`}
                        >
                          {isDriverLicUploaded ? (
                            <>
                              <span className="text-xl mb-1">✅</span>
                              <p className="text-[10px] font-black">ktp_sim_dokumen.pdf Berhasil Diunggah!</p>
                              <span className="text-[9px] text-emerald-600/70 font-semibold mt-0.5">Klik untuk mengunggah ulang</span>
                            </>
                          ) : (
                            <>
                              <span className="text-xl mb-1">📂</span>
                              <p className="text-[10px] font-black text-slate-600">Seret file ke sini atau klik untuk Upload</p>
                              <span className="text-[9px] text-slate-400 font-semibold mt-0.5">Format pendukung: JPG, PNG, PDF (Maks. 5MB)</span>
                            </>
                          )}
                        </div>
                      </div>

                      <button 
                        onClick={() => {
                          if (!driverName || !driverPhone || !driverPlate) {
                            alert('Mohon isi semua data formulir pendaftaran!');
                            return;
                          }
                          if (!isDriverLicUploaded) {
                            alert('Mohon upload foto KTP & SIM terlebih dahulu!');
                            return;
                          }
                          setDriverRegSubmitted(true);
                        }}
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-3.5 rounded-xl text-xs uppercase tracking-wider transition-colors cursor-pointer text-center mt-1"
                      >
                        Kirim Formulir Pendaftaran
                      </button>
                    </div>
                  ) : (
                    /* Registrasi Sukses Ticket Screen */
                    <div className="p-6 flex flex-col items-center text-center py-8">
                      <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-xl shadow-inner mb-4">
                        🎉
                      </div>

                      <span className="bg-emerald-100 text-emerald-800 text-[8px] font-black uppercase px-3 py-1 rounded-full tracking-widest">
                        PENDAFTARAN DITERIMA
                      </span>

                      <h4 className="font-sans font-black text-sm text-slate-800 mt-3">Registrasi Anda Berhasil Terkirim!</h4>
                      
                      <div className="bg-slate-50 border border-dashed border-slate-200 rounded-2xl p-4 w-full text-left my-4 flex flex-col gap-2.5">
                        <div className="flex justify-between items-center text-[10px] font-bold text-slate-400">
                          <span>KODE PENDAFTARAN:</span>
                          <span className="text-emerald-700 font-black">TG-DRV-{Math.floor(1000 + Math.random() * 9000)}</span>
                        </div>
                        <div className="flex justify-between items-center text-xs font-bold text-slate-700 border-t border-slate-100 pt-2">
                          <span>Nama Calon Driver:</span>
                          <span className="text-slate-900">{driverName}</span>
                        </div>
                        <div className="flex justify-between items-center text-xs font-bold text-slate-700">
                          <span>Nomor WhatsApp:</span>
                          <span className="text-slate-900">{driverPhone}</span>
                        </div>
                        <div className="flex justify-between items-center text-xs font-bold text-slate-700">
                          <span>Jenis Kendaraan:</span>
                          <span className="text-slate-900">{driverVehicle === 'motorcycle' ? '🏍️ Sepeda Motor' : '🚗 Mobil'}</span>
                        </div>
                        <div className="flex justify-between items-center text-xs font-bold text-slate-700">
                          <span>Status Dokumen:</span>
                          <span className="text-emerald-600 font-extrabold">TERUNGGAH</span>
                        </div>
                      </div>

                      <p className="text-[10px] text-slate-500 font-medium leading-relaxed px-2">
                        Halo <strong className="text-slate-700">{driverName}</strong>, data Anda berhasil masuk ke database otonom Tumpang Go. Admin kami akan menghubungi Anda via WhatsApp di nomor <strong className="text-slate-700">{driverPhone}</strong> dalam waktu maksimal 1x24 jam untuk koordinasi verifikasi fisik kendaraan. Matur nuwun! 🙏
                      </p>

                      <button 
                        onClick={() => {
                          setIsDriverModalOpen(false);
                          setDriverRegSubmitted(false);
                          setIsDriverLicUploaded(false);
                          setDriverName('');
                          setDriverPhone('');
                          setDriverPlate('');
                        }}
                        className="w-full bg-slate-800 hover:bg-slate-900 text-white font-extrabold py-3 rounded-xl text-xs transition-colors cursor-pointer text-center mt-5"
                      >
                        Tutup & Kembali ke Portal
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* APK DOWNLOAD / INSTALLER MODAL */}
            {isApkModalOpen && (
              <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden border border-slate-150 animate-in zoom-in-95 duration-200">
                  {/* Android Style Header */}
                  <div className="bg-[#A4C639] text-white p-5 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Smartphone className="w-8 h-8 text-white animate-pulse" />
                      <div>
                        <h4 className="font-sans font-black text-sm uppercase tracking-wider">Tumpang Go APK Installer</h4>
                        <p className="text-[10px] text-white/90">Aplikasi Resmi Paguyuban Otonom</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => {
                        setIsApkModalOpen(false);
                        setApkDownloadProgress(0);
                        setIsApkDownloaded(false);
                      }}
                      className="p-1.5 rounded-full bg-black/10 hover:bg-black/25 text-white transition-colors cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="p-6 flex flex-col items-center text-center">
                    {!isApkDownloaded ? (
                      /* Downloading Screen */
                      <div className="w-full py-4">
                        <div className="w-16 h-16 rounded-2xl bg-amber-50 text-amber-500 flex items-center justify-center text-2xl shadow-sm mb-4 mx-auto animate-bounce">
                          📥
                        </div>
                        <h5 className="font-sans font-black text-xs text-slate-700 uppercase tracking-wider">Mengunduh File APK...</h5>
                        <p className="text-[10px] text-slate-400 font-semibold mt-1">TumpangGo_v2.4_Official.apk (18.4 MB)</p>
                        
                        {/* Progress Bar */}
                        <div className="w-full bg-slate-100 rounded-full h-3.5 overflow-hidden mt-5 mb-2 border border-slate-200/50">
                          <div 
                            className="bg-gradient-to-r from-[#A4C639] to-emerald-500 h-full transition-all duration-300"
                            style={{ width: `${apkDownloadProgress}%` }}
                          ></div>
                        </div>
                        <div className="flex justify-between items-center text-[10px] text-slate-400 font-bold px-1">
                          <span>Progress: {apkDownloadProgress}%</span>
                          <span>{apkDownloadProgress === 100 ? 'Selesai' : 'Sedang mengunduh...'}</span>
                        </div>
                      </div>
                    ) : (
                      /* Install Screen */
                      <div className="w-full py-3">
                        <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-500 flex items-center justify-center text-2xl shadow-sm mb-4 mx-auto">
                          🤖
                        </div>
                        <h5 className="font-sans font-black text-sm text-slate-800 uppercase tracking-tight">Unduhan Selesai!</h5>
                        <p className="text-[10px] text-slate-500 font-medium leading-relaxed max-w-xs mt-1.5">
                          File APK resmi Tumpang Go berhasil diunduh ke penyimpanan internal HP Anda. Silakan pasang aplikasi untuk menikmati akses langsung yang lebih cepat.
                        </p>

                        <div className="bg-slate-50 rounded-2xl p-4 my-4 border border-slate-100 flex flex-col gap-2.5 text-left text-xs font-bold text-slate-600">
                          <div className="flex justify-between items-center text-[9px] text-slate-400 font-black uppercase">
                            <span>Informasi File:</span>
                            <span className="text-emerald-700 font-black">AMANKAN BY PLAY PROTECT</span>
                          </div>
                          <div className="flex justify-between items-center pt-1">
                            <span>Nama File:</span>
                            <span className="text-slate-900 font-bold">TumpangGo_v2.4.apk</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span>Ukuran:</span>
                            <span className="text-slate-900 font-bold">18.4 MB</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span>Versi OS:</span>
                            <span className="text-slate-900 font-bold">Android 5.0 atau terbaru</span>
                          </div>
                        </div>

                        <div className="flex gap-2.5 mt-5">
                          <button 
                            onClick={() => {
                              setIsApkModalOpen(false);
                              setApkDownloadProgress(0);
                              setIsApkDownloaded(false);
                            }}
                            className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold py-3 rounded-xl text-xs transition-colors cursor-pointer"
                          >
                            Batal
                          </button>
                          <button 
                            onClick={() => {
                              alert('Aplikasi Tumpang Go berhasil diinstal di smartphone Anda! Silakan cek menu utama HP Anda.');
                              setIsApkModalOpen(false);
                              setApkDownloadProgress(0);
                              setIsApkDownloaded(false);
                            }}
                            className="flex-1 bg-[#A4C639] hover:bg-[#92b232] text-white font-black py-3 rounded-xl text-xs uppercase tracking-wider transition-colors cursor-pointer"
                          >
                            Instal Sekarang
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* HEADQUARTERS MAP MODAL */}
            {isMapModalOpen && (
              <div className="fixed inset-0 z-[100] bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
                <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden border border-slate-150 animate-in zoom-in-95 duration-200">
                  {/* Header */}
                  <div className="bg-slate-900 text-white p-4.5 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <MapPin className="w-5 h-5 text-red-500 fill-red-500" />
                      <div>
                        <h4 className="font-sans font-black text-xs uppercase tracking-wider">Kantor Pusat Tumpang Go</h4>
                        <p className="text-[9px] text-slate-400">Malang, Jawa Timur, Indonesia</p>
                      </div>
                    </div>
                    <button 
                      onClick={() => setIsMapModalOpen(false)}
                      className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Satellite Map Canvas Wrapper */}
                  <div className="p-4 flex flex-col gap-4">
                    <div className="w-full h-52 bg-[#E5E3DF] rounded-2xl relative overflow-hidden shadow-inner border border-slate-200 flex items-center justify-center">
                      
                      {/* Grid Roads simulation using customized SVG styling */}
                      <svg className="absolute inset-0 w-full h-full opacity-60" viewBox="0 0 100 100" preserveAspectRatio="none">
                        {/* Major highway: Jl. Raya Tumpang */}
                        <line x1="10" y1="50" x2="90" y2="50" stroke="#FFF" strokeWidth="4" />
                        <line x1="10" y1="50" x2="90" y2="50" stroke="#E29578" strokeWidth="2" />
                        
                        {/* Crossroads */}
                        <line x1="50" y1="10" x2="50" y2="90" stroke="#FFF" strokeWidth="3" />
                        <line x1="50" y1="10" x2="50" y2="90" stroke="#F4A261" strokeWidth="1.5" />
                        
                        <line x1="25" y1="10" x2="25" y2="90" stroke="#FFF" strokeWidth="2" />
                        <line x1="75" y1="10" x2="75" y2="90" stroke="#FFF" strokeWidth="2" />
                        
                        {/* Alun-alun Central Green Square */}
                        <rect x="42" y="42" width="16" height="16" fill="#A8D5BA" stroke="#2D6A4F" strokeWidth="1" rx="2" />
                        
                        {/* Pasar Tumpang Orange Square */}
                        <rect x="65" y="42" width="12" height="12" fill="#FFE3A8" stroke="#D4A373" strokeWidth="1" rx="1" />
                      </svg>

                      {/* Map Labels */}
                      <span className="absolute text-[8px] font-black text-slate-500 bg-white/80 px-1.5 py-0.5 rounded shadow-sm border border-slate-200/50 top-14 left-12 rotate-[-12deg]">
                        Jl. Raya Tumpang
                      </span>
                      <span className="absolute text-[8px] font-black text-[#2D6A4F] bg-[#E8F5E9]/90 px-1.5 py-0.5 rounded shadow-sm border border-emerald-200/50 top-11 left-46">
                        Alun-alun Tumpang
                      </span>
                      <span className="absolute text-[8px] font-black text-amber-800 bg-[#FFF8E1]/90 px-1.5 py-0.5 rounded shadow-sm border border-amber-200/50 top-11 right-6">
                        Pasar Tumpang
                      </span>

                      {/* Candi Jago Label */}
                      <span className="absolute text-[8px] font-black text-stone-600 bg-stone-100/90 px-1.5 py-0.5 rounded shadow-sm border border-stone-200/50 bottom-8 left-1/3">
                        🗿 Candi Jago
                      </span>

                      {/* Interactive Radar Location Indicator */}
                      <div className="absolute top-[46%] left-[48%] -translate-x-1/2 -translate-y-1/2 flex flex-col items-center z-20">
                        {/* Red pulsating indicator ring */}
                        <div className="absolute w-12 h-12 bg-red-500/25 border-2 border-red-500 rounded-full animate-ping"></div>
                        <div className="w-3.5 h-3.5 bg-red-600 border border-white rounded-full shadow-md relative z-10 flex items-center justify-center">
                          <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></span>
                        </div>
                        {/* Location Name Tooltip */}
                        <div className="mt-1 bg-slate-900 text-white text-[9px] font-black uppercase py-1 px-2.5 rounded-xl shadow-lg border border-slate-700 whitespace-nowrap animate-bounce flex items-center gap-1">
                          🏢 KANTOR PUSAT TUMPANG GO
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col gap-3">
                      <div>
                        <h5 className="font-sans font-black text-xs text-slate-800">Alamat Lengkap:</h5>
                        <p className="text-[10px] text-slate-500 font-medium leading-relaxed mt-1">
                          Jl. Raya Tumpang No. 45, RT 02/RW 03, Krajan, Kec. Tumpang, Kabupaten Malang, Jawa Timur 65156 (Tepat di timur laut Alun-alun Tumpang, depan Kantor Koramil).
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-3.5 border-t border-slate-100 pt-3 mt-1">
                        <div>
                          <span className="text-[9px] text-slate-400 font-black uppercase tracking-wider block">Jam Operasional:</span>
                          <span className="text-[10px] font-bold text-slate-700">08:00 - 21:00 WIB (Setiap Hari)</span>
                        </div>
                        <div>
                          <span className="text-[9px] text-slate-400 font-black uppercase tracking-wider block">Nomor Telepon Kantor:</span>
                          <span className="text-[10px] font-bold text-slate-700">0341 - 789123</span>
                        </div>
                      </div>

                      <button 
                        onClick={() => {
                          const routeUri = 'https://www.google.com/maps/dir/?api=1&destination=-7.9455,112.7595';
                          alert('Membuka Google Maps untuk rute navigasi ke Kantor Tumpang Go...');
                          window.open(routeUri, '_blank', 'noreferrer,noopener');
                        }}
                        className="w-full bg-slate-800 hover:bg-slate-900 text-white font-black py-3 rounded-xl text-xs uppercase tracking-wider transition-colors cursor-pointer text-center flex items-center justify-center gap-1.5 mt-2 shadow-sm"
                      >
                        <MapPin className="w-4 h-4 text-red-400" />
                        Buka Rute di Google Maps
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
          
        {/* 2. MERCHANT DETAIL TAB */}
        {activeTab === 'merchant-detail' && selectedMerchant && (
          <div className="flex flex-col gap-4 pb-36">
            {/* Back to list */}
            <button 
              onClick={() => setActiveTab('home')}
              className="flex items-center gap-1.5 text-slate-600 hover:text-slate-900 text-sm font-semibold self-start"
            >
              <ArrowLeft className="w-4 h-4" />
              Kembali
            </button>

            {/* Merchant Store Details Card */}
            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
              <div className="w-full h-32 bg-slate-100 relative">
                <img 
                  src={selectedMerchant.bannerImage || selectedMerchant.image} 
                  alt={selectedMerchant.name} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>
                <div className="absolute top-3 right-3">
                  <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full shadow-md uppercase tracking-wider ${
                    selectedMerchant.active ? 'bg-emerald-500 text-white' : 'bg-slate-600 text-white'
                  }`}>
                    {selectedMerchant.active ? 'Buka' : 'Tutup'}
                  </span>
                </div>
              </div>
              <div className="px-4 pb-4 pt-2 relative">
                {/* Logo overlapping banner */}
                <div className="absolute -top-10 left-4 w-16 h-16 rounded-full border-4 border-white bg-white shadow-md overflow-hidden">
                  <img 
                    src={selectedMerchant.image} 
                    alt="Logo" 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                
                <div className="pl-20 pt-1 min-h-[30px]">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-display font-bold text-lg text-slate-800 leading-snug">{selectedMerchant.name}</h3>
                    <span className="bg-rose-50 text-rose-600 font-extrabold text-[9px] px-2 py-0.5 rounded uppercase tracking-wider border border-rose-100 flex items-center gap-0.5">
                      {CULINARY_CATEGORIES.find(c => c.name === getMerchantCategory(selectedMerchant))?.emoji || '🍛'}{' '}
                      {getMerchantCategory(selectedMerchant)}
                    </span>
                  </div>
                  <p className="text-slate-500 text-xs mt-1 leading-relaxed">{selectedMerchant.description}</p>
                </div>
                
                <div className="flex flex-wrap items-center gap-y-2 gap-x-4 mt-3 pt-3 border-t border-slate-100 text-xs text-slate-500">
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4 text-slate-400" />
                    Buka {selectedMerchant.openTime} - {selectedMerchant.closeTime}
                  </span>
                  <span className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                    {selectedMerchant.rating ? `${selectedMerchant.rating.toFixed(1)} Bintang` : 'Mitra Baru'}
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-4 h-4 text-slate-400" />
                    {selectedMerchant.address}
                  </span>
                </div>
              </div>
            </div>

            {/* Menu Sections */}
            <div>
              <div className="flex justify-between items-center mb-3">
                <h4 className="font-display font-bold text-base text-slate-800">Daftar Menu Makanan</h4>
              </div>

              {/* Category selector */}
              <div className="flex gap-2 overflow-x-auto pb-2 -mx-1 px-1">
                <button
                  onClick={() => setSelectedCategory('all')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-full whitespace-nowrap transition-all ${
                    selectedCategory === 'all' 
                      ? 'bg-rose-500 text-white shadow-md shadow-rose-500/10' 
                      : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                  }`}
                >
                  Semua Menu
                </button>
                {categories.map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-full whitespace-nowrap transition-all ${
                      selectedCategory === cat.id 
                        ? 'bg-rose-500 text-white shadow-md shadow-rose-500/10' 
                        : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                    }`}
                  >
                    {cat.name}
                  </button>
                ))}
              </div>

              {/* Menu List */}
              <div className="flex flex-col gap-3 mt-3">
                {(Array.isArray(selectedMerchantMenu) ? selectedMerchantMenu : [])
                  .filter(item => item && (selectedCategory === 'all' || item.categoryId === selectedCategory))
                  .map(item => (
                    <div 
                      key={item.id}
                      className="bg-white border border-slate-200 hover:border-rose-200 rounded-xl p-3.5 shadow-sm flex gap-3 items-center transition-all"
                    >
                      {item.image && (
                        <img 
                          src={item.image} 
                          alt={item.name} 
                          onClick={() => setSelectedMenuItemDetail({ item, merchant: selectedMerchant })}
                          className="w-16 h-16 rounded-lg object-cover bg-slate-100 flex-shrink-0 cursor-pointer hover:opacity-90 transition-opacity"
                          referrerPolicy="no-referrer"
                        />
                      )}
                      <div 
                        className="flex-1 min-w-0 cursor-pointer"
                        onClick={() => setSelectedMenuItemDetail({ item, merchant: selectedMerchant })}
                      >
                        <div className="flex items-center gap-1">
                          <h5 className="font-semibold text-slate-800 truncate text-sm hover:text-rose-600 transition-colors">{item.name}</h5>
                          <Info className="w-3.5 h-3.5 text-slate-400 hover:text-rose-500 flex-shrink-0" />
                        </div>
                        <p className="text-slate-500 text-xs line-clamp-1 mt-0.5">{item.description}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <span className="font-display font-bold text-rose-600 text-xs inline-block">
                            Rp {item.price.toLocaleString('id-ID')}
                          </span>
                          <span className="text-[10px] text-rose-500 font-medium hover:underline flex items-center gap-0.5">
                            Lihat Rincian &rarr;
                          </span>
                        </div>
                      </div>

                      {/* Quantity Selector or Add Button */}
                      {(() => {
                        const cartItem = cart.find(i => i.menuItemId === item.id);
                        if (cartItem) {
                          return (
                            <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-xl p-1 shadow-sm">
                              {/* Decrease button */}
                              <button
                                type="button"
                                onClick={() => updateCartQuantity(item.id, -1)}
                                className="w-7 h-7 rounded-lg hover:bg-rose-50 text-slate-500 hover:text-rose-600 flex items-center justify-center transition-all"
                                title="Kurangi Jumlah"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              
                              <span className="w-6 text-center text-xs font-bold font-mono text-slate-800">
                                {cartItem.quantity}
                              </span>

                              {/* Increase button */}
                              <button
                                type="button"
                                onClick={() => updateCartQuantity(item.id, 1)}
                                className="w-7 h-7 rounded-lg hover:bg-slate-50 text-slate-500 hover:text-slate-700 flex items-center justify-center transition-all"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          );
                        }

                        return (
                          <button
                            onClick={() => addToCart(item, selectedMerchant)}
                            disabled={!item.available || !selectedMerchant.active}
                            className={`p-2 rounded-xl border transition-all ${
                              !item.available || !selectedMerchant.active
                                ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
                                : 'bg-rose-50 hover:bg-rose-100 border-rose-200 text-rose-600 shadow-sm'
                            }`}
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        );
                      })()}
                    </div>
                  ))}
              </div>
            </div>
          </div>
        )}

        {/* 3. CART SUMMARY - Interactive Draggable & Dockable Floating Cart */}
        {cart.length > 0 && homeSubView === 'food' && activeTab !== 'checkout' && activeTab !== 'payment' && (
          <FloatingCart
            cart={cart}
            cartMerchant={cartMerchant}
            subtotal={getSubtotal()}
            onCheckout={() => setActiveTab('checkout')}
          />
        )}

        {/* 4. CHECKOUT TAB */}
        {activeTab === 'checkout' && cartMerchant && (
          <form onSubmit={handleCheckout} className="flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <button 
                type="button"
                onClick={() => setActiveTab('merchant-detail')}
                className="p-1 hover:bg-slate-200 rounded-lg"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <h3 className="font-display font-bold text-lg text-slate-800">Konfirmasi Pemesanan</h3>
            </div>

            {/* Merchant Recap */}
            <div className="bg-white border border-slate-200 rounded-xl p-3.5 shadow-sm">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Toko Tujuan</span>
              <p className="font-semibold text-slate-800 text-sm mt-0.5">{cartMerchant.name}</p>
            </div>

            {/* Daftar Pesanan Anda */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col gap-3">
              <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                <h4 className="font-display font-semibold text-xs text-slate-700 flex items-center gap-1.5 uppercase tracking-wider">
                  <ShoppingBag className="w-3.5 h-3.5 text-rose-500" />
                  Daftar Pesanan Anda
                </h4>
                <span className="text-[10px] bg-slate-100 text-slate-600 font-bold px-2 py-0.5 rounded-full">
                  {cart.length} Menu
                </span>
              </div>

              <div className="flex flex-col gap-2.5">
                {cart.map((item) => (
                  <div 
                    key={item.menuItemId} 
                    className="flex gap-3 items-center p-3 rounded-xl border border-slate-100 bg-slate-50/30 transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <h5 className="font-semibold text-slate-800 text-xs truncate">{item.name}</h5>
                      <p className="text-[10px] text-slate-400 font-medium mt-0.5">
                        Rp {item.price.toLocaleString('id-ID')} / porsi
                      </p>
                    </div>

                    {/* Quantity Selector */}
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-0.5 shadow-sm">
                        <button
                          type="button"
                          onClick={() => updateCartQuantity(item.menuItemId, -1)}
                          className="w-5 h-5 rounded-md hover:bg-slate-50 text-slate-500 font-bold text-xs flex items-center justify-center transition-colors"
                          title="Kurangi Jumlah"
                        >
                          -
                        </button>
                        <span className="w-6 text-center text-xs font-bold font-mono text-slate-800">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => updateCartQuantity(item.menuItemId, 1)}
                          className="w-5 h-5 rounded-md hover:bg-slate-50 text-slate-500 font-bold text-xs flex items-center justify-center transition-colors"
                          title="Tambah Jumlah"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Customer Inputs */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col gap-3.5">
              <h4 className="font-display font-semibold text-sm text-slate-700 border-b border-slate-100 pb-2">Detail Penerima</h4>
              
              <div>
                <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">Nama Lengkap</label>
                <input
                  type="text"
                  required
                  value={checkoutName}
                  onChange={(e) => setCheckoutName(e.target.value)}
                  placeholder="Masukkan nama Anda"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none focus:border-rose-500 mt-1"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">No WhatsApp (Aktif)</label>
                <input
                  type="tel"
                  required
                  value={checkoutPhone}
                  onChange={(e) => setCheckoutPhone(e.target.value)}
                  placeholder="Contoh: 0812XXXXXXXX"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none focus:border-rose-500 mt-1"
                />
              </div>
            </div>

            {/* Pin Location on Map */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex flex-col gap-3">
              <h4 className="font-display font-semibold text-sm text-slate-700 border-b border-slate-100 pb-2">Tandai Peta Pengantaran</h4>
              <div className="w-full h-[250px] overflow-hidden rounded-xl">
                <MapPicker 
                  initialLat={checkoutLat}
                  initialLng={checkoutLng}
                  onLocationSelected={(lat, lng, address) => {
                    setCheckoutLat(lat);
                    setCheckoutLng(lng);
                    if (address && !checkoutAddress) {
                      setCheckoutAddress(address);
                    }
                  }}
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">Detail Alamat Lengkap</label>
                <textarea
                  required
                  rows={2}
                  value={checkoutAddress}
                  onChange={(e) => setCheckoutAddress(e.target.value)}
                  placeholder="Nama jalan, nomor rumah, RT/RW, Dusun..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none focus:border-rose-500 mt-1"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">Patokan Lokasi (Opsional)</label>
                <input
                  type="text"
                  value={checkoutLandmark}
                  onChange={(e) => setCheckoutLandmark(e.target.value)}
                  placeholder="Contoh: Depan masjid, sebelah konter pulsa"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs focus:outline-none focus:border-rose-500 mt-1"
                />
              </div>
            </div>

            {/* Ringkasan Biaya */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
              <h4 className="font-display font-semibold text-sm text-slate-700 border-b border-slate-100 pb-2 mb-3">Ringkasan Pembayaran</h4>
              <div className="flex flex-col gap-2.5 text-xs text-slate-600">
                <div className="flex justify-between">
                  <span>Subtotal Makanan</span>
                  <span className="font-semibold">Rp {getSubtotal().toLocaleString('id-ID')}</span>
                </div>
                <div className="flex justify-between items-start">
                  <div>
                    <span className="block font-medium">Ongkos Kirim</span>
                    {getDeliveryCalculation().isInTumpang ? (
                      <span className="text-[10px] text-emerald-600 font-bold block">Tarif Flat Kec. Tumpang</span>
                    ) : (
                      <span className="text-[10px] text-amber-600 font-bold block">Luar Kec. Tumpang</span>
                    )}
                  </div>
                  <span className="font-semibold text-slate-900">
                    Rp {getDeliveryFee().toLocaleString('id-ID')}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Biaya Layanan</span>
                  <span className="font-semibold">Rp {getServiceFee().toLocaleString('id-ID')}</span>
                </div>
                <div className="border-t border-slate-100 pt-2.5 flex justify-between text-sm font-bold text-slate-800">
                  <span>Estimasi Total</span>
                  <span className="text-rose-600 font-mono font-extrabold text-base">
                    Rp {(getSubtotal() + getDeliveryFee() + getServiceFee()).toLocaleString('id-ID')}*
                  </span>
                </div>
              </div>
              <p className="text-[10px] text-slate-400 mt-3 leading-relaxed">
                *Total akhir akan ditambahkan 3 digit Kode Unik Pembayaran (Rp 1 - Rp 99) pada halaman berikutnya untuk mempermudah verifikasi.
              </p>
            </div>

            <div className="flex flex-col gap-2.5">
              {checkoutErrorMsg && (
                <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-xs text-rose-800 animate-fade-in shadow-xs">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <span className="font-bold block">Pemberitahuan Pesanan:</span>
                    <p className="mt-0.5 leading-relaxed">{checkoutErrorMsg}</p>
                  </div>
                </div>
              )}
              <button
                type="submit"
                disabled={isSubmittingOrder}
                className={`w-full py-3.5 font-extrabold rounded-xl transition-all text-sm flex items-center justify-center gap-2 ${
                  isSubmittingOrder
                    ? 'bg-slate-200 text-slate-400 border border-slate-300 shadow-none cursor-not-allowed'
                    : 'bg-rose-600 hover:bg-rose-700 text-white shadow-lg shadow-rose-600/25 cursor-pointer'
                }`}
              >
                {isSubmittingOrder ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Memproses Pesanan...</span>
                  </>
                ) : (
                  <>
                    <QrCode className="w-4 h-4" />
                    <span>Bayar dengan QRIS</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </div>
          </form>
        )}

        {/* 5. PAYMENT / BILLING TAB - MERCHANT STATIC QRIS */}
        {activeTab === 'payment' && activeOrder && (() => {
          const currentOrderMerchant = merchants.find(m => m.id === activeOrder.merchantId) || (activeOrder.merchantId === selectedMerchant?.id ? selectedMerchant : null);
          const rawQris = activeOrder.merchantQrisImage || currentOrderMerchant?.qrisImage;

          // Safe QRIS source resolution with primary and fallback staging
          const resolveQrisSource = (): string | null => {
            let candidateUrl: string | null = null;
            if (qrisImageStage === 'primary' && rawQris && typeof rawQris === 'string' && !rawQris.includes('unsplash') && rawQris.trim().length > 3) {
              const trimmed = rawQris.trim();
              if (trimmed.startsWith('data:image/') || trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
                candidateUrl = trimmed;
              } else if (trimmed.startsWith('/')) {
                const baseUrl = getApiBaseUrl();
                candidateUrl = baseUrl ? `${baseUrl}${trimmed}` : trimmed;
              } else {
                candidateUrl = trimmed;
              }
            } else if (activeOrder.id) {
              // Fallback endpoint specific to this verified order
              const baseUrl = getApiBaseUrl();
              const endpoint = `/api/orders/${activeOrder.id}/qris-image`;
              candidateUrl = baseUrl ? `${baseUrl}${endpoint}` : endpoint;
            }

            if (!candidateUrl) return null;

            // Apply cache-buster ONLY upon explicit user retry
            if (qrisRetryTimestamp) {
              const sep = candidateUrl.includes('?') ? '&' : '?';
              return `${candidateUrl}${sep}retry=${qrisRetryTimestamp}`;
            }
            return candidateUrl;
          };

          const qrisImageUrl = resolveQrisSource();

          const handleQrisImageError = () => {
            console.warn(`[TumpangFood QRIS] Image failed at stage "${qrisImageStage}" (Order: ${activeOrder.id}, Merchant: ${activeOrder.merchantName})`);
            // If primary failed, automatically try order-specific fallback endpoint
            if (qrisImageStage === 'primary' && activeOrder.id) {
              console.log('[TumpangFood QRIS] Trying order-specific fallback endpoint...');
              setQrisImageStage('fallback');
              setQrisLoading(true);
              return;
            }
            // If fallback also failed or retries exhausted
            setQrisLoading(false);
            setQrisLoadFailed(true);
          };

          const handleQrisImageLoad = () => {
            setQrisLoading(false);
            setQrisLoadFailed(false);
          };

          const handleRetryQris = () => {
            if (qrisRetryCount >= 3) {
              alert('Batas maksimal muat ulang (3x) tercapai. Silakan periksa koneksi internet Anda atau kunjungi Pusat Bantuan TumpangGo.');
              return;
            }
            setQrisRetryCount(prev => prev + 1);
            setQrisRetryTimestamp(Date.now());
            setQrisImageStage('primary');
            setQrisLoadFailed(false);
            setQrisLoading(true);
          };
          const isPaid = activeOrder.status === OrderStatus.PAYMENT_VERIFIED || activeOrder.paymentStatus === PaymentStatus.PAID;
          const isWaitingVerification = activeOrder.status === OrderStatus.WAITING_PAYMENT_VERIFICATION || activeOrder.paymentStatus === PaymentStatus.WAITING_VERIFICATION;
          const isRejected = activeOrder.status === OrderStatus.PAYMENT_REJECTED || activeOrder.paymentStatus === PaymentStatus.REJECTED;
          const isExpired = activeOrder.status === OrderStatus.EXPIRED || activeOrder.paymentStatus === PaymentStatus.EXPIRED;
          const isCancelled = activeOrder.status === OrderStatus.CANCELLED;
          const isPending = !isPaid && !isWaitingVerification && !isRejected && !isExpired && !isCancelled;

          return (
            <div className="flex flex-col gap-4">
              {/* Header Title */}
              <div className="text-center">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold mb-1">
                  <QrCode className="w-3.5 h-3.5" />
                  <span>Pembayaran QRIS Merchant</span>
                </div>
                <div className="flex items-center justify-center gap-1.5 mt-0.5">
                  <span className="text-xs text-slate-500">Nomor Pesanan:</span>
                  <span className="font-mono font-bold text-slate-800 text-xs">#{activeOrder.orderNumber || activeOrder.id}</span>
                  <button
                    type="button"
                    onClick={() => handleCopyCustomerOrderNumber(activeOrder.orderNumber || activeOrder.id)}
                    title="Salin Nomor Order"
                    className="p-1 hover:bg-slate-200 text-slate-400 hover:text-slate-700 rounded transition-colors cursor-pointer"
                  >
                    {copiedTrackingId === (activeOrder.orderNumber || activeOrder.id) ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Status Header Badge */}
              <div className="flex items-center justify-between p-3.5 rounded-2xl border text-xs font-bold shadow-xs bg-white">
                <span className="text-slate-500 font-medium">Status Pembayaran:</span>
                {isPaid ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-emerald-100 text-emerald-800 border border-emerald-300">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    PAID (Lunas Terverifikasi)
                  </span>
                ) : isWaitingVerification ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-blue-100 text-blue-800 border border-blue-300">
                    <Clock className="w-3.5 h-3.5 text-blue-600 animate-pulse" />
                    WAITING_VERIFICATION (Menunggu Verifikasi Admin)
                  </span>
                ) : isRejected ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-rose-100 text-rose-800 border border-rose-300">
                    <XCircle className="w-3.5 h-3.5 text-rose-600" />
                    REJECTED (Bukti Ditolak Admin)
                  </span>
                ) : isExpired ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-200 text-slate-700">
                    EXPIRED (Pesanan Kedaluwarsa)
                  </span>
                ) : isCancelled ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-200 text-slate-700">
                    CANCELLED (Pesanan Dibatalkan)
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-100 text-amber-800 border border-amber-300">
                    <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping"></span>
                    PENDING (Menunggu Pembayaran)
                  </span>
                )}
              </div>

              {/* Total Bill Card */}
              <div className="bg-gradient-to-br from-rose-50 via-white to-amber-50 border border-rose-200/90 rounded-2xl p-5 shadow-xs text-center relative overflow-hidden">
                <span className="text-[10px] text-rose-700 font-extrabold uppercase tracking-widest block">TOTAL NOMINAL TAGIHAN</span>
                <h2 className="font-display font-black text-3xl sm:text-4xl text-rose-900 mt-1">
                  Rp {activeOrder.total.toLocaleString('id-ID')}
                </h2>

                <div className="mt-2.5 inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-white border border-rose-200 text-rose-800 shadow-xs">
                  <span>Termasuk Kode Unik Verifikasi:</span>
                  <span className="font-mono bg-rose-600 text-white px-1.5 py-0.2 rounded text-[11px]">+{activeOrder.uniqueCode}</span>
                </div>

                <p className="text-[11px] text-slate-500 mt-2 font-medium max-w-sm mx-auto">
                  Harap transfer <strong className="text-slate-800">tepat sesuai nominal di atas</strong>. Kode unik verifikasi memudahkan Admin mencocokkan pembayaran Anda.
                </p>

                {/* Rincian Pesanan Box */}
                <div className="mt-4 pt-3.5 border-t border-rose-100 text-left text-xs space-y-1.5 bg-white/70 p-3 rounded-xl">
                  <div className="flex justify-between items-center text-slate-600 pb-1 border-b border-rose-100/60">
                    <span className="font-medium">Toko Kuliner:</span>
                    <strong className="text-slate-900 font-semibold">{activeOrder.merchantName}</strong>
                  </div>
                  <div className="space-y-1 py-1">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Ringkasan Menu:</span>
                    {activeOrder.items?.map((item, idx) => (
                      <div key={idx} className="flex justify-between text-slate-700 text-[11px]">
                        <span>{item.quantity}x {item.name}</span>
                        <span className="font-mono font-semibold">Rp {(item.price * item.quantity).toLocaleString('id-ID')}</span>
                      </div>
                    ))}
                  </div>
                  <div className="pt-1.5 border-t border-rose-100/60 space-y-1 text-slate-600 text-[11px]">
                    <div className="flex justify-between">
                      <span>Subtotal Menu</span>
                      <span className="font-mono font-medium">Rp {activeOrder.subtotal.toLocaleString('id-ID')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Biaya Pengantaran</span>
                      <span className="font-mono font-medium">Rp {activeOrder.deliveryFee.toLocaleString('id-ID')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Biaya Layanan</span>
                      <span className="font-mono font-medium">Rp {activeOrder.serviceFee.toLocaleString('id-ID')}</span>
                    </div>
                    <div className="flex justify-between text-rose-700 font-bold">
                      <span>Kode Unik</span>
                      <span className="font-mono">+{activeOrder.uniqueCode}</span>
                    </div>
                    <div className="flex justify-between text-xs font-bold text-slate-900 pt-1 border-t border-slate-200">
                      <span>Total Pembayaran</span>
                      <span className="font-mono text-rose-700 text-sm">Rp {activeOrder.total.toLocaleString('id-ID')}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Status Specific Notification Banner */}
              {isWaitingVerification && (
                <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 text-xs text-blue-900 shadow-xs flex flex-col gap-2.5">
                  <div className="flex items-start gap-2.5">
                    <Clock className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-sm text-blue-900">Bukti Pembayaran Terkirim!</h4>
                      <p className="text-[11px] text-blue-700 mt-0.5 leading-relaxed">
                        Admin kami sedang memeriksa bukti pembayaran Anda dan mencocokkannya dengan mutasi transaksi merchant. Anda <strong>tidak perlu melakukan pembayaran ulang</strong>.
                      </p>
                    </div>
                  </div>
                  {activeOrder.paymentProof && (
                    <div className="mt-1 flex items-center gap-3 bg-white p-2.5 rounded-xl border border-blue-200">
                      <img 
                        src={activeOrder.paymentProof} 
                        alt="Bukti yang diunggah" 
                        className="w-14 h-14 object-cover rounded-lg border border-slate-200 cursor-pointer"
                        onClick={() => setProofZoomModalImage(activeOrder.paymentProof || null)}
                      />
                      <div className="flex-1 text-[11px]">
                        <span className="text-slate-500 font-medium block">Foto Bukti Terunggah:</span>
                        <button
                          type="button"
                          onClick={() => setProofZoomModalImage(activeOrder.paymentProof || null)}
                          className="text-blue-700 font-bold hover:underline inline-flex items-center gap-1 mt-0.5 cursor-pointer"
                        >
                          <ZoomIn className="w-3.5 h-3.5" /> Lihat Ukuran Penuh
                        </button>
                      </div>
                      <button
                        type="button"
                        onClick={() => refreshActiveOrder()}
                        className="p-2 bg-blue-100 hover:bg-blue-200 text-blue-800 rounded-xl font-bold transition-all"
                        title="Perbarui Status"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              )}

              {isRejected && (
                <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 text-xs text-rose-900 shadow-xs flex flex-col gap-2">
                  <div className="flex items-start gap-2.5">
                    <XCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-sm text-rose-900">Bukti Pembayaran Ditolak oleh Admin</h4>
                      <div className="mt-1 bg-white p-2.5 rounded-xl border border-rose-200 font-medium text-[11px]">
                        <span className="text-rose-500 block text-[10px] font-bold uppercase tracking-wider">Alasan Penolakan:</span>
                        <p className="text-rose-900 font-bold mt-0.5">
                          {activeOrder.paymentRejectionReason || activeOrder.cancelReason || 'Nominal tidak cocok atau bukti foto tidak terbaca jelas.'}
                        </p>
                      </div>
                      <p className="text-[11px] text-rose-700 mt-2">
                        Silakan periksa kembali transaksi Anda dan unggah ulang foto bukti transfer yang sah pada form di bawah.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {isPaid && (
                <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-xs text-emerald-900 shadow-xs flex flex-col gap-3">
                  <div className="flex items-start gap-2.5">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-sm text-emerald-900">Pembayaran Berhasil Diverifikasi (LUNAS)</h4>
                      <p className="text-[11px] text-emerald-700 mt-0.5 leading-relaxed">
                        Pembayaran telah disetujui oleh admin. Pesanan Anda kini diteruskan ke dapur toko <strong>{activeOrder.merchantName}</strong> untuk mulai dimasak.
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <button
                      type="button"
                      onClick={() => setShowReceiptModal(true)}
                      className="flex-1 py-2.5 px-3 bg-slate-900 hover:bg-slate-800 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-xs transition-all cursor-pointer"
                    >
                      <Receipt className="w-4 h-4 text-amber-400" />
                      <span>Lihat E-Receipt Resmi (PDF)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setTrackingOrderId(activeOrder.id);
                        setActiveTab('tracking');
                      }}
                      className="flex-1 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-xs transition-all cursor-pointer"
                    >
                      <span>Pantau Pengantaran</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* MERCHANT STATIC QRIS CONTAINER */}
              {qrisImageUrl && !qrisLoadFailed ? (
                <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs flex flex-col items-center">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 text-slate-700 text-[11px] font-bold mb-3">
                    <Store className="w-3.5 h-3.5 text-rose-600" />
                    <span>QRIS Resmi Toko: {activeOrder.merchantName}</span>
                  </div>

                  {/* QRIS Image Frame */}
                  <div className="w-full max-w-[320px] sm:max-w-[360px] bg-slate-50 border-2 border-slate-200 rounded-2xl p-3 sm:p-4 flex flex-col items-center justify-center relative shadow-sm group min-h-[300px]">
                    {qrisLoading && (
                      <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-slate-50/90 backdrop-blur-xs rounded-xl">
                        <RefreshCw className="w-6 h-6 text-rose-600 animate-spin mb-2" />
                        <span className="text-xs font-semibold text-slate-600">Memuat gambar QRIS...</span>
                        {qrisImageStage === 'fallback' && (
                          <span className="text-[10px] text-slate-400 mt-1">Menggunakan jalur cadangan...</span>
                        )}
                      </div>
                    )}
                    <img 
                      key={`${qrisImageUrl}_${qrisImageStage}`}
                      src={qrisImageUrl} 
                      alt={`QRIS ${activeOrder.merchantName}`}
                      className={`w-full h-auto max-h-[460px] object-contain rounded-xl cursor-pointer transition-transform group-hover:scale-[1.01] bg-white border border-slate-100 shadow-xs ${qrisLoading ? 'opacity-0' : 'opacity-100'}`}
                      onClick={() => setProofZoomModalImage(qrisImageUrl)}
                      onLoad={handleQrisImageLoad}
                      onError={handleQrisImageError}
                    />
                    <div className="flex items-center gap-2 mt-3 w-full justify-center">
                      <button
                        type="button"
                        onClick={() => setProofZoomModalImage(qrisImageUrl)}
                        className="bg-slate-800 hover:bg-slate-900 text-white text-[11px] font-bold px-3 py-1.5 rounded-xl flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                      >
                        <ZoomIn className="w-3.5 h-3.5" />
                        <span>Perbesar QRIS</span>
                      </button>
                      <a
                        href={qrisImageUrl}
                        download={`qris-${activeOrder.merchantName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.png`}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold px-3 py-1.5 rounded-xl flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Unduh QRIS</span>
                      </a>
                    </div>
                  </div>

                  <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest mt-3">
                    QRIS STATIS RESMI {activeOrder.merchantName.toUpperCase()}
                  </span>

                  {/* Step-by-Step Payment Instructions */}
                  <div className="w-full mt-4 bg-slate-50 border border-slate-200 rounded-xl p-3.5 text-xs text-slate-700 space-y-2">
                    <span className="font-bold text-slate-900 flex items-center gap-1.5 text-xs">
                      <ShieldCheck className="w-4 h-4 text-rose-600" />
                      Petunjuk Pembayaran QRIS:
                    </span>
                    <ol className="list-decimal pl-4 space-y-1.5 text-[11px] text-slate-600 leading-relaxed">
                      <li>Buka aplikasi e-Wallet atau Mobile Banking Anda (BCA, Mandiri, BRI, BNI, GoPay, OVO, Dana, ShopeePay, LinkAja, dll).</li>
                      <li>Pilih menu <strong>Scan / Bayar QRIS</strong> dan arahkan kamera ke kode QRIS toko di atas.</li>
                      <li>Masukkan nominal pembayaran tepat sebesar <strong className="text-rose-700 font-mono font-bold">Rp {activeOrder.total.toLocaleString('id-ID')}</strong>.</li>
                      <li>Selesaikan pembayaran dan simpan tangkapan layar (screenshot) bukti transfer berhasil.</li>
                      <li>Unggah foto bukti pembayaran pada formulir di bawah ini dan klik <strong>Kirim Bukti Pembayaran</strong>.</li>
                    </ol>
                  </div>
                </div>
              ) : (
                /* Anti-Fake Fallback: Merchant doesn't have QRIS uploaded yet or image failed to load */
                <div className="bg-amber-50 border border-amber-200 rounded-2xl p-5 shadow-xs flex flex-col gap-3 text-xs text-amber-900">
                  <div className="flex items-start gap-2.5">
                    <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                    <div className="space-y-1">
                      <h4 className="font-extrabold text-sm text-amber-900">
                        {qrisLoadFailed ? 'Gambar QRIS Gagal Dimuat' : 'Pembayaran QRIS Toko Belum Tersedia'}
                      </h4>
                      <p className="text-[11px] text-amber-800 leading-relaxed">
                        {qrisLoadFailed 
                          ? <>Gambar QRIS resmi untuk merchant <strong>{activeOrder.merchantName}</strong> mengalami kendala jaringan saat dimuat dari server. Demi keamanan transaksi Anda, sistem TumpangGo <strong>tidak menampilkan QRIS palsu/tiruan atau QRIS milik merchant lain</strong>.</>
                          : <>Merchant <strong>{activeOrder.merchantName}</strong> belum mengunggah gambar QRIS statis resminya. Demi keamanan transaksi dan perlindungan data Anda, sistem TumpangGo <strong>tidak menampilkan QRIS palsu/tiruan atau QRIS milik merchant lain</strong>.</>
                        }
                      </p>
                      <p className="text-[11px] text-amber-700 mt-1">
                        Silakan coba muat ulang atau buka Pusat Bantuan TumpangGo untuk panduan dan verifikasi pembayaran.
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2 pt-2 border-t border-amber-200">
                    <button
                      type="button"
                      onClick={handleRetryQris}
                      className="flex-1 py-2.5 px-3 bg-amber-700 hover:bg-amber-800 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer text-center"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Coba Muat Ulang QRIS {qrisRetryCount > 0 ? `(${qrisRetryCount}/3)` : ''}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setActiveTab('help');
                        if (typeof window !== 'undefined') {
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }
                      }}
                      className="flex-1 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors text-center cursor-pointer shadow-xs"
                    >
                      <HelpCircle className="w-3.5 h-3.5" />
                      <span>Kunjungi Pusat Bantuan</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setActiveOrder(null);
                        setActiveTab('home');
                      }}
                      className="py-2.5 px-4 bg-white hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold rounded-xl text-xs transition-colors cursor-pointer"
                    >
                      Pilih Merchant Lain
                    </button>
                  </div>
                </div>
              )}

              {/* UPLOAD PAYMENT PROOF SECTION */}
              {(isRejected || isPending) && (
                <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2.5 mb-3.5">
                    <h4 className="font-display font-bold text-sm text-slate-800 flex items-center gap-1.5">
                      <Upload className="w-4 h-4 text-rose-600" />
                      <span>Unggah Bukti Pembayaran</span>
                    </h4>
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Format: JPG, PNG, WEBP</span>
                  </div>

                  <form onSubmit={handlePaymentProofUpload} className="flex flex-col gap-3.5">
                    {proofUploadSuccess && (
                      <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-xs text-emerald-800 font-semibold animate-fade-in">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>{proofUploadSuccess}</span>
                      </div>
                    )}

                    {proofUploadError && (
                      <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-xs text-rose-800 font-semibold animate-fade-in">
                        <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                        <span>{proofUploadError}</span>
                      </div>
                    )}

                    <div>
                      <label className="text-xs font-bold text-slate-800 block mb-1">
                        Unggah Bukti Pembayaran
                      </label>
                      <p className="text-xs text-slate-500 mb-2.5 leading-relaxed">
                        Pilih foto atau screenshot bukti pembayaran dari perangkat Anda.
                      </p>

                      {/* Hidden native file input for mobile gallery & desktop file picker */}
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/jpeg,image/jpg,image/png,image/webp"
                        onChange={handleFileChange}
                        className="hidden"
                      />

                      {/* File Upload Control: Button Pilih Gambar */}
                      {!paymentProofFile ? (
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="w-full py-4 px-4 bg-slate-50 hover:bg-rose-50/50 border-2 border-dashed border-slate-300 hover:border-rose-400 rounded-2xl flex flex-col items-center justify-center gap-2 transition-all cursor-pointer group text-center"
                        >
                          <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center group-hover:scale-110 transition-transform">
                            <Upload className="w-6 h-6" />
                          </div>
                          <div className="flex flex-col items-center">
                            <span className="font-extrabold text-sm text-slate-800 group-hover:text-rose-700 transition-colors">
                              Pilih Gambar
                            </span>
                            <span className="text-[11px] text-slate-500 mt-0.5">
                              Pilih foto dari galeri HP atau folder komputer (JPG, PNG, WEBP maks. 10MB)
                            </span>
                          </div>
                        </button>
                      ) : (
                        /* Image Preview Container */
                        <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 flex flex-col gap-3">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider">
                              Pratinjau Bukti Sebelum Dikirim:
                            </span>
                            {paymentProofFileSize && (
                              <span className="text-[10px] font-mono font-bold text-slate-500 bg-white px-2 py-0.5 rounded-md border border-slate-200">
                                {paymentProofFileSize}
                              </span>
                            )}
                          </div>

                          <div className="w-full h-56 bg-white border border-slate-200 rounded-xl overflow-hidden relative shadow-xs flex items-center justify-center group">
                            <img 
                              src={paymentProofFile} 
                              alt="Pratinjau Bukti Pembayaran" 
                              className="w-full h-full object-contain cursor-pointer transition-transform group-hover:scale-[1.02]"
                              onClick={() => setProofZoomModalImage(paymentProofFile)}
                            />
                            <button
                              type="button"
                              onClick={() => setProofZoomModalImage(paymentProofFile)}
                              className="absolute bottom-2 right-2 bg-slate-900/80 hover:bg-slate-900 text-white text-[10px] font-bold px-2.5 py-1 rounded-lg flex items-center gap-1 backdrop-blur-xs transition-colors cursor-pointer"
                            >
                              <ZoomIn className="w-3 h-3" />
                              <span>Perbesar</span>
                            </button>
                          </div>

                          {paymentProofFileName && (
                            <p className="text-[11px] text-slate-600 font-mono truncate text-center">
                              {paymentProofFileName}
                            </p>
                          )}

                          <div className="flex items-center gap-2 pt-1">
                            <button
                              type="button"
                              onClick={() => fileInputRef.current?.click()}
                              className="flex-1 py-2 px-3 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                            >
                              <Upload className="w-3.5 h-3.5" />
                              <span>Ganti Gambar</span>
                            </button>
                            <button
                              type="button"
                              onClick={handleClearSelectedProof}
                              className="py-2 px-3 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Hapus</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </div>

                    <button
                      type="submit"
                      disabled={uploadLoading || !paymentProofFile}
                      className={`w-full py-3.5 font-extrabold rounded-xl transition-all shadow-md text-xs flex items-center justify-center gap-2 ${
                        uploadLoading || !paymentProofFile
                          ? 'bg-slate-200 text-slate-400 border border-slate-300 shadow-none cursor-not-allowed'
                          : 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-600/20 cursor-pointer active:scale-[0.99]'
                      }`}
                    >
                      {uploadLoading ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>Mengirim Bukti Pembayaran...</span>
                        </>
                      ) : (
                        <>
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Kirim Bukti Pembayaran</span>
                        </>
                      )}
                    </button>
                  </form>
                </div>
              )}

              {/* Bottom Actions & Support */}
              <div className="flex flex-col gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setTrackingOrderId(activeOrder.orderNumber || activeOrder.id);
                    setActiveTab('tracking');
                  }}
                  className="w-full py-3 bg-slate-900 text-white hover:bg-slate-800 font-bold rounded-xl transition-all text-xs text-center cursor-pointer shadow-xs"
                >
                  Pantau Status Pesanan (Tracking)
                </button>

                <div className="p-3 bg-slate-100 rounded-xl text-center text-[11px] text-slate-600">
                  <span>Butuh bantuan pembayaran? Buka </span>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveTab('help');
                      if (typeof window !== 'undefined') {
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }
                    }}
                    className="text-emerald-700 font-bold hover:underline cursor-pointer inline-flex items-center gap-0.5 mx-1"
                  >
                    <span>Pusat Bantuan TumpangGo</span>
                  </button>
                  <span>untuk panduan resmi dan pelaporan kendala.</span>
                </div>
              </div>
            </div>
          );
        })()}

        {/* 6. TRACKING PESANAN TAB */}
        {activeTab === 'tracking' && (
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setActiveTab('home')}
                className="p-1 hover:bg-slate-200 rounded-lg cursor-pointer"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <h3 className="font-display font-bold text-lg text-slate-800">Lacak Order</h3>
            </div>

            {/* Input Form Lacak Order - Selalu tersedia untuk melacak pesanan kapan saja */}
            <form 
              onSubmit={(e) => {
                e.preventDefault();
                refreshActiveOrder(trackingOrderId);
              }}
              className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 shadow-sm flex flex-col gap-4"
            >
              <div>
                <h4 className="font-display font-bold text-base text-slate-800">Lacak Status Pesanan Makanan</h4>
                <p className="text-slate-500 text-xs leading-relaxed mt-1">
                  Pantau proses memasak dan pengantaran pesanan secara langsung dengan memasukkan kode order Anda.
                </p>
              </div>
              <div className="flex flex-col gap-1.5">
                <label htmlFor="input-order-code" className="text-xs font-bold text-slate-700">
                  Masukkan Kode Order
                </label>
                <div className="flex flex-col sm:flex-row gap-2">
                  <input
                    id="input-order-code"
                    type="text"
                    value={trackingOrderId}
                    onChange={(e) => {
                      setTrackingOrderId(e.target.value);
                      if (trackingError) setTrackingError(null);
                    }}
                    placeholder="Contoh: TF-20261021-001"
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-mono uppercase focus:outline-none focus:border-rose-500 focus:bg-white transition-colors"
                  />
                  <button
                    type="submit"
                    disabled={trackingLoading}
                    className="px-5 py-3 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow-xs transition-colors shrink-0"
                  >
                    {trackingLoading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Memeriksa...</span>
                      </>
                    ) : (
                      <>
                        <Search className="w-4 h-4" />
                        <span>Lacak Pesanan</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
              {trackingError && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                  <span className="font-medium">{trackingError}</span>
                </div>
              )}
            </form>

            {!activeOrder ? (
              /* Secondary Option: Cari via WhatsApp jika belum ada pesanan aktif */
              <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
                <div>
                  <span className="text-xs font-bold text-slate-700 block">Lupa atau belum memiliki kode order?</span>
                  <span className="text-[11px] text-slate-500">Anda dapat mencari daftar pesanan menggunakan nomor WhatsApp saat checkout.</span>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTab('history')}
                  className="px-3.5 py-2 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer shrink-0"
                >
                  Cari via WhatsApp
                </button>
              </div>
            ) : (
              <div className="flex flex-col gap-4">
                {/* Active Info Header */}
                <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
                  <div className="flex justify-between items-start border-b border-slate-100 pb-3 flex-wrap gap-2">
                    <div className="flex flex-col">
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">NOMOR ORDER KANONIS</span>
                      <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                        <span className="font-mono text-base font-extrabold text-slate-900">
                          #{activeOrder.orderNumber || activeOrder.id}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleCopyCustomerOrderNumber(activeOrder.orderNumber || activeOrder.id)}
                          title="Salin Nomor Order"
                          className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors cursor-pointer"
                        >
                          {copiedTrackingId === (activeOrder.orderNumber || activeOrder.id) ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-600" />
                              <span className="text-emerald-700 font-bold">Disalin</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3 text-slate-500" />
                              <span>Salin No</span>
                            </>
                          )}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleCopyCustomerTrackingLink(activeOrder.orderNumber || activeOrder.id)}
                          title="Salin Tautan Pelacakan"
                          className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-medium bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg transition-colors cursor-pointer"
                        >
                          {copiedCustomerTrackingLink === (activeOrder.orderNumber || activeOrder.id) ? (
                            <>
                              <Check className="w-3 h-3 text-blue-600" />
                              <span className="font-bold">Tautan Disalin</span>
                            </>
                          ) : (
                            <>
                              <Share2 className="w-3 h-3 text-blue-500" />
                              <span>Salin Tautan</span>
                            </>
                          )}
                        </button>
                      </div>

                      {/* Tanggal Pemesanan */}
                      <div className="mt-2 text-xs text-slate-500 flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>
                          Tanggal Pemesanan: <strong className="text-slate-800 font-semibold">
                            {new Date(activeOrder.createdAt).toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' })} • {new Date(activeOrder.createdAt).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} WIB
                          </strong>
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setActiveOrder(null);
                          setTrackingOrderId('');
                          setTrackingError(null);
                        }}
                        className="px-2.5 py-1.5 text-[11px] font-medium text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                        title="Lacak pesanan lainnya"
                      >
                        Lacak Lainnya
                      </button>
                      <button
                        type="button"
                        onClick={() => refreshActiveOrder()}
                        disabled={trackingLoading}
                        className="p-1.5 hover:bg-slate-100 text-slate-500 rounded-lg transition-colors border border-slate-200 shadow-sm cursor-pointer"
                        title="Perbarui Status"
                      >
                        <RefreshCw className={`w-3.5 h-3.5 ${trackingLoading ? 'animate-spin text-rose-600' : ''}`} />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Status Pembayaran Card (Terpisah dari Status Proses) */}
                <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-col gap-2.5">
                  <div className="flex justify-between items-center border-b border-slate-100 pb-2.5">
                    <div className="flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-slate-500" />
                      <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">Status Pembayaran</span>
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                      activeOrder.paymentStatus === PaymentStatus.PAID || [OrderStatus.PAYMENT_VERIFIED, OrderStatus.COOKING, OrderStatus.READY_FOR_PICKUP, OrderStatus.ORDER_PICKED_UP, OrderStatus.DELIVERED, OrderStatus.COMPLETED].includes(activeOrder.status)
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : activeOrder.status === OrderStatus.WAITING_PAYMENT_VERIFICATION
                          ? 'bg-amber-50 text-amber-700 border border-amber-200 animate-pulse'
                          : activeOrder.status === OrderStatus.PAYMENT_REJECTED
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : 'bg-rose-50 text-rose-700 border border-rose-200'
                    }`}>
                      {activeOrder.paymentStatus === PaymentStatus.PAID || [OrderStatus.PAYMENT_VERIFIED, OrderStatus.COOKING, OrderStatus.READY_FOR_PICKUP, OrderStatus.ORDER_PICKED_UP, OrderStatus.DELIVERED, OrderStatus.COMPLETED].includes(activeOrder.status)
                        ? '✓ LUNAS / TERVERIFIKASI'
                        : activeOrder.status === OrderStatus.WAITING_PAYMENT_VERIFICATION
                          ? '⏳ MENUNGGU VERIFIKASI ADMIN'
                          : activeOrder.status === OrderStatus.PAYMENT_REJECTED
                            ? '❌ BUKTI DITOLAK'
                            : '⏳ MENUNGGU PEMBAYARAN QRIS'}
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-500">
                      {activeOrder.paymentStatus === PaymentStatus.PAID || [OrderStatus.PAYMENT_VERIFIED, OrderStatus.COOKING, OrderStatus.READY_FOR_PICKUP, OrderStatus.ORDER_PICKED_UP, OrderStatus.DELIVERED, OrderStatus.COMPLETED].includes(activeOrder.status)
                        ? 'Pembayaran QRIS telah diverifikasi sah oleh Admin.'
                        : activeOrder.status === OrderStatus.WAITING_PAYMENT_VERIFICATION
                          ? 'Bukti transfer sedang diperiksa oleh tim Admin.'
                          : activeOrder.status === OrderStatus.PAYMENT_REJECTED
                            ? 'Bukti pembayaran ditolak. Silakan unggah bukti transfer yang sesuai.'
                            : 'Silakan selesaikan pembayaran QRIS dan unggah bukti transfer.'}
                    </span>
                    <div className="text-right shrink-0 ml-3">
                      <span className="text-[10px] text-slate-400 block">Total Tagihan:</span>
                      <span className="font-mono font-extrabold text-sm text-slate-900">
                        Rp {activeOrder.total.toLocaleString('id-ID')}
                      </span>
                    </div>
                  </div>

                  {([OrderStatus.WAITING_PAYMENT, OrderStatus.WAITING_PAYMENT_VERIFICATION, OrderStatus.PAYMENT_REJECTED].includes(activeOrder.status) && activeOrder.paymentStatus !== PaymentStatus.PAID) && (
                    <button
                      type="button"
                      onClick={() => setActiveTab('payment')}
                      className="mt-1 w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-xs"
                    >
                      <QrCode className="w-3.5 h-3.5" />
                      <span>Buka Halaman Pembayaran QRIS & Bukti</span>
                    </button>
                  )}
                </div>

                {/* Status Proses Pesanan & Estimasi Card (Terpisah dari Status Pembayaran) */}
                <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-col gap-3">
                  <div className="flex justify-between items-center border-b border-slate-100 pb-2.5">
                    <div className="flex items-center gap-2">
                      <Utensils className="w-4 h-4 text-slate-500" />
                      <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">Status Proses Pesanan</span>
                    </div>
                    <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold ${
                      activeOrder.status === OrderStatus.COOKING
                        ? 'bg-amber-50 text-amber-700 border border-amber-200'
                        : activeOrder.status === OrderStatus.READY_FOR_PICKUP
                          ? 'bg-blue-50 text-blue-700 border border-blue-200'
                          : activeOrder.status === OrderStatus.ORDER_PICKED_UP
                            ? 'bg-purple-50 text-purple-700 border border-purple-200'
                            : [OrderStatus.DELIVERED, OrderStatus.COMPLETED].includes(activeOrder.status)
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : activeOrder.status === OrderStatus.CANCELLED
                                ? 'bg-red-50 text-red-700 border border-red-200'
                                : 'bg-slate-100 text-slate-700 border border-slate-200'
                    }`}>
                      {activeOrder.status === OrderStatus.COOKING
                        ? '👨‍🍳 SEDANG DIMASAK'
                        : activeOrder.status === OrderStatus.READY_FOR_PICKUP
                          ? '📦 MAKANAN SIAP DIJEMPUT'
                          : activeOrder.status === OrderStatus.ORDER_PICKED_UP
                            ? '🛵 DALAM PENGANTARAN'
                            : [OrderStatus.DELIVERED, OrderStatus.COMPLETED].includes(activeOrder.status)
                              ? '🎉 PESANAN SELESAI'
                              : activeOrder.status === OrderStatus.CANCELLED
                                ? '❌ DIBATALKAN'
                                : '📝 PESANAN DITERIMA'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs text-slate-600">
                    <div>
                      <span className="text-slate-400 font-medium block">Toko Kuliner:</span>
                      <p className="font-semibold text-slate-800 mt-0.5">{activeOrder.merchantName}</p>
                    </div>
                    <div>
                      <span className="text-slate-400 font-medium block">Estimasi Waktu Memasak:</span>
                      <p className="font-semibold text-amber-700 mt-0.5 flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" />
                        {activeOrder.cookingTimeMinutes ? `${activeOrder.cookingTimeMinutes} menit` : '15-25 menit'}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Status Pengantaran Card */}
                <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-col gap-3">
                  <div className="flex justify-between items-center border-b border-slate-100 pb-2.5">
                    <div className="flex items-center gap-2">
                      <Bike className="w-4 h-4 text-slate-500" />
                      <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">Status Pengantaran</span>
                    </div>
                    <span className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                      {activeOrder.driverName ? `Kurir: ${activeOrder.driverName}` : 'Menunggu Kurir'}
                    </span>
                  </div>

                  <div className="flex flex-col gap-2.5 text-xs text-slate-600">
                    <div>
                      <span className="text-slate-400 font-medium block">Kondisi Pengantaran:</span>
                      <p className="font-semibold text-slate-800 mt-0.5">
                        {activeOrder.status === OrderStatus.ORDER_PICKED_UP
                          ? `Kurir (${activeOrder.driverName || 'Kurir'}) sedang dalam perjalanan membawa pesanan ke alamat Anda.`
                          : activeOrder.status === OrderStatus.READY_FOR_PICKUP
                            ? `Makanan telah siap. Kurir (${activeOrder.driverName || 'Kurir'}) dalam perjalanan menjemput ke toko.`
                            : [OrderStatus.DELIVERED, OrderStatus.COMPLETED].includes(activeOrder.status)
                              ? 'Pesanan telah berhasil diantar ke alamat Anda.'
                              : 'Kurir akan ditugaskan segera setelah toko selesai memasak.'}
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-400 font-medium block">Alamat Tujuan:</span>
                      <p className="font-semibold text-slate-800 mt-0.5">{activeOrder.deliveryAddress}</p>
                      {(activeOrder.landmark || activeOrder.deliveryDetails) && (
                        <p className="text-[11px] text-slate-500 mt-0.5 italic">
                          Patokan: {activeOrder.landmark || activeOrder.deliveryDetails}
                        </p>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-2 pt-1.5 border-t border-slate-50 text-[11px]">
                      <div>
                        <span className="text-slate-400">Penerima:</span>
                        <span className="font-semibold text-slate-800 ml-1">{activeOrder.customerName}</span>
                      </div>
                      <div>
                        <span className="text-slate-400">No WhatsApp:</span>
                        <span className="font-semibold text-slate-800 ml-1">
                          {activeOrder.customerPhoneMasked || (activeOrder.customerPhone ? (activeOrder.customerPhone.includes('****') ? activeOrder.customerPhone : activeOrder.customerPhone.substring(0, 4) + '****' + activeOrder.customerPhone.slice(-3)) : '-')}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Ringkasan Item Pesanan Card */}
                <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-col gap-3">
                  <div className="flex items-center gap-2 border-b border-slate-100 pb-2.5">
                    <ShoppingBag className="w-4 h-4 text-slate-500" />
                    <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">Ringkasan Item Pesanan</span>
                  </div>

                  <div className="flex flex-col divide-y divide-slate-100">
                    {activeOrder.items?.map((item, idx) => (
                      <div key={idx} className="py-2 flex justify-between items-start text-xs">
                        <div className="flex flex-col">
                          <span className="font-semibold text-slate-800">{item.quantity}x {item.name}</span>
                          {item.notes && (
                            <span className="text-[11px] text-slate-400 italic mt-0.5">Catatan: {item.notes}</span>
                          )}
                        </div>
                        <span className="font-mono font-bold text-slate-700 ml-3 shrink-0">
                          Rp {(item.price * item.quantity).toLocaleString('id-ID')}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex flex-col gap-1.5 text-xs">
                    <div className="flex justify-between text-slate-500">
                      <span>Subtotal Menu</span>
                      <span className="font-mono">Rp {activeOrder.subtotal.toLocaleString('id-ID')}</span>
                    </div>
                    <div className="flex justify-between text-slate-500">
                      <span>Ongkir Flat (Kec. Tumpang)</span>
                      <span className="font-mono">Rp {activeOrder.deliveryFee.toLocaleString('id-ID')}</span>
                    </div>
                    <div className="flex justify-between text-slate-500">
                      <span>Biaya Layanan</span>
                      <span className="font-mono">Rp {activeOrder.serviceFee.toLocaleString('id-ID')}</span>
                    </div>
                    {Boolean(activeOrder.uniqueCode) && (
                      <div className="flex justify-between text-slate-500">
                        <span>Kode Unik</span>
                        <span className="font-mono">Rp {activeOrder.uniqueCode}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-sm font-extrabold text-slate-900 pt-1.5 border-t border-slate-200">
                      <span>Total Pembayaran</span>
                      <span className="font-mono text-rose-600">Rp {activeOrder.total.toLocaleString('id-ID')}</span>
                    </div>
                  </div>
                </div>

                {/* Official E-Receipt Banner & Access (Only shown if payment is verified/paid) */}
                {Boolean(
                  activeOrder.paymentStatus === PaymentStatus.PAID || 
                  [OrderStatus.PAYMENT_VERIFIED, OrderStatus.COOKING, OrderStatus.READY_FOR_PICKUP, OrderStatus.ORDER_PICKED_UP, OrderStatus.DELIVERED, OrderStatus.COMPLETED].includes(activeOrder.status)
                ) && (
                  <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-emerald-50 border-2 border-emerald-300 rounded-2xl p-4 shadow-xs flex flex-col gap-3">
                    <div className="flex items-start justify-between border-b border-emerald-200/70 pb-2.5">
                      <div className="flex items-center gap-2.5">
                        <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs shrink-0">
                          <Receipt className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-display font-extrabold text-sm text-emerald-950">E-Receipt Resmi TumpangGo</span>
                            <span className="bg-emerald-600 text-white text-[9px] font-black uppercase px-2 py-0.5 rounded-full tracking-wider">LUNAS</span>
                          </div>
                          <p className="text-[11px] text-emerald-800 font-mono font-medium mt-0.5">
                            No. Bukti: <span className="font-bold">{activeOrder.receiptNumber || activeOrder.receipt?.receiptNumber || `TG-RCP-${(activeOrder.orderNumber || activeOrder.id).replace(/^ord_/, '').replace(/^TF-/, '').toUpperCase()}`}</span>
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs bg-white/90 p-3 rounded-xl border border-emerald-100">
                      <div>
                        <span className="text-slate-400 block text-[10px] font-medium">Status Pembayaran:</span>
                        <span className="font-bold text-emerald-700 flex items-center gap-1 mt-0.5">
                          <ShieldCheck className="w-3.5 h-3.5" /> Terverifikasi Admin
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px] font-medium">Total Pembayaran:</span>
                        <span className="font-bold text-emerald-800 font-mono text-sm mt-0.5 block">
                          Rp {activeOrder.total.toLocaleString('id-ID')}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setShowReceiptModal(true)}
                      className="w-full py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer active:scale-[0.99]"
                    >
                      <Receipt className="w-4 h-4 text-emerald-100" />
                      <span>Lihat & Unduh E-Receipt (PDF)</span>
                    </button>
                  </div>
                )}

                {/* Tracking Progress Steps */}
                <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
                  <h4 className="font-display font-semibold text-sm text-slate-800 border-b border-slate-100 pb-2.5 mb-4">Status Pengantaran</h4>
                  
                  <div className="flex flex-col gap-5 relative pl-4 border-l border-slate-200">
                    
                    {/* Step 1: Menunggu pembayaran */}
                    <div className="relative">
                      <div className={`absolute -left-[21px] top-0.5 w-2.5 h-2.5 rounded-full ring-4 ${
                        activeOrder.status === OrderStatus.WAITING_PAYMENT 
                          ? 'bg-rose-500 ring-rose-100 animate-ping' 
                          : 'bg-emerald-500 ring-emerald-100'
                      }`} />
                      <span className="text-xs font-bold text-slate-800">Pesanan Dibuat</span>
                      <p className="text-[11px] text-slate-500 mt-0.5">Pesanan berhasil dicatat dengan kode unik.</p>
                    </div>

                    {/* Step 2: Menunggu verifikasi */}
                    <div className="relative">
                      <div className={`absolute -left-[21px] top-0.5 w-2.5 h-2.5 rounded-full ring-4 ${
                        [OrderStatus.WAITING_PAYMENT].includes(activeOrder.status) 
                          ? 'bg-slate-200 ring-slate-100' 
                          : activeOrder.status === OrderStatus.WAITING_PAYMENT_VERIFICATION 
                            ? 'bg-rose-500 ring-rose-100' 
                            : 'bg-emerald-500 ring-emerald-100'
                      }`} />
                      <span className="text-xs font-bold text-slate-800">Verifikasi Pembayaran</span>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {activeOrder.status === OrderStatus.WAITING_PAYMENT 
                          ? 'Menunggu unggahan bukti transfer.' 
                          : activeOrder.status === OrderStatus.WAITING_PAYMENT_VERIFICATION 
                            ? 'Admin sedang memverifikasi bukti pembayaran.' 
                            : 'Pembayaran telah dikonfirmasi oleh Admin.'}
                      </p>
                    </div>

                    {/* Step 3: Memasak */}
                    <div className="relative">
                      <div className={`absolute -left-[21px] top-0.5 w-2.5 h-2.5 rounded-full ring-4 ${
                        [OrderStatus.WAITING_PAYMENT, OrderStatus.WAITING_PAYMENT_VERIFICATION, OrderStatus.PAYMENT_REJECTED].includes(activeOrder.status) 
                          ? 'bg-slate-200 ring-slate-100' 
                          : activeOrder.status === OrderStatus.COOKING 
                            ? 'bg-rose-500 ring-rose-100' 
                            : [OrderStatus.PAYMENT_VERIFIED].includes(activeOrder.status)
                              ? 'bg-amber-500 ring-amber-100'
                              : 'bg-emerald-500 ring-emerald-100'
                      }`} />
                      <span className="text-xs font-bold text-slate-800">Diproses Toko</span>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {activeOrder.status === OrderStatus.COOKING ? (() => {
                          const c = calculateRemainingCooking(activeOrder, cookingTickerNow);
                          return (
                            <span>
                              Toko sedang memasak (Estimasi: {c.durationMinutes} menit).{' '}
                              <strong className="font-mono text-slate-800">
                                {c.isExpired ? 'Waktu estimasi tercapai' : `Sisa ${c.formattedRemaining}`}
                              </strong>
                              .{' '}Target selesai pukul {c.estimatedEndTime}.
                            </span>
                          );
                        })()
                          : [OrderStatus.PAYMENT_VERIFIED].includes(activeOrder.status)
                            ? 'Pesanan diteruskan ke toko, menunggu respon...'
                            : [OrderStatus.WAITING_PAYMENT, OrderStatus.WAITING_PAYMENT_VERIFICATION].includes(activeOrder.status)
                              ? 'Menunggu pembayaran selesai.'
                              : 'Toko telah menyelesaikan proses memasak.'}
                      </p>
                    </div>

                    {/* Step 4: Menuju lokasi */}
                    <div className="relative">
                      <div className={`absolute -left-[21px] top-0.5 w-2.5 h-2.5 rounded-full ring-4 ${
                        [OrderStatus.READY_FOR_PICKUP, OrderStatus.ORDER_PICKED_UP].includes(activeOrder.status)
                          ? 'bg-rose-500 ring-rose-100'
                          : [OrderStatus.DELIVERED, OrderStatus.COMPLETED].includes(activeOrder.status)
                            ? 'bg-emerald-500 ring-emerald-100'
                            : 'bg-slate-200 ring-slate-100'
                      }`} />
                      <span className="text-xs font-bold text-slate-800">Pengantaran oleh Kurir</span>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {activeOrder.status === OrderStatus.READY_FOR_PICKUP 
                          ? 'Pesanan siap dijemput. Kurir menuju toko.' 
                          : activeOrder.status === OrderStatus.ORDER_PICKED_UP 
                            ? `Kurir (${activeOrder.driverName || 'Kurir'}) sedang membawa makanan ke lokasi Anda.` 
                            : [OrderStatus.DELIVERED, OrderStatus.COMPLETED].includes(activeOrder.status)
                              ? 'Makanan telah diambil dan diantar oleh kurir.'
                              : 'Menunggu proses memasak selesai.'}
                      </p>
                    </div>

                    {/* Step 5: Sampai */}
                    <div className="relative">
                      <div className={`absolute -left-[21px] top-0.5 w-2.5 h-2.5 rounded-full ring-4 ${
                        [OrderStatus.DELIVERED, OrderStatus.COMPLETED].includes(activeOrder.status)
                          ? 'bg-emerald-500 ring-emerald-100'
                          : 'bg-slate-200 ring-slate-100'
                      }`} />
                      <span className="text-xs font-bold text-slate-800">Pesanan Selesai (Sudah Terkirim)</span>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        {[OrderStatus.DELIVERED, OrderStatus.COMPLETED].includes(activeOrder.status)
                          ? 'Terima kasih, pesanan telah selesai secara otomatis setelah driver mengirimkan bukti pengantaran!' 
                          : 'Menunggu pengantaran kurir.'}
                      </p>
                    </div>
                  </div>

                  {/* Action Link to QRIS Payment Page if not yet finalized */}
                  {([OrderStatus.WAITING_PAYMENT, OrderStatus.WAITING_PAYMENT_VERIFICATION].includes(activeOrder.status) || activeOrder.paymentStatus === PaymentStatus.PENDING) && (
                    <div className="mt-4 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex flex-col gap-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-rose-950 flex items-center gap-1.5">
                          <QrCode className="w-4 h-4 text-rose-600" />
                          {activeOrder.status === OrderStatus.WAITING_PAYMENT_VERIFICATION 
                            ? 'Menunggu Verifikasi Pembayaran' 
                            : 'Pembayaran QRIS Belum Selesai'}
                        </span>
                        <span className="font-bold font-mono text-rose-700">
                          Rp {activeOrder.total.toLocaleString('id-ID')}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setActiveTab('payment')}
                        className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-extrabold rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer"
                      >
                        <QrCode className="w-3.5 h-3.5" />
                        <span>Buka Halaman Pembayaran QRIS & Bukti</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}

                  {/* Terminal / Cancel / Rejections states */}
                  {activeOrder.status === OrderStatus.PAYMENT_REJECTED && (
                    <div className="mt-5 p-3 bg-red-50 border border-red-100 rounded-xl text-xs text-red-800">
                      <span className="font-bold">❌ Pembayaran Ditolak</span>
                      <p className="mt-0.5">Alasan: {activeOrder.cancelReason || 'Bukti transfer tidak sesuai nominal.'}</p>
                      <button 
                        onClick={() => setActiveTab('payment')} 
                        className="mt-2 text-rose-600 font-bold hover:underline"
                      >
                        Kirim Ulang Bukti Pembayaran
                      </button>
                    </div>
                  )}

                  {activeOrder.status === OrderStatus.CANCELLED && (
                    <div className="mt-5 p-3 bg-red-50 border border-red-100 rounded-xl text-xs text-red-800">
                      <span className="font-bold">❌ Pesanan Dibatalkan</span>
                      <p className="mt-0.5">Alasan: {activeOrder.cancelReason || 'Dibatalkan oleh sistem atau toko.'}</p>
                    </div>
                  )}
                </div>
                
                {/* Back to Home */}
                <button
                  onClick={() => {
                    setActiveOrder(null);
                    setTrackingOrderId('');
                    setActiveTab('home');
                  }}
                  className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl text-xs text-center transition-colors"
                >
                  Kembali Belanja
                </button>
              </div>
            )}
          </div>
        )}

        {/* 7. HISTORY TAB */}
        {activeTab === 'history' && (
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setActiveTab('home')}
                className="p-1 hover:bg-slate-200 rounded-lg"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <h3 className="font-display font-bold text-lg text-slate-800">Riwayat Pembelian</h3>
            </div>

            {/* Search History Form */}
            <form onSubmit={searchHistory} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm flex flex-col gap-3">
              <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider">CARI BERDASARKAN NO WHATSAPP</span>
              <div className="flex gap-2">
                <input
                  type="tel"
                  required
                  value={historyPhone}
                  onChange={(e) => setHistoryPhone(e.target.value)}
                  placeholder="Masukkan nomor WhatsApp saat checkout"
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs focus:outline-none focus:border-rose-500"
                />
                <button
                  type="submit"
                  disabled={historyLoading}
                  className="px-5 py-3 bg-rose-600 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1 hover:bg-rose-700 shadow-md shadow-rose-600/10"
                >
                  {historyLoading ? (
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  ) : (
                    'Cari'
                  )}
                </button>
              </div>
            </form>

            {/* History Results */}
            {historySearched && (
              <div className="flex flex-col gap-3 mt-2">
                <div className="flex flex-col gap-0.5">
                  <h4 className="font-display font-semibold text-sm text-slate-700">Ditemukan ({historyOrders.length}) Pesanan</h4>
                  <p className="text-[11px] text-slate-400">Riwayat tersimpan pada perangkat ini demi menjaga privasi data Anda.</p>
                </div>
                
                {historyOrders.length === 0 ? (
                  <div className="text-center py-8 bg-white border border-slate-200 rounded-xl">
                    <ClipboardList className="w-8 h-8 text-slate-300 mx-auto" />
                    <p className="text-slate-400 text-xs mt-2">Belum ada riwayat pesanan untuk nomor ini.</p>
                  </div>
                ) : (
                  <div className="flex flex-col gap-3">
                    {historyOrders.map(o => (
                      <div 
                        key={o.id}
                        onClick={() => {
                          setActiveOrder(o);
                          setTrackingOrderId(o.orderNumber || o.id);
                          setActiveTab('tracking');
                        }}
                        className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm hover:shadow-md transition-all cursor-pointer flex flex-col gap-2"
                      >
                        <div className="flex justify-between items-center text-xs">
                          <span className="font-mono font-bold text-slate-800">#{o.orderNumber || o.id}</span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            o.status === OrderStatus.COMPLETED 
                              ? 'bg-emerald-100 text-emerald-800' 
                              : o.status === OrderStatus.CANCELLED || o.status === OrderStatus.EXPIRED
                                ? 'bg-red-100 text-red-800'
                                : 'bg-amber-100 text-amber-800'
                          }`}>
                            {o.status}
                          </span>
                        </div>

                        <div className="flex justify-between items-end mt-1">
                          <div className="flex flex-col">
                            <h5 className="font-semibold text-slate-800 text-sm leading-snug">{o.merchantName}</h5>
                            <span className="text-[10px] text-slate-400 mt-0.5">{new Date(o.createdAt).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                          </div>
                          <span className="font-display font-bold text-rose-600 text-xs">
                            Rp {o.total.toLocaleString('id-ID')}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* 8. PARTNER REGISTER TAB - PORTAL AKSES MITRA */}
        {activeTab === 'partner-register' && (
          <div className="flex flex-col gap-5 pb-6">
            <PartnerPortalHub
              onBackToHome={() => {
                setActiveTab('home');
                setHomeSubView('main');
                if (typeof window !== 'undefined') {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              }}
              onLoginSuccess={(role, id, email) => {
                if (onSelectRole) {
                  onSelectRole(role, id, 'login', email);
                }
              }}
            />

            {/* Footer Section */}
            {renderFooter('-partner')}
          </div>
        )}

        {/* 9. EDUKASI & PANDUAN DIGITALISASI UMKM TAB */}
        {activeTab === 'edukasi' && (
          <div className="flex flex-col gap-5 pb-6">
            <UmkmEducationModule
              onBackToHome={() => {
                setActiveTab('home');
                setHomeSubView('main');
              }}
              onOpenPartnerRegister={() => {
                setActiveTab('partner-register');
              }}
              onExploreFood={() => {
                setActiveTab('home');
                setHomeSubView('food');
              }}
            />
            {/* Footer Section */}
            {renderFooter('-edukasi')}
          </div>
        )}

        {/* 10. PUSAT BANTUAN TUMPANGGO TAB */}
        {activeTab === 'help' && (
          <div className="flex flex-col gap-5 pb-6">
            <HelpCenterView
              onBack={() => {
                setActiveTab('home');
                setHomeSubView('main');
                if (typeof window !== 'undefined') {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              }}
              onNavigateToPartnerRegister={() => {
                setActiveTab('partner-register');
                if (typeof window !== 'undefined') {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              }}
              onNavigateToTracking={() => {
                setActiveTab('tracking');
                if (typeof window !== 'undefined') {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              }}
            />
            {/* Footer Section */}
            {renderFooter('-help')}
          </div>
        )}
      </main>

      {/* Sticky Bottom Navigation Footer: Khusus Layanan Tumpang Food */}
      {isTumpangFoodFlow && (
        <nav 
          id="tumpang-food-bottom-nav"
          aria-label="Navigasi Layanan Tumpang Food"
          className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-slate-100 px-6 py-2.5 flex justify-between items-center z-[90] shadow-[0_-4px_12px_rgba(0,0,0,0.06)] rounded-t-3xl transition-all duration-300"
        >
          {/* 1. Beranda Layanan Tumpang Food */}
          <button 
            id="nav-home"
            onClick={() => {
              setSelectedMerchant(null);
              setHomeSubView('food');
              setActiveTab('home');
              if (typeof window !== 'undefined') {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }
            }}
            className={`flex flex-col items-center gap-1.5 flex-1 py-1 cursor-pointer transition-all ${
              (activeTab === 'home' || activeTab === 'merchant-detail' || activeTab === 'cart' || activeTab === 'checkout')
                ? 'text-[#EE2737] font-extrabold scale-105' 
                : 'text-slate-400 hover:text-slate-600 font-semibold'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px] tracking-tight">
              Beranda
            </span>
          </button>

          {/* 2. Lacak Order Layanan Tumpang Food */}
          <button 
            id="nav-track-order"
            onClick={() => {
              setActiveTab('tracking');
              if (trackingError) setTrackingError(null);
              if (typeof window !== 'undefined') {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }
            }}
            className={`flex flex-col items-center gap-1.5 flex-1 py-1 cursor-pointer transition-all ${
              (activeTab === 'tracking' || activeTab === 'history' || activeTab === 'payment')
                ? 'text-[#EE2737] font-extrabold scale-105' 
                : 'text-slate-400 hover:text-slate-600 font-semibold'
            }`}
          >
            <Search className="w-5 h-5" />
            <span className="text-[10px] tracking-tight">
              Lacak Order
            </span>
          </button>

          {/* 3. Pendaftaran Kemitraan Layanan Tumpang Food */}
          <button 
            id="nav-partner-register"
            onClick={() => {
              setActiveTab('partner-register');
              if (typeof window !== 'undefined') {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }
            }}
            className={`flex flex-col items-center gap-1.5 flex-1 py-1 cursor-pointer transition-all ${
              activeTab === 'partner-register' 
                ? 'text-[#EE2737] font-extrabold scale-105' 
                : 'text-slate-400 hover:text-slate-600 font-semibold'
            }`}
          >
            <UserPlus className="w-5 h-5" />
            <span className="text-[10px] tracking-tight">
              Mitra TumpangGo
            </span>
            <span className="sr-only">Mitra Tumpang Go</span>
          </button>

          {/* 4. Pusat Bantuan Layanan Tumpang Food */}
          <button 
            id="nav-help-center"
            onClick={() => {
              setActiveTab('help');
              if (typeof window !== 'undefined') {
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }
            }}
            className={`flex flex-col items-center gap-1.5 flex-1 py-1 cursor-pointer transition-all ${
              activeTab === 'help' 
                ? 'text-[#EE2737] font-extrabold scale-105' 
                : 'text-slate-400 hover:text-slate-600 font-semibold'
            }`}
          >
            <HelpCircle className="w-5 h-5" />
            <span className="text-[10px] tracking-tight">
              Bantuan
            </span>
          </button>

          {/* Portal Demo (Only shown when secret portal access is unlocked) */}
          {portalAccessUnlocked && (
            <button 
              id="nav-portal-demo"
              onClick={onOpenAuthModal}
              className="flex flex-col items-center gap-1.5 flex-1 py-1 cursor-pointer transition-all text-amber-600 hover:text-amber-700 font-extrabold hover:scale-105"
            >
              <Key className="w-5 h-5 animate-pulse text-amber-500" />
              <span className="text-[10px] tracking-tight">Portal Demo</span>
            </button>
          )}
        </nav>
      )}

      {/* FLOATING PUSAT BANTUAN BUTTON */}
      {!isTumpangFoodFlow && activeTab !== 'help' && (
        <button
          type="button"
          onClick={handleOpenHelpCenter}
          className="fixed bottom-5 right-4 sm:right-6 z-[95] w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center shadow-lg shadow-emerald-700/30 transition-all hover:scale-110 active:scale-95 group cursor-pointer"
          title="Pusat Bantuan TumpangGo"
          aria-label="Pusat Bantuan TumpangGo"
        >
          <HelpCircle className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
        </button>
      )}

      {/* Lightbox Zoom Modal for QRIS and Payment Proof */}
      {proofZoomModalImage && (
        <div 
          onClick={() => setProofZoomModalImage(null)}
          className="fixed inset-0 z-[120] bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-4 cursor-pointer"
        >
          <div 
            onClick={(e) => e.stopPropagation()} 
            className="relative max-w-lg w-full bg-white rounded-3xl p-4 shadow-2xl overflow-hidden flex flex-col items-center"
          >
            <div className="w-full flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <span className="text-xs font-bold text-slate-800">Pratinjau Gambar</span>
              <button
                type="button"
                onClick={() => setProofZoomModalImage(null)}
                className="p-1 rounded-full hover:bg-slate-100 text-slate-500 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="w-full max-h-[75vh] flex items-center justify-center overflow-auto bg-slate-50 rounded-2xl p-2">
              <img 
                src={proofZoomModalImage} 
                alt="Zoomed" 
                className="max-w-full max-h-[70vh] object-contain rounded-xl"
              />
            </div>
            <button
              type="button"
              onClick={() => setProofZoomModalImage(null)}
              className="mt-3.5 w-full py-2.5 bg-slate-900 text-white font-bold text-xs rounded-xl hover:bg-slate-800 cursor-pointer"
            >
              Tutup
            </button>
          </div>
        </div>
      )}

      {showReceiptModal && activeOrder && (
        <EReceiptModal 
          order={activeOrder} 
          onClose={() => setShowReceiptModal(false)} 
        />
      )}
    </div>
  );
}
